import React, { createContext, useContext, useEffect, useState } from 'react';

export type UILayoutMode = 'calm-steps' | 'labtop' | 'saydaliti-v2' | 'classic';

const STORAGE_KEY = 'pharma_ui_layout_v2';

interface LayoutContextValue {
  layout: UILayoutMode;
  setLayout: (mode: UILayoutMode) => void;
  isCalmSteps: boolean;
  isLabTop: boolean;
  isSplitV2: boolean;
  isClassic: boolean;
}

const LayoutModeContext = createContext<LayoutContextValue>({
  layout: 'calm-steps',
  setLayout: () => {},
  isCalmSteps: true,
  isLabTop: false,
  isSplitV2: false,
  isClassic: false
});

function readStoredLayout(): UILayoutMode {
  try {
    const val = localStorage.getItem(STORAGE_KEY);
    if (val === 'calm-steps' || val === 'labtop' || val === 'saydaliti-v2' || val === 'classic') {
      return val;
    }
  } catch {
    // ignore storage errors
  }
  return 'calm-steps';
}

export function LayoutModeProvider({ children }: { children: React.ReactNode }) {
  const [layout, setLayoutState] = useState<UILayoutMode>(() => readStoredLayout());

  const setLayout = (mode: UILayoutMode) => {
    setLayoutState(mode);
    try {
      localStorage.setItem(STORAGE_KEY, mode);
    } catch {
      // ignore storage errors
    }
  };

  useEffect(() => {
    document.title =
      layout === 'labtop'
        ? 'مخازن LAB top — إدارة المخازن والفواتير'
        : 'صيدليتي — إدارة المخازن والفواتير';
  }, [layout]);

  return (
    <LayoutModeContext.Provider
      value={{
        layout,
        setLayout,
        isCalmSteps: layout === 'calm-steps',
        isLabTop: layout === 'labtop',
        isSplitV2: layout === 'saydaliti-v2',
        isClassic: layout === 'classic'
      }}
    >
      {children}
    </LayoutModeContext.Provider>
  );
}

export function useLayoutMode() {
  return useContext(LayoutModeContext);
}
