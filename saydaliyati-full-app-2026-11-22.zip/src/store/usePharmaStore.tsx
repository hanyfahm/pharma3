import React, { createContext, useContext, useState, useCallback, useEffect, useRef } from 'react';
import type {
  AppDB,
  CompanyInfo,
  CustomerReturn,
  CustomerReturnLine,
  DraftIncoming,
  DraftIssue,
  DraftTransfer,
  Invoice,
  IssueOrder,
  Partner,
  Product,
  TeamMember,
  TransferOrder
} from '../types/pharma';
import { todayISO, uid } from '../utils/format';
import {
  computeNextIssueNo,
  computeNextReturnNo,
  distributeQuantities,
  executePharmaAction,
  makeSeed,
  normalizeDB
} from '../utils/pharmaEngine';
import type { PharmaAction } from '../utils/pharmaEngine';

export { distributeQuantities };

const DB_CACHE_KEY = 'pharma-warehouse-v3-cache';
const MEMBER_NAME_KEY = 'pharma-member-name';
const CLIENT_ID_KEY = 'pharma-client-id';

declare global {
  interface Window {
    __PHARMA_STANDALONE__?: boolean;
    __PHARMA_EMBEDDED_KEY__?: string;
    __PHARMA_EMBEDDED_DB__?: AppDB;
  }
}

function isStandaloneRuntime(): boolean {
  if (typeof window === 'undefined') return false;
  return Boolean(window.__PHARMA_STANDALONE__) || window.location.protocol === 'file:';
}

function getCacheStorageKey(): string {
  if (typeof window !== 'undefined' && window.__PHARMA_EMBEDDED_KEY__) {
    return `pharma-standalone-${window.__PHARMA_EMBEDDED_KEY__}`;
  }
  return DB_CACHE_KEY;
}

function getOrCreateClientId(): string {
  try {
    const existing = sessionStorage.getItem(CLIENT_ID_KEY);
    if (existing) return existing;
    const created = uid('u');
    sessionStorage.setItem(CLIENT_ID_KEY, created);
    return created;
  } catch {
    return uid('u');
  }
}

function getInitialMemberName(): string {
  try {
    const saved = localStorage.getItem(MEMBER_NAME_KEY)?.trim();
    return saved || 'عضو الفريق';
  } catch {
    return 'عضو الفريق';
  }
}

function loadCachedDB(): AppDB {
  const storageKey = getCacheStorageKey();
  try {
    const raw = localStorage.getItem(storageKey);
    if (raw) {
      const parsed = JSON.parse(raw) as AppDB;
      if (parsed && parsed.version === 3 && Array.isArray(parsed.warehouses)) {
        return normalizeDB(parsed);
      }
    }
  } catch {
    // ignore invalid cache
  }
  if (typeof window !== 'undefined' && window.__PHARMA_EMBEDDED_DB__) {
    const embedded = window.__PHARMA_EMBEDDED_DB__;
    if (embedded && embedded.version === 3 && Array.isArray(embedded.warehouses)) {
      return normalizeDB(JSON.parse(JSON.stringify(embedded)) as AppDB);
    }
  }
  return normalizeDB(makeSeed());
}

export interface ToastMessage {
  id: string;
  text: string;
  type: 'ok' | 'warn' | 'err';
}

interface PharmaStoreContextValue {
  db: AppDB;
  dbLoading: boolean;
  memberName: string;
  setMemberName: (name: string) => void;
  activeMembers: TeamMember[];
  toasts: ToastMessage[];
  toast: (text: string, type?: 'ok' | 'warn' | 'err') => void;
  getProduct: (id?: string | null) => Product | undefined;
  getWarehouse: (id?: string | null) => AppDB['warehouses'][number] | undefined;
  getPartner: (id?: string | null) => Partner | undefined;
  availableStock: (productId: string, warehouseId?: string | null) => number;
  totalProductStock: (productId: string, includeExpired?: boolean) => number;
  expiredProductStock: (productId: string) => number;
  nearestExpiry: (productId: string, warehouseId?: string | null) => string | null;
  nextIssueNo: () => string;
  nextReturnNo: () => string;
  returnedStripsFor: (issueId: string, productId: string, batch?: string, expiry?: string) => number;
  issueReturnStats: (issue: IssueOrder) => {
    totalIssued: number;
    totalReturned: number;
    returnedVal: number;
    status: 'none' | 'partial' | 'full';
  };
  saveShares: (shares: Record<string, number>) => Promise<void>;
  addProduct: (data: Omit<Product, 'id'>) => Promise<Product>;
  updateProduct: (id: string, data: Partial<Omit<Product, 'id'>>) => Promise<void>;
  addPartner: (data: Omit<Partner, 'id'>) => Promise<Partner>;
  updatePartner: (id: string, data: Partial<Omit<Partner, 'id'>>) => Promise<void>;
  deletePartner: (id: string) => Promise<void>;
  updateCompany: (data: CompanyInfo) => Promise<void>;
  commitIncomingInvoice: (draft: DraftIncoming) => Promise<Invoice>;
  bulkImportIncoming: (
    rows: { productId: string; units: { name: string; qty: number }[]; strips: number; expiry: string; batch: string }[],
    meta: { no: string; supplierId: string; date: string; mode: 'shares' | 'equal' }
  ) => Promise<Invoice>;
  commitIssueOrder: (draft: DraftIssue) => Promise<IssueOrder>;
  updateIssueOrder: (id: string, draft: DraftIssue) => Promise<IssueOrder>;
  createSalesInvoice: (params: { issueId: string; invoiceNo: string; invoiceDate: string }) => Promise<IssueOrder>;
  setIssueInvoiced: (issueId: string, invoiced: boolean) => Promise<IssueOrder>;
  commitCustomerReturn: (params: {
    issueId: string;
    warehouseId: string;
    date: string;
    reason: string;
    lines: CustomerReturnLine[];
    keptStrips: number;
    returnType: 'full' | 'partial';
  }) => Promise<CustomerReturn>;
  commitTransferOrder: (draft: DraftTransfer) => Promise<TransferOrder>;
  restoreBackup: (jsonText: string) => Promise<void>;
  resetData: () => Promise<void>;
}

const PharmaStoreContext = createContext<PharmaStoreContextValue | null>(null);

export function PharmaStoreProvider({ children }: { children: React.ReactNode }) {
  const [db, setDb] = useState<AppDB>(() => loadCachedDB());
  const [dbLoading, setDbLoading] = useState(() => !isStandaloneRuntime());
  const [memberName, setMemberNameState] = useState<string>(() => getInitialMemberName());
  const [activeMembers, setActiveMembers] = useState<TeamMember[]>([]);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const clientIdRef = useRef<string>(getOrCreateClientId());
  const memberNameRef = useRef<string>(memberName);
  const wsRef = useRef<WebSocket | null>(null);
  const revRef = useRef<number>(0);
  const dbRef = useRef<AppDB>(db);
  const serverAvailableRef = useRef<boolean>(false);

  dbRef.current = db;

  useEffect(() => {
    memberNameRef.current = memberName;
  }, [memberName]);

  useEffect(() => {
    try {
      localStorage.setItem(getCacheStorageKey(), JSON.stringify(db));
    } catch {
      // ignore storage quota errors
    }
  }, [db]);

  const toast = useCallback((text: string, type: 'ok' | 'warn' | 'err' = 'ok') => {
    const id = uid('t');
    setToasts(prev => [...prev, { id, text, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(x => x.id !== id));
    }, 3600);
  }, []);

  const fetchLatestDB = useCallback(async () => {
    if (isStandaloneRuntime()) {
      setDbLoading(false);
      return;
    }
    try {
      const res = await fetch('/api/db', { cache: 'no-store' });
      const ct = res.headers.get('content-type') || '';
      if (!res.ok || !ct.includes('application/json')) {
        serverAvailableRef.current = false;
        return;
      }
      const payload = (await res.json()) as {
        ok?: boolean;
        rev?: number;
        db?: AppDB;
        members?: TeamMember[];
      };
      if (payload.ok && payload.db) {
        serverAvailableRef.current = true;
        revRef.current = typeof payload.rev === 'number' ? payload.rev : revRef.current;
        const normalized = normalizeDB(payload.db);
        dbRef.current = normalized;
        setDb(normalized);
        if (Array.isArray(payload.members)) {
          setActiveMembers(payload.members);
        }
      }
    } catch {
      serverAvailableRef.current = false;
    } finally {
      setDbLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchLatestDB();
  }, [fetchLatestDB]);

  useEffect(() => {
    if (isStandaloneRuntime()) return;
    let cancelled = false;
    let reconnectTimer: number | null = null;
    let pingTimer: number | null = null;
    let attempt = 0;

    const connect = () => {
      if (cancelled) return;
      if (window.location.protocol !== 'http:' && window.location.protocol !== 'https:') return;
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${proto}//${window.location.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => {
        attempt = 0;
        ws.send(
          JSON.stringify({
            type: 'hello',
            clientId: clientIdRef.current,
            name: memberNameRef.current
          })
        );
        if (pingTimer !== null) window.clearInterval(pingTimer);
        pingTimer = window.setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'ping' }));
          }
        }, 20000);
      };

      ws.onmessage = ev => {
        try {
          const msg = JSON.parse(String(ev.data)) as {
            type?: string;
            rev?: number;
            updatedBy?: string;
            clientId?: string;
            summary?: string;
            db?: AppDB;
            members?: TeamMember[];
          };
          if (msg.type === 'welcome') {
            if (Array.isArray(msg.members)) setActiveMembers(msg.members);
            if (typeof msg.rev === 'number' && msg.rev > revRef.current) {
              void fetchLatestDB();
            }
          } else if (msg.type === 'presence:list') {
            if (Array.isArray(msg.members)) setActiveMembers(msg.members);
          } else if (msg.type === 'db:updated' && msg.db) {
            if (typeof msg.rev === 'number' && msg.rev <= revRef.current) return;
            if (typeof msg.rev === 'number') revRef.current = msg.rev;
            setDb(normalizeDB(msg.db));
            if (msg.clientId && msg.clientId !== clientIdRef.current && msg.summary) {
              toast(`${msg.updatedBy || 'عضو الفريق'}: ${msg.summary}`);
            }
          }
        } catch {
          // ignore malformed messages
        }
      };

      ws.onclose = () => {
        if (pingTimer !== null) {
          window.clearInterval(pingTimer);
          pingTimer = null;
        }
        if (cancelled) return;
        const delay = Math.min(5000, 1000 + attempt * 1000);
        attempt += 1;
        reconnectTimer = window.setTimeout(connect, delay);
      };

      ws.onerror = () => {
        try {
          ws.close();
        } catch {
          // ignore
        }
      };
    };

    connect();

    return () => {
      cancelled = true;
      if (reconnectTimer !== null) window.clearTimeout(reconnectTimer);
      if (pingTimer !== null) window.clearInterval(pingTimer);
      if (wsRef.current) {
        try {
          wsRef.current.close();
        } catch {
          // ignore
        }
      }
    };
  }, [fetchLatestDB, toast]);

  const setMemberName = useCallback((name: string) => {
    const clean = name.trim().slice(0, 40) || 'عضو الفريق';
    setMemberNameState(clean);
    memberNameRef.current = clean;
    try {
      localStorage.setItem(MEMBER_NAME_KEY, clean);
    } catch {
      // ignore storage errors
    }
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          type: 'set-name',
          clientId: clientIdRef.current,
          name: clean
        })
      );
    }
  }, []);

  const runLocalAction = useCallback(<T = unknown>(action: PharmaAction): T => {
    const { db: nextDb, result } = executePharmaAction(dbRef.current, action, memberNameRef.current);
    const normalized = normalizeDB(nextDb);
    dbRef.current = normalized;
    setDb(normalized);
    return result as T;
  }, []);

  const sendAction = useCallback(async <T = unknown>(action: PharmaAction): Promise<T> => {
    if (isStandaloneRuntime()) {
      return runLocalAction<T>(action);
    }
    try {
      const res = await fetch('/api/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          actor: memberNameRef.current,
          clientId: clientIdRef.current
        })
      });
      const ct = res.headers.get('content-type') || '';
      if (!ct.includes('application/json')) {
        serverAvailableRef.current = false;
        return runLocalAction<T>(action);
      }
      const payload = (await res.json().catch(() => null)) as {
        ok?: boolean;
        error?: string;
        rev?: number;
        db?: AppDB;
        result?: T;
      } | null;

      if (!res.ok || !payload?.ok || !payload.db) {
        if (res.status >= 400 && res.status < 500 && res.status !== 404 && payload?.error) {
          throw new Error(payload.error);
        }
        serverAvailableRef.current = false;
        return runLocalAction<T>(action);
      }

      serverAvailableRef.current = true;
      if (typeof payload.rev === 'number') {
        revRef.current = payload.rev;
      }
      const normalized = normalizeDB(payload.db);
      dbRef.current = normalized;
      setDb(normalized);
      return payload.result as T;
    } catch (err) {
      if (err instanceof TypeError) {
        serverAvailableRef.current = false;
        return runLocalAction<T>(action);
      }
      throw err;
    }
  }, [runLocalAction]);

  const getProduct = useCallback((id?: string | null) => db.products.find(p => p.id === id), [db.products]);
  const getWarehouse = useCallback((id?: string | null) => db.warehouses.find(w => w.id === id), [db.warehouses]);
  const getPartner = useCallback((id?: string | null) => db.partners.find(p => p.id === id), [db.partners]);

  const availableStock = useCallback(
    (productId: string, warehouseId?: string | null) => {
      const today = todayISO();
      return db.batches
        .filter(b => b.productId === productId && (!warehouseId || b.warehouseId === warehouseId) && b.strips > 0 && b.expiry >= today)
        .reduce((s, b) => s + b.strips, 0);
    },
    [db.batches]
  );

  const totalProductStock = useCallback(
    (productId: string, includeExpired = false) => {
      const today = todayISO();
      return db.batches
        .filter(b => b.productId === productId && b.strips > 0 && (includeExpired || b.expiry >= today))
        .reduce((s, b) => s + b.strips, 0);
    },
    [db.batches]
  );

  const expiredProductStock = useCallback(
    (productId: string) => {
      const today = todayISO();
      return db.batches
        .filter(b => b.productId === productId && b.strips > 0 && b.expiry < today)
        .reduce((s, b) => s + b.strips, 0);
    },
    [db.batches]
  );

  const nearestExpiry = useCallback(
    (productId: string, warehouseId?: string | null) => {
      const today = todayISO();
      const list = db.batches
        .filter(b => b.productId === productId && (!warehouseId || b.warehouseId === warehouseId) && b.strips > 0 && b.expiry >= today)
        .map(b => b.expiry)
        .sort();
      return list[0] || null;
    },
    [db.batches]
  );

  const nextIssueNo = useCallback(() => computeNextIssueNo(db), [db]);
  const nextReturnNo = useCallback(() => computeNextReturnNo(db), [db]);

  const returnedStripsFor = useCallback(
    (issueId: string, productId: string, batch?: string, expiry?: string) => {
      return (db.returns || [])
        .filter(r => r.issueId === issueId)
        .reduce(
          (sum, r) =>
            sum +
            (r.lines || [])
              .filter(l => l.productId === productId && (!batch || l.batch === batch) && (!expiry || l.expiry === expiry))
              .reduce((s, l) => s + (l.strips || 0), 0),
          0
        );
    },
    [db.returns]
  );

  const issueReturnStats = useCallback(
    (issue: IssueOrder) => {
      const totalIssued = (issue.lines || []).reduce((s, l) => s + (l.strips || 0), 0);
      const matching = (db.returns || []).filter(r => r.issueId === issue.id);
      const totalReturned = matching.reduce((s, r) => s + (r.totalStrips || 0), 0);
      const returnedVal = matching.reduce((s, r) => s + (r.totalValue || 0), 0);
      return {
        totalIssued,
        totalReturned,
        returnedVal,
        status: (totalReturned <= 0 ? 'none' : totalReturned >= totalIssued ? 'full' : 'partial') as 'none' | 'partial' | 'full'
      };
    },
    [db.returns]
  );

  const saveShares = useCallback(
    async (shares: Record<string, number>) => {
      await sendAction({ type: 'saveShares', shares });
    },
    [sendAction]
  );

  const addProduct = useCallback(
    async (data: Omit<Product, 'id'>) => sendAction<Product>({ type: 'addProduct', data }),
    [sendAction]
  );

  const updateProduct = useCallback(
    async (id: string, data: Partial<Omit<Product, 'id'>>) => {
      await sendAction({ type: 'updateProduct', id, data });
    },
    [sendAction]
  );

  const addPartner = useCallback(
    async (data: Omit<Partner, 'id'>) => sendAction<Partner>({ type: 'addPartner', data }),
    [sendAction]
  );

  const updatePartner = useCallback(
    async (id: string, data: Partial<Omit<Partner, 'id'>>) => {
      await sendAction({ type: 'updatePartner', id, data });
    },
    [sendAction]
  );

  const deletePartner = useCallback(
    async (id: string) => {
      await sendAction({ type: 'deletePartner', id });
    },
    [sendAction]
  );

  const updateCompany = useCallback(
    async (data: CompanyInfo) => {
      await sendAction({ type: 'updateCompany', data });
    },
    [sendAction]
  );

  const commitIncomingInvoice = useCallback(
    async (draft: DraftIncoming) => sendAction<Invoice>({ type: 'commitIncoming', draft }),
    [sendAction]
  );

  const bulkImportIncoming = useCallback(
    async (
      rows: { productId: string; units: { name: string; qty: number }[]; strips: number; expiry: string; batch: string }[],
      meta: { no: string; supplierId: string; date: string; mode: 'shares' | 'equal' }
    ) => sendAction<Invoice>({ type: 'bulkImportIncoming', rows, meta }),
    [sendAction]
  );

  const commitIssueOrder = useCallback(
    async (draft: DraftIssue) => sendAction<IssueOrder>({ type: 'commitIssue', draft }),
    [sendAction]
  );

  const updateIssueOrder = useCallback(
    async (id: string, draft: DraftIssue) => sendAction<IssueOrder>({ type: 'updateIssue', id, draft }),
    [sendAction]
  );

  const createSalesInvoice = useCallback(
    async (params: { issueId: string; invoiceNo: string; invoiceDate: string }) =>
      sendAction<IssueOrder>({ type: 'createSalesInvoice', ...params }),
    [sendAction]
  );

  const setIssueInvoiced = useCallback(
    async (issueId: string, invoiced: boolean) =>
      sendAction<IssueOrder>({ type: 'setIssueInvoiced', issueId, invoiced }),
    [sendAction]
  );

  const commitCustomerReturn = useCallback(
    async (params: {
      issueId: string;
      warehouseId: string;
      date: string;
      reason: string;
      lines: CustomerReturnLine[];
      keptStrips: number;
      returnType: 'full' | 'partial';
    }) => sendAction<CustomerReturn>({ type: 'commitReturn', params }),
    [sendAction]
  );

  const commitTransferOrder = useCallback(
    async (draft: DraftTransfer) => sendAction<TransferOrder>({ type: 'commitTransfer', draft }),
    [sendAction]
  );

  const restoreBackup = useCallback(
    async (jsonText: string) => {
      await sendAction({ type: 'restoreBackup', jsonText });
    },
    [sendAction]
  );

  const resetData = useCallback(async () => {
    await sendAction({ type: 'resetData' });
  }, [sendAction]);

  return (
    <PharmaStoreContext.Provider
      value={{
        db,
        dbLoading,
        memberName,
        setMemberName,
        activeMembers,
        toasts,
        toast,
        getProduct,
        getWarehouse,
        getPartner,
        availableStock,
        totalProductStock,
        expiredProductStock,
        nearestExpiry,
        nextIssueNo,
        nextReturnNo,
        returnedStripsFor,
        issueReturnStats,
        saveShares,
        addProduct,
        updateProduct,
        addPartner,
        updatePartner,
        deletePartner,
        updateCompany,
        commitIncomingInvoice,
        bulkImportIncoming,
        commitIssueOrder,
        updateIssueOrder,
        createSalesInvoice,
        setIssueInvoiced,
        commitCustomerReturn,
        commitTransferOrder,
        restoreBackup,
        resetData
      }}
    >
      {children}
    </PharmaStoreContext.Provider>
  );
}

export function usePharmaStore() {
  const ctx = useContext(PharmaStoreContext);
  if (!ctx) throw new Error('usePharmaStore must be used within PharmaStoreProvider');
  return ctx;
}
