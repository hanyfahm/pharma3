import React, { useMemo, useState } from 'react';
import { PackageCheck, Search } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import { expiryState, fmtDate, fmtMoney, fmtNum, todayISO, unitsText } from '../utils/format';
import { exportToExcel, exportWarehouseReceiptToWord } from '../utils/export';
import { EmptyState, ExcelButton, ExpiryTag, Modal, PrintButton, WordButton } from './ui/CommonUI';

export function WarehouseReceiptModal({
  warehouseId,
  onSelectWarehouse,
  onClose,
  onPrintHtml
}: {
  warehouseId: string | null;
  onSelectWarehouse: (id: string) => void;
  onClose: () => void;
  onPrintHtml: (html: string) => void;
}) {
  const { db, getWarehouse, getProduct, toast } = usePharmaStore();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'valid' | 'soon' | 'expired'>('all');

  const wh = getWarehouse(warehouseId);

  const batches = useMemo(() => {
    if (!warehouseId) return [];
    const q = search.trim().toLowerCase();
    return db.batches
      .filter(b => b.warehouseId === warehouseId && b.strips > 0)
      .filter(b => {
        const p = getProduct(b.productId);
        if (!p) return false;
        if (q && !`${p.name} ${p.code} ${b.batch} ${p.form}`.toLowerCase().includes(q)) return false;
        const st = expiryState(b.expiry);
        if (statusFilter === 'valid') return st !== 'expired';
        if (statusFilter === 'soon') return st === 'soon';
        if (statusFilter === 'expired') return st === 'expired';
        return true;
      })
      .sort((a, b) => {
        const pa = getProduct(a.productId)?.name || '';
        const pb = getProduct(b.productId)?.name || '';
        return pa.localeCompare(pb, 'ar') || a.expiry.localeCompare(b.expiry);
      });
  }, [warehouseId, db.batches, search, statusFilter, getProduct]);

  if (!warehouseId || !wh) return null;

  const totalStrips = batches.reduce((s, b) => s + b.strips, 0);
  const validStrips = batches.filter(b => expiryState(b.expiry) !== 'expired').reduce((s, b) => s + b.strips, 0);
  const totalValue = batches.reduce((s, b) => {
    const p = getProduct(b.productId);
    return s + (p ? b.strips * (p.price || 0) : 0);
  }, 0);
  const uniqueProducts = new Set(batches.map(b => b.productId)).size;

  const handleExcel = () => {
    const headers = ['م', 'الكود', 'الصنف', 'الشكل', 'التشغيلة (Lot)', 'تاريخ الصلاحية', 'الكمية بالوحدات', 'الرصيد الأساسي', 'الوحدة الأساسية', 'الحالة'];
    const rows = batches.map((b, idx) => {
      const p = getProduct(b.productId)!;
      const st = expiryState(b.expiry);
      return [
        idx + 1,
        p.code,
        p.name,
        p.form || '—',
        b.batch,
        fmtDate(b.expiry),
        unitsText(b.strips, p),
        b.strips,
        p.units[0]?.name || 'وحدة',
        st === 'expired' ? 'منتهي الصلاحية' : st === 'soon' ? 'قارب الانتهاء' : 'ساري'
      ];
    });
    exportToExcel(
      `رصيد_استلام_${wh.name}_${todayISO()}.xlsx`,
      `استلام ${wh.name}`,
      headers,
      rows,
      ['الإجمالي', '', `${uniqueProducts} صنف`, '', `${batches.length} تشغيلة`, '', '', totalStrips, 'وحدة', '']
    );
    toast(`تم تصدير رصيد استلام ${wh.name} إلى Excel`);
  };

  const handleWord = async () => {
    try {
      await exportWarehouseReceiptToWord(wh, batches, db.products, db.company);
      toast(`تم تحميل كشف استلام ${wh.name} بصيغة Word (.docx)`);
    } catch {
      toast('تعذر إنشاء ملف Word', 'err');
    }
  };

  const handlePrint = () => {
    const rowsHtml = batches.map((b, i) => {
      const p = getProduct(b.productId);
      if (!p) return '';
      const st = expiryState(b.expiry);
      return `<tr>
        <td style="text-align:center">${i + 1}</td>
        <td><b>${p.code}</b></td>
        <td><b>${p.name}</b><br><span style="color:#666;font-size:9pt">${p.form || ''}</span></td>
        <td style="text-align:center">${b.batch}</td>
        <td style="text-align:center">${fmtDate(b.expiry)}</td>
        <td><b>${unitsText(b.strips, p)}</b></td>
        <td style="text-align:center">${fmtNum(b.strips)} ${p.units[0]?.name || ''}</td>
        <td style="text-align:center">${st === 'expired' ? 'منتهي' : st === 'soon' ? 'قريب' : 'ساري'}</td>
      </tr>`;
    }).join('');

    onPrintHtml(`
      <div style="font-family:Cairo,Arial,sans-serif;direction:rtl;color:#111">
        <table style="width:100%;border-collapse:collapse;border:2px solid #0b4f4b;margin-bottom:14px">
          <tr>
            <td style="width:34%;padding:8px 10px;border:1px solid #9cc7bf">
              <strong style="font-size:15px;color:#073b39">${db.company.name}</strong><br>
              <span style="font-size:11px">${db.company.address}</span><br>
              <span style="font-size:11px">هاتف: ${db.company.phone}</span>
            </td>
            <td style="width:32%;padding:8px 10px;border:1px solid #9cc7bf;text-align:center;background:#eef8f6">
              <strong style="font-size:15px;color:#073b39">كشف رصيد واستلام مخزن</strong><br>
              <strong style="font-size:13px;color:#0f766e">${wh.name}</strong><br>
              <span style="font-size:11px">محافظة ${wh.gov}</span>
            </td>
            <td style="width:34%;padding:8px 10px;border:1px solid #9cc7bf;font-size:11px">
              <b>تاريخ الجرد/الاستلام:</b> ${fmtDate(todayISO())}<br>
              <b>عدد الأصناف:</b> ${fmtNum(uniqueProducts)} صنف<br>
              <b>عدد التشغيلات:</b> ${fmtNum(batches.length)} لوت<br>
              <b>إجمالي الوحدات:</b> ${fmtNum(totalStrips)} وحدة
            </td>
          </tr>
        </table>
        <table style="width:100%;border-collapse:collapse;font-size:11px">
          <thead>
            <tr style="background:#0f766e;color:#fff">
              <th style="border:1px solid #0b4f4b;padding:6px">م</th>
              <th style="border:1px solid #0b4f4b;padding:6px">الكود</th>
              <th style="border:1px solid #0b4f4b;padding:6px;text-align:right">الصنف</th>
              <th style="border:1px solid #0b4f4b;padding:6px">التشغيلة</th>
              <th style="border:1px solid #0b4f4b;padding:6px">الصلاحية</th>
              <th style="border:1px solid #0b4f4b;padding:6px;text-align:right">الكمية</th>
              <th style="border:1px solid #0b4f4b;padding:6px">الرصيد الأساسي</th>
              <th style="border:1px solid #0b4f4b;padding:6px">الحالة</th>
            </tr>
          </thead>
          <tbody>${rowsHtml}</tbody>
        </table>
        <table style="width:100%;border-collapse:collapse;border:1.5px solid #0b4f4b;margin-top:20px;font-size:11px">
          <tr>
            <td style="width:33%;padding:14px;border:1px solid #9cc7bf;text-align:center"><b>المُسلِّم</b><br><br>....................</td>
            <td style="width:33%;padding:14px;border:1px solid #9cc7bf;text-align:center"><b>تاريخ اليوم</b><br><br>${fmtDate(todayISO())}</td>
            <td style="width:34%;padding:14px;border:1px solid #9cc7bf;text-align:center"><b>أمين المخزن المستلم (التوقيع)</b><br><br>....................</td>
          </tr>
        </table>
      </div>
    `);
  };

  return (
    <Modal
      open={!!warehouseId}
      onClose={onClose}
      wide
      title={`كشف رصيد واستلام — ${wh.name}`}
      subtitle={`محافظة ${wh.gov} · نصيب التوزيع ${wh.share}% · جرد فعلي بتاريخ ${fmtDate(todayISO())}`}
      footer={
        <>
          <ExcelButton onClick={handleExcel} />
          <WordButton onClick={handleWord} label="فتح في Word" />
          <PrintButton onClick={handlePrint} label="طباعة الاستلام" />
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
          >
            إغلاق
          </button>
        </>
      }
    >
      {/* Warehouse switcher */}
      <div className="flex flex-wrap items-center gap-1.5 mb-4 p-1.5 bg-[#f4f8f7] border border-[#dce6e3] rounded-xl">
        {db.warehouses.map(w => (
          <button
            key={w.id}
            type="button"
            onClick={() => onSelectWarehouse(w.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
              w.id === wh.id
                ? 'bg-[#0f766e] text-white shadow-sm'
                : 'text-[#3b5653] hover:bg-white hover:text-[#102523]'
            }`}
          >
            {w.name} ({w.gov})
          </button>
        ))}
      </div>

      {/* Receipt header banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-center bg-[#f6fbfa] border border-[#cde3de] rounded-xl p-4 mb-4">
        <div className="text-xs leading-relaxed">
          <div className="font-extrabold text-sm text-[#073b39]">{db.company.name}</div>
          <div className="text-[#5c7471]">{db.company.address} · هاتف: {db.company.phone}</div>
        </div>
        <div className="text-center md:border-x md:border-dashed md:border-[#b7d6cf] md:px-4">
          <div className="text-[11px] font-bold text-[#0f766e]">سند استلام وجرد رصيد مخزن</div>
          <div className="text-base font-extrabold text-[#102523] mt-0.5">{wh.name}</div>
          <div className="text-[11px] text-[#5c7471] tabular-nums">{fmtDate(todayISO())}</div>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="bg-white border border-[#dce6e3] rounded-lg px-2.5 py-1.5">
            <span className="text-[10.5px] text-[#5c7471] block">الأصناف / التشغيلات</span>
            <strong className="tabular-nums text-[#102523]">{fmtNum(uniqueProducts)} صنف · {fmtNum(batches.length)} لوت</strong>
          </div>
          <div className="bg-white border border-[#dce6e3] rounded-lg px-2.5 py-1.5">
            <span className="text-[10.5px] text-[#5c7471] block">إجمالي الرصيد الساري</span>
            <strong className="tabular-nums text-[#0f766e]">{fmtNum(validStrips)} وحدة</strong>
          </div>
        </div>
      </div>

      {/* Filter toolbar */}
      <div className="flex flex-wrap items-center gap-2.5 mb-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-[#6b8481] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="ابحث داخل المخزن بالكود أو اسم الصنف أو اللوت..."
            className="w-full pr-9 pl-3 py-2 text-xs bg-white border border-[#dce6e3] rounded-lg focus:outline-none focus:border-[#0f766e]"
          />
        </div>
        <div className="flex items-center gap-1 p-1 bg-[#f0f5f4] rounded-lg">
          {(
            [
              ['all', 'الكل'],
              ['valid', 'الساري فقط'],
              ['soon', 'قريب الانتهاء'],
              ['expired', 'المنتهي']
            ] as const
          ).map(([k, lbl]) => (
            <button
              key={k}
              type="button"
              onClick={() => setStatusFilter(k)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-colors whitespace-nowrap cursor-pointer ${
                statusFilter === k ? 'bg-white text-[#102523] shadow-sm' : 'text-[#5c7471] hover:text-[#102523]'
              }`}
            >
              {lbl}
            </button>
          ))}
        </div>
      </div>

      {batches.length ? (
        <div className="overflow-x-auto border border-[#dce6e3] rounded-xl">
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="bg-[#f4f8f7] text-[#5c7471] border-b border-[#dce6e3]">
                <th className="py-2.5 px-3 text-center font-bold">م</th>
                <th className="py-2.5 px-3 text-right font-bold">الكود</th>
                <th className="py-2.5 px-3 text-right font-bold">الصنف والوصف</th>
                <th className="py-2.5 px-3 text-center font-bold">التشغيلة (Lot)</th>
                <th className="py-2.5 px-3 text-center font-bold">تاريخ الصلاحية</th>
                <th className="py-2.5 px-3 text-right font-bold">كمية الاستلام بالوحدات</th>
                <th className="py-2.5 px-3 text-center font-bold">الرصيد الأساسي</th>
                <th className="py-2.5 px-3 text-left font-bold">القيمة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#edf3f1]">
              {batches.map((b, idx) => {
                const p = getProduct(b.productId)!;
                return (
                  <tr key={b.id} className="hover:bg-[#f9fcfb]">
                    <td className="py-2.5 px-3 text-center text-[#5c7471] tabular-nums">{idx + 1}</td>
                    <td className="py-2.5 px-3 font-mono-num font-bold text-[#0f766e]">{p.code}</td>
                    <td className="py-2.5 px-3">
                      <div className="font-bold text-[#102523]">{p.name}</div>
                      <div className="text-[11px] text-[#5c7471]">{p.form}{p.marked ? ' · مستلزمات' : ''}</div>
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono-num font-semibold text-[#3b5653]">{b.batch}</td>
                    <td className="py-2.5 px-3 text-center"><ExpiryTag date={b.expiry} /></td>
                    <td className="py-2.5 px-3 font-bold text-[#102523] tabular-nums">{unitsText(b.strips, p)}</td>
                    <td className="py-2.5 px-3 text-center tabular-nums text-[#3b5653]">
                      {fmtNum(b.strips)} {p.units[0]?.name}
                    </td>
                    <td className="py-2.5 px-3 text-left font-bold tabular-nums text-[#102523]">
                      {fmtMoney(b.strips * (p.price || 0))} ج.م
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="bg-[#f4f8f7] border-t border-[#dce6e3] font-extrabold text-[#102523]">
                <td colSpan={6} className="py-2.5 px-3 text-right">الإجمالي العام للرصيد في {wh.name}</td>
                <td className="py-2.5 px-3 text-center tabular-nums">{fmtNum(totalStrips)} وحدة</td>
                <td className="py-2.5 px-3 text-left tabular-nums text-[#0f766e]">{fmtMoney(totalValue)} ج.م</td>
              </tr>
            </tfoot>
          </table>
        </div>
      ) : (
        <EmptyState
          icon={<PackageCheck className="w-6 h-6" />}
          title="لا توجد أرصدة مطابقة"
          description="لا توجد دفعات تطابق الفلتر الحالي داخل هذا المخزن."
        />
      )}
    </Modal>
  );
}
