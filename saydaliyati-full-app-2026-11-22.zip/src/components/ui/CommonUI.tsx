import React from 'react';
import { FileSpreadsheet, FileText, Printer, X } from 'lucide-react';
import { expiryState, fmtDate } from '../../utils/format';
import type { MovementType } from '../../types/pharma';
import { useLayoutMode } from '../../store/useLayoutMode';

export function PageHeader({
  title,
  subtitle,
  actions
}: {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}) {
  const { isClassic } = useLayoutMode();
  return (
    <div className={`flex flex-wrap items-end justify-between gap-3 ${isClassic ? 'mb-5' : 'mb-3.5'}`}>
      <div>
        <h2 className={`${isClassic ? 'text-xl' : 'text-lg'} font-extrabold text-[#102523] tracking-tight text-balance`}>{title}</h2>
        {subtitle && (
          <p className={`${isClassic ? 'text-[13px]' : 'text-xs'} text-[#5c7471] mt-0.5 max-w-2xl`}>{subtitle}</p>
        )}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function KpiCard({
  label,
  value,
  unit,
  hint,
  icon,
  tone = 'teal'
}: {
  label: string;
  value: string;
  unit?: string;
  hint?: string;
  icon: React.ReactNode;
  tone?: 'teal' | 'blue' | 'amber' | 'violet';
}) {
  const tones = {
    teal: 'bg-[#eef8f6] text-[#0f766e]',
    blue: 'bg-[#eff6ff] text-[#1d4ed8]',
    amber: 'bg-[#fffbeb] text-[#b45309]',
    violet: 'bg-[#f5f3ff] text-[#6d28d9]'
  }[tone];

  return (
    <div className="bg-white border border-[#dce6e3] rounded-xl p-4 flex flex-col justify-between">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-semibold text-[#5c7471]">{label}</span>
        <span className={`w-8 h-8 rounded-lg grid place-items-center shrink-0 ${tones}`}>{icon}</span>
      </div>
      <div className="mt-2.5 text-2xl font-extrabold text-[#102523] tabular-nums leading-tight">
        {value}
        {unit && <span className="text-xs font-semibold text-[#5c7471] mr-1.5">{unit}</span>}
      </div>
      {hint && <div className="mt-1.5 text-[11.5px] text-[#5c7471]">{hint}</div>}
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action
}: {
  icon: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-10 px-4">
      <div className="w-12 h-12 rounded-xl bg-[#eef8f6] text-[#0f766e] grid place-items-center mb-3">
        {icon}
      </div>
      <div className="text-sm font-bold text-[#102523]">{title}</div>
      {description && <p className="text-xs text-[#5c7471] mt-1 max-w-sm leading-relaxed">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function ExpiryTag({ date }: { date?: string | null }) {
  if (!date) return <span className="text-xs text-[#6b8481]">—</span>;
  const st = expiryState(date);
  const cls =
    st === 'expired'
      ? 'text-[#b91c1c] bg-[#fef2f2] border-[#fecaca]'
      : st === 'soon'
        ? 'text-[#b45309] bg-[#fffbeb] border-[#fde68a]'
        : 'text-[#047857] bg-[#ecfdf5] border-[#a7f3d0]';
  const stateLabel = st === 'expired' ? 'منتهي' : st === 'soon' ? 'قريب' : '';
  return (
    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md border text-[11px] font-bold tabular-nums whitespace-nowrap ${cls}`}>
      <span>{fmtDate(date)}</span>
      {stateLabel && <span className="opacity-85">({stateLabel})</span>}
    </span>
  );
}

export const MOVE_LABELS: Record<MovementType, { label: string; cls: string }> = {
  in: { label: 'وارد فاتورة', cls: 'text-[#047857] bg-[#ecfdf5] border-[#a7f3d0]' },
  issue: { label: 'أذن صرف', cls: 'text-[#1d4ed8] bg-[#eff6ff] border-[#bfdbfe]' },
  'return-in': { label: 'مرتجع عميل', cls: 'text-[#6d28d9] bg-[#f5f3ff] border-[#ddd6fe]' },
  'transfer-in': { label: 'تحويل وارد', cls: 'text-[#0f766e] bg-[#eef8f6] border-[#99f6e4]' },
  'transfer-out': { label: 'تحويل صادر', cls: 'text-[#b45309] bg-[#fffbeb] border-[#fde68a]' }
};

export function ExcelButton({ onClick, label = 'تصدير إكسل', small = false }: { onClick: () => void; label?: string; small?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-lg border border-[#a7f3d0] bg-[#ecfdf5] text-[#047857] hover:bg-[#d1fae5] font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
        small ? 'px-2.5 py-1.5 text-[11px]' : 'px-3.5 py-2 text-xs'
      }`}
    >
      <FileSpreadsheet className="w-3.5 h-3.5 shrink-0" />
      <span>{label}</span>
    </button>
  );
}

export function WordButton({ onClick, label = 'فتح في Word', small = false }: { onClick: () => void; label?: string; small?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-lg border border-[#bfdbfe] bg-[#eff6ff] text-[#1d4ed8] hover:bg-[#dbeafe] font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
        small ? 'px-2.5 py-1.5 text-[11px]' : 'px-3.5 py-2 text-xs'
      }`}
    >
      <FileText className="w-3.5 h-3.5 shrink-0" />
      <span>{label}</span>
    </button>
  );
}

export function PrintButton({ onClick, label = 'طباعة', small = false }: { onClick: () => void; label?: string; small?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-lg border border-[#dce6e3] bg-white text-[#233d3a] hover:bg-[#f4f8f7] font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
        small ? 'px-2.5 py-1.5 text-[11px]' : 'px-3.5 py-2 text-xs'
      }`}
    >
      <Printer className="w-3.5 h-3.5 shrink-0" />
      <span>{label}</span>
    </button>
  );
}

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  wide = false,
  footer,
  children
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  wide?: boolean;
  footer?: React.ReactNode;
  children: React.ReactNode;
}) {
  const { isLabTop, isSplitV2 } = useLayoutMode();
  if (!open) return null;

  if (isLabTop) {
    return (
      <div
        className="fixed inset-0 z-50 bg-[#062220]/45 backdrop-blur-[2px] flex justify-end no-print"
        onClick={e => {
          if (e.target === e.currentTarget) onClose();
        }}
      >
        <div
          className={`bg-white border-r border-[#dce6e3] shadow-2xl w-full max-w-full min-w-0 h-[100dvh] flex flex-col ui-compact overflow-hidden ${
            wide ? 'sm:max-w-3xl' : 'sm:max-w-lg'
          }`}
        >
          <div className="flex items-start justify-between gap-3 px-4 py-3 border-b border-[#eaf1ef] bg-[#f8fbfa] shrink-0">
            <div className="min-w-0">
              <h3 className="text-sm font-extrabold text-[#102523] truncate">{title}</h3>
              {subtitle && <p className="text-[11px] text-[#5c7471] mt-0.5 truncate">{subtitle}</p>}
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="إغلاق"
              className="w-8 h-8 rounded-lg border border-[#dce6e3] bg-white text-[#5c7471] hover:text-[#102523] hover:bg-[#f4f8f7] grid place-items-center cursor-pointer shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="p-4 flex-1 overflow-y-auto overflow-x-hidden min-w-0">{children}</div>
          {footer && (
            <div className="px-4 py-3 bg-[#f8fbfa] border-t border-[#eaf1ef] flex flex-wrap items-center justify-end gap-2 shrink-0">
              {footer}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 z-50 bg-[#062220]/50 backdrop-blur-[2px] flex items-start justify-center p-3 sm:p-5 overflow-y-auto no-print"
      onClick={e => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className={`bg-white border border-[#dce6e3] rounded-2xl shadow-2xl w-full my-3 overflow-hidden ${
          isSplitV2 ? 'ui-compact ' : ''
        }${wide ? 'max-w-5xl' : 'max-w-xl'}`}
      >
        <div className={`flex items-start justify-between gap-4 border-b border-[#eaf1ef] ${isSplitV2 ? 'px-4 py-3' : 'px-5 py-4'}`}>
          <div>
            <h3 className={`${isSplitV2 ? 'text-sm' : 'text-base'} font-extrabold text-[#102523]`}>{title}</h3>
            {subtitle && <p className="text-[11.5px] text-[#5c7471] mt-0.5">{subtitle}</p>}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="w-8 h-8 rounded-lg border border-[#dce6e3] bg-white text-[#5c7471] hover:text-[#102523] hover:bg-[#f4f8f7] grid place-items-center cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className={`${isSplitV2 ? 'p-4 max-h-[80vh]' : 'p-5 max-h-[76vh]'} overflow-y-auto`}>{children}</div>
        {footer && (
          <div className={`${isSplitV2 ? 'px-4 py-2.5' : 'px-5 py-3.5'} bg-[#f8fbfa] border-t border-[#eaf1ef] flex flex-wrap items-center justify-end gap-2`}>
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}
