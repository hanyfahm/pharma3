import React, { useEffect, useState } from 'react';
import { Pencil, Plus, Trash2 } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { Product, ProductUnit } from '../types/pharma';
import { expiryState, fmtDate, fmtMoney, fmtNum, normalizeUnits, todayISO, unitLabel, unitsText } from '../utils/format';
import { exportToExcel } from '../utils/export';
import { ExcelButton, ExpiryTag, Modal } from './ui/CommonUI';

export function ProductDetailModal({
  productId,
  onClose,
  onEdit
}: {
  productId: string | null;
  onClose: () => void;
  onEdit: (p: Product) => void;
}) {
  const { db, getProduct, getWarehouse, totalProductStock, expiredProductStock, toast } = usePharmaStore();
  const p = getProduct(productId);
  if (!productId || !p) return null;

  const batches = db.batches
    .filter(b => b.productId === p.id && b.strips > 0)
    .sort((a, b) => a.expiry.localeCompare(b.expiry));
  const active = totalProductStock(p.id);
  const expired = expiredProductStock(p.id);
  const supplier = p.supplierId ? db.partners.find(x => x.id === p.supplierId) : null;

  const handleExcel = () => {
    const headers = ['المخزن', 'المحافظة', 'التشغيلة', 'تاريخ الصلاحية', 'الكمية بالوحدات', 'الرصيد الأساسي', 'القيمة (ج.م)', 'الحالة'];
    const rows = batches.map(b => {
      const w = getWarehouse(b.warehouseId);
      const st = expiryState(b.expiry);
      return [
        w?.name || '—',
        w?.gov || '—',
        b.batch,
        fmtDate(b.expiry),
        unitsText(b.strips, p),
        b.strips,
        Number((b.strips * (p.price || 0)).toFixed(2)),
        st === 'expired' ? 'منتهي' : st === 'soon' ? 'قارب الانتهاء' : 'ساري'
      ];
    });
    exportToExcel(`تفاصيل_صنف_${p.code}_${todayISO()}.xlsx`, p.name, headers, rows);
    toast(`تم تصدير دفعات ${p.name} إلى Excel`);
  };

  return (
    <Modal
      open={!!productId}
      onClose={onClose}
      wide
      title={`${p.name} (${p.code})`}
      subtitle={`${p.form || 'بدون شكل صيدلي'} · ${p.marked ? 'مستلزمات طبية' : 'دواء'} · ${unitLabel(p)}`}
      footer={
        <>
          <ExcelButton onClick={handleExcel} />
          <button
            type="button"
            onClick={() => {
              onClose();
              onEdit(p);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#102523] hover:bg-[#f4f8f7] cursor-pointer"
          >
            <Pencil className="w-3.5 h-3.5" />
            <span>تعديل الصنف</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] cursor-pointer"
          >
            إغلاق
          </button>
        </>
      }
    >
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
        <div className="bg-[#f8fbfa] border border-[#dce6e3] rounded-xl p-3">
          <div className="text-[11px] text-[#5c7471]">المتاح للصرف</div>
          <div className="text-sm font-extrabold text-[#102523] mt-1 tabular-nums">{unitsText(active, p)}</div>
        </div>
        <div className="bg-[#f8fbfa] border border-[#dce6e3] rounded-xl p-3">
          <div className="text-[11px] text-[#5c7471]">منتهي الصلاحية</div>
          <div className={`text-sm font-extrabold mt-1 tabular-nums ${expired > 0 ? 'text-[#dc2626]' : 'text-[#102523]'}`}>
            {expired > 0 ? unitsText(expired, p) : 'لا يوجد'}
          </div>
        </div>
        <div className="bg-[#f8fbfa] border border-[#dce6e3] rounded-xl p-3">
          <div className="text-[11px] text-[#5c7471]">سعر الوحدة الأساسية</div>
          <div className="text-sm font-extrabold text-[#0f766e] mt-1 tabular-nums">
            {fmtMoney(p.price)} ج.م / {p.units[0].name}
          </div>
        </div>
        <div className="bg-[#f8fbfa] border border-[#dce6e3] rounded-xl p-3">
          <div className="text-[11px] text-[#5c7471]">المورّد الافتراضي</div>
          <div className="text-sm font-bold text-[#102523] mt-1 truncate">{supplier?.name || 'غير محدد'}</div>
        </div>
      </div>

      {p.description && (
        <p className="text-xs text-[#3b5653] bg-[#f8fbfa] border border-[#eaf1ef] rounded-lg px-3 py-2 mb-4">
          {p.description}
        </p>
      )}

      <div className="overflow-x-auto border border-[#dce6e3] rounded-xl">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-[#f4f8f7] text-[#5c7471] border-b border-[#dce6e3]">
              <th className="py-2.5 px-3 text-right font-bold">المخزن</th>
              <th className="py-2.5 px-3 text-center font-bold">التشغيلة</th>
              <th className="py-2.5 px-3 text-center font-bold">الصلاحية</th>
              <th className="py-2.5 px-3 text-right font-bold">الكمية</th>
              <th className="py-2.5 px-3 text-left font-bold">القيمة</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#edf3f1]">
            {batches.length ? (
              batches.map(b => {
                const w = getWarehouse(b.warehouseId);
                return (
                  <tr key={b.id} className="hover:bg-[#f9fcfb]">
                    <td className="py-2.5 px-3 font-bold text-[#102523]">
                      {w?.name || '—'} <span className="text-[11px] font-normal text-[#5c7471]">({w?.gov})</span>
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono-num font-semibold text-[#3b5653]">{b.batch}</td>
                    <td className="py-2.5 px-3 text-center"><ExpiryTag date={b.expiry} /></td>
                    <td className="py-2.5 px-3 font-bold tabular-nums">{unitsText(b.strips, p)}</td>
                    <td className="py-2.5 px-3 text-left font-bold tabular-nums">{fmtMoney(b.strips * (p.price || 0))} ج.م</td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={5} className="py-6 text-center text-[#5c7471]">لا توجد دفعات حالية لهذا الصنف.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Modal>
  );
}

export function ProductFormModal({
  open,
  editingProduct,
  onClose
}: {
  open: boolean;
  editingProduct: Product | null;
  onClose: () => void;
}) {
  const { db, addProduct, updateProduct, toast } = usePharmaStore();
  const suppliers = db.partners.filter(p => p.type === 'supplier');

  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [form, setForm] = useState('');
  const [category, setCategory] = useState('دواء');
  const [price, setPrice] = useState('');
  const [supplierId, setSupplierId] = useState('');
  const [marked, setMarked] = useState(false);
  const [units, setUnits] = useState<ProductUnit[]>([
    { name: 'شريط', factor: 1 },
    { name: 'علبة', factor: 2 },
    { name: 'كرتونة', factor: 12 }
  ]);

  useEffect(() => {
    if (!open) return;
    if (editingProduct) {
      setCode(editingProduct.code);
      setName(editingProduct.name);
      setDescription(editingProduct.description || '');
      setForm(editingProduct.form || '');
      setCategory(editingProduct.category || 'دواء');
      setPrice(String(editingProduct.price || 0));
      setSupplierId(editingProduct.supplierId || suppliers[0]?.id || '');
      setMarked(editingProduct.marked);
      setUnits(editingProduct.units.map(u => ({ ...u })));
    } else {
      setCode(`P${String(db.products.length + 1).padStart(3, '0')}`);
      setName('');
      setDescription('');
      setForm('');
      setCategory('دواء');
      setPrice('25');
      setSupplierId(suppliers[0]?.id || '');
      setMarked(false);
      setUnits([
        { name: 'شريط', factor: 1 },
        { name: 'علبة', factor: 2 },
        { name: 'كرتونة', factor: 12 }
      ]);
    }
  }, [open, editingProduct, db.products.length]);

  const handleAddUnit = () => {
    const lastFactor = units[units.length - 1]?.factor || 1;
    setUnits(prev => [...prev, { name: `وحدة ${prev.length + 1}`, factor: lastFactor * 10 }]);
  };

  const handleRemoveUnit = (idx: number) => {
    if (idx === 0 || units.length <= 1) return;
    setUnits(prev => prev.filter((_, i) => i !== idx));
  };

  const handleUnitChange = (idx: number, field: 'name' | 'factor', val: string) => {
    setUnits(prev =>
      prev.map((u, i) => {
        if (i !== idx) return u;
        if (field === 'name') return { ...u, name: val };
        return { ...u, factor: Math.max(1, Math.round(Number(val) || 1)) };
      })
    );
  };

  const previewUnits = normalizeUnits(units);
  const basePrice = Math.max(0, Number(price) || 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast('أدخل اسم الصنف أولًا', 'err');
      return;
    }
    const payload = {
      code: code.trim().toUpperCase() || `P${db.products.length + 1}`,
      name: name.trim(),
      description: description.trim(),
      form: form.trim(),
      category: marked ? 'مستلزمات' : category,
      price: basePrice,
      marked,
      supplierId: supplierId || null,
      units: previewUnits
    };
    if (editingProduct) {
      updateProduct(editingProduct.id, payload);
      toast(`تم تحديث الصنف «${payload.name}»`);
    } else {
      addProduct(payload);
      toast(`تمت إضافة الصنف «${payload.name}»`);
    }
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      wide
      title={editingProduct ? `تعديل الصنف — ${editingProduct.name}` : 'إضافة صنف جديد'}
      subtitle="عرّف بيانات الصنف وهرم الوحدات المتدرج (أساسية ← علبة ← كرتونة)"
      footer={
        <>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
          >
            إلغاء
          </button>
          <button
            type="submit"
            form="product-form"
            className="px-5 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] cursor-pointer"
          >
            {editingProduct ? 'حفظ التعديلات' : 'حفظ الصنف'}
          </button>
        </>
      }
    >
      <form id="product-form" onSubmit={handleSubmit} className="space-y-4">
        <div className="bg-[#f8fbfa] border border-[#dce6e3] rounded-xl p-3">
          <label htmlFor="product-supplier-select" className="block text-xs font-bold text-[#233d3a]">
            اسم الشركة المورّدة
          </label>
          <select
            id="product-supplier-select"
            value={supplierId}
            onChange={e => setSupplierId(e.target.value)}
            className="mt-1.5 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white focus:outline-none focus:border-[#0f766e]"
          >
            <option value="">بدون مورد محدد</option>
            {suppliers.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <label className="block text-xs font-bold text-[#233d3a] min-w-0">
                <span>الكود *</span>
                <input
                  value={code}
                  onChange={e => setCode(e.target.value)}
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] font-mono-num text-xs focus:outline-none focus:border-[#0f766e]"
                  required
                />
              </label>
              <label className="block text-xs font-bold text-[#233d3a] min-w-0">
                <span>اسم الصنف *</span>
                <input
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="مثال: بانادول إكسترا 24 قرص"
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs focus:outline-none focus:border-[#0f766e]"
                  required
                />
              </label>
              <label className="block text-xs font-bold text-[#233d3a] min-w-0">
                <span>الشكل / العبوة</span>
                <input
                  value={form}
                  onChange={e => setForm(e.target.value)}
                  placeholder="أقراص 20 / شراب 120 مل"
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs focus:outline-none focus:border-[#0f766e]"
                />
              </label>
              <label className="block text-xs font-bold text-[#233d3a] min-w-0">
                <span>سعر الوحدة الأساسية (ج.م)</span>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={price}
                  onChange={e => setPrice(e.target.value)}
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs tabular-nums focus:outline-none focus:border-[#0f766e]"
                  required
                />
              </label>
              <label className="block text-xs font-bold text-[#233d3a] col-span-2">
                <span>الوصف / المادة الفعالة</span>
                <input
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="وصف مختصر أو المادة الفعالة"
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs focus:outline-none focus:border-[#0f766e]"
                />
              </label>
            </div>

            <label className="flex items-start gap-2.5 p-3 rounded-xl border border-[#dce6e3] bg-[#f8fbfa] cursor-pointer">
              <input
                type="checkbox"
                checked={marked}
                onChange={e => {
                  setMarked(e.target.checked);
                  setCategory(e.target.checked ? 'مستلزمات' : 'دواء');
                }}
                className="mt-0.5 accent-[#0f766e] w-4 h-4 shrink-0"
              />
              <span className="text-xs text-[#233d3a]">
                <strong className="block">صنف مستلزمات طبية (لا يدخل في قيمة فاتورة العميل)</strong>
                <span className="text-[11px] text-[#5c7471]">يُصرف في إيصال مستلزمات منفصل ولا يُحتسب في إجمالي الفاتورة.</span>
              </span>
            </label>
          </div>

          <div className="border border-[#dce6e3] rounded-xl p-3.5 bg-[#f8fbfa]">
            <div className="flex items-center justify-between gap-2 mb-3">
              <div>
                <div className="text-xs font-extrabold text-[#102523]">هرم الوحدات المتدرج</div>
                <div className="text-[11px] text-[#5c7471]">المستوى الأول هو الوحدة الأساسية (المعامل = 1)، والمستويات الأعلى تُضرب فيها.</div>
              </div>
              <button
                type="button"
                onClick={handleAddUnit}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#eef8f6] text-[#0f766e] border border-[#b7dfd7] text-[11px] font-bold hover:bg-[#dff3ef] cursor-pointer shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة مستوى</span>
              </button>
            </div>

            <div className="space-y-2">
              {units.map((u, idx) => (
                <div key={idx} className="grid grid-cols-12 gap-2 items-center bg-white p-2 rounded-lg border border-[#dce6e3]">
                  <div className="col-span-5">
                    <input
                      type="text"
                      value={u.name}
                      onChange={e => handleUnitChange(idx, 'name', e.target.value)}
                      placeholder="اسم الوحدة (شريط / علبة / كرتونة)"
                      className="w-full px-2.5 py-1.5 rounded-md border border-[#dce6e3] text-xs focus:outline-none focus:border-[#0f766e]"
                    />
                  </div>
                  <div className="col-span-5 flex items-center gap-2">
                    <span className="text-[11px] text-[#5c7471] whitespace-nowrap">المعامل:</span>
                    <input
                      type="number"
                      min={1}
                      value={idx === 0 ? 1 : u.factor}
                      disabled={idx === 0}
                      onChange={e => handleUnitChange(idx, 'factor', e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-md border border-[#dce6e3] text-xs tabular-nums disabled:bg-[#f4f8f7] focus:outline-none focus:border-[#0f766e]"
                    />
                  </div>
                  <div className="col-span-2 flex justify-end">
                    {idx === 0 ? (
                      <span className="text-[10.5px] font-bold text-[#0f766e]">أساسية</span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleRemoveUnit(idx)}
                        className="w-7 h-7 rounded-md border border-[#fecaca] text-[#dc2626] hover:bg-[#fef2f2] grid place-items-center cursor-pointer"
                        title="حذف المستوى"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-3 text-[11.5px] text-[#233d3a] bg-white border border-[#dce6e3] rounded-lg px-3 py-2">
              <b>معاينة الأسعار والتحويل: </b>
              {previewUnits.map((u, i) => (
                <span key={i} className="inline-block ml-3 tabular-nums">
                  {u.name} ({fmtNum(u.factor)} {previewUnits[0].name}) = <b>{fmtMoney(basePrice * u.factor)} ج.م</b>
                </span>
              ))}
            </div>
          </div>
        </div>
      </form>
    </Modal>
  );
}
