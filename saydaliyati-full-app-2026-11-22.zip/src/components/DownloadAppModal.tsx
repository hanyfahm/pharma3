import React, { useState } from 'react';
import { Archive, Download, FileCode2, FileJson, Globe, Loader2 } from 'lucide-react';
import { Modal } from './ui/CommonUI';
import { usePharmaStore } from '../store/usePharmaStore';
import {
  downloadFullAppZIP,
  downloadStandaloneAppHTML,
  exportBackupJSON,
  exportFullHTMLCopy
} from '../utils/export';

export function DownloadAppModal({
  open,
  onClose
}: {
  open: boolean;
  onClose: () => void;
}) {
  const { db, toast } = usePharmaStore();
  const [busyMode, setBusyMode] = useState<'html' | 'zip' | null>(null);
  const isOfflineStandalone =
    typeof window !== 'undefined' &&
    (Boolean(window.__PHARMA_STANDALONE__) || window.location.protocol === 'file:');

  const handleDownloadStandaloneHtml = async () => {
    setBusyMode('html');
    try {
      await downloadStandaloneAppHTML(db);
      toast('تم تحميل التطبيق كله كملف HTML مستقل يعمل بدون إنترنت');
    } catch (err) {
      toast(err instanceof Error ? err.message : 'تعذر تجهيز ملف التطبيق المستقل', 'err');
    } finally {
      setBusyMode(null);
    }
  };

  const handleDownloadZip = async () => {
    setBusyMode('zip');
    try {
      await downloadFullAppZIP();
      toast('تم تحميل حزمة المشروع الكاملة (ZIP) بنجاح');
    } catch (err) {
      toast(err instanceof Error ? err.message : 'تعذر تحميل ملف المشروع المضغوط', 'err');
    } finally {
      setBusyMode(null);
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="تحميل التطبيق كله"
      subtitle="احصل على نسخة كاملة من نظام صيدليتي بجميع الشاشات والتقارير والبيانات الحالية"
      wide
      footer={
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] cursor-pointer"
        >
          إغلاق
        </button>
      }
    >
      <div className="space-y-4">
        {/* Option 1: Standalone Single-File Interactive App */}
        <div className="rounded-xl border-2 border-[#0f766e]/35 bg-[#eef8f6] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-[#0f766e] text-white grid place-items-center shrink-0">
                <Globe className="w-4 h-4" />
              </span>
              <div>
                <h3 className="text-sm font-extrabold text-[#073b39]">
                  التطبيق الكامل في ملف واحد (HTML تشغيلي)
                </h3>
                <p className="text-[11px] font-bold text-[#0f766e]">
                  الأسهل للاستخدام المباشر بدون تثبيت أو إنترنت
                </p>
              </div>
            </div>
            <p className="text-xs text-[#233d3a] leading-relaxed pt-1">
              ملف واحد تفتحه بالضغط المزدوج على الكمبيوتر أو الموبايل ليفتح التطبيق بالكامل (كل الشاشات، Word، Excel، الطباعة) مدمجًا بداخله بياناتك الحالية ويحفظ تعديلاتك تلقائيًا.
            </p>
          </div>
          <button
            type="button"
            disabled={busyMode !== null}
            onClick={handleDownloadStandaloneHtml}
            className="shrink-0 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#0f766e] hover:bg-[#0d655e] disabled:opacity-60 text-white text-xs font-extrabold cursor-pointer whitespace-nowrap shadow-sm"
          >
            {busyMode === 'html' ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>جاري التجهيز...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>تنزيل التطبيق (.html)</span>
              </>
            )}
          </button>
        </div>

        {/* Option 2: Full Project ZIP */}
        <div className="rounded-xl border border-[#dce6e3] bg-white p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-[#102523] text-white grid place-items-center shrink-0">
                <Archive className="w-4 h-4" />
              </span>
              <div>
                <h3 className="text-sm font-extrabold text-[#102523]">
                  حزمة المشروع والكود المصدري الكامل (ZIP)
                </h3>
                <p className="text-[11px] font-bold text-[#5c7471]">
                  للتشغيل المحلي على جهازك أو الشبكة الداخلية عبر Node.js
                </p>
              </div>
            </div>
            <p className="text-xs text-[#3b5653] leading-relaxed pt-1">
              يشمل جميع ملفات المصدر، الخادم المشترك، قاعدة البيانات الحالية، وملف تشغيل جاهز لويندوز (<span className="font-mono-num">تشغيل_التطبيق_ويندوز.bat</span>).
            </p>
          </div>
          <button
            type="button"
            disabled={busyMode !== null || isOfflineStandalone}
            onClick={handleDownloadZip}
            className="shrink-0 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#102523] hover:bg-[#1a3835] disabled:opacity-50 text-white text-xs font-extrabold cursor-pointer whitespace-nowrap"
          >
            {busyMode === 'zip' ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>جاري الضغط...</span>
              </>
            ) : (
              <>
                <Archive className="w-4 h-4" />
                <span>تنزيل المشروع (.zip)</span>
              </>
            )}
          </button>
        </div>

        {/* Quick secondary exports */}
        <div className="pt-2 border-t border-[#eaf1ef] grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => {
              exportFullHTMLCopy(db);
              toast('تم تنزيل تقرير البيانات HTML');
            }}
            className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl border border-[#dce6e3] bg-[#f8fbfa] hover:bg-[#eef8f6] text-right cursor-pointer"
          >
            <FileCode2 className="w-4 h-4 text-[#0f766e] shrink-0" />
            <div>
              <div className="text-xs font-bold text-[#102523]">تقرير البيانات HTML للطباعة</div>
              <div className="text-[11px] text-[#5c7471]">نسخة قراءة وطباعة للجداول الحالية</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => {
              exportBackupJSON(db);
              toast('تم تحميل النسخة الاحتياطية JSON');
            }}
            className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl border border-[#dce6e3] bg-[#f8fbfa] hover:bg-[#eef8f6] text-right cursor-pointer"
          >
            <FileJson className="w-4 h-4 text-[#0f766e] shrink-0" />
            <div>
              <div className="text-xs font-bold text-[#102523]">نسخة احتياطية للبيانات (JSON)</div>
              <div className="text-[11px] text-[#5c7471]">لحفظ أو استعادة قاعدة البيانات لاحقًا</div>
            </div>
          </button>
        </div>
      </div>
    </Modal>
  );
}
