import React, { useEffect, useMemo, useState } from 'react';
import { Check, FilePlus2, Lock, Receipt, Search } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { IssueOrder } from '../types/pharma';
import {
  calc14Percent,
  calcIssueValue,
  calcTotalWith14,
  fmtDate,
  fmtMoney,
  fmtNum,
  isLineReceipt,
  resolveIssueCustomer,
  tafqeetEGP,
  todayISO,
  unitsText
} from '../utils/format';
import { computeNextSalesInvoiceNo, findDuplicateInvoiceNo } from '../utils/pharmaEngine';
import { Modal } from './ui/CommonUI';

export function CreateSalesInvoiceModal({
  open,
  preselectedIssueId,
  onClose,
  onCreated,
  onGoCreateIssue
}: {
  open: boolean;
  preselectedIssueId?: string | null;
  onClose: () => void;
  onCreated: (updatedIssue: IssueOrder) => void;
  onGoCreateIssue: () => void;
}) {
  const { db, getProduct, getWarehouse, createSalesInvoice, setIssueInvoiced, toast } = usePharmaStore();

  const [search, setSearch] = useState('');
  const [selectedIssueId, setSelectedIssueId] = useState<string>('');
  const [invoiceNo, setInvoiceNo] = useState('');
  const [invoiceDate, setInvoiceDate] = useState(todayISO());
  const [submitting, setSubmitting] = useState(false);

  const openIssues = useMemo(() => {
    return (db.issues || []).filter(i => !i.closed && !i.invoiced);
  }, [db.issues]);

  const openBillableIssues = useMemo(() => {
    return openIssues.filter(i => {
      const hasBillable = (i.lines || []).some(l => !isLineReceipt(l, getProduct(l.productId)));
      return hasBillable && calcIssueValue(i, db.products) > 0;
    });
  }, [openIssues, db.products, getProduct]);

  const filteredOpenIssues = useMemo(() => {
    const q = search.trim().toLowerCase();
    return openIssues.filter(i => {
      if (!q) return true;
      const itemsText = (i.lines || [])
        .map(l => {
          const p = getProduct(l.productId);
          return p ? `${p.code} ${p.name}` : '';
        })
        .join(' ');
      const whName = getWarehouse(i.warehouseId)?.name || '';
      return `${i.no} ${i.customer} ${whName} ${itemsText}`.toLowerCase().includes(q);
    });
  }, [openIssues, search, getProduct, getWarehouse]);

  useEffect(() => {
    if (!open) return;
    setSearch('');
    setInvoiceDate(todayISO());
    setInvoiceNo(computeNextSalesInvoiceNo(db));
    if (preselectedIssueId && openIssues.some(i => i.id === preselectedIssueId)) {
      setSelectedIssueId(preselectedIssueId);
    } else if (openBillableIssues.length > 0) {
      setSelectedIssueId(openBillableIssues[0].id);
    } else if (openIssues.length > 0) {
      setSelectedIssueId(openIssues[0].id);
    } else {
      setSelectedIssueId('');
    }
  }, [open, preselectedIssueId]);

  // Keep selection valid if an open issue is closed via inline checkbox
  useEffect(() => {
    if (!open) return;
    if (selectedIssueId && !openIssues.some(i => i.id === selectedIssueId)) {
      const next = openBillableIssues[0] || openIssues[0];
      setSelectedIssueId(next?.id || '');
    }
  }, [open, openIssues, openBillableIssues, selectedIssueId]);

  const selectedIssue = useMemo(
    () => openIssues.find(i => i.id === selectedIssueId) || null,
    [openIssues, selectedIssueId]
  );

  const selectedBillableLines = useMemo(() => {
    if (!selectedIssue) return [];
    return (selectedIssue.lines || []).filter(l => !isLineReceipt(l, getProduct(l.productId)));
  }, [selectedIssue, getProduct]);

  const selectedBaseVal = selectedIssue ? calcIssueValue(selectedIssue, db.products) : 0;
  const selectedVal14 = calc14Percent(selectedBaseVal);
  const selectedGrandTotal = calcTotalWith14(selectedBaseVal);
  const selectedCustomerInfo = selectedIssue ? resolveIssueCustomer(selectedIssue, db.partners) : null;
  const dupInvoice = selectedIssue ? findDuplicateInvoiceNo(db, invoiceNo, selectedIssue.id) : null;
  const isSelectedReceiptOnly = Boolean(selectedIssue && selectedBillableLines.length === 0);

  const handleToggleCheckboxOnOpen = async (iss: IssueOrder) => {
    try {
      await setIssueInvoiced(iss.id, true);
      toast(`تم التعليم على أذن الصرف ${iss.no} بأنه تم عمل فاتورة وإغلاقه (لا يحتاج فاتورة مبيعات)`);
    } catch (err) {
      toast(err instanceof Error ? err.message : 'تعذر تحديث حالة الأذن', 'err');
    }
  };

  const handleConfirm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedIssue) {
      toast('اختر أذن صرف مفتوحًا أولًا', 'err');
      return;
    }
    if (isSelectedReceiptOnly) {
      toast('هذا الأذن يحتوي على إيصالات فقط — يمكنك التعليم عليه بـ «تم عمل فاتورة» لإغلاقه', 'err');
      return;
    }
    if (!invoiceNo.trim()) {
      toast('أدخل رقم فاتورة المبيعات', 'err');
      return;
    }
    if (dupInvoice) {
      toast(
        `رقم الفاتورة «${invoiceNo.trim()}» مستخدم بالفعل (${dupInvoice.source === 'incoming' ? `فاتورة وارد ${dupInvoice.ref}` : `أذن صرف ${dupInvoice.ref}`}) — لا يصح التكرار`,
        'err'
      );
      return;
    }
    setSubmitting(true);
    try {
      const updated = await createSalesInvoice({
        issueId: selectedIssue.id,
        invoiceNo: invoiceNo.trim(),
        invoiceDate: invoiceDate || todayISO()
      });
      toast(`تم إصدار فاتورة المبيعات ${updated.invoiceNo} وإغلاق أذن الصرف ${updated.no}`);
      onClose();
      onCreated(updated);
    } catch (err) {
      toast(err instanceof Error ? err.message : 'تعذر إنشاء الفاتورة', 'err');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      wide
      title="عمل فاتورة مبيعات من أذن صرف"
      subtitle="اختر أذن الصرف المفتوح الذي تريد إصدار الفاتورة منه، وبعد الاعتماد يُغلق أذن الصرف تلقائيًا"
      footer={
        <>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] cursor-pointer"
          >
            إلغاء
          </button>
          <button
            type="submit"
            form="create-sales-invoice-form"
            disabled={!selectedIssue || isSelectedReceiptOnly || Boolean(dupInvoice) || !invoiceNo.trim() || submitting}
            className="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-extrabold hover:bg-[#0d655e] disabled:opacity-45 cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>اعتماد الفاتورة وإغلاق أذن الصرف</span>
          </button>
        </>
      }
    >
      {openIssues.length === 0 ? (
        <div className="py-8 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-[#eef8f6] text-[#0f766e] grid place-items-center mx-auto">
            <Receipt className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <div className="text-sm font-extrabold text-[#102523]">لا توجد أذون صرف مفتوحة بانتظار عمل فاتورة</div>
            <p className="text-xs text-[#5c7471] max-w-md mx-auto">
              جميع أذون الصرف المسجلة إما تم إصدار فواتيرها وإغلاقها أو تم التعليم عليها بأنها «تم عمل فاتورة».
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              onClose();
              onGoCreateIssue();
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] cursor-pointer"
          >
            <FilePlus2 className="w-4 h-4" />
            <span>إنشاء أذن صرف جديد</span>
          </button>
        </div>
      ) : (
        <form id="create-sales-invoice-form" onSubmit={handleConfirm} className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
          {/* Right 6 cols: Select Open Issue Order */}
          <div className="lg:col-span-6 border border-[#dce6e3] rounded-xl overflow-hidden bg-white">
            <div className="p-3 border-b border-[#edf3f1] bg-[#f8fbfa] space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-extrabold text-[#102523]">
                  ١) اختر أذن الصرف ({fmtNum(filteredOpenIssues.length)} مفتوح)
                </span>
                <span className="text-[10.5px] text-[#5c7471]">المغلق لا يظهر هنا</span>
              </div>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-[#6b8481] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="بحث برقم الأذن، العميل، المخزن أو الصنف..."
                  className="w-full pr-8 pl-2.5 py-1.5 text-xs bg-white border border-[#dce6e3] rounded-lg focus:outline-none focus:border-[#0f766e]"
                />
              </div>
            </div>

            <div className="max-h-[380px] overflow-y-auto divide-y divide-[#edf3f1]">
              {filteredOpenIssues.length ? (
                filteredOpenIssues.map(iss => {
                  const selected = iss.id === selectedIssueId;
                  const val = calcIssueValue(iss, db.products);
                  const grand = calcTotalWith14(val);
                  const billableCount = (iss.lines || []).filter(l => !isLineReceipt(l, getProduct(l.productId))).length;
                  const whName = getWarehouse(iss.warehouseId)?.name || '—';

                  return (
                    <div
                      key={iss.id}
                      onClick={() => setSelectedIssueId(iss.id)}
                      className={`p-3 cursor-pointer transition-colors space-y-2 ${
                        selected ? 'bg-[#eef8f6]/80 border-r-4 border-r-[#0f766e]' : 'hover:bg-[#f9fcfb]'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2 min-w-0">
                          <input
                            type="radio"
                            name="selectedIssueOrder"
                            checked={selected}
                            onChange={() => setSelectedIssueId(iss.id)}
                            className="mt-1 accent-[#0f766e] cursor-pointer shrink-0"
                          />
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span className="font-mono-num text-xs font-extrabold text-[#0f766e]">{iss.no}</span>
                              <span className="text-[10.5px] text-[#5c7471]">{fmtDate(iss.date)}</span>
                            </div>
                            <div className="text-xs font-bold text-[#102523] truncate mt-0.5">{iss.customer}</div>
                            <div className="text-[11px] text-[#5c7471]">
                              {whName} · {billableCount > 0 ? `${fmtNum(billableCount)} بند فاتورة` : 'إيصالات بدون قيمة فقط'}
                            </div>
                          </div>
                        </div>
                        <div className="text-left shrink-0 tabular-nums">
                          {val > 0 ? (
                            <>
                              <div className="text-xs font-extrabold text-[#0f766e]">{fmtMoney(grand)} ج.م</div>
                              <div className="text-[10px] text-[#5c7471]">شامل 14%</div>
                            </>
                          ) : (
                            <span className="text-[10.5px] font-bold text-[#b45309]">بدون فاتورة</span>
                          )}
                        </div>
                      </div>

                      <div
                        className="pt-1.5 border-t border-[#e5efec]/70 flex items-center justify-between gap-2"
                        onClick={e => e.stopPropagation()}
                      >
                        <label className="inline-flex items-center gap-1.5 text-[11px] font-bold text-[#3b5653] cursor-pointer select-none">
                          <input
                            type="checkbox"
                            checked={false}
                            onChange={() => handleToggleCheckboxOnOpen(iss)}
                            className="accent-[#0f766e] w-3.5 h-3.5 cursor-pointer"
                          />
                          <span>تم عمل فاتورة له (إغلاق ولا يحتاج فاتورة مبيعات)</span>
                        </label>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="p-6 text-center text-xs text-[#5c7471]">لا توجد أذون مطابقة لعبارة البحث.</div>
              )}
            </div>
          </div>

          {/* Left 6 cols: Selected Issue Preview & Invoice Number */}
          <div className="lg:col-span-6 space-y-3">
            {selectedIssue ? (
              <>
                <div className="border border-[#dce6e3] rounded-xl p-3.5 bg-[#f8fbfa] space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-extrabold text-[#102523]">٢) بيانات الفاتورة للأذن {selectedIssue.no}</span>
                    <span className="inline-flex items-center gap-1 text-[10.5px] font-bold text-[#0f766e]">
                      <Lock className="w-3 h-3" />
                      <span>سيُغلق الأذن بعد الاعتماد</span>
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <label className="block text-xs font-bold text-[#233d3a]">
                      <span>رقم فاتورة المبيعات * (غير مكرر)</span>
                      <input
                        value={invoiceNo}
                        onChange={e => setInvoiceNo(e.target.value)}
                        required
                        className={`mt-1 w-full px-3 py-2 rounded-lg border font-mono-num font-bold text-xs bg-white ${
                          dupInvoice ? 'border-[#dc2626] bg-[#fef2f2] text-[#b91c1c]' : 'border-[#dce6e3]'
                        }`}
                      />
                      {dupInvoice && (
                        <span className="block mt-1 text-[10.5px] font-bold text-[#dc2626]">
                          رقم الفاتورة مستخدم بالفعل — ممنوع التكرار
                        </span>
                      )}
                    </label>
                    <label className="block text-xs font-bold text-[#233d3a]">
                      <span>تاريخ الفاتورة</span>
                      <input
                        type="date"
                        value={invoiceDate}
                        onChange={e => setInvoiceDate(e.target.value)}
                        className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs"
                      />
                    </label>
                  </div>

                  {selectedCustomerInfo && (
                    <div className="text-[11px] text-[#3b5653] bg-white border border-[#e5efec] rounded-lg px-3 py-2 space-y-0.5">
                      <div>
                        <b className="text-[#073b39]">العميل:</b> <b>{selectedCustomerInfo.name}</b>
                        {selectedCustomerInfo.code && <span className="font-mono-num text-[#0f766e] mr-1">({selectedCustomerInfo.code})</span>}
                      </div>
                      {(selectedCustomerInfo.phone || selectedCustomerInfo.taxNo) && (
                        <div className="text-[#5c7471]">
                          {[selectedCustomerInfo.phone && `هاتف: ${selectedCustomerInfo.phone}`, selectedCustomerInfo.taxNo && `ضريبي: ${selectedCustomerInfo.taxNo}`]
                            .filter(Boolean)
                            .join(' · ')}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {isSelectedReceiptOnly ? (
                  <div className="p-4 rounded-xl border border-[#fde68a] bg-[#fffbeb] text-xs text-[#92400e] space-y-2">
                    <div className="font-extrabold">هذا الأذن لا يحتوي على أصناف فاتورة مسعّرة</div>
                    <p className="text-[11px]">
                      جميع بنوده مصروفة بإيصالات (مستلزمات أو هدايا بدون قيمة). يمكنك التعليم على خيار «تم عمل فاتورة له» لإغلاقه مباشرة دون إصدار فاتورة مبيعات.
                    </p>
                  </div>
                ) : (
                  <div className="border border-[#dce6e3] rounded-xl overflow-hidden bg-white">
                    <div className="max-h-[210px] overflow-x-auto overflow-y-auto">
                      <table className="w-full text-[11.5px] border-collapse">
                        <thead>
                          <tr className="bg-[#f4f8f7] text-[#5c7471] border-b border-[#dce6e3]">
                            <th className="py-2 px-3 text-right font-bold">الصنف</th>
                            <th className="py-2 px-3 text-right font-bold">الكمية</th>
                            <th className="py-2 px-3 text-left font-bold">السعر</th>
                            <th className="py-2 px-3 text-left font-bold">الإجمالي</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#edf3f1]">
                          {selectedBillableLines.map((l, idx) => {
                            const p = getProduct(l.productId);
                            if (!p) return null;
                            const price = l.pricePerStrip || p.price || 0;
                            return (
                              <tr key={idx}>
                                <td className="py-2 px-3 font-bold text-[#102523]">{p.name}</td>
                                <td className="py-2 px-3 tabular-nums">{unitsText(l.strips, p)}</td>
                                <td className="py-2 px-3 text-left tabular-nums">{fmtMoney(price)}</td>
                                <td className="py-2 px-3 text-left font-bold tabular-nums">{fmtMoney(l.strips * price)} ج.م</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>

                    <div className="border-t border-[#dce6e3] text-xs divide-y divide-[#edf3f1]">
                      <div className="flex justify-between px-3 py-2 bg-white">
                        <span className="text-[#5c7471] font-bold">القيمة الأساسية</span>
                        <span className="font-bold tabular-nums">{fmtMoney(selectedBaseVal)} ج.م</span>
                      </div>
                      <div className="flex justify-between px-3 py-2 bg-[#f8fbfa]">
                        <span className="text-[#073b39] font-bold">قيمة 14%</span>
                        <span className="font-extrabold text-[#0f766e] tabular-nums">{fmtMoney(selectedVal14)} ج.م</span>
                      </div>
                      <div className="px-3 py-2.5 bg-[#eef8f6] space-y-1">
                        <div className="flex justify-between items-center">
                          <span className="font-extrabold text-[#073b39]">الإجمالي شامل 14%</span>
                          <span className="text-sm font-extrabold text-[#0f766e] tabular-nums">{fmtMoney(selectedGrandTotal)} ج.م</span>
                        </div>
                        <div className="text-[11px] font-bold text-[#14532d]">{tafqeetEGP(selectedGrandTotal)}</div>
                      </div>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="p-6 text-center text-xs text-[#5c7471] border border-[#dce6e3] rounded-xl">
                اختر أذن صرف من القائمة على اليمين لمعاينة بيانات الفاتورة.
              </div>
            )}
          </div>
        </form>
      )}
    </Modal>
  );
}
