import React, { useMemo, useState } from 'react';
import { Check, ChevronDown, ChevronLeft, ChevronRight, FileSpreadsheet, Plus, Search, Trash2, Upload } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { DraftIncoming, Invoice } from '../types/pharma';
import { fmtDate, fmtMoney, fmtNum, shiftISO, todayISO, toFullDate, uid, unitsText } from '../utils/format';
import { downloadExcelTemplate } from '../utils/export';
import {
  computeNextIncomingNo,
  distributeQuantities,
  findDuplicateInvoiceNo
} from '../utils/pharmaEngine';

export function CalmIncomingWizard({
  draft,
  setDraft,
  onOpenImport,
  onQuickSupplier,
  onViewInvoice
}: {
  draft: DraftIncoming;
  setDraft: React.Dispatch<React.SetStateAction<DraftIncoming>>;
  onOpenImport: () => void;
  onQuickSupplier: () => void;
  onViewInvoice: (inv: Invoice) => void;
}) {
  const { db, getProduct, commitIncomingInvoice, toast } = usePharmaStore();
  const suppliers = db.partners.filter(p => p.type === 'supplier');

  const [step, setStep] = useState<1 | 2 | 3>(() => (draft.lines.length > 0 ? 2 : 1));
  const [showDateField, setShowDateField] = useState(false);
  const [prodSearch, setProdSearch] = useState('');
  const [selectedProdId, setSelectedProdId] = useState(db.products[0]?.id || '');
  const [qty, setQty] = useState(1);
  const [unitName, setUnitName] = useState('');
  const [expiry, setExpiry] = useState(() => shiftISO(todayISO(), 365));
  const [batch, setBatch] = useState(() => `L-${Math.floor(1000 + Math.random() * 8999)}`);

  const dupInvoiceNo = findDuplicateInvoiceNo(db, draft.no);
  const filteredProds = useMemo(() => {
    const q = prodSearch.trim().toLowerCase();
    return db.products.filter(p => !q || `${p.name} ${p.code} ${p.form}`.toLowerCase().includes(q));
  }, [db.products, prodSearch]);

  const activeProd = getProduct(selectedProdId) || filteredProds[0] || db.products[0] || null;
  const activeUnit = (activeProd && activeProd.units.find(u => u.name === unitName)) || activeProd?.units[0] || null;

  const totalStrips = draft.lines.reduce((s, l) => s + l.strips, 0);
  const totalValue = draft.lines.reduce((s, l) => s + l.strips * (getProduct(l.productId)?.price || 0), 0);

  const previewWarehouses = useMemo(() => {
    const sums: Record<string, number> = {};
    db.warehouses.forEach(w => {
      sums[w.id] = 0;
    });
    const shares = db.warehouses.map(w => (draft.mode === 'equal' ? 1 : w.share));
    draft.lines.forEach(l => {
      if (draft.mode === 'manual' && l.manualAlloc) {
        db.warehouses.forEach(w => {
          sums[w.id] += Math.max(0, Math.round(l.manualAlloc?.[w.id] || 0));
        });
      } else {
        const nums = distributeQuantities(l.strips, shares);
        db.warehouses.forEach((w, idx) => {
          sums[w.id] += nums[idx] || 0;
        });
      }
    });
    return sums;
  }, [db.warehouses, draft.lines, draft.mode]);

  const handleAddLine = () => {
    if (!activeProd || !activeUnit) {
      toast('اختر صنفًا أولًا', 'err');
      return;
    }
    const q = Math.max(1, Math.round(qty || 1));
    const strips = q * activeUnit.factor;
    setDraft(prev => ({
      ...prev,
      lines: [
        ...prev.lines,
        {
          id: uid('ln'),
          productId: activeProd.id,
          strips,
          units: [{ name: activeUnit.name, qty: q }],
          expiry: toFullDate(expiry),
          batch: batch.trim() || `L-${Math.floor(1000 + Math.random() * 8999)}`
        }
      ]
    }));
    setQty(1);
    setBatch(`L-${Math.floor(1000 + Math.random() * 8999)}`);
    toast(`تمت إضافة ${q} ${activeUnit.name} من ${activeProd.name}`);
  };

  const handleConfirm = async () => {
    if (!draft.no.trim()) {
      setStep(1);
      toast('أدخل رقم فاتورة المورد أولًا', 'err');
      return;
    }
    if (dupInvoiceNo) {
      setStep(1);
      toast(`رقم الفاتورة «${draft.no.trim()}» مستخدم بالفعل — ممنوع التكرار`, 'err');
      return;
    }
    if (!draft.lines.length) {
      setStep(2);
      toast('أضف صنفًا واحدًا على الأقل', 'err');
      return;
    }
    try {
      const inv = await commitIncomingInvoice(draft);
      toast(`تم ترحيل فاتورة الوارد ${inv.no} وتوزيعها على المخازن`);
      setDraft(prev => ({
        ...prev,
        no: computeNextIncomingNo({ ...db, invoices: [inv, ...db.invoices] }),
        lines: []
      }));
      setStep(1);
      onViewInvoice(inv);
    } catch (err) {
      toast(err instanceof Error ? err.message : 'تعذر ترحيل فاتورة الوارد', 'err');
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg sm:text-xl font-extrabold text-[#102523]">فاتورة وارد جديدة</h2>
          <p className="text-xs text-[#5c7471] mt-0.5">إدخال الوارد وتوزيعه على المخازن الأربعة في 3 خطوات أو استيراده من Excel</p>
        </div>
        <button
          type="button"
          onClick={() => setDraft(prev => ({ ...prev, lines: [] }))}
          className="px-3 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
        >
          مسح المسودة
        </button>
      </div>

      {/* 3-Step Horizontal Bar */}
      <nav aria-label="خطوات فاتورة الوارد" className="grid grid-cols-3 gap-2 bg-white border border-[#dce6e3] rounded-2xl p-1.5">
        {(
          [
            { num: 1, title: '١. المورد والفاتورة' },
            { num: 2, title: `٢. الأصناف (${fmtNum(draft.lines.length)})` },
            { num: 3, title: '٣. التوزيع والترحيل' }
          ] as const
        ).map(s => {
          const active = step === s.num;
          const done = step > s.num;
          return (
            <button
              key={s.num}
              type="button"
              onClick={() => setStep(s.num)}
              className={`min-h-[42px] px-3 py-2 rounded-xl text-xs font-extrabold transition-colors cursor-pointer whitespace-nowrap truncate ${
                active
                  ? 'bg-[#0f766e] text-white'
                  : done
                    ? 'bg-[#eef8f6] text-[#0f766e]'
                    : 'text-[#5c7471] hover:bg-[#f8fbfa]'
              }`}
            >
              {s.title}
            </button>
          );
        })}
      </nav>

      {/* STEP 1 */}
      {step === 1 && (
        <div className="max-w-3xl mx-auto space-y-4">
          <section className="bg-white border border-[#dce6e3] rounded-2xl p-5 sm:p-6 space-y-4">
            <h3 className="text-base font-extrabold text-[#102523]">الخطوة ١: بيانات فاتورة المورد</h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="block text-xs font-bold text-[#233d3a]">
                <label htmlFor="calm-sup-select" className="block mb-1.5">الشركة الموردة *</label>
                <div className="flex items-center gap-2">
                  <select
                    id="calm-sup-select"
                    value={draft.supplierId}
                    onChange={e => setDraft(prev => ({ ...prev, supplierId: e.target.value }))}
                    className="flex-1 min-w-0 min-h-[44px] px-3 py-2 rounded-xl border border-[#dce6e3] text-sm bg-white"
                  >
                    {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                  <button
                    type="button"
                    onClick={onQuickSupplier}
                    className="min-h-[44px] px-3 rounded-xl border border-[#dce6e3] bg-white hover:bg-[#f4f8f7] text-xs font-bold text-[#0f766e] shrink-0 cursor-pointer"
                  >
                    + مورد
                  </button>
                </div>
              </div>

              <label className="block text-xs font-bold text-[#233d3a]">
                <span className="block mb-1.5">رقم فاتورة المورد *</span>
                <input
                  value={draft.no}
                  onChange={e => setDraft(prev => ({ ...prev, no: e.target.value }))}
                  className={`w-full min-h-[44px] px-3 py-2 rounded-xl border text-sm font-mono-num font-bold ${
                    dupInvoiceNo ? 'border-[#dc2626] bg-[#fef2f2] text-[#b91c1c]' : 'border-[#dce6e3]'
                  }`}
                />
                {dupInvoiceNo && (
                  <span className="block mt-1 text-[10.5px] font-bold text-[#dc2626]">
                    رقم الفاتورة مستخدم بالفعل — ممنوع التكرار
                  </span>
                )}
              </label>

              <label className="block text-xs font-bold text-[#233d3a] sm:col-span-2">
                <span className="block mb-1.5">طريقة توزيع الكميات على المخازن الأربعة</span>
                <select
                  value={draft.mode}
                  onChange={e => setDraft(prev => ({ ...prev, mode: e.target.value as 'shares' | 'equal' | 'manual' }))}
                  className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-[#dce6e3] text-sm bg-white"
                >
                  <option value="shares">تلقائي حسب نسب المخازن ({db.warehouses.map(w => `${w.name} ${w.share}%`).join(' · ')})</option>
                  <option value="equal">توزيع متساوٍ بين المخازن الأربعة</option>
                  <option value="manual">توزيع يدوي لكل صنف على حدة</option>
                </select>
              </label>
            </div>

            <div className="pt-2 border-t border-[#edf3f1]">
              <button
                type="button"
                onClick={() => setShowDateField(o => !o)}
                className="inline-flex items-center gap-1 text-xs font-bold text-[#0f766e] hover:underline cursor-pointer"
              >
                <ChevronDown className={`w-4 h-4 transition-transform ${showDateField ? 'rotate-180' : ''}`} />
                <span>تاريخ الاستلام ({fmtDate(draft.date)})</span>
              </button>
              {showDateField && (
                <div className="mt-2 max-w-xs">
                  <input
                    type="date"
                    value={draft.date}
                    onChange={e => setDraft(prev => ({ ...prev, date: e.target.value }))}
                    className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-[#dce6e3] text-xs"
                  />
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-[#edf3f1] flex items-center justify-end">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="inline-flex items-center gap-2 min-h-[44px] px-6 py-2.5 rounded-xl bg-[#0f766e] text-white text-sm font-extrabold hover:bg-[#0d655e] cursor-pointer"
              >
                <span>التالي: إضافة الأصناف</span>
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          </section>

          {/* Calm Excel Import Option */}
          <section className="bg-white border border-[#a7f3d0] rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3">
            <div className="space-y-0.5">
              <div className="inline-flex items-center gap-2 text-sm font-extrabold text-[#065f46]">
                <FileSpreadsheet className="w-4 h-4" />
                <span>هل لديك الفاتورة في ملف Excel (.xlsx)؟</span>
              </div>
              <p className="text-xs text-[#5c7471]">استورد كافة البنود والتشغيلات والصلاحيات دفعة واحدة بدون إدخال يدوي.</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={downloadExcelTemplate}
                className="min-h-[40px] px-3.5 py-2 rounded-xl border border-[#a7f3d0] bg-[#ecfdf5] text-xs font-bold text-[#047857] hover:bg-[#d1fae5] cursor-pointer"
              >
                تحميل قالب Excel
              </button>
              <button
                type="button"
                onClick={onOpenImport}
                className="min-h-[40px] inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#047857] text-white text-xs font-bold hover:bg-[#065f46] cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>استيراد ملف Excel (.xlsx)</span>
              </button>
            </div>
          </section>
        </div>
      )}

      {/* STEP 2 */}
      {step === 2 && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          <section className="lg:col-span-6 bg-white border border-[#dce6e3] rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-extrabold text-[#102523]">إضافة صنف للفاتورة</h3>

            <div className="relative">
              <Search className="w-4 h-4 text-[#6b8481] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={prodSearch}
                onChange={e => setProdSearch(e.target.value)}
                placeholder="ابحث عن الصنف بالاسم أو الكود..."
                className="w-full min-h-[42px] pr-9 pl-3 py-2 text-xs bg-[#f8fbfa] border border-[#dce6e3] rounded-xl focus:outline-none focus:border-[#0f766e]"
              />
            </div>

            <label className="block text-xs font-bold text-[#233d3a]">
              <span className="block mb-1">الصنف *</span>
              <select
                value={activeProd?.id || ''}
                onChange={e => {
                  setSelectedProdId(e.target.value);
                  setUnitName('');
                }}
                className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-[#dce6e3] text-xs bg-white"
              >
                {filteredProds.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.code} — {p.name} ({fmtMoney(p.price)} ج.م)
                  </option>
                ))}
              </select>
            </label>

            <div className="grid grid-cols-2 gap-3">
              <label className="block text-xs font-bold text-[#233d3a]">
                <span className="block mb-1">الكمية *</span>
                <input
                  type="number"
                  min={1}
                  value={qty}
                  onChange={e => setQty(Math.max(1, Number(e.target.value) || 1))}
                  className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-[#dce6e3] text-xs font-bold text-center tabular-nums"
                />
              </label>
              <label className="block text-xs font-bold text-[#233d3a]">
                <span className="block mb-1">الوحدة *</span>
                <select
                  value={activeUnit?.name || ''}
                  onChange={e => setUnitName(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-[#dce6e3] text-xs bg-white"
                >
                  {(activeProd?.units || []).map(u => (
                    <option key={u.name} value={u.name}>
                      {u.name} ({u.factor})
                    </option>
                  ))}
                </select>
              </label>
              <label className="block text-xs font-bold text-[#233d3a]">
                <span className="block mb-1">تاريخ الصلاحية *</span>
                <input
                  type="date"
                  value={expiry}
                  onChange={e => setExpiry(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-[#dce6e3] text-xs"
                />
              </label>
              <label className="block text-xs font-bold text-[#233d3a]">
                <span className="block mb-1">رقم التشغيلة (Lot) *</span>
                <input
                  value={batch}
                  onChange={e => setBatch(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-[#dce6e3] font-mono-num text-xs"
                />
              </label>
            </div>

            <button
              type="button"
              disabled={!activeProd}
              onClick={handleAddLine}
              className="w-full min-h-[44px] inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-[#0f766e] text-white text-xs font-extrabold hover:bg-[#0d655e] cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة للفاتورة</span>
            </button>
          </section>

          <aside className="lg:col-span-6 bg-white border border-[#dce6e3] rounded-2xl overflow-hidden">
            <div className="px-4 py-3 border-b border-[#edf3f1] flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-[#102523]">بنود الفاتورة ({fmtNum(draft.lines.length)})</h3>
              <span className="text-xs font-bold text-[#0f766e] tabular-nums">{fmtNum(totalStrips)} وحدة</span>
            </div>

            {draft.lines.length ? (
              <div className="max-h-[380px] overflow-y-auto divide-y divide-[#edf3f1]">
                {draft.lines.map(l => {
                  const p = getProduct(l.productId);
                  if (!p) return null;
                  return (
                    <div key={l.id} className="p-3.5 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="text-xs font-bold text-[#102523]">{p.name}</div>
                          <div className="text-[11px] text-[#5c7471] tabular-nums">
                            {unitsText(l.strips, p)} · تشغيلة {l.batch} · صلاحية {fmtDate(l.expiry)}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setDraft(prev => ({ ...prev, lines: prev.lines.filter(x => x.id !== l.id) }))}
                          className="p-1.5 rounded-lg text-[#dc2626] hover:bg-[#fef2f2] cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      {draft.mode === 'manual' && (
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 pt-1">
                          {db.warehouses.map(w => (
                            <label key={w.id} className="block text-[10px] font-bold text-[#5c7471]">
                              <span className="block truncate">{w.name}</span>
                              <input
                                type="number"
                                min={0}
                                value={l.manualAlloc?.[w.id] ?? 0}
                                onChange={e => {
                                  const v = Math.max(0, Math.round(Number(e.target.value) || 0));
                                  setDraft(prev => ({
                                    ...prev,
                                    lines: prev.lines.map(x =>
                                      x.id === l.id
                                        ? { ...x, manualAlloc: { ...(x.manualAlloc || {}), [w.id]: v } }
                                        : x
                                    )
                                  }));
                                }}
                                className="mt-0.5 w-full px-2 py-1 rounded border border-[#dce6e3] text-xs font-bold text-center tabular-nums text-[#102523]"
                              />
                            </label>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-8 text-center text-xs text-[#5c7471]">لم تضف أي أصناف بعد.</div>
            )}

            <div className="p-3.5 border-t border-[#edf3f1] bg-[#f8fbfa] flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="inline-flex items-center gap-1 min-h-[42px] px-3.5 py-2 rounded-xl border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
                <span>السابق</span>
              </button>
              <button
                type="button"
                disabled={!draft.lines.length}
                onClick={() => setStep(3)}
                className="flex-1 inline-flex items-center justify-center gap-1.5 min-h-[42px] px-4 py-2 rounded-xl bg-[#0f766e] text-white text-xs font-extrabold hover:bg-[#0d655e] disabled:opacity-45 cursor-pointer"
              >
                <span>التالي: التوزيع والترحيل</span>
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* STEP 3 */}
      {step === 3 && (
        <section className="max-w-3xl mx-auto bg-white border border-[#dce6e3] rounded-2xl p-5 sm:p-6 space-y-5">
          <div>
            <h3 className="text-base font-extrabold text-[#102523]">الخطوة ٣: مراجعة التوزيع والترحيل</h3>
            <p className="text-xs text-[#5c7471]">فاتورة رقم <span className="font-mono-num font-bold text-[#0f766e]">{draft.no}</span> · إجمالي {fmtNum(totalStrips)} وحدة · قيمة {fmtMoney(totalValue)} ج.م</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {db.warehouses.map(w => (
              <div key={w.id} className="p-3 rounded-xl bg-[#f8fbfa] border border-[#dce6e3] space-y-1">
                <div className="text-xs font-bold text-[#5c7471]">{w.name}</div>
                <div className="text-base font-extrabold text-[#0f766e] tabular-nums">
                  {fmtNum(previewWarehouses[w.id] || 0)} وحدة
                </div>
              </div>
            ))}
          </div>

          <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="inline-flex items-center gap-1 min-h-[44px] px-4 py-2 rounded-xl border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
              <span>تعديل الأصناف</span>
            </button>
            <button
              type="button"
              disabled={!draft.lines.length || Boolean(dupInvoiceNo)}
              onClick={handleConfirm}
              className="flex-1 sm:flex-none min-h-[46px] inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-[#0f766e] text-white text-sm font-extrabold hover:bg-[#0d655e] disabled:opacity-45 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>ترحيل فاتورة الوارد للمخازن</span>
            </button>
          </div>
        </section>
      )}
    </div>
  );
}
