import React, { useEffect, useMemo, useState } from 'react';
import { Lock, Pencil, Receipt, RotateCcw, Search, Upload } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { CustomerReturn, Invoice, IssueOrder, ReceiptType, TransferOrder, UnitQty } from '../types/pharma';
import {
  calc14Percent,
  calcInvoiceValue,
  calcIssueValue,
  calcTotalWith14,
  escHtml,
  fmtDate,
  fmtMoney,
  fmtNum,
  getIssueReceipts,
  getLineReceiptType,
  isLineReceipt,
  receiptTypeLabel,
  resolveIssueCustomer,
  shiftISO,
  sortIssueLines,
  tafqeetEGP,
  todayISO,
  toFullDate,
  unitsText
} from '../utils/format';
import {
  downloadCSVTemplate,
  downloadExcelTemplate,
  exportInvoiceToWord,
  exportIssueReceiptToWord,
  exportIssueToWord,
  exportReturnToWord,
  exportSalesInvoiceToWord,
  exportToExcel,
  exportTransferToWord,
  parseCSVRow,
  parseExcelImportRows
} from '../utils/export';
import { computeNextIncomingNo, findDuplicateInvoiceNo } from '../utils/pharmaEngine';
import { ExcelButton, ExpiryTag, Modal, PrintButton, WordButton } from './ui/CommonUI';

export function LinePickerModal({
  open,
  mode,
  warehouseId,
  onChangeWarehouse,
  initialSupplierId,
  onChangeSupplier,
  extraStockByProduct,
  onClose,
  onAdd
}: {
  open: boolean;
  mode: 'incoming' | 'issue' | 'transfer';
  warehouseId?: string;
  onChangeWarehouse?: (warehouseId: string) => void;
  initialSupplierId?: string;
  onChangeSupplier?: (supplierId: string) => void;
  extraStockByProduct?: Record<string, number>;
  onClose: () => void;
  onAdd: (data: { productId: string; strips: number; units: UnitQty[]; expiry?: string; batch?: string; asReceipt?: boolean; receiptType?: ReceiptType }) => void;
}) {
  const { db, getProduct, getPartner, availableStock, nearestExpiry, toast } = usePharmaStore();
  const [search, setSearch] = useState('');
  const [supplierId, setSupplierId] = useState<string>('all');
  const [productId, setProductId] = useState('');
  const [unitQtys, setUnitQtys] = useState<Record<string, number>>({});
  const [expiry, setExpiry] = useState(() => shiftISO(todayISO(), 365));
  const [batch, setBatch] = useState(() => `L-${Math.floor(1000 + Math.random() * 8999)}`);
  const [asReceipt, setAsReceipt] = useState(false);
  const [receiptType, setReceiptType] = useState<ReceiptType>('supplies');

  const suppliers = useMemo(() => db.partners.filter(p => p.type === 'supplier'), [db.partners]);

  const effectiveAvail = (pid: string, whId: string | undefined = warehouseId) => {
    const base = availableStock(pid, whId);
    if (!whId || whId === warehouseId) return base + (extraStockByProduct?.[pid] || 0);
    return base;
  };

  const eligibleProducts = useMemo(() => {
    if (mode === 'incoming') return db.products;
    return db.products.filter(p => availableStock(p.id, warehouseId) + (extraStockByProduct?.[p.id] || 0) > 0);
  }, [db.products, mode, warehouseId, availableStock, extraStockByProduct]);

  const supplierCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    eligibleProducts.forEach(p => {
      const key = p.supplierId || '__none__';
      counts[key] = (counts[key] || 0) + 1;
    });
    return counts;
  }, [eligibleProducts]);

  const warehouseEligibleCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    db.warehouses.forEach(w => {
      counts[w.id] = db.products.filter(
        p => availableStock(p.id, w.id) + (w.id === warehouseId ? extraStockByProduct?.[p.id] || 0 : 0) > 0
      ).length;
    });
    return counts;
  }, [db.warehouses, db.products, availableStock, warehouseId, extraStockByProduct]);

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    return eligibleProducts.filter(p => {
      if (supplierId !== 'all') {
        if (supplierId === '__none__' ? Boolean(p.supplierId) : p.supplierId !== supplierId) {
          return false;
        }
      }
      if (q && !`${p.name} ${p.code} ${p.form}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [eligibleProducts, supplierId, search]);

  useEffect(() => {
    if (!open) return;
    setSearch('');
    setSupplierId(initialSupplierId || 'all');
    setUnitQtys({});
    setExpiry(shiftISO(todayISO(), 365));
    setBatch(`L-${Math.floor(1000 + Math.random() * 8999)}`);
  }, [open, initialSupplierId]);

  useEffect(() => {
    if (!open) return;
    if (!filteredProducts.some(p => p.id === productId)) {
      const firstProd = filteredProducts[0];
      setProductId(firstProd?.id || '');
      setUnitQtys({});
    }
  }, [open, filteredProducts, productId]);

  const product = getProduct(productId);
  useEffect(() => {
    if (open && mode === 'issue' && product) {
      setAsReceipt(Boolean(product.marked));
      setReceiptType(product.marked ? 'supplies' : 'gift');
    }
  }, [open, mode, productId, product]);
  const avail = product && warehouseId ? effectiveAvail(product.id, warehouseId) : 0;
  const near = product && warehouseId ? nearestExpiry(product.id, warehouseId) : null;

  const totalStrips = useMemo(() => {
    if (!product) return 0;
    return product.units.reduce((sum, u) => sum + Math.max(0, Math.round(unitQtys[u.name] || 0)) * u.factor, 0);
  }, [product, unitQtys]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!product) {
      toast('اختر صنفًا أولًا', 'err');
      return;
    }
    if (totalStrips <= 0) {
      toast('أدخل كمية أكبر من صفر', 'err');
      return;
    }
    if ((mode === 'issue' || mode === 'transfer') && totalStrips > avail) {
      toast(`الكمية المطلوبة (${fmtNum(totalStrips)}) أكبر من المتاح بالمخزن (${fmtNum(avail)})`, 'err');
      return;
    }
    if (mode === 'incoming' && (!expiry || !batch.trim())) {
      toast('أدخل تاريخ الصلاحية ورقم التشغيلة', 'err');
      return;
    }
    const units: UnitQty[] = product.units
      .map(u => ({ name: u.name, qty: Math.max(0, Math.round(unitQtys[u.name] || 0)) }))
      .filter(u => u.qty > 0);
    onAdd({
      productId: product.id,
      strips: totalStrips,
      units,
      expiry: mode === 'incoming' ? toFullDate(expiry) : undefined,
      batch: mode === 'incoming' ? batch.trim() : undefined,
      asReceipt: mode === 'issue' ? asReceipt : undefined,
      receiptType: mode === 'issue' && asReceipt ? receiptType : undefined
    });
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={mode === 'incoming' ? 'إضافة بند لفاتورة الوارد' : mode === 'issue' ? 'إضافة صنف لأذن الصرف' : 'إضافة صنف لأذن التحويل'}
      subtitle={
        mode === 'incoming'
          ? 'اختر الشركة الموردة أو ابحث بالاسم/الكود وحدد الكمية بأي مستوى من هرم الوحدات'
          : 'اختر الشركة الموردة والمخزن (الرئيسي أو الفرعي) لتظهر الأصناف المتاحة برصيد ساري'
      }
      footer={
        <>
          <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] cursor-pointer">
            إلغاء
          </button>
          <button
            type="submit"
            form="line-picker-form"
            disabled={!product}
            className="px-5 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold disabled:opacity-45 cursor-pointer"
          >
            إضافة البند
          </button>
        </>
      }
    >
      <form id="line-picker-form" onSubmit={handleSubmit} className="space-y-3.5">
        <div className={`grid grid-cols-1 ${mode === 'issue' ? 'sm:grid-cols-2' : ''} gap-2.5`}>
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>الشركة الموردة</span>
            <select
              value={supplierId}
              onChange={e => {
                const val = e.target.value;
                setSupplierId(val);
                onChangeSupplier?.(val);
                setUnitQtys({});
              }}
              className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white focus:outline-none focus:border-[#0f766e]"
            >
              <option value="all">كل الشركات الموردة ({fmtNum(eligibleProducts.length)} صنف)</option>
              {suppliers.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} ({fmtNum(supplierCounts[s.id] || 0)} متاح)
                </option>
              ))}
              {(supplierCounts.__none__ || 0) > 0 && (
                <option value="__none__">أصناف بدون شركة محددة ({fmtNum(supplierCounts.__none__)})</option>
              )}
            </select>
          </label>

          {mode === 'issue' && (
            <label className="block text-xs font-bold text-[#233d3a]">
              <span>المخزن (المخازن الأربعة: الرئيسي والفرعي)</span>
              <select
                value={warehouseId || ''}
                disabled={!onChangeWarehouse}
                onChange={e => onChangeWarehouse?.(e.target.value)}
                className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white disabled:bg-[#f4f8f7] focus:outline-none focus:border-[#0f766e]"
              >
                {db.warehouses.map(w => (
                  <option key={w.id} value={w.id}>
                    {w.name} — {w.gov} ({fmtNum(warehouseEligibleCounts[w.id] || 0)} صنف متاح)
                  </option>
                ))}
              </select>
            </label>
          )}
        </div>

        <div className="relative">
          <Search className="w-4 h-4 text-[#6b8481] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="بحث سريع عن الصنف بالاسم أو الكود داخل الشركة المحددة..."
            className="w-full pr-9 pl-3 py-2 text-xs bg-[#f8fbfa] border border-[#dce6e3] rounded-lg focus:outline-none focus:border-[#0f766e]"
          />
        </div>

        <label className="block text-xs font-bold text-[#233d3a]">
          <span>
            الصنف *{' '}
            {mode !== 'incoming' && (
              <span className="text-[11px] font-normal text-[#0f766e]">
                ({fmtNum(filteredProducts.length)} صنف متاح وساري{supplierId !== 'all' ? ' من الشركة المحددة' : ''})
              </span>
            )}
          </span>
          <select
            value={productId}
            onChange={e => {
              setProductId(e.target.value);
              setUnitQtys({});
            }}
            className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white focus:outline-none focus:border-[#0f766e]"
          >
            {filteredProducts.length === 0 ? (
              <option value="">
                {eligibleProducts.length === 0
                  ? 'لا توجد أصناف برصيد ساري الصلاحية في هذا المخزن'
                  : 'لا توجد أصناف مطابقة للشركة الموردة أو البحث'}
              </option>
            ) : (
              filteredProducts.map(p => {
                const av = warehouseId ? effectiveAvail(p.id, warehouseId) : null;
                return (
                  <option key={p.id} value={p.id}>
                    {p.code} — {p.name} {p.form ? `(${p.form})` : ''} {av !== null ? `· متاح ${unitsText(av, p)}` : ''}
                  </option>
                );
              })
            )}
          </select>
        </label>

        {product && (
          <>
            <div className="bg-[#f8fbfa] border border-[#dce6e3] rounded-xl p-3 text-xs space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-bold text-[#102523]">
                  {product.marked ? 'مستلزمات طبية (لا تدخل الفاتورة)' : `سعر الوحدة الأساسية: ${fmtMoney(product.price)} ج.م`}
                </span>
                {warehouseId && (
                  <span className={`font-bold tabular-nums ${avail > 0 ? 'text-[#0f766e]' : 'text-[#dc2626]'}`}>
                    المتاح بالمخزن المحدد: {unitsText(avail, product)}
                  </span>
                )}
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#5c7471]">
                <span>الشركة الموردة: <b className="text-[#233d3a]">{getPartner(product.supplierId)?.name || 'غير محدد'}</b></span>
                {near && <span>أقرب صلاحية متاحة (FEFO): {fmtDate(near)}</span>}
              </div>
              {mode === 'issue' && (
                <div className="pt-1.5 border-t border-[#e5efec]">
                  <div className="text-[10.5px] font-bold text-[#5c7471] mb-1.5">الرصيد المتاح في المخازن الأربعة (اضغط لاختيار المخزن الصارف):</div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                    {db.warehouses.map(w => {
                      const whAvail = effectiveAvail(product.id, w.id);
                      const isCurrent = w.id === warehouseId;
                      return (
                        <button
                          key={w.id}
                          type="button"
                          disabled={!onChangeWarehouse}
                          onClick={() => onChangeWarehouse?.(w.id)}
                          className={`text-right px-2 py-1.5 rounded-lg border text-[10.5px] transition cursor-pointer disabled:cursor-default ${
                            isCurrent
                              ? 'bg-[#eef8f6] border-[#0f766e] text-[#0f766e] font-extrabold'
                              : 'bg-white border-[#dce6e3] text-[#233d3a] hover:border-[#0f766e]/50'
                          }`}
                        >
                          <div className="truncate font-bold">{w.name}</div>
                          <div className={`tabular-nums mt-0.5 ${whAvail > 0 ? 'text-[#0f766e]' : 'text-[#94a3b8]'}`}>
                            {whAvail > 0 ? unitsText(whAvail, product) : 'غير متاح'}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {[...product.units].reverse().map(u => (
                <label key={u.name} className="block text-xs font-bold text-[#233d3a]">
                  <span>{u.name} <span className="text-[10.5px] font-normal text-[#5c7471]">({fmtNum(u.factor)})</span></span>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={unitQtys[u.name] || ''}
                    onChange={e => setUnitQtys(prev => ({ ...prev, [u.name]: Math.max(0, Number(e.target.value) || 0) }))}
                    placeholder="0"
                    className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs tabular-nums focus:outline-none focus:border-[#0f766e]"
                  />
                </label>
              ))}
            </div>

            {mode === 'incoming' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="block text-xs font-bold text-[#233d3a]">
                  <span>تاريخ الصلاحية *</span>
                  <input
                    type="date"
                    value={expiry}
                    onChange={e => setExpiry(e.target.value)}
                    required
                    className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs focus:outline-none focus:border-[#0f766e]"
                  />
                </label>
                <label className="block text-xs font-bold text-[#233d3a]">
                  <span>رقم التشغيلة (Lot) *</span>
                  <input
                    type="text"
                    value={batch}
                    onChange={e => setBatch(e.target.value)}
                    required
                    className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] font-mono-num text-xs focus:outline-none focus:border-[#0f766e]"
                  />
                </label>
              </div>
            )}

            {mode === 'issue' && (
              <div className="p-3 rounded-xl border border-[#fde68a] bg-[#fffbeb] space-y-2.5">
                <label className="flex items-start gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={asReceipt}
                    onChange={e => setAsReceipt(e.target.checked)}
                    className="mt-0.5 accent-[#b45309] w-4 h-4 cursor-pointer"
                  />
                  <span className="text-xs text-[#78350f]">
                    <strong className="block">صرف بإيصال بدون قيمة (لا يدخل الفاتورة)</strong>
                    <span className="text-[11px] text-[#92400e]">
                      عند التعليم عليه: يُخصم من المخزن بشكل طبيعي ويصدر في إيصال منفصل برقم أذن الصرف ورقم الإيصال.
                    </span>
                  </span>
                </label>
                {asReceipt && (
                  <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-[#fde68a]">
                    <span className="text-[11px] font-bold text-[#78350f]">نوع الإيصال:</span>
                    <button
                      type="button"
                      onClick={() => setReceiptType('supplies')}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-bold border cursor-pointer ${
                        receiptType === 'supplies'
                          ? 'bg-[#b45309] text-white border-[#b45309]'
                          : 'bg-white text-[#78350f] border-[#fde68a]'
                      }`}
                    >
                      إيصال مستلزمات
                    </button>
                    <button
                      type="button"
                      onClick={() => setReceiptType('gift')}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-bold border cursor-pointer ${
                        receiptType === 'gift'
                          ? 'bg-[#b45309] text-white border-[#b45309]'
                          : 'bg-white text-[#78350f] border-[#fde68a]'
                      }`}
                    >
                      إيصال هدية بدون قيمة
                    </button>
                  </div>
                )}
              </div>
            )}

            <div className="flex items-center justify-between text-xs bg-[#eef8f6] border border-[#b7dfd7] rounded-lg px-3 py-2">
              <span className="font-bold text-[#073b39]">الإجمالي المحسوب:</span>
              <span className="font-extrabold text-[#0f766e] tabular-nums">
                {unitsText(totalStrips, product)} ({fmtNum(totalStrips)} {product.units[0].name})
              </span>
            </div>
          </>
        )}
      </form>
    </Modal>
  );
}

export function ImportBulkModal({
  open,
  onClose,
  onImportedToDraft
}: {
  open: boolean;
  onClose: () => void;
  onImportedToDraft: (lines: { productId: string; units: UnitQty[]; strips: number; expiry: string; batch: string }[]) => void;
}) {
  const { db, bulkImportIncoming, toast } = usePharmaStore();
  const suppliers = db.partners.filter(p => p.type === 'supplier');
  const [no, setNo] = useState('');
  const [supplierId, setSupplierId] = useState(suppliers[0]?.id || '');
  const [date, setDate] = useState(todayISO());
  const [mode, setMode] = useState<'shares' | 'equal'>('shares');
  const [directCommit, setDirectCommit] = useState(true);
  const [parsedRows, setParsedRows] = useState<{ productId: string; units: UnitQty[]; strips: number; expiry: string; batch: string }[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [fileName, setFileName] = useState('');

  useEffect(() => {
    if (!open) return;
    setNo(computeNextIncomingNo(db));
    setSupplierId(suppliers[0]?.id || '');
    setDate(todayISO());
    setParsedRows([]);
    setErrors([]);
    setFileName('');
  }, [open, db]);

  const dupBulkInvoice = directCommit ? findDuplicateInvoiceNo(db, no) : null;

  const handleFile = async (file: File) => {
    setFileName(file.name);
    const errs: string[] = [];
    const out: { productId: string; units: UnitQty[]; strips: number; expiry: string; batch: string }[] = [];

    const findProd = (codeOrName: string) => {
      const q = codeOrName.trim().toLowerCase();
      if (!q) return undefined;
      return db.products.find(p => p.code.toLowerCase() === q || p.name.toLowerCase() === q);
    };

    const normalizeExpiry = (rawVal: string) => {
      const s = rawVal.trim();
      if (/^\d{5}$/.test(s)) {
        const serial = Number(s);
        if (serial >= 30000 && serial <= 80000) {
          const dt = new Date(Date.UTC(1899, 11, 30) + serial * 86400000);
          return dt.toISOString().slice(0, 10);
        }
      }
      return toFullDate(s || shiftISO(todayISO(), 365));
    };

    const processTabularRows = (rows: string[][]) => {
      if (!rows.length) throw new Error('الملف فارغ');
      const headerLower = rows[0].map(c => c.trim().toLowerCase());
      const findCol = (aliases: string[]) => headerLower.findIndex(h => aliases.some(a => h === a || h.includes(a)));
      const colCode = findCol(['code', 'الكود', 'كود']);
      const colName = findCol(['name', 'الصنف', 'اسم الصنف']);
      const colUnit = findCol(['unit', 'الوحدة', 'وحدة']);
      const colQty = findCol(['qty', 'quantity', 'الكمية', 'كمية']);
      const colExp = findCol(['expiry', 'exp', 'الصلاحية', 'تاريخ الصلاحية']);
      const colBatch = findCol(['batch', 'lot', 'التشغيلة', 'تشغيلة']);

      const hasHeader = colCode !== -1 || colName !== -1 || colQty !== -1;
      const startIdx = hasHeader ? 1 : 0;

      for (let i = startIdx; i < rows.length; i++) {
        const cols = rows[i];
        if (!cols || !cols.some(c => c.trim())) continue;

        const codeVal = hasHeader ? (colCode >= 0 ? cols[colCode] || '' : '') : cols[0] || '';
        const nameVal = hasHeader ? (colName >= 0 ? cols[colName] || '' : '') : cols[1] || '';
        const unitVal = hasHeader ? (colUnit >= 0 ? cols[colUnit] || '' : '') : cols[2] || '';
        const qtyVal = hasHeader ? (colQty >= 0 ? cols[colQty] || '' : '') : cols[3] || '';
        const expVal = hasHeader ? (colExp >= 0 ? cols[colExp] || '' : '') : cols[4] || '';
        const batchVal = hasHeader ? (colBatch >= 0 ? cols[colBatch] || '' : '') : cols[5] || '';

        if (!hasHeader && cols.length < 4) {
          errs.push(`السطر ${i + 1}: عدد الأعمدة غير كافٍ`);
          continue;
        }
        const p = findProd(codeVal) || findProd(nameVal);
        if (!p) {
          errs.push(`السطر ${i + 1}: صنف غير موجود (${codeVal || nameVal || '—'})`);
          continue;
        }
        const uObj = p.units.find(u => u.name === unitVal.trim()) || p.units[0];
        const qty = Math.max(0, Number(qtyVal) || 0);
        const strips = Math.round(qty * uObj.factor);
        if (strips <= 0) continue;
        out.push({
          productId: p.id,
          units: [{ name: uObj.name, qty }],
          strips,
          expiry: normalizeExpiry(expVal),
          batch: (batchVal || `IMP-${i}`).trim()
        });
      }
    };

    try {
      const lowerName = file.name.toLowerCase();
      if (lowerName.endsWith('.xlsx') || lowerName.endsWith('.xls')) {
        const buffer = await file.arrayBuffer();
        const rows = parseExcelImportRows(buffer);
        processTabularRows(rows);
      } else if (lowerName.endsWith('.json')) {
        const text = (await file.text()).replace(/^\uFEFF/, '');
        const arr = JSON.parse(text);
        if (!Array.isArray(arr)) throw new Error('ملف JSON يجب أن يكون مصفوفة بنود');
        arr.forEach((row, idx) => {
          const p = findProd(String(row.code || row.productId || row.name || ''));
          if (!p) {
            errs.push(`سطر ${idx + 1}: صنف غير معروف (${row.code || row.name || '—'})`);
            return;
          }
          const uName = String(row.unit || p.units[0].name);
          const uObj = p.units.find(u => u.name === uName) || p.units[0];
          const qty = Math.max(0, Number(row.qty) || 0);
          const strips = Math.round(qty * uObj.factor);
          if (strips <= 0) return;
          out.push({
            productId: p.id,
            units: [{ name: uObj.name, qty }],
            strips,
            expiry: normalizeExpiry(String(row.expiry || '')),
            batch: String(row.batch || `IMP-${idx + 1}`)
          });
        });
      } else {
        const text = (await file.text()).replace(/^\uFEFF/, '');
        const rawLines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
        if (!rawLines.length) throw new Error('الملف فارغ');
        const delim = rawLines[0].includes(';') && !rawLines[0].includes(',') ? ';' : ',';
        const rows = rawLines.map(line => parseCSVRow(line, delim));
        processTabularRows(rows);
      }
    } catch (err) {
      errs.push(err instanceof Error ? err.message : 'تعذر قراءة الملف');
    }

    setParsedRows(out);
    setErrors(errs);
  };

  const handleConfirm = async () => {
    if (!parsedRows.length) {
      toast('ارفع ملفًا يحتوي على بنود صحيحة أولًا', 'err');
      return;
    }
    if (directCommit && dupBulkInvoice) {
      toast(`رقم الفاتورة «${no.trim()}» مستخدم بالفعل — لا يصح تكرار رقم الفاتورة`, 'err');
      return;
    }
    try {
      if (directCommit) {
        const inv = await bulkImportIncoming(parsedRows, { no, supplierId, date, mode });
        toast(`تم استيراد وترحيل فاتورة الوارد ${inv.no} وتوزيعها على المخازن`);
      } else {
        onImportedToDraft(parsedRows);
        toast(`تم تحميل ${parsedRows.length} بند في مسودة الفاتورة للمراجعة`);
      }
      onClose();
    } catch (err) {
      toast(err instanceof Error ? err.message : 'تعذر استيراد الفاتورة', 'err');
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      wide
      title="استيراد بيانات فاتورة الوارد"
      subtitle="يدعم ملفات Excel (.xlsx / .xls) و CSV و JSON مع تجميع التشغيلات المتشابهة تلقائيًا"
      footer={
        <>
          <button
            type="button"
            onClick={downloadExcelTemplate}
            className="px-3.5 py-2 rounded-lg border border-[#a7f3d0] bg-[#ecfdf5] text-xs font-bold text-[#047857] hover:bg-[#d1fae5] cursor-pointer"
          >
            تحميل قالب Excel (.xlsx)
          </button>
          <button
            type="button"
            onClick={downloadCSVTemplate}
            className="px-3.5 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#0f766e] cursor-pointer"
          >
            تحميل قالب CSV
          </button>
          <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] cursor-pointer">
            إلغاء
          </button>
          <button
            type="button"
            disabled={!parsedRows.length || Boolean(dupBulkInvoice)}
            onClick={handleConfirm}
            className="px-5 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold disabled:opacity-45 cursor-pointer"
          >
            {directCommit ? 'استيراد وترحيل للمخازن' : 'إضافة للمسودة'}
          </button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>رقم الفاتورة</span>
            <input
              value={no}
              onChange={e => setNo(e.target.value)}
              className={`mt-1 w-full px-3 py-2 rounded-lg border text-xs ${
                dupBulkInvoice ? 'border-[#dc2626] bg-[#fef2f2] text-[#b91c1c]' : 'border-[#dce6e3]'
              }`}
            />
            {dupBulkInvoice && (
              <span className="block mt-1 text-[10.5px] font-bold text-[#dc2626]">
                رقم الفاتورة مستخدم بالفعل — ممنوع التكرار
              </span>
            )}
          </label>
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>المورد</span>
            <select value={supplierId} onChange={e => setSupplierId(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white">
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </label>
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>تاريخ الاستلام</span>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs" />
          </label>
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>التوزيع</span>
            <select value={mode} onChange={e => setMode(e.target.value as 'shares' | 'equal')} className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white">
              <option value="shares">حسب نسب المخازن</option>
              <option value="equal">بالتساوي</option>
            </select>
          </label>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 bg-[#ecfdf5]/70 border border-[#a7f3d0] rounded-xl px-3.5 py-2.5">
          <div className="text-xs text-[#065f46]">
            <strong className="block">استيراد سريع من Excel (.xlsx)</strong>
            <span className="text-[11px] text-[#047857]">اختر ملف إكسيل مباشرة أو حمّل قالب الإكسيل الجاهز</span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <label className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#047857] text-white text-xs font-bold hover:bg-[#065f46] cursor-pointer">
              <Upload className="w-3.5 h-3.5" />
              <span>استيراد ملف Excel (.xlsx)</span>
              <input
                type="file"
                accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
                className="hidden"
                onChange={e => {
                  const f = e.target.files?.[0];
                  if (f) handleFile(f);
                  e.target.value = '';
                }}
              />
            </label>
            <button
              type="button"
              onClick={downloadExcelTemplate}
              className="px-3 py-2 rounded-lg border border-[#a7f3d0] bg-white text-xs font-bold text-[#047857] hover:bg-[#ecfdf5] cursor-pointer"
            >
              قالب Excel (.xlsx)
            </button>
          </div>
        </div>

        <label className="flex flex-col items-center justify-center border-2 border-dashed border-[#b7d6cf] rounded-xl p-5 bg-[#f6fbfa] hover:bg-[#eef8f6] cursor-pointer text-center">
          <Upload className="w-7 h-7 text-[#0f766e] mb-2" />
          <span className="text-xs font-extrabold text-[#102523]">
            {fileName ? `الملف المختار: ${fileName}` : 'اضغط لاختيار ملف Excel (.xlsx) أو CSV أو JSON'}
          </span>
          <span className="text-[11px] text-[#5c7471] mt-1">الأعمدة: code, name, unit, qty, expiry, batch (أو بالعربية: الكود، الصنف، الوحدة، الكمية، الصلاحية، التشغيلة)</span>
          <input
            type="file"
            accept=".xlsx,.xls,.csv,.json,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,text/csv,application/json"
            className="hidden"
            onChange={e => {
              const f = e.target.files?.[0];
              if (f) handleFile(f);
              e.target.value = '';
            }}
          />
        </label>

        <label className="flex items-center gap-2 text-xs font-bold text-[#233d3a] cursor-pointer">
          <input type="checkbox" checked={directCommit} onChange={e => setDirectCommit(e.target.checked)} className="accent-[#0f766e] w-4 h-4" />
          <span>ترحيل فوري للمخازن وتوزيع الكميات بعد الاستيراد</span>
        </label>

        {errors.length > 0 && (
          <div className="bg-[#fef2f2] border border-[#fecaca] rounded-lg p-3 text-xs text-[#b91c1c] space-y-1">
            {errors.slice(0, 6).map((err, i) => <div key={i}>{err}</div>)}
          </div>
        )}

        {parsedRows.length > 0 && (
          <div className="bg-[#ecfdf5] border border-[#a7f3d0] rounded-lg px-3 py-2 text-xs font-bold text-[#047857]">
            تمت قراءة {parsedRows.length} بند بنجاح بإجمالي {fmtNum(parsedRows.reduce((s, r) => s + r.strips, 0))} وحدة.
          </div>
        )}
      </div>
    </Modal>
  );
}

export function InvoiceDetailModal({
  invoice,
  onClose,
  onPrintHtml
}: {
  invoice: Invoice | null;
  onClose: () => void;
  onPrintHtml: (html: string) => void;
}) {
  const { db, getProduct, toast } = usePharmaStore();
  if (!invoice) return null;

  const val = calcInvoiceValue(invoice, db.products);
  const val14 = calc14Percent(val);
  const grandTotal = calcTotalWith14(val);
  const grandTotalWords = tafqeetEGP(grandTotal);

  const handleExcel = () => {
    const headers = ['الكود', 'الصنف', 'التشغيلة', 'الصلاحية', 'إجمالي الكمية', ...db.warehouses.map(w => w.name), 'القيمة (ج.م)', 'قيمة 14% (ج.م)', 'الإجمالي شامل 14% (ج.م)'];
    const rows = invoice.lines.map(l => {
      const p = getProduct(l.productId);
      const map: Record<string, number> = {};
      l.alloc.forEach(a => { map[a.warehouseId] = a.strips; });
      const lineVal = (l.strips || 0) * (p?.price || 0);
      return [
        p?.code || '',
        p?.name || '',
        l.batch,
        fmtDate(l.expiry),
        l.strips,
        ...db.warehouses.map(w => map[w.id] || 0),
        Number(lineVal.toFixed(2)),
        calc14Percent(lineVal),
        calcTotalWith14(lineVal)
      ];
    });
    const footerRow = [
      grandTotalWords,
      '', '', '', '',
      ...db.warehouses.map(() => ''),
      Number(val.toFixed(2)),
      val14,
      grandTotal
    ];
    exportToExcel(`فاتورة_وارد_${invoice.no}.xlsx`, `فاتورة ${invoice.no}`, headers, rows, footerRow);
    toast(`تم تصدير فاتورة ${invoice.no} إلى Excel`);
  };

  const handlePrint = () => {
    const rowsHtml = invoice.lines.map((l, idx) => {
      const p = getProduct(l.productId);
      if (!p) return '';
      const map: Record<string, number> = {};
      l.alloc.forEach(a => { map[a.warehouseId] = a.strips; });
      return `<tr>
        <td style="border:1px solid #0b4f4b;padding:6px;text-align:center">${idx + 1}</td>
        <td style="border:1px solid #0b4f4b;padding:6px">${p.name}</td>
        <td style="border:1px solid #0b4f4b;padding:6px;text-align:center">${l.batch}</td>
        <td style="border:1px solid #0b4f4b;padding:6px;text-align:center">${fmtDate(l.expiry)}</td>
        <td style="border:1px solid #0b4f4b;padding:6px">${unitsText(l.strips, p)}</td>
        ${db.warehouses.map(w => `<td style="border:1px solid #0b4f4b;padding:6px;text-align:center">${map[w.id] ? unitsText(map[w.id], p) : '—'}</td>`).join('')}
      </tr>`;
    }).join('');
    onPrintHtml(`
      <div style="font-family:Cairo,Arial,sans-serif;direction:rtl;color:#111">
        <h2>فاتورة وارد رقم ${invoice.no}</h2>
        <p>المورد: ${invoice.supplier} · التاريخ: ${fmtDate(invoice.date)}</p>
        <table style="width:100%;border-collapse:collapse;font-size:11px;margin-bottom:12px">
          <thead><tr style="background:#0f766e;color:#fff">
            <th style="border:1px solid #0b4f4b;padding:6px">م</th>
            <th style="border:1px solid #0b4f4b;padding:6px">الصنف</th>
            <th style="border:1px solid #0b4f4b;padding:6px">التشغيلة</th>
            <th style="border:1px solid #0b4f4b;padding:6px">الصلاحية</th>
            <th style="border:1px solid #0b4f4b;padding:6px">الكمية</th>
            ${db.warehouses.map(w => `<th style="border:1px solid #0b4f4b;padding:6px">${w.name}</th>`).join('')}
          </tr></thead>
          <tbody>${rowsHtml}</tbody>
        </table>
        <table style="width:100%;border-collapse:collapse;font-size:12px">
          <tr>
            <td style="width:32%;border:1px solid #0b4f4b;padding:7px 10px;background:#f4f9f8"><b>القيمة الأساسية</b></td>
            <td colspan="2" style="border:1px solid #0b4f4b;padding:7px 10px"><b>${fmtMoney(val)} ج.م</b></td>
          </tr>
          <tr>
            <td style="border:1px solid #0b4f4b;padding:7px 10px;background:#f4f9f8"><b>قيمة 14%</b></td>
            <td colspan="2" style="border:1px solid #0b4f4b;padding:7px 10px"><b>${fmtMoney(val14)} ج.م</b></td>
          </tr>
          <tr style="background:#eef8f6">
            <td style="border:1px solid #0b4f4b;padding:8px 10px;color:#073b39"><b>المبلغ الإجمالي (شامل 14%)</b></td>
            <td style="width:20%;border:1px solid #0b4f4b;padding:8px 10px;color:#0f766e"><b>${fmtMoney(grandTotal)} ج.م</b></td>
            <td style="border:1px solid #0b4f4b;padding:8px 10px;color:#14532d"><b>${grandTotalWords}</b></td>
          </tr>
        </table>
      </div>
    `);
  };

  return (
    <Modal
      open={!!invoice}
      onClose={onClose}
      wide
      title={`فاتورة وارد — ${invoice.no}`}
      subtitle={`المورد: ${invoice.supplier} · التاريخ: ${fmtDate(invoice.date)} · الإجمالي شامل 14%: ${fmtMoney(grandTotal)} ج.م`}
      footer={
        <>
          <WordButton
            onClick={async () => {
              try {
                await exportInvoiceToWord(invoice, db.company, db.products);
                toast(`تم تحميل فاتورة ${invoice.no} بصيغة Word (.docx)`);
              } catch {
                toast('تعذر إنشاء ملف Word', 'err');
              }
            }}
            label="تحميل Word"
          />
          <ExcelButton onClick={handleExcel} />
          <PrintButton onClick={handlePrint} />
          <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold cursor-pointer">
            إغلاق
          </button>
        </>
      }
    >
      <div className="mb-4 border border-[#dce6e3] rounded-xl overflow-hidden text-xs">
        <div className="flex items-center justify-between px-4 py-2.5 bg-white border-b border-[#edf3f1]">
          <span className="font-bold text-[#5c7471]">القيمة الأساسية</span>
          <span className="font-bold tabular-nums text-[#102523]">{fmtMoney(val)} ج.م</span>
        </div>
        <div className="flex items-center justify-between px-4 py-2.5 bg-[#f8fbfa] border-b border-[#edf3f1]">
          <span className="font-bold text-[#073b39]">قيمة 14%</span>
          <span className="font-extrabold tabular-nums text-[#0f766e]">{fmtMoney(val14)} ج.م</span>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 bg-[#eef8f6]">
          <div className="flex items-center gap-3">
            <span className="font-extrabold text-[#073b39]">المبلغ الإجمالي (شامل 14%):</span>
            <span className="text-sm font-extrabold tabular-nums text-[#0f766e]">{fmtMoney(grandTotal)} ج.م</span>
          </div>
          <span className="font-extrabold text-[#14532d]">{grandTotalWords}</span>
        </div>
      </div>
      <div className="overflow-x-auto border border-[#dce6e3] rounded-xl">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-[#f4f8f7] text-[#5c7471] border-b border-[#dce6e3]">
              <th className="py-2.5 px-3 text-right font-bold">الصنف</th>
              <th className="py-2.5 px-3 text-center font-bold">التشغيلة</th>
              <th className="py-2.5 px-3 text-center font-bold">الصلاحية</th>
              <th className="py-2.5 px-3 text-right font-bold">الإجمالي</th>
              {db.warehouses.map(w => (
                <th key={w.id} className="py-2.5 px-3 text-center font-bold">{w.name}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-[#edf3f1]">
            {invoice.lines.map((l, idx) => {
              const p = getProduct(l.productId);
              if (!p) return null;
              const map: Record<string, number> = {};
              l.alloc.forEach(a => { map[a.warehouseId] = a.strips; });
              return (
                <tr key={idx}>
                  <td className="py-2.5 px-3 font-bold">{p.name}</td>
                  <td className="py-2.5 px-3 text-center font-mono-num">{l.batch}</td>
                  <td className="py-2.5 px-3 text-center"><ExpiryTag date={l.expiry} /></td>
                  <td className="py-2.5 px-3 font-bold tabular-nums">{unitsText(l.strips, p)}</td>
                  {db.warehouses.map(w => (
                    <td key={w.id} className="py-2.5 px-3 text-center tabular-nums">
                      {map[w.id] ? unitsText(map[w.id], p) : '—'}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Modal>
  );
}

export function IssueDetailModal({
  issue,
  onClose,
  onEdit,
  onCreateSalesInvoice,
  onStartReturn,
  onPrintHtml
}: {
  issue: IssueOrder | null;
  onClose: () => void;
  onEdit?: (issue: IssueOrder) => void;
  onCreateSalesInvoice?: (issueId: string) => void;
  onStartReturn: (issueId: string) => void;
  onPrintHtml: (html: string) => void;
}) {
  const { db, getProduct, getWarehouse, getPartner, issueReturnStats, setIssueInvoiced, toast } = usePharmaStore();
  if (!issue) return null;
  const liveIssue = db.issues.find(i => i.id === issue.id) || issue;

  const wh = getWarehouse(issue.warehouseId);
  const customerPartner =
    getPartner(issue.customerId) ||
    db.partners.find(p => p.type === 'customer' && p.name === issue.customer);
  const customerInfo = resolveIssueCustomer(issue, db.partners);
  const val = calcIssueValue(issue, db.products);
  const rs = issueReturnStats(issue);
  const sortedLines = sortIssueLines(liveIssue.lines || [], db.products);
  const billableLines = sortedLines.filter(l => !isLineReceipt(l, getProduct(l.productId)));
  const receiptLines = sortedLines.filter(l => isLineReceipt(l, getProduct(l.productId)));
  const receiptGroups = getIssueReceipts(liveIssue, db.products);
  const isMixed = billableLines.length > 0 && receiptLines.length > 0;
  const invDisplayNo = liveIssue.invoiceNo && liveIssue.invoiceNo !== '—' ? liveIssue.invoiceNo : liveIssue.no;

  const handleWord = async (mode: 'all' | 'billable' = 'all') => {
    try {
      await exportIssueToWord(liveIssue, db.company, wh, db.products, { mode, customer: customerPartner });
      toast(
        mode === 'billable'
          ? `تم تحميل أذن صرف بضاعة الفاتورة ${liveIssue.no} بصيغة Word (.docx)`
          : `تم تحميل أذن الصرف ${liveIssue.no} بالكامل بصيغة Word (.docx) بدون أسعار`
      );
    } catch {
      toast('تعذر إنشاء ملف Word', 'err');
    }
  };

  const handleSalesInvoiceWord = async () => {
    try {
      await exportSalesInvoiceToWord(issue, db.company, wh, db.products, customerPartner);
      toast(`تم تحميل فاتورة المبيعات ${invDisplayNo} بصيغة Word (.docx)`);
    } catch {
      toast('تعذر إنشاء ملف الفاتورة', 'err');
    }
  };

  const handleReceiptWord = async (receiptType: ReceiptType) => {
    const g = receiptGroups.find(x => x.type === receiptType);
    try {
      await exportIssueReceiptToWord(issue, db.company, wh, db.products, { receiptType, customer: customerPartner });
      toast(`تم تحميل ${g?.label || 'الإيصال'} (${g?.receiptNo || issue.no}) بصيغة Word (.docx)`);
    } catch {
      toast('تعذر إنشاء ملف الإيصال', 'err');
    }
  };

  const handleExcel = () => {
    const headers = ['الكود', 'الصنف', 'النوع', 'رقم الإيصال', 'التشغيلة', 'الصلاحية', 'الكمية بالوحدات', 'الوحدات الأساسية', 'سعر الوحدة', 'القيمة'];
    const rows: (string | number)[][] = [];
    sortedLines.forEach(l => {
      const p = getProduct(l.productId);
      if (!p) return;
      const receipt = isLineReceipt(l, p);
      const rType = receipt ? getLineReceiptType(l, p) : undefined;
      const groupRecNo = rType ? (receiptGroups.find(g => g.type === rType)?.receiptNo || '') : '';
      const allocs = l.alloc?.length ? l.alloc : [{ batch: '—', expiry: '', strips: l.strips }];
      allocs.forEach(a => {
        const price = receipt ? 0 : l.pricePerStrip;
        rows.push([
          p.code,
          p.name,
          receipt ? receiptTypeLabel(rType) : 'فاتورة',
          groupRecNo || '—',
          a.batch,
          a.expiry ? fmtDate(a.expiry) : '—',
          unitsText(a.strips, p),
          a.strips,
          price,
          Number((a.strips * price).toFixed(2))
        ]);
      });
    });
    exportToExcel(`اذن_صرف_${issue.no}.xlsx`, `أذن ${issue.no}`, headers, rows);
    toast(`تم تصدير أذن الصرف ${issue.no} إلى Excel`);
  };

  const buildPrintDoc = (mode: 'invoice' | 'sales-invoice' | ReceiptType) => {
    const isSalesInv = mode === 'sales-invoice';
    const isRecPrint = mode === 'supplies' || mode === 'gift';
    const recGroup = isRecPrint ? receiptGroups.find(g => g.type === mode) : undefined;
    const recNo = recGroup?.receiptNo || '';
    const recTitle = recGroup?.label || '';
    const targetLines = isRecPrint
      ? (recGroup?.lines || [])
      : isSalesInv
        ? billableLines
        : sortedLines;

    let idx = 1;
    const rowsHtml: string[] = [];
    if (isSalesInv) {
      targetLines.forEach(l => {
        const p = getProduct(l.productId);
        if (!p) return;
        const unitPrice = l.pricePerStrip || p.price || 0;
        const lineVal = l.strips * unitPrice;
        rowsHtml.push(`<tr>
          <td style="border:1px solid #0b4f4b;padding:6px;text-align:center">${idx++}</td>
          <td style="border:1px solid #0b4f4b;padding:6px;text-align:center"><b>${escHtml(p.code)}</b></td>
          <td style="border:1px solid #0b4f4b;padding:6px"><b>${escHtml(p.name)}</b>${p.form ? `<br><span style="color:#555;font-size:10px">${escHtml(p.form)}</span>` : ''}</td>
          <td style="border:1px solid #0b4f4b;padding:6px;text-align:center"><b>${escHtml(unitsText(l.strips, p))}</b></td>
          <td style="border:1px solid #0b4f4b;padding:6px;text-align:center">${fmtMoney(unitPrice)} ج.م</td>
          <td style="border:1px solid #0b4f4b;padding:6px;text-align:center"><b>${fmtMoney(lineVal)} ج.م</b></td>
        </tr>`);
      });
    } else {
      targetLines.forEach(l => {
        const p = getProduct(l.productId);
        if (!p) return;
        const rec = isLineReceipt(l, p);
        const lineKind = rec ? receiptTypeLabel(getLineReceiptType(l, p)) : 'فاتورة';
        const allocs = l.alloc?.length ? l.alloc : [{ batch: '—', expiry: '', strips: l.strips }];
        allocs.forEach(a => {
          rowsHtml.push(`<tr>
            <td style="border:1px solid #0b4f4b;padding:6px;text-align:center">${idx++}</td>
            <td style="border:1px solid #0b4f4b;padding:6px"><b>${escHtml(p.code)}</b></td>
            <td style="border:1px solid #0b4f4b;padding:6px"><b>${escHtml(p.name)}</b><br><span style="color:#555;font-size:10px">${escHtml([p.form, lineKind].filter(Boolean).join(' — '))}</span></td>
            <td style="border:1px solid #0b4f4b;padding:6px;text-align:center">${escHtml(a.batch)}</td>
            <td style="border:1px solid #0b4f4b;padding:6px;text-align:center"><b>${a.expiry ? fmtDate(a.expiry) : '—'}</b></td>
            <td style="border:1px solid #0b4f4b;padding:6px"><b>${escHtml(unitsText(a.strips, p))}</b> (${fmtNum(a.strips)} ${escHtml(p.units[0]?.name || '')})</td>
          </tr>`);
        });
      });
    }

    const accentBg = mode === 'gift' ? '#f5f3ff' : mode === 'supplies' ? '#fffbeb' : '#eef8f6';
    const accentTitle = mode === 'gift' ? '#5b21b6' : mode === 'supplies' ? '#92400e' : '#073b39';
    const accentNo = mode === 'gift' ? '#6d28d9' : mode === 'supplies' ? '#b45309' : '#0f766e';
    const val14 = calc14Percent(val);
    const grandTotal = calcTotalWith14(val);
    const grandTotalWords = tafqeetEGP(grandTotal);

    const customerHeaderRow = `
      <tr style="background:#f4f9f8">
        <td colspan="3" style="padding:8px 10px;border:1px solid #9cc7bf;font-size:11px;line-height:1.7">
          <b style="color:#073b39">بيانات العميل:</b> <b>${escHtml(customerInfo.name)}</b>
          ${customerInfo.code ? ` &nbsp;|&nbsp; <b style="color:#073b39">كود العميل:</b> ${escHtml(customerInfo.code)}` : ''}
          ${customerInfo.contact ? ` &nbsp;|&nbsp; <b style="color:#073b39">المسؤول:</b> ${escHtml(customerInfo.contact)}` : ''}
          <br>
          <b style="color:#073b39">الهاتف:</b> ${escHtml(customerInfo.phone || '—')}
          &nbsp;|&nbsp; <b style="color:#073b39">العنوان:</b> ${escHtml(customerInfo.address || '—')}
          &nbsp;|&nbsp; <b style="color:#073b39">الرقم الضريبي:</b> ${escHtml(customerInfo.taxNo || '—')}
        </td>
      </tr>
    `;

    const salesTotalsHtml = isSalesInv
      ? `
        <table style="width:100%;border-collapse:collapse;font-size:12px;margin-top:12px">
          <tr>
            <td style="width:32%;border:1px solid #0b4f4b;padding:7px 10px;background:#f4f9f8"><b>القيمة الأساسية (قبل 14%)</b></td>
            <td colspan="2" style="border:1px solid #0b4f4b;padding:7px 10px"><b>${fmtMoney(val)} ج.م</b></td>
          </tr>
          <tr>
            <td style="border:1px solid #0b4f4b;padding:7px 10px;background:#f4f9f8"><b>قيمة 14%</b></td>
            <td colspan="2" style="border:1px solid #0b4f4b;padding:7px 10px"><b>${fmtMoney(val14)} ج.م</b></td>
          </tr>
          <tr style="background:#eef8f6">
            <td style="border:1px solid #0b4f4b;padding:8px 10px;color:#073b39"><b>المبلغ الإجمالي (شامل 14%)</b></td>
            <td style="width:20%;border:1px solid #0b4f4b;padding:8px 10px;color:#0f766e"><b>${fmtMoney(grandTotal)} ج.م</b></td>
            <td style="border:1px solid #0b4f4b;padding:8px 10px;color:#14532d"><b>${escHtml(grandTotalWords)}</b></td>
          </tr>
        </table>
      `
      : '';

    onPrintHtml(`
      <div style="font-family:Cairo,Arial,sans-serif;direction:rtl;color:#111">
        <table style="width:100%;border-collapse:collapse;border:2px solid #0b4f4b;margin-bottom:14px">
          <tr>
            <td style="width:34%;padding:8px 10px;border:1px solid #9cc7bf">
              <strong style="font-size:16px;color:#073b39">${escHtml(db.company.name)}</strong><br>
              <span style="font-size:11px"><b>العنوان:</b> ${escHtml(db.company.address)}</span><br>
              <span style="font-size:11px"><b>الهاتف:</b> ${escHtml(db.company.phone)}</span><br>
              <span style="font-size:11px"><b>الرقم الضريبي:</b> ${escHtml(db.company.taxNo || '—')}</span>
            </td>
            <td style="width:32%;padding:8px 10px;border:1px solid #9cc7bf;text-align:center;background:${accentBg}">
              <strong style="font-size:15px;color:${accentTitle}">${
                isSalesInv
                  ? 'فاتورة مبيعات'
                  : isRecPrint
                    ? escHtml(recTitle)
                    : 'أذن صرف مخزني'
              }</strong><br>
              <div style="font-family:monospace;font-size:14px;font-weight:bold;color:${accentNo};margin:4px 0">${
                isSalesInv
                  ? `فاتورة: ${escHtml(invDisplayNo)}`
                  : isRecPrint
                    ? `إيصال: ${escHtml(recNo)}`
                    : `أذن: ${escHtml(issue.no)}`
              }</div>
              <span style="font-size:11px">${isRecPrint || isSalesInv ? `<b>أذن الصرف:</b> ${escHtml(issue.no)} · ` : ''}<b>التاريخ:</b> ${fmtDate(issue.date)}</span>
            </td>
            <td style="width:34%;padding:8px 10px;border:1px solid #9cc7bf;font-size:11px">
              <b>العميل:</b> ${escHtml(customerInfo.name)}<br>
              <b>المخزن الصارف:</b> ${escHtml(wh?.name || '—')}<br>
              ${isRecPrint
                ? `<b>رقم أذن الصرف:</b> ${escHtml(issue.no)}<br><b>رقم الإيصال:</b> ${escHtml(recNo)}<br><b>نوع الإيصال:</b> ${escHtml(recTitle)}<br>`
                : `<b>رقم الفاتورة:</b> ${escHtml(invDisplayNo)}<br>${isSalesInv ? `<b>رقم أذن الصرف:</b> ${escHtml(issue.no)}<br>` : ''}`}
              <b>المندوب:</b> ${escHtml(db.company.sales)}
            </td>
          </tr>
          ${customerHeaderRow}
        </table>
        <table style="width:100%;border-collapse:collapse;font-size:11px">
          <thead>
            <tr style="background:#0f766e;color:#fff">
              <th style="border:1px solid #0b4f4b;padding:6px">م</th>
              <th style="border:1px solid #0b4f4b;padding:6px">الكود</th>
              <th style="border:1px solid #0b4f4b;padding:6px;text-align:right">${isSalesInv ? 'الصنف' : 'هيكل المواد'}</th>
              ${isSalesInv
                ? `
                  <th style="border:1px solid #0b4f4b;padding:6px">الكمية</th>
                  <th style="border:1px solid #0b4f4b;padding:6px">سعر الوحدة</th>
                  <th style="border:1px solid #0b4f4b;padding:6px">الإجمالي</th>
                `
                : `
                  <th style="border:1px solid #0b4f4b;padding:6px">التشغيلة</th>
                  <th style="border:1px solid #0b4f4b;padding:6px">تاريخ الصلاحية</th>
                  <th style="border:1px solid #0b4f4b;padding:6px;text-align:right">الكمية</th>
                `}
            </tr>
          </thead>
          <tbody>${rowsHtml.join('')}</tbody>
        </table>
        ${salesTotalsHtml}
        <table style="width:100%;border-collapse:collapse;border:1.5px solid #0b4f4b;margin-top:22px;font-size:11.5px">
          <tr>
            <td style="width:33%;padding:14px;border:1px solid #9cc7bf;text-align:center"><b>المُسلِّم</b><br><br>${escHtml(db.company.sales)}</td>
            <td style="width:33%;padding:14px;border:1px solid #9cc7bf;text-align:center"><b>تاريخ اليوم</b><br><br><b>${fmtDate(todayISO())}</b></td>
            <td style="width:34%;padding:14px;border:1px solid #9cc7bf;text-align:center"><b>${isRecPrint || isSalesInv ? 'توقيع المستلم / العميل' : 'التوقيع'}</b><br><br>............................</td>
          </tr>
        </table>
      </div>
    `);
  };

  const receiptSummarySubtitle = receiptGroups.length > 0
    ? ` · ${receiptGroups.map(g => `${g.label} (${g.receiptNo})`).join(' + ')}`
    : '';

  return (
    <Modal
      open={!!issue}
      onClose={onClose}
      wide
      title={`أذن صرف رقم ${issue.no}${receiptSummarySubtitle}`}
      subtitle={`العميل: ${customerInfo.name} · المخزن: ${wh?.name || '—'} · فاتورة: ${issue.invoiceNo || '—'} · ${fmtDate(issue.date)}`}
      footer={
        <>
          {billableLines.length > 0 && (
            <>
              <WordButton onClick={handleSalesInvoiceWord} label="فاتورة المبيعات (Word)" />
              <PrintButton onClick={() => buildPrintDoc('sales-invoice')} label="طباعة الفاتورة" />
            </>
          )}
          <WordButton onClick={() => handleWord('all')} label="أذن صرف (Word)" />
          <PrintButton onClick={() => buildPrintDoc('invoice')} label="طباعة أذن الصرف" />
          {receiptGroups.map(g => (
            <React.Fragment key={g.type}>
              <WordButton onClick={() => handleReceiptWord(g.type)} label={`${g.label} (Word)`} />
              <PrintButton onClick={() => buildPrintDoc(g.type)} label={`طباعة ${g.label}`} />
            </React.Fragment>
          ))}
          <ExcelButton onClick={handleExcel} />
          {!liveIssue.closed && !liveIssue.invoiced && billableLines.length > 0 && onCreateSalesInvoice && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onCreateSalesInvoice(liveIssue.id);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#b7dfd7] bg-[#eef8f6] text-[#0f766e] hover:bg-[#dff2ee] text-xs font-extrabold cursor-pointer"
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>عمل فاتورة مبيعات</span>
            </button>
          )}
          {onEdit && !liveIssue.closed && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onEdit(liveIssue);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#fde68a] bg-[#fffbeb] text-[#92400e] hover:bg-[#fef3c7] text-xs font-bold cursor-pointer"
            >
              <Pencil className="w-3.5 h-3.5" />
              <span>تعديل الأذن</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              onClose();
              onStartReturn(liveIssue.id);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#ddd6fe] bg-[#f5f3ff] text-[#6d28d9] hover:bg-[#ede9fe] text-xs font-bold cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>عمل مرتجع عميل</span>
          </button>
          <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold cursor-pointer">
            إغلاق
          </button>
        </>
      }
    >
      <div
        className={`mb-3 rounded-xl px-4 py-2.5 text-xs flex flex-wrap items-center justify-between gap-2 border ${
          liveIssue.closed || liveIssue.invoiced
            ? 'bg-[#ecfdf5] border-[#a7f3d0] text-[#065f46]'
            : 'bg-[#fffbeb] border-[#fde68a] text-[#92400e]'
        }`}
      >
        <label
          className={`inline-flex items-center gap-2 font-bold select-none ${
            liveIssue.invoicedByFlow ? 'cursor-default' : 'cursor-pointer'
          }`}
        >
          <input
            type="checkbox"
            checked={Boolean(liveIssue.invoiced)}
            disabled={Boolean(liveIssue.invoicedByFlow)}
            onChange={async e => {
              const chk = e.target.checked;
              try {
                await setIssueInvoiced(liveIssue.id, chk);
                toast(
                  chk
                    ? `تم التعليم على أذن الصرف ${liveIssue.no}: تم عمل فاتورة وإغلاقه`
                    : `تم إعادة فتح أذن الصرف ${liveIssue.no}`
                );
              } catch (err) {
                toast(err instanceof Error ? err.message : 'تعذر تحديث الحالة', 'err');
              }
            }}
            className="accent-[#0f766e] w-4 h-4 cursor-pointer disabled:cursor-not-allowed"
          />
          <span>
            {liveIssue.invoicedByFlow
              ? `مغلق — تم إصدار فاتورة مبيعات رقم ${liveIssue.invoiceNo}`
              : liveIssue.invoiced
                ? 'تم عمل فاتورة (أذن مغلق — لا يحتاج لعمل فاتورة مبيعات)'
                : 'لم يتم عمل فاتورة بعد (الأذن مفتوح)'}
          </span>
        </label>
        {liveIssue.closed && (
          <span className="inline-flex items-center gap-1 text-[11px] font-extrabold">
            <Lock className="w-3.5 h-3.5" />
            <span>أذن مغلق</span>
          </span>
        )}
      </div>

      <div className="mb-3 bg-[#f4f9f8] border border-[#dce6e3] rounded-xl px-4 py-2.5 text-xs flex flex-wrap items-center gap-x-5 gap-y-1">
        <div>
          <span className="text-[#5c7471] font-bold">العميل: </span>
          <span className="font-extrabold text-[#102523]">{customerInfo.name}</span>
          {customerInfo.code && <span className="font-mono-num text-[#0f766e] mr-1.5">({customerInfo.code})</span>}
        </div>
        {customerInfo.phone && (
          <div>
            <span className="text-[#5c7471] font-bold">الهاتف: </span>
            <span className="font-semibold text-[#102523]">{customerInfo.phone}</span>
          </div>
        )}
        {customerInfo.address && (
          <div>
            <span className="text-[#5c7471] font-bold">العنوان: </span>
            <span className="font-semibold text-[#102523]">{customerInfo.address}</span>
          </div>
        )}
        {customerInfo.taxNo && (
          <div>
            <span className="text-[#5c7471] font-bold">الرقم الضريبي: </span>
            <span className="font-mono-num font-semibold text-[#102523]">{customerInfo.taxNo}</span>
          </div>
        )}
        {customerInfo.contact && (
          <div>
            <span className="text-[#5c7471] font-bold">المسؤول: </span>
            <span className="font-semibold text-[#102523]">{customerInfo.contact}</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
        <div className="bg-[#f8fbfa] border border-[#dce6e3] rounded-xl p-3">
          <div className="text-[11px] text-[#5c7471]">رقم أذن الصرف</div>
          <div className="text-sm font-extrabold font-mono-num text-[#0f766e] mt-0.5">{issue.no}</div>
        </div>
        <div className="bg-[#f8fbfa] border border-[#dce6e3] rounded-xl p-3">
          <div className="text-[11px] text-[#5c7471]">قيمة الفاتورة ({billableLines.length} بند)</div>
          <div className="text-sm font-extrabold tabular-nums mt-0.5">{fmtMoney(val)} ج.م</div>
          {val > 0 && (
            <div className="text-[11px] font-bold text-[#0f766e] tabular-nums mt-0.5">
              شامل 14%: {fmtMoney(calcTotalWith14(val))} ج.م
            </div>
          )}
        </div>
        {receiptGroups.length > 1 ? (
          <div className="bg-[#fffbeb] border border-[#fde68a] rounded-xl p-3 space-y-1">
            {receiptGroups.map(g => (
              <div key={g.type} className="flex items-center justify-between gap-2 text-[11px]">
                <span className={g.type === 'gift' ? 'font-bold text-[#6d28d9]' : 'font-bold text-[#92400e]'}>
                  {g.label} ({g.receiptNo})
                </span>
                <span className="font-extrabold tabular-nums text-[#102523]">{fmtNum(g.totalStrips)}</span>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-[#fffbeb] border border-[#fde68a] rounded-xl p-3">
            <div className="text-[11px] text-[#92400e]">
              {receiptGroups[0] ? `${receiptGroups[0].label} (${receiptGroups[0].receiptNo})` : 'بنود الإيصال'}
            </div>
            <div className="text-sm font-extrabold text-[#b45309] tabular-nums mt-0.5">{fmtNum(issue.suppliesStrips)} وحدة</div>
          </div>
        )}
        <div className="bg-[#f8fbfa] border border-[#dce6e3] rounded-xl p-3">
          <div className="text-[11px] text-[#5c7471]">حالة المرتجع</div>
          <div className="text-sm font-extrabold mt-0.5">
            {rs.status === 'full' ? (
              <span className="text-[#dc2626]">مرتجع كلي</span>
            ) : rs.status === 'partial' ? (
              <span className="text-[#6d28d9]">مرتجع جزئي ({fmtNum(rs.totalReturned)})</span>
            ) : (
              <span className="text-[#047857]">مسلّم بالكامل</span>
            )}
          </div>
        </div>
      </div>

      {val > 0 && (
        <div className="mb-4 border border-[#dce6e3] rounded-xl overflow-hidden text-xs">
          <div className="flex items-center justify-between px-4 py-2 bg-white border-b border-[#edf3f1]">
            <span className="font-bold text-[#5c7471]">القيمة الأساسية</span>
            <span className="font-bold tabular-nums">{fmtMoney(val)} ج.م</span>
          </div>
          <div className="flex items-center justify-between px-4 py-2 bg-[#f8fbfa] border-b border-[#edf3f1]">
            <span className="font-bold text-[#073b39]">قيمة 14%</span>
            <span className="font-extrabold text-[#0f766e] tabular-nums">{fmtMoney(calc14Percent(val))} ج.م</span>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 bg-[#eef8f6]">
            <div className="flex items-center gap-2.5">
              <span className="font-extrabold text-[#073b39]">المبلغ الإجمالي (شامل 14%):</span>
              <span className="text-sm font-extrabold text-[#0f766e] tabular-nums">{fmtMoney(calcTotalWith14(val))} ج.م</span>
            </div>
            <span className="font-extrabold text-[#14532d]">{tafqeetEGP(calcTotalWith14(val))}</span>
          </div>
        </div>
      )}

      <div className="overflow-x-auto border border-[#dce6e3] rounded-xl">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-[#f4f8f7] text-[#5c7471] border-b border-[#dce6e3]">
              <th className="py-2.5 px-3 text-right font-bold">الصنف</th>
              <th className="py-2.5 px-3 text-center font-bold">التصنيف</th>
              <th className="py-2.5 px-3 text-right font-bold">التشغيلات والصلاحيات (FEFO)</th>
              <th className="py-2.5 px-3 text-right font-bold">الكمية</th>
              <th className="py-2.5 px-3 text-left font-bold">القيمة</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#edf3f1]">
            {sortedLines.map((l, idx) => {
              const p = getProduct(l.productId);
              if (!p) return null;
              const receipt = isLineReceipt(l, p);
              const rLabel = receipt ? receiptTypeLabel(getLineReceiptType(l, p)) : 'فاتورة';
              return (
                <tr key={idx}>
                  <td className="py-2.5 px-3">
                    <div className="font-bold text-[#102523]">{p.name}</div>
                    <div className="text-[11px] text-[#5c7471]">{p.code}</div>
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className={`text-[11px] font-bold ${receipt ? 'text-[#b45309]' : 'text-[#0f766e]'}`}>
                      {rLabel}
                    </span>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="space-y-1">
                      {(l.alloc || []).map((a, ai) => (
                        <div key={ai} className="text-[11px] text-[#3b5653] tabular-nums">
                          لوت <b className="font-mono-num">{a.batch}</b> · {fmtDate(a.expiry)} · ({unitsText(a.strips, p)})
                        </div>
                      ))}
                    </div>
                  </td>
                  <td className="py-2.5 px-3 font-bold tabular-nums">{unitsText(l.strips, p)}</td>
                  <td className="py-2.5 px-3 text-left font-bold tabular-nums">
                    {receipt ? <span className="text-[#b45309] font-normal">{rLabel}</span> : `${fmtMoney(l.strips * l.pricePerStrip)} ج.م`}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Modal>
  );
}

export function ReturnDetailModal({
  ret,
  onClose,
  onPrintHtml
}: {
  ret: CustomerReturn | null;
  onClose: () => void;
  onPrintHtml: (html: string) => void;
}) {
  const { db, getProduct, getWarehouse, toast } = usePharmaStore();
  if (!ret) return null;
  const wh = getWarehouse(ret.warehouseId);

  const handleWord = async () => {
    try {
      await exportReturnToWord(ret, wh, db.products, db.company);
      toast(`تم تحميل مرتجع ${ret.no} بصيغة Word (.docx)`);
    } catch {
      toast('تعذر إنشاء ملف Word', 'err');
    }
  };

  const handleExcel = () => {
    const headers = ['الكود', 'الصنف', 'التشغيلة', 'الصلاحية', 'الكمية المرتجعة', 'الوحدات الأساسية', 'القيمة', 'سبب الرفض'];
    const rows = ret.lines.map(l => {
      const p = getProduct(l.productId);
      return [
        p?.code || '',
        p?.name || '',
        l.batch,
        l.expiry ? fmtDate(l.expiry) : '—',
        unitsText(l.strips, p),
        l.strips,
        Number((l.strips * (l.pricePerStrip || 0)).toFixed(2)),
        l.reason || ret.reason || '—'
      ];
    });
    exportToExcel(`مرتجع_${ret.no}.xlsx`, ret.no, headers, rows);
    toast(`تم تصدير مرتجع ${ret.no} إلى Excel`);
  };

  const handlePrint = () => {
    const rowsHtml = ret.lines.map((l, i) => {
      const p = getProduct(l.productId);
      return `<tr>
        <td style="border:1px solid #0b4f4b;padding:6px">${i + 1}</td>
        <td style="border:1px solid #0b4f4b;padding:6px">${p?.name || '—'}</td>
        <td style="border:1px solid #0b4f4b;padding:6px">${l.batch}</td>
        <td style="border:1px solid #0b4f4b;padding:6px">${l.expiry ? fmtDate(l.expiry) : '—'}</td>
        <td style="border:1px solid #0b4f4b;padding:6px">${unitsText(l.strips, p)}</td>
        <td style="border:1px solid #0b4f4b;padding:6px">${l.reason || ret.reason || '—'}</td>
      </tr>`;
    }).join('');
    onPrintHtml(`
      <div style="font-family:Cairo,Arial,sans-serif;direction:rtl;color:#111">
        <h2>أذن مرتجع عميل — ${ret.no}</h2>
        <p>العميل: ${ret.customer} · أذن الصرف: ${ret.issueNo} · النوع: ${ret.returnType === 'full' ? 'مرتجع كلي' : 'مرتجع جزئي'} · المخزن المستلم: ${wh?.name || '—'}</p>
        <table style="width:100%;border-collapse:collapse;font-size:11px">
          <thead><tr style="background:#6d28d9;color:#fff">
            <th style="border:1px solid #4c1d95;padding:6px">م</th>
            <th style="border:1px solid #4c1d95;padding:6px">الصنف</th>
            <th style="border:1px solid #4c1d95;padding:6px">التشغيلة</th>
            <th style="border:1px solid #4c1d95;padding:6px">الصلاحية</th>
            <th style="border:1px solid #4c1d95;padding:6px">الكمية المرتجعة</th>
            <th style="border:1px solid #4c1d95;padding:6px">السبب</th>
          </tr></thead>
          <tbody>${rowsHtml}</tbody>
        </table>
      </div>
    `);
  };

  return (
    <Modal
      open={!!ret}
      onClose={onClose}
      wide
      title={`أذن مرتجع عميل — ${ret.no}`}
      subtitle={`العميل: ${ret.customer} · أذن الصرف: ${ret.issueNo} · المخزن المستلم: ${wh?.name || '—'} · ${fmtDate(ret.date)}`}
      footer={
        <>
          <WordButton onClick={handleWord} label="فتح في Word" />
          <ExcelButton onClick={handleExcel} />
          <PrintButton onClick={handlePrint} />
          <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold cursor-pointer">
            إغلاق
          </button>
        </>
      }
    >
      <div className="overflow-x-auto border border-[#dce6e3] rounded-xl">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-[#f4f8f7] text-[#5c7471] border-b border-[#dce6e3]">
              <th className="py-2.5 px-3 text-right font-bold">الصنف</th>
              <th className="py-2.5 px-3 text-center font-bold">التشغيلة</th>
              <th className="py-2.5 px-3 text-center font-bold">الصلاحية</th>
              <th className="py-2.5 px-3 text-right font-bold">الكمية المرتجعة</th>
              <th className="py-2.5 px-3 text-right font-bold">سبب الرفض</th>
              <th className="py-2.5 px-3 text-left font-bold">القيمة</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#edf3f1]">
            {ret.lines.map((l, idx) => {
              const p = getProduct(l.productId);
              return (
                <tr key={idx}>
                  <td className="py-2.5 px-3 font-bold">{p?.name || '—'}</td>
                  <td className="py-2.5 px-3 text-center font-mono-num">{l.batch}</td>
                  <td className="py-2.5 px-3 text-center">{l.expiry ? <ExpiryTag date={l.expiry} /> : '—'}</td>
                  <td className="py-2.5 px-3 font-bold tabular-nums">{unitsText(l.strips, p)}</td>
                  <td className="py-2.5 px-3 text-[#5c7471]">{l.reason || ret.reason || '—'}</td>
                  <td className="py-2.5 px-3 text-left font-bold tabular-nums">{fmtMoney(l.strips * (l.pricePerStrip || 0))} ج.م</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Modal>
  );
}

export function TransferDetailModal({
  transfer,
  onClose,
  onPrintHtml
}: {
  transfer: TransferOrder | null;
  onClose: () => void;
  onPrintHtml: (html: string) => void;
}) {
  const { db, getProduct, getWarehouse, toast } = usePharmaStore();
  if (!transfer) return null;
  const fromWh = getWarehouse(transfer.from);
  const toWh = getWarehouse(transfer.to);

  const handleWord = async () => {
    try {
      await exportTransferToWord(transfer, fromWh, toWh, db.products, db.company);
      toast(`تم تحميل أذن التحويل ${transfer.no} بصيغة Word (.docx)`);
    } catch {
      toast('تعذر إنشاء ملف Word', 'err');
    }
  };

  const handleExcel = () => {
    const headers = ['الكود', 'الصنف', 'التشغيلة', 'الصلاحية', 'الكمية المحولة', 'الوحدات الأساسية'];
    const rows: (string | number)[][] = [];
    transfer.lines.forEach(l => {
      const p = getProduct(l.productId);
      const allocs = l.alloc?.length ? l.alloc : [{ batch: '—', expiry: '', strips: l.strips }];
      allocs.forEach(a => {
        rows.push([p?.code || '', p?.name || '', a.batch, a.expiry ? fmtDate(a.expiry) : '—', unitsText(a.strips, p), a.strips]);
      });
    });
    exportToExcel(`اذن_تحويل_${transfer.no}.xlsx`, transfer.no, headers, rows);
    toast(`تم تصدير التحويل ${transfer.no} إلى Excel`);
  };

  const handlePrint = () => {
    const rowsHtml = transfer.lines.map((l, i) => {
      const p = getProduct(l.productId);
      return `<tr>
        <td style="border:1px solid #0b4f4b;padding:6px">${i + 1}</td>
        <td style="border:1px solid #0b4f4b;padding:6px">${p?.name || '—'}</td>
        <td style="border:1px solid #0b4f4b;padding:6px">${unitsText(l.strips, p)}</td>
      </tr>`;
    }).join('');
    onPrintHtml(`
      <div style="font-family:Cairo,Arial,sans-serif;direction:rtl;color:#111">
        <h2>أذن تحويل مخزني — ${transfer.no}</h2>
        <p>من: ${fromWh?.name || '—'} · إلى: ${toWh?.name || '—'} · التاريخ: ${fmtDate(transfer.date)}</p>
        <table style="width:100%;border-collapse:collapse;font-size:11px">
          <thead><tr style="background:#0f766e;color:#fff">
            <th style="border:1px solid #0b4f4b;padding:6px">م</th>
            <th style="border:1px solid #0b4f4b;padding:6px">الصنف</th>
            <th style="border:1px solid #0b4f4b;padding:6px">الكمية المحولة</th>
          </tr></thead>
          <tbody>${rowsHtml}</tbody>
        </table>
      </div>
    `);
  };

  return (
    <Modal
      open={!!transfer}
      onClose={onClose}
      wide
      title={`أذن تحويل مخزني — ${transfer.no}`}
      subtitle={`من ${fromWh?.name || '—'} ← إلى ${toWh?.name || '—'} · ${fmtDate(transfer.date)}`}
      footer={
        <>
          <WordButton onClick={handleWord} label="فتح في Word" />
          <ExcelButton onClick={handleExcel} />
          <PrintButton onClick={handlePrint} />
          <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold cursor-pointer">
            إغلاق
          </button>
        </>
      }
    >
      <div className="overflow-x-auto border border-[#dce6e3] rounded-xl">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-[#f4f8f7] text-[#5c7471] border-b border-[#dce6e3]">
              <th className="py-2.5 px-3 text-right font-bold">الصنف</th>
              <th className="py-2.5 px-3 text-right font-bold">التشغيلات</th>
              <th className="py-2.5 px-3 text-right font-bold">الكمية</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#edf3f1]">
            {transfer.lines.map((l, idx) => {
              const p = getProduct(l.productId);
              return (
                <tr key={idx}>
                  <td className="py-2.5 px-3 font-bold">{p?.name || '—'}</td>
                  <td className="py-2.5 px-3 text-[11px] text-[#3b5653]">
                    {(l.alloc || []).map((a, ai) => (
                      <div key={ai}>لوت {a.batch} · {fmtDate(a.expiry)} · {unitsText(a.strips, p)}</div>
                    ))}
                  </td>
                  <td className="py-2.5 px-3 font-bold tabular-nums">{unitsText(l.strips, p)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Modal>
  );
}
