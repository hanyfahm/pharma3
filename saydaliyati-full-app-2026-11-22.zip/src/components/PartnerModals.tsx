import React, { useEffect, useState } from 'react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { Partner, PartnerType } from '../types/pharma';
import { Modal } from './ui/CommonUI';

export function PartnerFormModal({
  open,
  defaultType,
  editingPartner,
  onClose,
  onSaved
}: {
  open: boolean;
  defaultType: PartnerType;
  editingPartner: Partner | null;
  onClose: () => void;
  onSaved?: (p: Partner) => void;
}) {
  const { db, addPartner, updatePartner, toast } = usePharmaStore();
  const [type, setType] = useState<PartnerType>(defaultType);
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [taxNo, setTaxNo] = useState('');
  const [contact, setContact] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (!open) return;
    if (editingPartner) {
      setType(editingPartner.type);
      setCode(editingPartner.code);
      setName(editingPartner.name);
      setPhone(editingPartner.phone);
      setAddress(editingPartner.address);
      setTaxNo(editingPartner.taxNo);
      setContact(editingPartner.contact);
      setNotes(editingPartner.notes);
    } else {
      setType(defaultType);
      const prefix = defaultType === 'supplier' ? 'SUP' : 'CUS';
      const count = db.partners.filter(p => p.type === defaultType).length + 1;
      setCode(`${prefix}-${String(count).padStart(3, '0')}`);
      setName('');
      setPhone('');
      setAddress('');
      setTaxNo('');
      setContact('');
      setNotes('');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editingPartner, defaultType]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast('أدخل اسم الجهة أولًا', 'err');
      return;
    }
    const payload = {
      type,
      code: code.trim().toUpperCase(),
      name: name.trim(),
      phone: phone.trim(),
      address: address.trim(),
      taxNo: taxNo.trim(),
      contact: contact.trim(),
      notes: notes.trim()
    };
    try {
      if (editingPartner) {
        await updatePartner(editingPartner.id, payload);
        toast(`تم تعديل بيانات «${payload.name}»`);
      } else {
        const created = await addPartner(payload);
        toast(`تمت إضافة «${created.name}»`);
        onSaved?.(created);
      }
      onClose();
    } catch (err) {
      toast(err instanceof Error ? err.message : 'تعذر حفظ بيانات الجهة', 'err');
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={
        editingPartner
          ? `تعديل بيانات ${editingPartner.name}`
          : defaultType === 'customer'
            ? 'إضافة عميل جديد'
            : 'إضافة مورد جديد'
      }
      subtitle={
        (editingPartner?.type || defaultType) === 'customer'
          ? 'سجّل بيانات العميل لتظهر في أذون الصرف وفواتير المبيعات والمرتجعات'
          : 'سجّل بيانات المورد لتظهر في فواتير الوارد والأصناف'
      }
      footer={
        <>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
          >
            إلغاء
          </button>
          <button
            type="submit"
            form="partner-form"
            className="px-5 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] cursor-pointer"
          >
            حفظ
          </button>
        </>
      }
    >
      <form id="partner-form" onSubmit={handleSubmit} className="space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>النوع</span>
            <select
              value={type}
              onChange={e => setType(e.target.value as PartnerType)}
              className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white focus:outline-none focus:border-[#0f766e]"
            >
              <option value="supplier">مورد</option>
              <option value="customer">عميل</option>
            </select>
          </label>
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>الكود</span>
            <input
              value={code}
              onChange={e => setCode(e.target.value)}
              className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] font-mono-num text-xs focus:outline-none focus:border-[#0f766e]"
            />
          </label>
          <label className="block text-xs font-bold text-[#233d3a] sm:col-span-2">
            <span>الاسم *</span>
            <input
              value={name}
              onChange={e => setName(e.target.value)}
              required
              className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs focus:outline-none focus:border-[#0f766e]"
            />
          </label>
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>الهاتف</span>
            <input
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs focus:outline-none focus:border-[#0f766e]"
            />
          </label>
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>الشخص المسؤول</span>
            <input
              value={contact}
              onChange={e => setContact(e.target.value)}
              className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs focus:outline-none focus:border-[#0f766e]"
            />
          </label>
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>الرقم الضريبي</span>
            <input
              value={taxNo}
              onChange={e => setTaxNo(e.target.value)}
              className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs focus:outline-none focus:border-[#0f766e]"
            />
          </label>
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>العنوان</span>
            <input
              value={address}
              onChange={e => setAddress(e.target.value)}
              className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs focus:outline-none focus:border-[#0f766e]"
            />
          </label>
        </div>
        <label className="block text-xs font-bold text-[#233d3a]">
          <span>ملاحظات</span>
          <input
            value={notes}
            onChange={e => setNotes(e.target.value)}
            className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs focus:outline-none focus:border-[#0f766e]"
          />
        </label>
      </form>
    </Modal>
  );
}

export function CompanyModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { db, updateCompany, toast } = usePharmaStore();
  const [name, setName] = useState(db.company.name);
  const [address, setAddress] = useState(db.company.address);
  const [gov, setGov] = useState(db.company.gov);
  const [phone, setPhone] = useState(db.company.phone);
  const [taxNo, setTaxNo] = useState(db.company.taxNo);
  const [sales, setSales] = useState(db.company.sales);

  useEffect(() => {
    if (!open) return;
    setName(db.company.name);
    setAddress(db.company.address);
    setGov(db.company.gov);
    setPhone(db.company.phone);
    setTaxNo(db.company.taxNo);
    setSales(db.company.sales);
  }, [open, db.company]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateCompany({
        name: name.trim() || 'صيدليتي',
        address: address.trim(),
        gov: gov.trim(),
        phone: phone.trim(),
        taxNo: taxNo.trim(),
        sales: sales.trim()
      });
      toast('تم تحديث بيانات الشركة للترويسة والطباعة');
      onClose();
    } catch (err) {
      toast(err instanceof Error ? err.message : 'تعذر تحديث بيانات الشركة', 'err');
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="بيانات الصيدلية / الشركة"
      subtitle="تظهر هذه البيانات في ترويسة أذون الصرف في Word والمطبوعات"
      footer={
        <>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] cursor-pointer"
          >
            إلغاء
          </button>
          <button
            type="submit"
            form="company-form"
            className="px-5 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold cursor-pointer"
          >
            حفظ البيانات
          </button>
        </>
      }
    >
      <form id="company-form" onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <label className="block text-xs font-bold text-[#233d3a] sm:col-span-2">
          <span>اسم الشركة / الصيدلية</span>
          <input value={name} onChange={e => setName(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs" required />
        </label>
        <label className="block text-xs font-bold text-[#233d3a]">
          <span>العنوان</span>
          <input value={address} onChange={e => setAddress(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs" />
        </label>
        <label className="block text-xs font-bold text-[#233d3a]">
          <span>المحافظة</span>
          <input value={gov} onChange={e => setGov(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs" />
        </label>
        <label className="block text-xs font-bold text-[#233d3a]">
          <span>الهاتف</span>
          <input value={phone} onChange={e => setPhone(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs" />
        </label>
        <label className="block text-xs font-bold text-[#233d3a]">
          <span>الرقم الضريبي</span>
          <input value={taxNo} onChange={e => setTaxNo(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs" />
        </label>
        <label className="block text-xs font-bold text-[#233d3a] sm:col-span-2">
          <span>المُسلِّم / المندوب الافتراضي</span>
          <input value={sales} onChange={e => setSales(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs" />
        </label>
      </form>
    </Modal>
  );
}
