import React, { useMemo, useState } from 'react';
import { PackagePlus, Search, Send } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import { expiryState, fmtMoney, fmtNum, unitsText } from '../utils/format';
import { ExpiryTag, Modal } from './ui/CommonUI';

export function QuickStockDrawer({
  open,
  initialQuery = '',
  onClose,
  onGoIssue,
  onAddProduct
}: {
  open: boolean;
  initialQuery?: string;
  onClose: () => void;
  onGoIssue: () => void;
  onAddProduct: () => void;
}) {
  const { db, availableStock, totalProductStock, nearestExpiry } = usePharmaStore();
  const [search, setSearch] = useState(initialQuery);
  const [filter, setFilter] = useState<'all' | 'in-stock' | 'soon' | 'empty'>('all');

  React.useEffect(() => {
    if (open && initialQuery) {
      setSearch(initialQuery);
    }
  }, [open, initialQuery]);

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return db.products
      .map(p => {
        const total = totalProductStock(p.id);
        const near = nearestExpiry(p.id);
        const st = near ? expiryState(near) : null;
        return { product: p, total, near, st };
      })
      .filter(({ product, total, st }) => {
        if (q && !`${product.name} ${product.code} ${product.form}`.toLowerCase().includes(q)) return false;
        if (filter === 'in-stock') return total > 0;
        if (filter === 'soon') return total > 0 && st === 'soon';
        if (filter === 'empty') return total <= 0;
        return true;
      })
      .sort((a, b) => b.total - a.total);
  }, [db.products, search, filter, totalProductStock, nearestExpiry]);

  return (
    <Modal
      open={open}
      onClose={onClose}
      wide
      title="فحص الرصيد الفوري للمخازن"
      subtitle="استعلام سريع عن الكميات المتاحة والسارية لكل صنف في المخزن الرئيسي والفروع"
      footer={
        <>
          <button
            type="button"
            onClick={() => {
              onClose();
              onAddProduct();
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#b7dfd7] bg-[#eef8f6] text-xs font-bold text-[#0f766e] hover:bg-[#dff2ee] cursor-pointer"
          >
            <PackagePlus className="w-3.5 h-3.5" />
            <span>إضافة منتج جديد</span>
          </button>
          <button
            type="button"
            onClick={() => {
              onClose();
              onGoIssue();
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>عمل أذن صرف</span>
          </button>
        </>
      }
    >
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-[#6b8481] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="ابحث بالاسم أو الكود لمعرفة الرصيد..."
              className="w-full pr-9 pl-3 py-2 text-xs bg-[#f8fbfa] border border-[#dce6e3] rounded-lg focus:outline-none focus:border-[#0f766e]"
            />
          </div>
          <div className="flex items-center gap-1 p-1 bg-[#e9f0ee] rounded-lg">
            {(
              [
                ['all', 'الكل'],
                ['in-stock', 'المتوفر'],
                ['soon', 'صلاحية قريبة'],
                ['empty', 'نافد']
              ] as const
            ).map(([k, lbl]) => (
              <button
                key={k}
                type="button"
                onClick={() => setFilter(k)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-colors whitespace-nowrap cursor-pointer ${
                  filter === k ? 'bg-white text-[#102523] shadow-sm' : 'text-[#5c7471] hover:text-[#102523]'
                }`}
              >
                {lbl}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto border border-[#dce6e3] rounded-xl">
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="bg-[#f4f8f7] text-[#5c7471] border-b border-[#dce6e3]">
                <th className="py-2 px-3 text-right font-bold">الصنف</th>
                <th className="py-2 px-2 text-center font-bold">الإجمالي</th>
                {db.warehouses.map(w => (
                  <th key={w.id} className="py-2 px-2 text-center font-bold whitespace-nowrap">
                    {w.name}
                  </th>
                ))}
                <th className="py-2 px-2 text-center font-bold">أقرب صلاحية</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#edf3f1]">
              {rows.length ? (
                rows.map(({ product: p, total, near }) => (
                  <tr key={p.id} className="hover:bg-[#f9fcfb]">
                    <td className="py-2 px-3">
                      <div className="font-bold text-[#102523]">{p.name}</div>
                      <div className="text-[10.5px] text-[#5c7471] tabular-nums">
                        {p.code} · {fmtMoney(p.price)} ج.م/{p.units[0]?.name}
                      </div>
                    </td>
                    <td className="py-2 px-2 text-center tabular-nums">
                      <span className={`font-extrabold ${total > 0 ? 'text-[#0f766e]' : 'text-[#dc2626]'}`}>
                        {total > 0 ? unitsText(total, p) : 'نافد'}
                      </span>
                      {total > 0 && (
                        <div className="text-[10px] text-[#5c7471]">
                          ({fmtNum(total)} {p.units[0]?.name})
                        </div>
                      )}
                    </td>
                    {db.warehouses.map(w => {
                      const av = availableStock(p.id, w.id);
                      return (
                        <td key={w.id} className="py-2 px-2 text-center tabular-nums">
                          {av > 0 ? (
                            <span className="font-bold text-[#102523]">{unitsText(av, p)}</span>
                          ) : (
                            <span className="text-[#94a3b8]">—</span>
                          )}
                        </td>
                      );
                    })}
                    <td className="py-2 px-2 text-center">
                      {near ? <ExpiryTag date={near} /> : <span className="text-[11px] text-[#dc2626] font-bold">—</span>}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={3 + db.warehouses.length} className="py-8 text-center text-[#5c7471]">
                    لا توجد أصناف مطابقة للبحث.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </Modal>
  );
}
