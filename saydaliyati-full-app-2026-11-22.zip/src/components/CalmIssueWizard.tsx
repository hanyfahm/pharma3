import React, { useMemo, useState } from 'react';
import { Check, ChevronDown, ChevronLeft, ChevronRight, FilePlus2, Plus, Search, Trash2, X } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { DraftIssue, IssueOrder, Product, ReceiptType } from '../types/pharma';
import {
  calc14Percent,
  calcTotalWith14,
  fmtDate,
  fmtMoney,
  fmtNum,
  getLineReceiptType,
  isLineReceipt,
  sortIssueLines,
  tafqeetEGP,
  todayISO,
  uid,
  unitsText
} from '../utils/format';
import {
  findDuplicateInvoiceNo,
  findDuplicateReceiptNo,
  normDocNo,
  suggestReceiptNumbers
} from '../utils/pharmaEngine';
import { ExcelButton } from './ui/CommonUI';

export function CalmIssueWizard({
  draft,
  setDraft,
  editingIssue,
  supplierFilter,
  onChangeSupplierFilter,
  onQuickCustomer,
  onViewIssue,
  onNewOrder,
  onExportExcel
}: {
  draft: DraftIssue;
  setDraft: React.Dispatch<React.SetStateAction<DraftIssue>>;
  editingIssue?: IssueOrder | null;
  supplierFilter: string;
  onChangeSupplierFilter: (val: string) => void;
  onQuickCustomer: () => void;
  onViewIssue: (iss: IssueOrder) => void;
  onNewOrder: () => void;
  onExportExcel: () => void;
}) {
  const {
    db,
    getProduct,
    getWarehouse,
    getPartner,
    availableStock,
    nearestExpiry,
    nextIssueNo,
    commitIssueOrder,
    updateIssueOrder,
    toast
  } = usePharmaStore();

  const isEditing = Boolean(editingIssue && draft.editingIssueId === editingIssue.id);
  const hasReturnsLock = Boolean(
    isEditing && editingIssue && (db.returns || []).some(r => r.issueId === editingIssue.id)
  );

  const [step, setStep] = useState<1 | 2 | 3>(() => (draft.lines.length > 0 ? 2 : 1));
  const [showExtraFields, setShowExtraFields] = useState(false);
  const [prodSearch, setProdSearch] = useState('');
  const [rowInputs, setRowInputs] = useState<Record<string, { qty: number; unitName: string }>>({});

  const restoredStockMap = useMemo(() => {
    const map: Record<string, number> = {};
    if (!isEditing || !editingIssue || editingIssue.warehouseId !== draft.warehouseId) return map;
    const today = todayISO();
    editingIssue.lines.forEach(ol => {
      const allocs = ol.alloc?.length ? ol.alloc : [{ batch: '', expiry: '', strips: ol.strips }];
      const validStrips = allocs.reduce((sum, a) => {
        if (!a.expiry || a.expiry >= today) return sum + (a.strips || 0);
        return sum;
      }, 0);
      map[ol.productId] = (map[ol.productId] || 0) + validStrips;
    });
    return map;
  }, [isEditing, editingIssue, draft.warehouseId]);

  const effectiveAvail = (productId: string) =>
    availableStock(productId, draft.warehouseId) + (restoredStockMap[productId] || 0);

  const customers = db.partners.filter(p => p.type === 'customer');
  const suppliers = useMemo(() => db.partners.filter(p => p.type === 'supplier'), [db.partners]);
  const selectedCustomer = getPartner(draft.customerId) || customers[0];
  const wh = getWarehouse(draft.warehouseId);
  const autoNo = nextIssueNo();
  const displayNo = isEditing && editingIssue ? editingIssue.no : autoNo;

  const warehouseAvailProducts = useMemo(() => {
    return db.products
      .map(p => ({
        product: p,
        avail: availableStock(p.id, draft.warehouseId) + (restoredStockMap[p.id] || 0),
        near: nearestExpiry(p.id, draft.warehouseId)
      }))
      .filter(row => row.avail > 0);
  }, [db.products, draft.warehouseId, availableStock, nearestExpiry, restoredStockMap]);

  const supplierCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    warehouseAvailProducts.forEach(row => {
      const k = row.product.supplierId || '__none__';
      counts[k] = (counts[k] || 0) + 1;
    });
    return counts;
  }, [warehouseAvailProducts]);

  const filteredProducts = useMemo(() => {
    const q = prodSearch.trim().toLowerCase();
    return warehouseAvailProducts.filter(row => {
      if (supplierFilter !== 'all') {
        if (supplierFilter === '__none__' ? Boolean(row.product.supplierId) : row.product.supplierId !== supplierFilter) {
          return false;
        }
      }
      if (q && !`${row.product.name} ${row.product.code} ${row.product.form}`.toLowerCase().includes(q)) {
        return false;
      }
      return true;
    });
  }, [warehouseAvailProducts, supplierFilter, prodSearch]);

  const sortedDraftLines = useMemo(() => sortIssueLines(draft.lines, db.products), [draft.lines, db.products]);
  const billableLines = sortedDraftLines.filter(l => !isLineReceipt(l, getProduct(l.productId)));
  const suppliesLines = sortedDraftLines.filter(l => isLineReceipt(l, getProduct(l.productId)));
  const suppliesOnlyLines = suppliesLines.filter(l => getLineReceiptType(l, getProduct(l.productId)) === 'supplies');
  const giftOnlyLines = suppliesLines.filter(l => getLineReceiptType(l, getProduct(l.productId)) === 'gift');
  const hasBothReceipts = suppliesOnlyLines.length > 0 && giftOnlyLines.length > 0;

  const suggestedRecs = suggestReceiptNumbers(
    db,
    displayNo,
    suppliesOnlyLines.length > 0,
    giftOnlyLines.length > 0,
    editingIssue?.id
  );
  const effSuppliesRecNo =
    suppliesOnlyLines.length > 0
      ? (hasBothReceipts
          ? draft.suppliesReceiptNo?.trim() || suggestedRecs.suppliesNo
          : draft.receiptNo?.trim() || draft.suppliesReceiptNo?.trim() || suggestedRecs.suppliesNo)
      : '';
  const effGiftRecNo =
    giftOnlyLines.length > 0
      ? (hasBothReceipts
          ? draft.giftReceiptNo?.trim() || suggestedRecs.giftNo
          : draft.receiptNo?.trim() || draft.giftReceiptNo?.trim() || suggestedRecs.giftNo)
      : '';

  const dupInvoice = findDuplicateInvoiceNo(db, draft.invoiceNo, editingIssue?.id);
  const dupSuppliesRec = suppliesOnlyLines.length > 0 ? findDuplicateReceiptNo(db, effSuppliesRecNo, editingIssue?.id) : null;
  const dupGiftRec = giftOnlyLines.length > 0 ? findDuplicateReceiptNo(db, effGiftRecNo, editingIssue?.id) : null;
  const sameRecConflict =
    hasBothReceipts && Boolean(effSuppliesRecNo) && normDocNo(effSuppliesRecNo) === normDocNo(effGiftRecNo);
  const hasDocNumberConflict = Boolean(dupInvoice || dupSuppliesRec || dupGiftRec || sameRecConflict);

  const invTotal = billableLines.reduce((s, l) => s + l.strips * (getProduct(l.productId)?.price || 0), 0);
  const val14 = calc14Percent(invTotal);
  const grandTotal = calcTotalWith14(invTotal);
  const totalStrips = draft.lines.reduce((s, l) => s + l.strips, 0);

  const handleQuickAdd = (p: Product, avail: number) => {
    if (hasReturnsLock) {
      toast('لا يمكن تعديل أصناف أذن صرف مسجل عليه مرتجع عميل', 'err');
      return;
    }
    const chosen = rowInputs[p.id] || { qty: 1, unitName: p.units[0]?.name || 'شريط' };
    const unitObj = p.units.find(u => u.name === chosen.unitName) || p.units[0];
    const qty = Math.max(1, Math.round(chosen.qty || 1));
    const strips = qty * (unitObj?.factor || 1);
    const alreadyInDraft = draft.lines
      .filter(l => l.productId === p.id)
      .reduce((s, l) => s + l.strips, 0);
    if (alreadyInDraft + strips > avail) {
      toast(`الكمية المطلوبة تتجاوز المتاح بالمخزن (${unitsText(avail, p)})`, 'err');
      return;
    }
    setDraft(prev => ({
      ...prev,
      lines: [
        ...prev.lines,
        {
          id: uid('ln'),
          productId: p.id,
          strips,
          units: [{ name: unitObj.name, qty }],
          asReceipt: Boolean(p.marked),
          receiptType: p.marked ? 'supplies' : undefined
        }
      ]
    }));
    toast(`تمت إضافة ${qty} ${unitObj.name} من ${p.name}`);
  };

  const handleSave = async () => {
    if (!draft.lines.length) {
      toast('أضف صنفًا واحدًا على الأقل في الخطوة الثانية', 'err');
      setStep(2);
      return;
    }
    if (dupInvoice) {
      setShowExtraFields(true);
      setStep(1);
      toast(`رقم الفاتورة «${draft.invoiceNo.trim()}» مستخدم بالفعل — لا يصح تكرار رقم الفاتورة`, 'err');
      return;
    }
    if (sameRecConflict) {
      toast('لا يصح تطابق رقم إيصال المستلزمات مع رقم إيصال الهدية في نفس الأذن', 'err');
      return;
    }
    if (dupSuppliesRec) {
      toast(`رقم إيصال المستلزمات «${effSuppliesRecNo}» مستخدم بالفعل في أذن ${dupSuppliesRec.issueNo}`, 'err');
      return;
    }
    if (dupGiftRec) {
      toast(`رقم إيصال الهدية «${effGiftRecNo}» مستخدم بالفعل في أذن ${dupGiftRec.issueNo}`, 'err');
      return;
    }
    try {
      const saved =
        isEditing && editingIssue
          ? await updateIssueOrder(editingIssue.id, { ...draft, no: editingIssue.no })
          : await commitIssueOrder({ ...draft, no: autoNo });
      toast(isEditing ? `تم تعديل أذن الصرف ${saved.no} بنجاح` : `تم حفظ وترحيل أذن الصرف ${saved.no} بنجاح`);
      setDraft({
        editingIssueId: undefined,
        no: nextIssueNo(),
        receiptNo: undefined,
        suppliesReceiptNo: undefined,
        giftReceiptNo: undefined,
        warehouseId: draft.warehouseId,
        invoiceNo: '',
        invoiced: false,
        customerId: customers[0]?.id || '',
        date: todayISO(),
        lines: []
      });
      setStep(1);
      onViewIssue(saved);
    } catch (err) {
      toast(err instanceof Error ? err.message : 'تعذر حفظ أذن الصرف', 'err');
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-5">
      {/* Calm Header & Stepper */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg sm:text-xl font-extrabold text-[#102523]">
            {isEditing ? `تعديل أذن الصرف — ${displayNo}` : 'أذن صرف جديد'}
          </h2>
          <p className="text-xs text-[#5c7471] mt-0.5">
            أذن رقم <span className="font-mono-num font-bold text-[#0f766e]">{displayNo}</span> · يتم الخصم تلقائيًا بنظام FEFO
          </p>
        </div>
        <div className="flex items-center gap-2">
          <ExcelButton small onClick={onExportExcel} label="تصدير Excel" />
          <button
            type="button"
            onClick={() => {
              onNewOrder();
              setStep(1);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
          >
            {isEditing ? <X className="w-3.5 h-3.5 text-[#dc2626]" /> : <FilePlus2 className="w-3.5 h-3.5 text-[#0f766e]" />}
            <span>{isEditing ? 'إلغاء التعديل' : 'بدء أذن جديد'}</span>
          </button>
        </div>
      </div>

      {isEditing && editingIssue && (
        <div className="bg-[#fffbeb] border border-[#fde68a] rounded-xl px-4 py-2.5 text-xs font-bold text-[#92400e]">
          أنت الآن في وضع تعديل أذن الصرف رقم {editingIssue.no}
          {hasReturnsLock && ' — مسجل عليه مرتجع عميل (تعديل البيانات والأرقام فقط).'}
        </div>
      )}

      {/* 3-Step Horizontal Bar */}
      <nav aria-label="خطوات أذن الصرف" className="grid grid-cols-3 gap-2 bg-white border border-[#dce6e3] rounded-2xl p-1.5">
        {(
          [
            { num: 1, title: '١. البيانات الأساسية' },
            { num: 2, title: `٢. اختيار الأصناف (${fmtNum(draft.lines.length)})` },
            { num: 3, title: '٣. المراجعة والحفظ' }
          ] as const
        ).map(s => {
          const active = step === s.num;
          const done = step > s.num;
          return (
            <button
              key={s.num}
              type="button"
              onClick={() => setStep(s.num)}
              className={`min-h-[42px] px-3 py-2 rounded-xl text-xs font-extrabold transition-colors cursor-pointer whitespace-nowrap truncate ${
                active
                  ? 'bg-[#0f766e] text-white'
                  : done
                    ? 'bg-[#eef8f6] text-[#0f766e]'
                    : 'text-[#5c7471] hover:bg-[#f8fbfa]'
              }`}
            >
              {s.title}
            </button>
          );
        })}
      </nav>

      {/* STEP 1: Essential Info Only */}
      {step === 1 && (
        <section className="max-w-3xl mx-auto bg-white border border-[#dce6e3] rounded-2xl p-5 sm:p-6 space-y-5">
          <div>
            <h3 className="text-base font-extrabold text-[#102523]">الخطوة ١: حدد العميل والمخزن</h3>
            <p className="text-xs text-[#5c7471] mt-0.5">اختر العميل والشركة الموردة والمخزن الصارف ثم انتقل لاختيار الأصناف</p>
          </div>

          <div className="space-y-4">
            <div className="block text-xs font-bold text-[#233d3a]">
              <label htmlFor="calm-customer-select" className="block mb-1.5">العميل *</label>
              <div className="flex items-center gap-2">
                <select
                  id="calm-customer-select"
                  value={draft.customerId || customers[0]?.id || ''}
                  onChange={e => setDraft(prev => ({ ...prev, customerId: e.target.value }))}
                  className="flex-1 min-w-0 min-h-[44px] px-3 py-2 rounded-xl border border-[#dce6e3] text-sm bg-white focus:outline-none focus:border-[#0f766e]"
                >
                  {customers.length ? (
                    customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)
                  ) : (
                    <option value="">لا يوجد عملاء مسجلون</option>
                  )}
                </select>
                <button
                  type="button"
                  onClick={onQuickCustomer}
                  title="إضافة عميل جديد"
                  className="min-h-[44px] px-3.5 rounded-xl border border-[#b7dfd7] bg-[#eef8f6] text-xs font-bold text-[#0f766e] hover:bg-[#dff2ee] inline-flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>عميل جديد</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <label className="block text-xs font-bold text-[#233d3a]">
                <span className="block mb-1.5">الشركة الموردة (تصفية الأصناف)</span>
                <select
                  value={supplierFilter}
                  onChange={e => onChangeSupplierFilter(e.target.value)}
                  className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-[#dce6e3] text-sm bg-white focus:outline-none focus:border-[#0f766e]"
                >
                  <option value="all">كل الشركات الموردة ({fmtNum(warehouseAvailProducts.length)} متاح)</option>
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({fmtNum(supplierCounts[s.id] || 0)} متاح)
                    </option>
                  ))}
                  {(supplierCounts.__none__ || 0) > 0 && (
                    <option value="__none__">بدون شركة محددة ({fmtNum(supplierCounts.__none__)})</option>
                  )}
                </select>
              </label>

              <label className="block text-xs font-bold text-[#233d3a]">
                <span className="block mb-1.5">المخزن الصارف (المخازن الأربعة) *</span>
                <select
                  value={draft.warehouseId}
                  disabled={hasReturnsLock}
                  onChange={e => setDraft(prev => ({ ...prev, warehouseId: e.target.value }))}
                  className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-[#dce6e3] text-sm bg-white disabled:bg-[#f4f8f7] focus:outline-none focus:border-[#0f766e]"
                >
                  {db.warehouses.map(w => {
                    const cnt = db.products.filter(
                      p => availableStock(p.id, w.id) + (w.id === draft.warehouseId ? restoredStockMap[p.id] || 0 : 0) > 0
                    ).length;
                    return (
                      <option key={w.id} value={w.id}>
                        {w.name} — {w.gov} ({fmtNum(cnt)} صنف)
                      </option>
                    );
                  })}
                </select>
              </label>
            </div>

            <div className="rounded-xl border border-[#dce6e3] bg-[#f8fbfa] px-3.5 py-2.5">
              <label className="flex items-start gap-2.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={Boolean(draft.invoiced)}
                  onChange={e => setDraft(prev => ({ ...prev, invoiced: e.target.checked }))}
                  className="mt-0.5 accent-[#0f766e] w-4 h-4 cursor-pointer"
                />
                <span className="text-xs text-[#233d3a]">
                  <strong className="block font-extrabold text-[#102523]">تم عمل فاتورة مبيعات لهذا الأذن</strong>
                  <span className="text-[11px] text-[#5c7471]">
                    عند التعليم عليه: يُغلق الأذن باعتبار أن فاتورته اتعملت ولا يحتاج لعمل فاتورة مبيعات لاحقًا.
                  </span>
                </span>
              </label>
            </div>

            {/* Collapsible Optional Fields */}
            <div className="pt-2 border-t border-[#edf3f1]">
              <button
                type="button"
                onClick={() => setShowExtraFields(o => !o)}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0f766e] hover:underline cursor-pointer"
              >
                <ChevronDown className={`w-4 h-4 transition-transform ${showExtraFields || dupInvoice ? 'rotate-180' : ''}`} />
                <span>بيانات إضافية (رقم الفاتورة والتاريخ ورقم الأذن)</span>
              </button>

              {(showExtraFields || dupInvoice) && (
                <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <label className="block text-xs font-bold text-[#233d3a]">
                    <span className="block mb-1">رقم فاتورة العميل</span>
                    <input
                      value={draft.invoiceNo}
                      onChange={e => setDraft(prev => ({ ...prev, invoiceNo: e.target.value }))}
                      placeholder="اختياري — مثال: 5521"
                      className={`w-full min-h-[42px] px-3 py-2 rounded-xl border text-xs ${
                        dupInvoice ? 'border-[#dc2626] bg-[#fef2f2] text-[#b91c1c]' : 'border-[#dce6e3]'
                      }`}
                    />
                    {dupInvoice && (
                      <span className="block mt-1 text-[10.5px] font-bold text-[#dc2626]">
                        رقم الفاتورة مستخدم بالفعل — ممنوع التكرار
                      </span>
                    )}
                  </label>
                  <label className="block text-xs font-bold text-[#233d3a]">
                    <span className="block mb-1">تاريخ الأذن</span>
                    <input
                      type="date"
                      value={draft.date}
                      onChange={e => setDraft(prev => ({ ...prev, date: e.target.value }))}
                      className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-[#dce6e3] text-xs"
                    />
                  </label>
                  <label className="block text-xs font-bold text-[#233d3a]">
                    <span className="block mb-1">رقم أذن الصرف</span>
                    <input
                      value={displayNo}
                      readOnly
                      className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-[#dce6e3] bg-[#f4f8f7] font-mono-num font-bold text-[#0f766e] text-xs"
                    />
                  </label>
                </div>
              )}
            </div>
          </div>

          <div className="pt-3 border-t border-[#edf3f1] flex items-center justify-end">
            <button
              type="button"
              onClick={() => setStep(hasReturnsLock ? 3 : 2)}
              className="inline-flex items-center gap-2 min-h-[44px] px-6 py-2.5 rounded-xl bg-[#0f766e] text-white text-sm font-extrabold hover:bg-[#0d655e] cursor-pointer"
            >
              <span>{hasReturnsLock ? 'التالي: المراجعة والحفظ' : 'التالي: اختيار الأصناف'}</span>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </section>
      )}

      {/* STEP 2: Pick Items + Live Order Cart */}
      {step === 2 && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Right 7 cols: Clean Product Selector */}
          <section className="lg:col-span-7 bg-white border border-[#dce6e3] rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-[#edf3f1] space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-sm font-extrabold text-[#102523]">
                  الأصناف المتاحة في {wh?.name} ({fmtNum(filteredProducts.length)})
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <label className="block text-[11px] font-bold text-[#5c7471]">
                  <span className="block mb-1">الشركة الموردة</span>
                  <select
                    value={supplierFilter}
                    onChange={e => onChangeSupplierFilter(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-xl border border-[#dce6e3] text-xs text-[#233d3a] bg-white focus:outline-none focus:border-[#0f766e]"
                  >
                    <option value="all">كل الشركات الموردة ({fmtNum(warehouseAvailProducts.length)})</option>
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({fmtNum(supplierCounts[s.id] || 0)})
                      </option>
                    ))}
                  </select>
                </label>

                <label className="block text-[11px] font-bold text-[#5c7471]">
                  <span className="block mb-1">المخزن (المخازن الأربعة)</span>
                  <select
                    value={draft.warehouseId}
                    disabled={hasReturnsLock}
                    onChange={e => setDraft(prev => ({ ...prev, warehouseId: e.target.value }))}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-xl border border-[#dce6e3] text-xs text-[#233d3a] bg-white focus:outline-none focus:border-[#0f766e]"
                  >
                    {db.warehouses.map(w => (
                      <option key={w.id} value={w.id}>{w.name} — {w.gov}</option>
                    ))}
                  </select>
                </label>
              </div>

              <div className="relative">
                <Search className="w-4 h-4 text-[#6b8481] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={prodSearch}
                  onChange={e => setProdSearch(e.target.value)}
                  placeholder="ابحث عن الصنف بالاسم أو الكود..."
                  className="w-full min-h-[42px] pr-9 pl-3 py-2 text-xs bg-[#f8fbfa] border border-[#dce6e3] rounded-xl focus:outline-none focus:border-[#0f766e]"
                />
              </div>
            </div>

            <div className="max-h-[460px] overflow-y-auto divide-y divide-[#edf3f1]">
              {filteredProducts.length ? (
                filteredProducts.map(({ product: p, avail, near }) => {
                  const rowInput = rowInputs[p.id] || { qty: 1, unitName: p.units[0]?.name || 'شريط' };
                  const supName = getPartner(p.supplierId)?.name;
                  return (
                    <div key={p.id} className="p-3.5 hover:bg-[#f9fcfb] flex flex-wrap items-center justify-between gap-3">
                      <div className="min-w-[180px] flex-1">
                        <div className="text-sm font-bold text-[#102523]">{p.name}</div>
                        <div className="text-[11.5px] text-[#5c7471] flex flex-wrap items-center gap-1.5 tabular-nums">
                          <span className="font-mono-num">{p.code}</span>
                          {supName && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span>{supName}</span>
                            </>
                          )}
                          <span aria-hidden="true">·</span>
                          <span>{p.marked ? 'مستلزمات' : `${fmtMoney(p.price)} ج.م`}</span>
                          <span aria-hidden="true">·</span>
                          <span className="font-bold text-[#0f766e]">متاح {unitsText(avail, p)}</span>
                          {near && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span>صلاحية {fmtDate(near)}</span>
                            </>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <input
                          type="number"
                          min={1}
                          value={rowInput.qty}
                          onChange={e =>
                            setRowInputs(prev => ({
                              ...prev,
                              [p.id]: {
                                qty: Math.max(1, Number(e.target.value) || 1),
                                unitName: rowInput.unitName
                              }
                            }))
                          }
                          className="w-16 min-h-[38px] px-2 py-1 rounded-lg border border-[#dce6e3] text-xs text-center font-bold tabular-nums"
                        />
                        <select
                          value={rowInput.unitName}
                          onChange={e =>
                            setRowInputs(prev => ({
                              ...prev,
                              [p.id]: { qty: rowInput.qty, unitName: e.target.value }
                            }))
                          }
                          className="min-h-[38px] px-2 py-1 rounded-lg border border-[#dce6e3] text-xs bg-white"
                        >
                          {p.units.map(u => (
                            <option key={u.name} value={u.name}>
                              {u.name} ({u.factor})
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={() => handleQuickAdd(p, avail)}
                          className="min-h-[38px] inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] cursor-pointer whitespace-nowrap"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>أضف</span>
                        </button>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="p-8 text-center text-xs text-[#5c7471]">
                  لا توجد أصناف متاحة مطابقة في هذا المخزن للشركة المحددة.
                </div>
              )}
            </div>
          </section>

          {/* Left 5 cols: Current Order Cart */}
          <aside className="lg:col-span-5 bg-white border border-[#dce6e3] rounded-2xl overflow-hidden lg:sticky lg:top-20">
            <div className="px-4 py-3 border-b border-[#edf3f1] flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-[#102523]">
                الأصناف المضافة ({fmtNum(draft.lines.length)})
              </h3>
              <span className="text-xs font-extrabold text-[#0f766e] tabular-nums">
                {invTotal > 0 ? `${fmtMoney(grandTotal)} ج.م` : 'بدون قيمة فاتورة'}
              </span>
            </div>

            {sortedDraftLines.length ? (
              <div className="max-h-[380px] overflow-y-auto divide-y divide-[#edf3f1]">
                {sortedDraftLines.map(l => {
                  const p = getProduct(l.productId);
                  if (!p) return null;
                  const av = effectiveAvail(p.id);
                  const totalForProd = draft.lines.filter(x => x.productId === p.id).reduce((s, x) => s + x.strips, 0);
                  const over = totalForProd > av;
                  const receipt = isLineReceipt(l, p);
                  const lineReceiptType = getLineReceiptType(l, p);
                  const matchedUnit =
                    (l.units?.length === 1 && p.units.find(u => u.name === l.units[0].name && l.units[0].qty * u.factor === l.strips)) ||
                    [...p.units].reverse().find(u => u.factor > 0 && l.strips % u.factor === 0) ||
                    p.units[0];
                  const activeQty = Math.max(1, Math.round(l.strips / (matchedUnit?.factor || 1)));

                  return (
                    <div key={l.id} className="p-3 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-[#102523] truncate">{p.name}</div>
                          <div className="text-[11px] text-[#5c7471] tabular-nums">
                            {unitsText(l.strips, p)} · {receipt ? 'إيصال بدون قيمة' : `${fmtMoney(l.strips * p.price)} ج.م`}
                          </div>
                          {over && <div className="text-[11px] font-bold text-[#dc2626]">يتجاوز المتاح ({unitsText(av, p)})</div>}
                        </div>
                        <button
                          type="button"
                          onClick={() => setDraft(prev => ({ ...prev, lines: prev.lines.filter(x => x.id !== l.id) }))}
                          className="p-1.5 rounded-lg text-[#dc2626] hover:bg-[#fef2f2] cursor-pointer shrink-0"
                          title="حذف"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-1">
                          <input
                            type="number"
                            min={1}
                            value={activeQty}
                            onChange={e => {
                              const nextQ = Math.max(1, Math.round(Number(e.target.value) || 1));
                              setDraft(prev => ({
                                ...prev,
                                lines: prev.lines.map(x =>
                                  x.id === l.id
                                    ? { ...x, strips: nextQ * (matchedUnit?.factor || 1), units: [{ name: matchedUnit.name, qty: nextQ }] }
                                    : x
                                )
                              }));
                            }}
                            className="w-14 px-1.5 py-1 rounded-md border border-[#dce6e3] text-xs text-center font-bold tabular-nums"
                          />
                          <select
                            value={matchedUnit.name}
                            onChange={e => {
                              const uObj = p.units.find(u => u.name === e.target.value) || p.units[0];
                              setDraft(prev => ({
                                ...prev,
                                lines: prev.lines.map(x =>
                                  x.id === l.id
                                    ? { ...x, strips: activeQty * uObj.factor, units: [{ name: uObj.name, qty: activeQty }] }
                                    : x
                                )
                              }));
                            }}
                            className="px-1.5 py-1 rounded-md border border-[#dce6e3] text-[11px] bg-white"
                          >
                            {p.units.map(u => <option key={u.name} value={u.name}>{u.name}</option>)}
                          </select>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <label className="inline-flex items-center gap-1 text-[11px] font-bold text-[#3b5653] cursor-pointer">
                            <input
                              type="checkbox"
                              checked={receipt}
                              onChange={e => {
                                const chk = e.target.checked;
                                setDraft(prev => ({
                                  ...prev,
                                  lines: prev.lines.map(x =>
                                    x.id === l.id
                                      ? { ...x, asReceipt: chk, receiptType: chk ? x.receiptType || (p.marked ? 'supplies' : 'gift') : undefined }
                                      : x
                                  )
                                }));
                              }}
                              className="accent-[#b45309]"
                            />
                            <span>بإيصال</span>
                          </label>
                          {receipt && (
                            <select
                              value={lineReceiptType}
                              onChange={e => {
                                const val = e.target.value as ReceiptType;
                                setDraft(prev => ({
                                  ...prev,
                                  lines: prev.lines.map(x => (x.id === l.id ? { ...x, receiptType: val } : x))
                                }));
                              }}
                              className="px-1.5 py-0.5 rounded border border-[#fde68a] bg-[#fffbeb] text-[10.5px] font-bold text-[#92400e]"
                            >
                              <option value="supplies">مستلزمات</option>
                              <option value="gift">هدية</option>
                            </select>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-8 text-center text-xs text-[#5c7471]">
                اختر الأصناف من القائمة لإضافتها إلى أذن الصرف.
              </div>
            )}

            <div className="p-3.5 border-t border-[#edf3f1] bg-[#f8fbfa] flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="inline-flex items-center gap-1 min-h-[42px] px-3.5 py-2 rounded-xl border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
                <span>السابق</span>
              </button>
              <button
                type="button"
                disabled={!draft.lines.length}
                onClick={() => setStep(3)}
                className="flex-1 inline-flex items-center justify-center gap-1.5 min-h-[42px] px-4 py-2 rounded-xl bg-[#0f766e] text-white text-xs font-extrabold hover:bg-[#0d655e] disabled:opacity-45 cursor-pointer"
              >
                <span>التالي: المراجعة والحفظ</span>
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* STEP 3: Review & Save */}
      {step === 3 && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          <section className="lg:col-span-7 bg-white border border-[#dce6e3] rounded-2xl p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#edf3f1]">
              <div>
                <h3 className="text-base font-extrabold text-[#102523]">الخطوة ٣: مراجعة أذن الصرف</h3>
                <p className="text-xs text-[#5c7471]">
                  العميل: <b className="text-[#102523]">{selectedCustomer?.name || '—'}</b> · المخزن: <b className="text-[#102523]">{wh?.name}</b>
                </p>
              </div>
              {!hasReturnsLock && (
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="text-xs font-bold text-[#0f766e] hover:underline cursor-pointer"
                >
                  تعديل الأصناف
                </button>
              )}
            </div>

            {suppliesLines.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-[#fffbeb]/50 border border-[#fde68a] rounded-xl p-3.5">
                {!hasBothReceipts ? (
                  <label className="block text-xs font-bold text-[#92400e] sm:col-span-2">
                    <span>
                      {giftOnlyLines.length > 0 ? 'رقم إيصال الهدية المرفق' : 'رقم إيصال المستلزمات المرفق'} (غير مكرر)
                    </span>
                    <input
                      value={draft.receiptNo ?? (suggestedRecs.suppliesNo || suggestedRecs.giftNo)}
                      onChange={e => setDraft(prev => ({ ...prev, receiptNo: e.target.value }))}
                      className={`mt-1 w-full min-h-[40px] px-3 py-1.5 rounded-lg border font-mono-num font-bold text-xs ${
                        dupSuppliesRec || dupGiftRec ? 'border-[#dc2626] bg-[#fef2f2] text-[#b91c1c]' : 'border-[#fde68a] bg-white text-[#b45309]'
                      }`}
                    />
                    {(dupSuppliesRec || dupGiftRec) && (
                      <span className="block mt-1 text-[10.5px] font-bold text-[#dc2626]">
                        مستخدم بالفعل في أذن {(dupSuppliesRec || dupGiftRec)?.issueNo} — ممنوع التكرار
                      </span>
                    )}
                  </label>
                ) : (
                  <>
                    <label className="block text-xs font-bold text-[#92400e]">
                      <span>رقم إيصال المستلزمات (1)</span>
                      <input
                        value={draft.suppliesReceiptNo ?? suggestedRecs.suppliesNo}
                        onChange={e => setDraft(prev => ({ ...prev, suppliesReceiptNo: e.target.value }))}
                        className={`mt-1 w-full min-h-[40px] px-3 py-1.5 rounded-lg border font-mono-num font-bold text-xs ${
                          dupSuppliesRec || sameRecConflict ? 'border-[#dc2626] bg-[#fef2f2] text-[#b91c1c]' : 'border-[#fde68a] bg-white text-[#b45309]'
                        }`}
                      />
                    </label>
                    <label className="block text-xs font-bold text-[#5b21b6]">
                      <span>رقم إيصال الهدية بدون قيمة (2)</span>
                      <input
                        value={draft.giftReceiptNo ?? suggestedRecs.giftNo}
                        onChange={e => setDraft(prev => ({ ...prev, giftReceiptNo: e.target.value }))}
                        className={`mt-1 w-full min-h-[40px] px-3 py-1.5 rounded-lg border font-mono-num font-bold text-xs ${
                          dupGiftRec || sameRecConflict ? 'border-[#dc2626] bg-[#fef2f2] text-[#b91c1c]' : 'border-[#ddd6fe] bg-white text-[#6d28d9]'
                        }`}
                      />
                    </label>
                  </>
                )}
              </div>
            )}

            <div className="divide-y divide-[#edf3f1]">
              {sortedDraftLines.map(l => {
                const p = getProduct(l.productId);
                if (!p) return null;
                const receipt = isLineReceipt(l, p);
                return (
                  <div key={l.id} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                    <div>
                      <div className="font-bold text-[#102523]">{p.name}</div>
                      <div className="text-[11px] text-[#5c7471] tabular-nums">
                        {unitsText(l.strips, p)} · {receipt ? (getLineReceiptType(l, p) === 'gift' ? 'إيصال هدية' : 'إيصال مستلزمات') : `سعر ${fmtMoney(p.price)} ج.م`}
                      </div>
                    </div>
                    <div className="font-bold tabular-nums text-[#102523]">
                      {receipt ? 'بدون قيمة' : `${fmtMoney(l.strips * p.price)} ج.م`}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <aside className="lg:col-span-5 bg-white border border-[#dce6e3] rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-extrabold text-[#102523]">ملخص الفاتورة والتأكيد</h3>
            <div className="divide-y divide-[#edf3f1] text-xs border border-[#edf3f1] rounded-xl overflow-hidden">
              <div className="flex justify-between px-3.5 py-2.5">
                <span className="text-[#5c7471]">عدد البنود / الوحدات</span>
                <span className="font-bold tabular-nums">{fmtNum(draft.lines.length)} بند · {fmtNum(totalStrips)} وحدة</span>
              </div>
              <div className="flex justify-between px-3.5 py-2.5">
                <span className="text-[#5c7471]">القيمة الأساسية</span>
                <span className="font-bold tabular-nums">{fmtMoney(invTotal)} ج.م</span>
              </div>
              <div className="flex justify-between px-3.5 py-2.5">
                <span className="text-[#5c7471]">قيمة 14%</span>
                <span className="font-bold tabular-nums">{fmtMoney(val14)} ج.م</span>
              </div>
              <div className="flex justify-between px-3.5 py-3 bg-[#eef8f6] font-extrabold text-[#0f766e]">
                <span>الإجمالي شامل 14%</span>
                <span className="tabular-nums text-sm">{fmtMoney(grandTotal)} ج.م</span>
              </div>
            </div>
            {invTotal > 0 && (
              <div className="text-[11px] text-[#073b39] bg-[#f8fbfa] border border-[#dce6e3] rounded-xl px-3 py-2 font-bold">
                {tafqeetEGP(grandTotal)}
              </div>
            )}

            <label className="flex items-start gap-2 p-3 rounded-xl border border-[#dce6e3] bg-[#f8fbfa] text-xs cursor-pointer select-none">
              <input
                type="checkbox"
                checked={Boolean(draft.invoiced)}
                onChange={e => setDraft(prev => ({ ...prev, invoiced: e.target.checked }))}
                className="mt-0.5 accent-[#0f766e] w-4 h-4 cursor-pointer"
              />
              <span className="text-[#233d3a]">
                <strong className="block font-bold text-[#102523]">تم عمل فاتورة (يغلق الأذن)</strong>
                <span className="text-[10.5px] text-[#5c7471]">
                  {draft.invoiced
                    ? 'الأذن سيُغلق ولن يظهر ضمن الأذون المنتظرة لعمل فاتورة مبيعات.'
                    : 'اتركه بدون تعليم ليظهر الأذن عند عمل فاتورة المبيعات لاحقًا.'}
                </span>
              </span>
            </label>

            <div className="space-y-2 pt-1">
              <button
                type="button"
                disabled={!draft.lines.length || hasDocNumberConflict}
                onClick={handleSave}
                className="w-full min-h-[46px] inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#0f766e] text-white text-sm font-extrabold hover:bg-[#0d655e] disabled:opacity-45 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{isEditing ? 'حفظ تعديلات أذن الصرف' : 'حفظ وترحيل أذن الصرف'}</span>
              </button>
              <button
                type="button"
                onClick={() => setStep(hasReturnsLock ? 1 : 2)}
                className="w-full min-h-[42px] inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
                <span>العودة للخطوة السابقة</span>
              </button>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
