import React, { useMemo, useRef, useState } from 'react';
import { BarChart3, PackagePlus, Plus, Search, X } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import { fmtDate, fmtMoney, unitsText } from '../utils/format';

export function GlobalStockSearch({
  onOpenStockDrawer,
  onNewIssue,
  onNewProduct
}: {
  onOpenStockDrawer: (query?: string) => void;
  onNewIssue: () => void;
  onNewProduct: () => void;
}) {
  const { db, availableStock, totalProductStock, nearestExpiry } = usePharmaStore();
  const [query, setQuery] = useState('');
  const [focused, setFocused] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  const matches = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return db.products
      .filter(p => `${p.name} ${p.code} ${p.form}`.toLowerCase().includes(q))
      .slice(0, 8)
      .map(p => ({
        product: p,
        total: totalProductStock(p.id),
        near: nearestExpiry(p.id)
      }));
  }, [db.products, query, totalProductStock, nearestExpiry]);

  return (
    <div className="mb-3.5 bg-white border border-[#dce6e3] rounded-xl p-2 flex flex-wrap items-center gap-2 relative z-20">
      <div
        ref={wrapRef}
        className="relative flex-1 min-w-[210px]"
        onBlur={e => {
          if (!wrapRef.current?.contains(e.relatedTarget as Node)) {
            setFocused(false);
          }
        }}
      >
        <Search className="w-3.5 h-3.5 text-[#6b8481] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          value={query}
          onFocus={() => setFocused(true)}
          onChange={e => {
            setQuery(e.target.value);
            setFocused(true);
          }}
          placeholder="بحث فوري عن صنف أو كود لمعرفة الرصيد والصلاحية من أي صفحة..."
          className="w-full pr-8 pl-8 py-1.5 text-xs bg-[#f8fbfa] border border-[#dce6e3] rounded-lg focus:outline-none focus:border-[#0f766e]"
        />
        {query && (
          <button
            type="button"
            onClick={() => setQuery('')}
            aria-label="مسح البحث"
            className="absolute left-2 top-1/2 -translate-y-1/2 text-[#6b8481] hover:text-[#102523] cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}

        {focused && query.trim() && (
          <div className="absolute top-full right-0 left-0 mt-1.5 bg-white border border-[#dce6e3] rounded-xl shadow-xl overflow-hidden z-40">
            {matches.length ? (
              <div className="divide-y divide-[#edf3f1] max-h-72 overflow-y-auto">
                {matches.map(({ product: p, total, near }) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      setFocused(false);
                      onOpenStockDrawer(p.name);
                    }}
                    className="w-full text-right px-3.5 py-2 hover:bg-[#f4f8f7] flex flex-wrap items-center justify-between gap-2 cursor-pointer"
                  >
                    <div>
                      <div className="text-xs font-bold text-[#102523]">
                        {p.name} <span className="font-mono-num text-[11px] text-[#5c7471]">({p.code})</span>
                      </div>
                      <div className="text-[11px] text-[#5c7471] flex flex-wrap items-center gap-2 mt-0.5">
                        {db.warehouses.map(w => {
                          const av = availableStock(p.id, w.id);
                          return (
                            <span key={w.id}>
                              {w.name}: <b className="text-[#102523]">{av > 0 ? unitsText(av, p) : '0'}</b>
                            </span>
                          );
                        })}
                      </div>
                    </div>
                    <div className="text-left tabular-nums">
                      <div className={`text-xs font-extrabold ${total > 0 ? 'text-[#0f766e]' : 'text-[#dc2626]'}`}>
                        {total > 0 ? unitsText(total, p) : 'نافد'}
                      </div>
                      <div className="text-[10.5px] text-[#5c7471]">
                        {fmtMoney(p.price)} ج.م · {near ? `صلاحية ${fmtDate(near)}` : 'لا توجد دفعات'}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="p-4 text-center text-xs text-[#5c7471]">لا توجد أصناف مطابقة لـ «{query}»</div>
            )}
          </div>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-1.5 shrink-0">
        <button
          type="button"
          onClick={onNewIssue}
          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] whitespace-nowrap cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>أذن صرف سريع</span>
        </button>
        <button
          type="button"
          onClick={onNewProduct}
          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-[#b7dfd7] bg-[#eef8f6] text-[#073b39] text-xs font-bold hover:bg-[#dff2ee] whitespace-nowrap cursor-pointer"
        >
          <PackagePlus className="w-3.5 h-3.5 text-[#0f766e]" />
          <span>إضافة منتج</span>
        </button>
        <button
          type="button"
          onClick={() => onOpenStockDrawer(query)}
          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-[#dce6e3] bg-white text-[#233d3a] text-xs font-bold hover:bg-[#f4f8f7] whitespace-nowrap cursor-pointer"
        >
          <BarChart3 className="w-3.5 h-3.5 text-[#0f766e]" />
          <span>كشف الرصيد الفوري</span>
        </button>
      </div>
    </div>
  );
}
