import React, { useMemo, useState } from 'react';
import {
  ArrowDownToLine,
  ArrowLeft,
  ArrowLeftRight,
  BarChart3,
  Building2,
  ClipboardList,
  Eye,
  FilePlus2,
  FileSpreadsheet,
  Lock,
  Package,
  PackagePlus,
  Pencil,
  Receipt,
  RotateCcw,
  Search,
  Truck,
  Users
} from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import { useLayoutMode, type UILayoutMode } from '../store/useLayoutMode';
import type { IssueOrder, PageId } from '../types/pharma';
import { calcIssueValue, calcTotalWith14, fmtDate, fmtMoney, fmtNum, isLineReceipt, sortIssuesByInvoiceStatus, unitsText } from '../utils/format';

export function CalmHomeHub({
  onNavigate,
  onOpenImportExcel,
  onCreateSalesInvoice,
  onNewProduct,
  onNewCustomer,
  onNewSupplier,
  onViewIssue,
  onEditIssue
}: {
  onNavigate: (page: PageId) => void;
  onOpenImportExcel: () => void;
  onCreateSalesInvoice: (issueId?: string) => void;
  onNewProduct: () => void;
  onNewCustomer: () => void;
  onNewSupplier: () => void;
  onViewIssue: (iss: IssueOrder) => void;
  onEditIssue: (iss: IssueOrder) => void;
}) {
  const { db, availableStock, getWarehouse, getPartner, getProduct, setIssueInvoiced, toast } = usePharmaStore();
  const { layout, setLayout } = useLayoutMode();
  const [quickQuery, setQuickQuery] = useState('');
  const openIssuesCount = useMemo(() => db.issues.filter(i => !i.closed && !i.invoiced).length, [db.issues]);

  const quickStockResults = useMemo(() => {
    const q = quickQuery.trim().toLowerCase();
    if (!q) return [];
    return db.products
      .filter(p => `${p.name} ${p.code} ${p.form}`.toLowerCase().includes(q))
      .slice(0, 6)
      .map(p => ({
        product: p,
        supplierName: getPartner(p.supplierId)?.name || 'غير محدد',
        perWh: db.warehouses.map(w => ({
          warehouse: w,
          strips: availableStock(p.id, w.id)
        })),
        total: db.warehouses.reduce((sum, w) => sum + availableStock(p.id, w.id), 0)
      }));
  }, [quickQuery, db.products, db.warehouses, availableStock, getPartner]);

  const recentIssues = useMemo(() => sortIssuesByInvoiceStatus(db.issues).slice(0, 5), [db.issues]);

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-4">
      {/* Calm Header & Quiet Unboxed Metrics */}
      <section className="pt-1 space-y-2">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="text-xl sm:text-2xl font-extrabold text-[#102523] tracking-tight">
            {db.company.name || 'صيدليتي'}
          </h2>
          <div className="flex flex-wrap items-center gap-2 text-xs text-[#5c7471] tabular-nums">
            <span>{fmtNum(db.products.length)} صنف</span>
            <span aria-hidden="true">·</span>
            <span>{fmtNum(db.issues.length)} أذن صرف</span>
            <span aria-hidden="true">·</span>
            <span>{fmtNum(db.warehouses.length)} مخازن</span>
          </div>
        </div>
        <p className="text-xs sm:text-sm text-[#5c7471]">
          اختر المهمة التي تريد تنفيذها الآن بخطوات بسيطة وواضحة.
        </p>
      </section>

      {/* Instant Stock Lookup (Zero-Click Search) */}
      <section className="bg-white border border-[#dce6e3] rounded-2xl p-3.5 sm:p-4 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-[#5c7471] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={quickQuery}
            onChange={e => setQuickQuery(e.target.value)}
            placeholder="استعلام فوري: اكتب اسم الصنف أو الكود لمعرفة رصيده في المخازن الأربعة..."
            className="w-full min-h-[44px] pr-10 pl-3 py-2 text-xs sm:text-sm bg-[#f8fbfa] border border-[#dce6e3] rounded-xl focus:outline-none focus:border-[#0f766e]"
          />
        </div>

        {quickQuery.trim() && (
          <div className="divide-y divide-[#edf3f1] border-t border-[#edf3f1] pt-1">
            {quickStockResults.length ? (
              quickStockResults.map(({ product: p, supplierName, perWh, total }) => (
                <div key={p.id} className="py-3 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="text-sm font-extrabold text-[#102523]">{p.name}</div>
                      <div className="text-[11.5px] text-[#5c7471] flex flex-wrap items-center gap-1.5">
                        <span className="font-mono-num">{p.code}</span>
                        <span aria-hidden="true">·</span>
                        <span>{supplierName}</span>
                        <span aria-hidden="true">·</span>
                        <span>{p.marked ? 'مستلزمات' : `${fmtMoney(p.price)} ج.م`}</span>
                      </div>
                    </div>
                    <div className="text-xs font-extrabold text-[#0f766e] tabular-nums">
                      الإجمالي المتاح: {total > 0 ? unitsText(total, p) : 'غير متوفر'}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                    {perWh.map(({ warehouse: w, strips }) => (
                      <div
                        key={w.id}
                        className="px-2.5 py-1.5 rounded-lg bg-[#f8fbfa] border border-[#e5efec] flex items-center justify-between gap-1"
                      >
                        <span className="text-[#5c7471] truncate">{w.name}</span>
                        <span className={`font-bold tabular-nums shrink-0 ${strips > 0 ? 'text-[#0f766e]' : 'text-[#94a3b8]'}`}>
                          {strips > 0 ? unitsText(strips, p) : '0'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            ) : (
              <div className="py-4 text-center text-xs text-[#5c7471]">
                لا توجد أصناف مطابقة للبحث «{quickQuery}»
              </div>
            )}
          </div>
        )}
      </section>

      {/* 4 Big Primary Daily Task Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        <button
          type="button"
          onClick={() => onNavigate('issue')}
          className="group text-right bg-white border border-[#b7dfd7] hover:border-[#0f766e] rounded-2xl p-5 transition-colors cursor-pointer flex items-start justify-between gap-3"
        >
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 text-[#0f766e]">
              <FilePlus2 className="w-5 h-5" />
              <span className="text-base font-extrabold text-[#102523]">أذن صرف جديد</span>
            </div>
            <p className="text-xs text-[#5c7471] leading-relaxed">
              تنفيذ الصرف في 3 خطوات بسيطة (العميل والمخزن ← الأصناف ← الحفظ وطباعة Word).
            </p>
          </div>
          <ArrowLeft className="w-4 h-4 text-[#0f766e] shrink-0 mt-1 group-hover:-translate-x-0.5 transition-transform" />
        </button>

        <div className="bg-white border border-[#dce6e3] rounded-2xl p-5 flex flex-col justify-between gap-3">
          <button
            type="button"
            onClick={() => onNavigate('incoming')}
            className="group text-right flex items-start justify-between gap-3 cursor-pointer"
          >
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-2 text-[#0f766e]">
                <ArrowDownToLine className="w-5 h-5" />
                <span className="text-base font-extrabold text-[#102523]">فاتورة وارد</span>
              </div>
              <p className="text-xs text-[#5c7471] leading-relaxed">
                إدخال وارد جديد وتوزيعه على المخازن الأربعة في 3 خطوات.
              </p>
            </div>
            <ArrowLeft className="w-4 h-4 text-[#5c7471] group-hover:text-[#0f766e] shrink-0 mt-1 transition-colors" />
          </button>
          <div className="pt-2.5 border-t border-[#edf3f1] flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={onOpenImportExcel}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#047857] hover:underline cursor-pointer min-h-[36px]"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>أو استيراد سريع من ملف Excel (.xlsx)</span>
            </button>
          </div>
        </div>

        <button
          type="button"
          onClick={() => onNavigate('balance')}
          className="group text-right bg-white border border-[#dce6e3] hover:border-[#0f766e] rounded-2xl p-5 transition-colors cursor-pointer flex items-start justify-between gap-3"
        >
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 text-[#0f766e]">
              <BarChart3 className="w-5 h-5" />
              <span className="text-base font-extrabold text-[#102523]">الأرصدة والصلاحية</span>
            </div>
            <p className="text-xs text-[#5c7471] leading-relaxed">
              مراجعة الكميات الموزعة على المخزن الرئيسي والفروع وحالة الصلاحيات.
            </p>
          </div>
          <ArrowLeft className="w-4 h-4 text-[#5c7471] group-hover:text-[#0f766e] shrink-0 mt-1 transition-colors" />
        </button>

        <div className="bg-white border border-[#dce6e3] rounded-2xl p-5 flex flex-col justify-between gap-3">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 text-[#0f766e]">
              <Package className="w-5 h-5" />
              <span className="text-base font-extrabold text-[#102523]">المنتجات والجهات</span>
            </div>
            <p className="text-xs text-[#5c7471]">إضافة أو تعديل الأصناف والعملاء والشركات الموردة بسرعة.</p>
          </div>
          <div className="pt-2.5 border-t border-[#edf3f1] flex flex-wrap items-center gap-3 text-xs font-bold">
            <button
              type="button"
              onClick={onNewProduct}
              className="inline-flex items-center gap-1 text-[#0f766e] hover:underline cursor-pointer min-h-[36px]"
            >
              <PackagePlus className="w-3.5 h-3.5" />
              <span>+ منتج</span>
            </button>
            <button
              type="button"
              onClick={onNewCustomer}
              className="inline-flex items-center gap-1 text-[#233d3a] hover:underline cursor-pointer min-h-[36px]"
            >
              <Users className="w-3.5 h-3.5" />
              <span>+ عميل</span>
            </button>
            <button
              type="button"
              onClick={onNewSupplier}
              className="inline-flex items-center gap-1 text-[#233d3a] hover:underline cursor-pointer min-h-[36px]"
            >
              <Truck className="w-3.5 h-3.5" />
              <span>+ مورد</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('products')}
              className="mr-auto text-[#5c7471] hover:text-[#102523] cursor-pointer min-h-[36px]"
            >
              عرض الكل ←
            </button>
          </div>
        </div>
      </section>

      {/* Quiet Secondary Shortcuts */}
      <section className="flex flex-wrap items-center gap-2 text-xs">
        <span className="text-[#5c7471] font-bold ml-1">السجل والمتابعة:</span>
        <button
          type="button"
          onClick={() => onCreateSalesInvoice()}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#eef8f6] border border-[#b7dfd7] text-[#0f766e] font-extrabold hover:bg-[#dff2ee] transition-colors whitespace-nowrap cursor-pointer min-h-[40px]"
        >
          <Receipt className="w-3.5 h-3.5" />
          <span>عمل فاتورة مبيعات{openIssuesCount > 0 ? ` (${fmtNum(openIssuesCount)})` : ''}</span>
        </button>
        {(
          [
            { id: 'issue-list', label: 'أذون الصرف', icon: <ClipboardList className="w-3.5 h-3.5" /> },
            { id: 'invoice-list', label: 'الفواتير', icon: <FileSpreadsheet className="w-3.5 h-3.5" /> },
            { id: 'returns', label: 'مرتجع عميل', icon: <RotateCcw className="w-3.5 h-3.5" /> },
            { id: 'transfers', label: 'تحويل مخزني', icon: <ArrowLeftRight className="w-3.5 h-3.5" /> },
            { id: 'warehouses', label: 'المخازن الـ 4', icon: <Building2 className="w-3.5 h-3.5" /> },
            { id: 'reports', label: 'التقارير', icon: <BarChart3 className="w-3.5 h-3.5" /> }
          ] as const
        ).map(link => (
          <button
            key={link.id}
            type="button"
            onClick={() => onNavigate(link.id)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white border border-[#dce6e3] text-[#233d3a] font-bold hover:border-[#0f766e] hover:text-[#0f766e] transition-colors whitespace-nowrap cursor-pointer min-h-[40px]"
          >
            {link.icon}
            <span>{link.label}</span>
          </button>
        ))}
      </section>

      {/* Recent Issue Orders (Clean Interactive Rows) */}
      <section className="bg-white border border-[#dce6e3] rounded-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-[#edf3f1] flex items-center justify-between gap-2">
          <h3 className="text-sm font-extrabold text-[#102523]">أحدث أذون الصرف</h3>
          <button
            type="button"
            onClick={() => onNavigate('issue-list')}
            className="text-xs font-bold text-[#0f766e] hover:underline cursor-pointer"
          >
            عرض السجل كاملًا
          </button>
        </div>
        {recentIssues.length ? (
          <div className="divide-y divide-[#edf3f1]">
            {recentIssues.map(iss => {
              const total = calcTotalWith14(calcIssueValue(iss, db.products));
              const hasBillable = iss.lines.some(l => !isLineReceipt(l, getProduct(l.productId)));
              return (
                <div
                  key={iss.id}
                  className="px-4 py-3 flex flex-wrap items-center justify-between gap-3 hover:bg-[#f9fcfb]"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-[#102523] truncate">{iss.customer}</div>
                    <div className="text-[11.5px] text-[#5c7471] flex flex-wrap items-center gap-1.5 tabular-nums">
                      <span className="font-mono-num font-bold text-[#0f766e]">{iss.no}</span>
                      <span aria-hidden="true">·</span>
                      <span>{fmtDate(iss.date)}</span>
                      <span aria-hidden="true">·</span>
                      <span>{getWarehouse(iss.warehouseId)?.name || '—'}</span>
                      {total > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-bold text-[#102523]">{fmtMoney(total)} ج.م</span>
                        </>
                      )}
                      <span aria-hidden="true">·</span>
                      <label
                        className={`inline-flex items-center gap-1 font-bold select-none ${
                          iss.invoicedByFlow ? 'cursor-default text-[#047857]' : 'cursor-pointer text-[#233d3a]'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={Boolean(iss.invoiced)}
                          disabled={Boolean(iss.invoicedByFlow)}
                          onChange={async e => {
                            const chk = e.target.checked;
                            try {
                              await setIssueInvoiced(iss.id, chk);
                              toast(
                                chk
                                  ? `تم التعليم على ${iss.no}: تم عمل فاتورة وإغلاق الأذن`
                                  : `تم إعادة فتح أذن الصرف ${iss.no}`
                              );
                            } catch (err) {
                              toast(err instanceof Error ? err.message : 'تعذر تحديث الحالة', 'err');
                            }
                          }}
                          className="accent-[#0f766e] w-3.5 h-3.5 cursor-pointer disabled:cursor-not-allowed"
                        />
                        <span>{iss.invoiced ? 'تم عمل فاتورة (مغلق)' : 'بانتظار فاتورة'}</span>
                      </label>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                    {!iss.closed && !iss.invoiced && hasBillable && (
                      <button
                        type="button"
                        onClick={() => onCreateSalesInvoice(iss.id)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-[#b7dfd7] bg-[#eef8f6] text-xs font-extrabold text-[#0f766e] hover:bg-[#dff2ee] min-h-[38px] cursor-pointer"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        <span>عمل فاتورة</span>
                      </button>
                    )}
                    {!iss.closed ? (
                      <button
                        type="button"
                        onClick={() => onEditIssue(iss)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] min-h-[38px] cursor-pointer"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                        <span>تعديل</span>
                      </button>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-[#dce6e3] bg-[#f8fbfa] text-[11px] font-bold text-[#5c7471] min-h-[38px]">
                        <Lock className="w-3.5 h-3.5" />
                        <span>مغلق</span>
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={() => onViewIssue(iss)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-[#b7dfd7] bg-[#eef8f6] text-xs font-bold text-[#0f766e] hover:bg-[#dff2ee] min-h-[38px] cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>عرض وطباعة</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-6 text-center text-xs text-[#5c7471]">
            لا توجد أذون صرف مسجلة بعد — اضغط «أذن صرف جديد» للبدء.
          </div>
        )}
      </section>

      {/* Quiet Design Switcher Footer */}
      <footer className="pt-2 border-t border-[#dce6e3] flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#5c7471]">
        <span>الواجهة الحالية: اللوحة الهادئة (1-2-3)</span>
        <div className="flex flex-wrap items-center gap-1.5">
          <span>تبديل التنسيق:</span>
          {(
            [
              { id: 'calm-steps', label: 'اللوحة الهادئة' },
              { id: 'labtop', label: 'مخازن LAB top' },
              { id: 'saydaliti-v2', label: 'صيدليتي الجديد' },
              { id: 'classic', label: 'الكلاسيكي' }
            ] as { id: UILayoutMode; label: string }[]
          ).map(opt => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setLayout(opt.id)}
              className={`px-2 py-1 rounded-md cursor-pointer transition-colors ${
                layout === opt.id
                  ? 'bg-[#0f766e] text-white font-bold'
                  : 'hover:bg-white hover:text-[#102523]'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </footer>
    </div>
  );
}
