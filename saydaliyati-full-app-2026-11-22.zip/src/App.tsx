import React, { useEffect, useState } from 'react';
import {
  Activity,
  ArrowDownToLine,
  ArrowLeftRight,
  BarChart3,
  Box,
  Building2,
  ChevronDown,
  ChevronRight,
  ClipboardList,
  Download,
  FileCode2,
  FileSpreadsheet,
  FileText,
  FolderKanban,
  LayoutGrid,
  Menu,
  Package,
  PackagePlus,
  PanelRightClose,
  PanelRightOpen,
  Plus,
  Receipt,
  RotateCcw,
  Search,
  Truck,
  Users,
  Warehouse as WarehouseIcon
} from 'lucide-react';
import { PharmaStoreProvider, usePharmaStore } from './store/usePharmaStore';
import { LayoutModeProvider, useLayoutMode, type UILayoutMode } from './store/useLayoutMode';
import type {
  CustomerReturn,
  DraftIncoming,
  DraftIssue,
  DraftTransfer,
  Invoice,
  IssueOrder,
  PageId,
  Partner,
  PartnerType,
  Product,
  TransferOrder
} from './types/pharma';
import { fmtDate, todayISO, uid } from './utils/format';
import { computeNextIncomingNo } from './utils/pharmaEngine';
import { exportFullHTMLCopy } from './utils/export';
import { Modal } from './components/ui/CommonUI';
import { CalmHomeHub } from './components/CalmHomeHub';
import { CreateSalesInvoiceModal } from './components/CreateSalesInvoiceModal';
import { DownloadAppModal } from './components/DownloadAppModal';
import { QuickStockDrawer } from './components/QuickStockDrawer';
import { GlobalStockSearch } from './components/GlobalStockSearch';
import { WarehouseReceiptModal } from './components/WarehouseReceiptModal';
import { ProductDetailModal, ProductFormModal } from './components/ProductModals';
import { CompanyModal, PartnerFormModal } from './components/PartnerModals';
import {
  ImportBulkModal,
  InvoiceDetailModal,
  IssueDetailModal,
  LinePickerModal,
  ReturnDetailModal,
  TransferDetailModal
} from './components/DocumentModals';

import { IssueListPage } from './pages/IssueListPage';
import { InvoiceListPage } from './pages/InvoiceListPage';
import { DashboardPage } from './pages/DashboardPage';
import { WarehousesPage } from './pages/WarehousesPage';
import { BalancePage } from './pages/BalancePage';
import { ProductsPage } from './pages/ProductsPage';
import { PartnersPage } from './pages/PartnersPage';
import { IncomingPage } from './pages/IncomingPage';
import { IssuePage } from './pages/IssuePage';
import { ReturnsPage } from './pages/ReturnsPage';
import { TransfersPage } from './pages/TransfersPage';
import { ReportsPage } from './pages/ReportsPage';
import { QueriesPage } from './pages/QueriesPage';
import { MovementsPage } from './pages/MovementsPage';

interface NavItem {
  id: PageId;
  label: string;
  sub: string;
  icon: React.ReactNode;
}

const MASTER_NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'لوحة التحكم', sub: 'نظرة سريعة على المخازن والحركة', icon: <LayoutGrid className="w-4 h-4" /> },
  { id: 'products', label: 'المنتجات والأصناف', sub: 'الأدوية والمستلزمات وهرم الوحدات والصلاحيات', icon: <Package className="w-4 h-4" /> },
  { id: 'customers', label: 'العملاء', sub: 'إدارة بيانات العملاء والصيدليات والمستشفيات', icon: <Users className="w-4 h-4" /> },
  { id: 'suppliers', label: 'الموردون', sub: 'إدارة شركات التوريد والموردين وبيانات الصيدلية', icon: <Truck className="w-4 h-4" /> }
];

const OPERATIONS_NAV_ITEMS: NavItem[] = [
  { id: 'issue-list', label: 'قائمة أذون الصرف', sub: 'سجل أذون الصرف والإيصالات المرفقة والطباعة', icon: <ClipboardList className="w-4 h-4" /> },
  { id: 'invoice-list', label: 'قائمة الفواتير', sub: 'فواتير المبيعات والوارد مع حساب 14% والتفقيط المصري', icon: <Receipt className="w-4 h-4" /> },
  { id: 'incoming', label: 'فاتورة وارد', sub: 'استيراد وتوزيع الوارد على المخازن', icon: <ArrowDownToLine className="w-4 h-4" /> },
  { id: 'issue', label: 'أذون الصرف', sub: 'ترقيم تلقائي وفتح في Word بدون أسعار', icon: <FileText className="w-4 h-4" /> },
  { id: 'returns', label: 'مرتجع العملاء', sub: 'مرتجع كلي أو جزئي وإعادة للمخزن', icon: <RotateCcw className="w-4 h-4" /> },
  { id: 'transfers', label: 'أذون التحويل', sub: 'نقل الكميات بين الفروع بنظام FEFO', icon: <ArrowLeftRight className="w-4 h-4" /> },
  { id: 'warehouses', label: 'المخازن', sub: 'اضغط على أي مخزن لفتح رصيد الاستلام', icon: <WarehouseIcon className="w-4 h-4" /> },
  { id: 'balance', label: 'الرصيد', sub: 'ميزان الرصيد المجمّع لكل لوت', icon: <BarChart3 className="w-4 h-4" /> },
  { id: 'reports', label: 'التقارير', sub: 'تقارير المخزون والصلاحية والمبيعات', icon: <FileSpreadsheet className="w-4 h-4" /> },
  { id: 'queries', label: 'الاستعلامات', sub: 'تتبع الصرف والنواقص وكشوف الحساب', icon: <Search className="w-4 h-4" /> },
  { id: 'movements', label: 'سجل الحركات', sub: 'السجل الكامل لحركات المخازن', icon: <Activity className="w-4 h-4" /> }
];

const ALL_NAV_ITEMS: NavItem[] = [...OPERATIONS_NAV_ITEMS, ...MASTER_NAV_ITEMS];

function MainShell() {
  const { db, toasts, toast, nextIssueNo, resetData } = usePharmaStore();
  const { layout, setLayout, isCalmSteps, isLabTop, isSplitV2, isClassic } = useLayoutMode();
  const [page, setPage] = useState<PageId>(() => (isCalmSteps ? 'dashboard' : 'issue-list'));
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [masterMenuOpen, setMasterMenuOpen] = useState(true);
  const [railExpanded, setRailExpanded] = useState(false);
  const [stockDrawerOpen, setStockDrawerOpen] = useState(false);
  const [stockDrawerQuery, setStockDrawerQuery] = useState('');

  // Draft states
  const [incomingDraft, setIncomingDraft] = useState<DraftIncoming>(() => ({
    no: computeNextIncomingNo(db),
    supplierId: db.partners.find(p => p.type === 'supplier')?.id || '',
    date: todayISO(),
    mode: 'shares',
    lines: []
  }));

  const [issueDraft, setIssueDraft] = useState<DraftIssue>(() => ({
    no: nextIssueNo(),
    warehouseId: db.warehouses[0]?.id || 'w1',
    invoiceNo: '',
    customerId: db.partners.find(p => p.type === 'customer')?.id || '',
    date: todayISO(),
    lines: []
  }));
  const [issueSupplierFilter, setIssueSupplierFilter] = useState<string>('all');

  const [transferDraft, setTransferDraft] = useState<DraftTransfer>(() => ({
    no: `TR-${db.meta.nextTransfer}`,
    from: db.warehouses[0]?.id || 'w1',
    to: db.warehouses[1]?.id || 'w2',
    date: todayISO(),
    lines: []
  }));

  // Modals
  const [warehouseModalId, setWarehouseModalId] = useState<string | null>(null);
  const [productDetailId, setProductDetailId] = useState<string | null>(null);
  const [productFormOpen, setProductFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [partnerModalState, setPartnerModalState] = useState<{
    open: boolean;
    type: PartnerType;
    editing: Partner | null;
    target?: 'incoming' | 'issue';
  }>({ open: false, type: 'customer', editing: null });
  const [companyModalOpen, setCompanyModalOpen] = useState(false);
  const [linePickerMode, setLinePickerMode] = useState<'incoming' | 'issue' | 'transfer' | null>(null);
  const [importModalOpen, setImportModalOpen] = useState(false);
  const [salesInvoiceModalState, setSalesInvoiceModalState] = useState<{
    open: boolean;
    preselectedIssueId?: string | null;
  }>({ open: false, preselectedIssueId: null });
  const [viewInvoice, setViewInvoice] = useState<Invoice | null>(null);
  const [viewIssue, setViewIssue] = useState<IssueOrder | null>(null);
  const [viewReturn, setViewReturn] = useState<CustomerReturn | null>(null);
  const [viewTransfer, setViewTransfer] = useState<TransferOrder | null>(null);
  const [preselectedReturnIssueId, setPreselectedReturnIssueId] = useState<string | null>(null);
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);
  const [downloadModalOpen, setDownloadModalOpen] = useState(false);

  // Print area HTML
  const [printHtml, setPrintHtml] = useState<string | null>(null);

  useEffect(() => {
    if (!printHtml) return;
    const t = setTimeout(() => {
      window.print();
    }, 100);
    return () => clearTimeout(t);
  }, [printHtml]);

  useEffect(() => {
    const onAfterPrint = () => setPrintHtml(null);
    window.addEventListener('afterprint', onAfterPrint);
    return () => window.removeEventListener('afterprint', onAfterPrint);
  }, []);

  const currentNav = ALL_NAV_ITEMS.find(n => n.id === page) || ALL_NAV_ITEMS[0];
  const isMasterPage = MASTER_NAV_ITEMS.some(n => n.id === page);

  const navigate = (nextPage: PageId) => {
    setPage(nextPage);
    if (MASTER_NAV_ITEMS.some(n => n.id === nextPage)) {
      setMasterMenuOpen(true);
    }
    setMobileNavOpen(false);
  };

  const handleStartReturn = (issId: string) => {
    setPreselectedReturnIssueId(issId);
    navigate('returns');
  };

  const editingIssue = issueDraft.editingIssueId
    ? db.issues.find(i => i.id === issueDraft.editingIssueId) || null
    : null;

  const issueExtraStockMap = React.useMemo(() => {
    const map: Record<string, number> = {};
    if (!editingIssue || editingIssue.warehouseId !== issueDraft.warehouseId) return map;
    const today = todayISO();
    editingIssue.lines.forEach(ol => {
      const allocs = ol.alloc?.length ? ol.alloc : [{ batch: '', expiry: '', strips: ol.strips }];
      const validStrips = allocs.reduce((sum, a) => {
        if (!a.expiry || a.expiry >= today) return sum + (a.strips || 0);
        return sum;
      }, 0);
      map[ol.productId] = (map[ol.productId] || 0) + validStrips;
    });
    return map;
  }, [editingIssue, issueDraft.warehouseId]);

  const openCreateSalesInvoice = (issueId?: string) => {
    setSalesInvoiceModalState({ open: true, preselectedIssueId: issueId || null });
  };

  const handleEditIssue = (iss: IssueOrder) => {
    if (iss.closed) {
      toast('أذن الصرف مغلق بعد عمل الفاتورة ولا يمكن تعديله', 'warn');
      return;
    }
    const matchedCustomer =
      (iss.customerId && db.partners.find(p => p.id === iss.customerId)) ||
      db.partners.find(p => p.type === 'customer' && p.name === iss.customer) ||
      db.partners.find(p => p.type === 'customer');
    setIssueDraft({
      editingIssueId: iss.id,
      no: iss.no,
      receiptNo: iss.receiptNo,
      suppliesReceiptNo: iss.suppliesReceiptNo,
      giftReceiptNo: iss.giftReceiptNo,
      receiptType: iss.receiptType,
      warehouseId: iss.warehouseId,
      invoiceNo: iss.invoiceNo === '—' ? '' : iss.invoiceNo,
      invoiced: Boolean(iss.invoiced),
      customerId: matchedCustomer?.id || '',
      date: iss.date,
      lines: iss.lines.map(l => {
        const prod = db.products.find(p => p.id === l.productId);
        const baseUnitName = prod?.units[0]?.name || 'شريط';
        return {
          id: uid('ln'),
          productId: l.productId,
          strips: l.strips,
          units: [{ name: baseUnitName, qty: l.strips }],
          asReceipt: l.asReceipt,
          receiptType: l.receiptType
        };
      })
    });
    setViewIssue(null);
    navigate('issue');
  };

  const handleSwitchLayout = (next: UILayoutMode) => {
    setLayout(next);
    if (next === 'calm-steps') {
      setPage('dashboard');
    }
    const label =
      next === 'calm-steps'
        ? 'اللوحة الهادئة والخطوات المرشدة (1-2-3)'
        : next === 'labtop'
          ? 'مخازن LAB top (الألواح الجانبية السريعة)'
          : next === 'saydaliti-v2'
            ? 'صيدليتي (التنسيق المقسّم الجديد)'
            : 'الوضع الكلاسيكي (نقطة الرجوع)';
    toast(`تم التبديل إلى: ${label}`);
  };

  const brandName = isLabTop ? 'مخازن LAB top' : 'صيدليتي';
  const isSlimRail = isSplitV2 && !railExpanded;

  return (
    <>
      <div className={`min-h-screen flex bg-[#f4f8f7] text-[#102523] no-print ${!isClassic && !isCalmSteps ? 'ui-compact' : ''}`}>
        {/* Nav drawer backdrop */}
        {mobileNavOpen && (
          <div
            className={`fixed inset-0 z-40 bg-[#062220]/50 backdrop-blur-[2px] ${isCalmSteps ? '' : 'lg:hidden'}`}
            onClick={() => setMobileNavOpen(false)}
          />
        )}

        {/* Sidebar (permanent on desktop for classic/labtop/v2; slide-over drawer on calm-steps) */}
        <aside
          className={`fixed top-0 right-0 z-50 h-[100dvh] shrink-0 bg-gradient-to-b from-[#072624] via-[#07312f] to-[#05201e] text-[#d5eae6] flex flex-col transition-all duration-200 overflow-y-auto ${
            isCalmSteps
              ? `w-[270px] p-4 ${mobileNavOpen ? 'translate-x-0' : 'translate-x-full'}`
              : `lg:sticky ${isSlimRail ? 'w-[240px] lg:w-[68px] p-3 lg:p-2' : isLabTop ? 'w-[228px] p-3' : 'w-[258px] p-4'} ${mobileNavOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}`
          }`}
        >
          <div className={`flex items-center justify-between gap-2 pb-3 border-b border-white/10 ${isSlimRail ? 'lg:justify-center px-0' : 'px-1.5'}`}>
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#0f766e] text-white grid place-items-center shrink-0 shadow-md">
                <Box className="w-5 h-5" />
              </div>
              <div className={`leading-tight min-w-0 ${isSlimRail ? 'lg:hidden' : ''}`}>
                <div className="text-base font-extrabold text-white truncate">{brandName}</div>
                <div className="text-[10.5px] text-[#98bdb7] truncate">
                  {isLabTop ? 'واجهة LAB top السريعة' : isSplitV2 ? 'التنسيق الجديد' : 'إدارة المخازن والفواتير'}
                </div>
              </div>
            </div>
            {isSplitV2 && (
              <button
                type="button"
                onClick={() => setRailExpanded(e => !e)}
                title={railExpanded ? 'تصغير القائمة' : 'توسيع القائمة'}
                className="hidden lg:grid w-7 h-7 rounded-lg bg-white/5 hover:bg-white/15 place-items-center text-[#98bdb7] cursor-pointer shrink-0"
              >
                {railExpanded ? <PanelRightClose className="w-3.5 h-3.5" /> : <PanelRightOpen className="w-3.5 h-3.5" />}
              </button>
            )}
          </div>

          <nav className="flex-1 py-3 space-y-2.5" aria-label="القائمة الرئيسية">
            {/* Separated unified menu: Control Panel, Products, Customers, Suppliers */}
            <div className="rounded-xl bg-white/[0.04] border border-white/10 p-1">
              {!isSlimRail && (
                <button
                  type="button"
                  onClick={() => setMasterMenuOpen(o => !o)}
                  className="w-full flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg text-[11px] font-extrabold text-[#5eead4] hover:bg-white/5 cursor-pointer"
                >
                  <span className="inline-flex items-center gap-2">
                    <FolderKanban className="w-3.5 h-3.5 shrink-0" />
                    <span>التحكم والمنتجات والجهات</span>
                  </span>
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform ${masterMenuOpen ? 'rotate-180' : ''}`} />
                </button>
              )}
              {(masterMenuOpen || isSlimRail) && (
                <div className={`${isSlimRail ? 'space-y-1' : 'mt-1 space-y-0.5'}`}>
                  {MASTER_NAV_ITEMS.map(item => {
                    const active = page === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        title={item.label}
                        onClick={() => navigate(item.id)}
                        className={`w-full flex items-center ${isSlimRail ? 'lg:justify-center lg:px-0 px-3' : 'px-2.5'} gap-2.5 py-2 rounded-lg text-xs font-bold transition-colors text-right cursor-pointer whitespace-nowrap ${
                          active
                            ? 'bg-[#0f766e]/45 text-white border border-[#14b8a6]/45'
                            : 'text-[#c2ded9] hover:bg-white/5 hover:text-white border border-transparent'
                        }`}
                      >
                        <span className={active ? 'text-[#5eead4]' : 'opacity-80'}>{item.icon}</span>
                        <span className={isSlimRail ? 'lg:hidden' : ''}>{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Operational & warehouse pages */}
            <div className="space-y-0.5">
              {!isSlimRail && (
                <div className="px-2.5 pt-1 text-[10.5px] font-bold text-[#7ca8a2]">العمليات والمخازن</div>
              )}
              {OPERATIONS_NAV_ITEMS.map(item => {
                const active = page === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    title={item.label}
                    onClick={() => navigate(item.id)}
                    className={`w-full flex items-center ${isSlimRail ? 'lg:justify-center lg:px-0 px-3' : 'px-2.5'} gap-2.5 py-2 rounded-xl text-xs font-bold transition-colors text-right cursor-pointer whitespace-nowrap ${
                      active
                        ? 'bg-[#0f766e]/35 text-white border border-[#14b8a6]/35'
                        : 'text-[#a8ccc6] hover:bg-white/5 hover:text-white border border-transparent'
                    }`}
                  >
                    <span className={active ? 'text-[#5eead4]' : 'opacity-80'}>{item.icon}</span>
                    <span className={isSlimRail ? 'lg:hidden' : ''}>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </nav>

          <div className="pt-3 border-t border-white/10 space-y-1.5">
            {isCalmSteps && (
              <div className="pb-2 mb-2 border-b border-white/10 space-y-1">
                <div className="px-1 text-[10.5px] font-bold text-[#7ca8a2]">تبديل التصميم:</div>
                <div className="grid grid-cols-2 gap-1">
                  {(
                    [
                      { id: 'calm-steps', label: 'اللوحة الهادئة' },
                      { id: 'labtop', label: 'LAB top' },
                      { id: 'saydaliti-v2', label: 'صيدليتي' },
                      { id: 'classic', label: 'الكلاسيكي' }
                    ] as { id: UILayoutMode; label: string }[]
                  ).map(opt => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => {
                        handleSwitchLayout(opt.id);
                        setMobileNavOpen(false);
                      }}
                      className={`px-2 py-1.5 rounded-lg text-[11px] font-bold cursor-pointer ${
                        layout === opt.id ? 'bg-[#0f766e] text-white' : 'bg-white/5 text-[#c2ded9] hover:bg-white/10'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
            <button
              type="button"
              title="تحميل التطبيق كله"
              onClick={() => setDownloadModalOpen(true)}
              className={`w-full flex items-center justify-center gap-1.5 px-2.5 py-2 rounded-lg bg-[#0f766e] hover:bg-[#0d655e] border border-[#14b8a6]/50 text-xs font-extrabold text-white cursor-pointer shadow-sm`}
            >
              <Download className="w-3.5 h-3.5 shrink-0" />
              <span className={isSlimRail ? 'lg:hidden' : ''}>تحميل التطبيق كله</span>
            </button>
            {!isSlimRail && (
              <>
                <button
                  type="button"
                  onClick={() => {
                    exportFullHTMLCopy(db);
                    toast('تم تنزيل نسخة HTML كاملة');
                  }}
                  className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0f766e]/40 hover:bg-[#0f766e]/60 border border-[#14b8a6]/35 text-[11px] font-bold text-white cursor-pointer"
                >
                  <FileCode2 className="w-3.5 h-3.5" />
                  <span>تنزيل نسخة HTML</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCompanyModalOpen(true)}
                  className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[11px] font-bold text-[#d5eae6] cursor-pointer"
                >
                  <Building2 className="w-3.5 h-3.5" />
                  <span>بيانات الصيدلية للترويسة</span>
                </button>
                <button
                  type="button"
                  onClick={() => setResetConfirmOpen(true)}
                  className="w-full px-3 py-1.5 rounded-lg border border-white/10 hover:bg-white/10 text-[11px] font-bold text-[#a8ccc6] cursor-pointer"
                >
                  إعادة ضبط البيانات التجريبية
                </button>
              </>
            )}
          </div>
        </aside>

        {/* Main Workspace */}
        <div className={`flex-1 min-w-0 flex flex-col ${isSplitV2 ? 'pb-16 lg:pb-0' : ''}`}>
          {isCalmSteps ? (
            <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-sm border-b border-[#dce6e3]">
              <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-8">
                {/* Zone 1: Brand Title */}
                <button
                  type="button"
                  onClick={() => navigate('dashboard')}
                  className="text-base font-extrabold text-[#102523] whitespace-nowrap shrink-0 cursor-pointer"
                >
                  صيدليتي
                </button>

                {/* Zone 2: 4 Clean Single-Line Nav Links */}
                <nav className="hidden md:flex items-center gap-6 text-xs font-bold text-[#5c7471]" aria-label="التنقل الرئيسي">
                  {(
                    [
                      { id: 'dashboard', label: 'الرئيسية' },
                      { id: 'issue', label: 'أذن صرف' },
                      { id: 'incoming', label: 'فاتورة وارد' },
                      { id: 'balance', label: 'الأرصدة' },
                      { id: 'products', label: 'المنتجات والجهات' }
                    ] as const
                  ).map(tab => {
                    const active = page === tab.id || (tab.id === 'products' && (page === 'customers' || page === 'suppliers'));
                    return (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => navigate(tab.id)}
                        className={`py-4 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                          active
                            ? 'border-[#0f766e] text-[#0f766e]'
                            : 'border-transparent hover:text-[#102523]'
                        }`}
                      >
                        {tab.label}
                      </button>
                    );
                  })}
                </nav>

                {/* Zone 3: Primary CTA + Menu Drawer Trigger */}
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => setMobileNavOpen(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Menu className="w-3.5 h-3.5" />
                    <span>كل الصفحات</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => navigate('issue')}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>أذن صرف</span>
                  </button>
                </div>
              </div>
            </header>
          ) : (
            <header className={`sticky top-0 z-30 bg-[#f4f8f7]/95 backdrop-blur-sm border-b border-[#dce6e3] px-3 sm:px-6 ${isClassic ? 'py-3' : 'py-2'} flex items-center justify-between gap-3`}>
              <div className="flex items-center gap-2.5 min-w-0">
                <button
                  type="button"
                  onClick={() => setMobileNavOpen(true)}
                  aria-label="فتح القائمة"
                  className="lg:hidden w-9 h-9 rounded-lg border border-[#dce6e3] bg-white grid place-items-center text-[#233d3a] cursor-pointer shrink-0"
                >
                  <Menu className="w-4 h-4" />
                </button>
                <div className="min-w-0">
                  <h1 className={`${isClassic ? 'text-base sm:text-lg' : 'text-sm sm:text-base'} font-extrabold text-[#102523] truncate`}>
                    {currentNav.label}
                  </h1>
                  {isClassic && (
                    <p className="text-[11.5px] text-[#5c7471] truncate hidden sm:block">{currentNav.sub}</p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
                <span className="hidden md:inline-block text-xs font-semibold text-[#5c7471] tabular-nums ml-1">
                  {fmtDate(todayISO())}
                </span>
                <button
                  type="button"
                  onClick={() => setDownloadModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg border border-[#b7dfd7] bg-[#eef8f6] text-xs font-bold text-[#073b39] hover:bg-[#dff2ee] whitespace-nowrap cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">تحميل التطبيق كله</span>
                  <span className="sm:hidden">تحميل</span>
                </button>
                <button
                  type="button"
                  onClick={() => navigate('returns')}
                  className="hidden sm:inline-flex px-3 py-1.5 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f0f5f4] whitespace-nowrap cursor-pointer"
                >
                  مرتجع عميل
                </button>
                <button
                  type="button"
                  onClick={() => navigate('issue')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] whitespace-nowrap cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>أذن صرف</span>
                </button>
              </div>
            </header>
          )}

          <main className={`flex-1 ${isCalmSteps ? 'p-4 sm:p-6' : isClassic ? 'p-4 sm:p-6 lg:p-7' : 'p-3 sm:p-4 lg:p-5'} max-w-[1440px] w-full mx-auto`}>
            {isCalmSteps && page !== 'dashboard' && (
              <div className="max-w-6xl mx-auto mb-4">
                <button
                  type="button"
                  onClick={() => navigate('dashboard')}
                  className="inline-flex items-center gap-1 text-xs font-bold text-[#0f766e] hover:underline cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                  <span>العودة للرئيسية</span>
                </button>
              </div>
            )}

            {/* Layout Comparison Switcher (shown on classic/labtop/v2; tucked cleanly on calm-steps) */}
            {!isCalmSteps && (
              <div className="mb-3 bg-white border border-[#dce6e3] rounded-xl p-1.5 flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-1">
                  <span className="text-[11px] font-extrabold text-[#5c7471] px-2">شكل الواجهة:</span>
                  <button
                    type="button"
                    onClick={() => handleSwitchLayout('calm-steps')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap cursor-pointer text-[#0f766e] hover:bg-[#eef8f6]`}
                  >
                    اللوحة الهادئة (1-2-3)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSwitchLayout('labtop')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                      isLabTop ? 'bg-[#0f766e] text-white shadow-sm' : 'text-[#3b5653] hover:bg-[#f4f8f7]'
                    }`}
                  >
                    ١) مخازن LAB top
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSwitchLayout('saydaliti-v2')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                      isSplitV2 ? 'bg-[#0f766e] text-white shadow-sm' : 'text-[#3b5653] hover:bg-[#f4f8f7]'
                    }`}
                  >
                    ٢) صيدليتي (التنسيق الجديد)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSwitchLayout('classic')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                      isClassic ? 'bg-[#102523] text-white shadow-sm' : 'text-[#5c7471] hover:bg-[#f4f8f7]'
                    }`}
                  >
                    الكلاسيكي (نقطة الرجوع)
                  </button>
                </div>
                <span className="text-[10.5px] text-[#5c7471] px-2 hidden md:inline">
                  جميع البيانات محفوظة ومشتركة — بدّل بين التصاميم بحرية
                </span>
              </div>
            )}

            {/* Design 1: LAB top Quick Action Dock */}
            {isLabTop && (
              <div className="mb-3.5 bg-[#eef8f6] border border-[#b7dfd7] rounded-xl p-2 flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => navigate('issue')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>أذن صرف جديد</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEditingProduct(null);
                    setProductFormOpen(true);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-[#b7dfd7] text-[#073b39] text-xs font-bold hover:bg-[#f7fbfa] cursor-pointer"
                >
                  <PackagePlus className="w-3.5 h-3.5 text-[#0f766e]" />
                  <span>منتج جديد</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setStockDrawerQuery('');
                    setStockDrawerOpen(true);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-[#dce6e3] text-[#233d3a] text-xs font-bold hover:bg-[#f7fbfa] cursor-pointer"
                >
                  <BarChart3 className="w-3.5 h-3.5 text-[#0f766e]" />
                  <span>فحص الرصيد الفوري</span>
                </button>
                <button
                  type="button"
                  onClick={() => navigate('incoming')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-[#dce6e3] text-[#233d3a] text-xs font-bold hover:bg-[#f7fbfa] cursor-pointer"
                >
                  <ArrowDownToLine className="w-3.5 h-3.5 text-[#0f766e]" />
                  <span>فاتورة وارد</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPartnerModalState({ open: true, type: 'customer', editing: null })}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white border border-[#dce6e3] text-[#233d3a] text-xs font-bold hover:bg-[#f7fbfa] cursor-pointer"
                >
                  <Plus className="w-3 h-3 text-[#0f766e]" />
                  <span>عميل</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPartnerModalState({ open: true, type: 'supplier', editing: null })}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white border border-[#dce6e3] text-[#233d3a] text-xs font-bold hover:bg-[#f7fbfa] cursor-pointer"
                >
                  <Plus className="w-3 h-3 text-[#0f766e]" />
                  <span>مورد</span>
                </button>
              </div>
            )}

            {/* Design 2: Saydaliti V2 Global Instant Stock Search */}
            {isSplitV2 && (
              <GlobalStockSearch
                onOpenStockDrawer={q => {
                  setStockDrawerQuery(q || '');
                  setStockDrawerOpen(true);
                }}
                onNewIssue={() => navigate('issue')}
                onNewProduct={() => {
                  setEditingProduct(null);
                  setProductFormOpen(true);
                }}
              />
            )}

            {isMasterPage && (
              <div className="mb-3.5 bg-white border border-[#dce6e3] rounded-xl p-1.5 flex flex-wrap items-center gap-1.5">
                {MASTER_NAV_ITEMS.map(item => {
                  const active = page === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => navigate(item.id)}
                      className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                        active
                          ? 'bg-[#0f766e] text-white shadow-sm'
                          : 'text-[#3b5653] hover:bg-[#f4f8f7] hover:text-[#102523]'
                      }`}
                    >
                      {item.icon}
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            )}
            {page === 'issue-list' && (
              <IssueListPage
                onCreateNew={() => navigate('issue')}
                onCreateSalesInvoice={openCreateSalesInvoice}
                onViewIssue={iss => setViewIssue(iss)}
                onEditIssue={handleEditIssue}
                onStartReturn={handleStartReturn}
              />
            )}
            {page === 'invoice-list' && (
              <InvoiceListPage
                onCreateIncoming={() => navigate('incoming')}
                onCreateSalesInvoice={openCreateSalesInvoice}
                onViewInvoice={inv => setViewInvoice(inv)}
                onViewIssue={iss => setViewIssue(iss)}
                onEditIssue={handleEditIssue}
              />
            )}
            {page === 'dashboard' &&
              (isCalmSteps ? (
                <CalmHomeHub
                  onNavigate={navigate}
                  onOpenImportExcel={() => setImportModalOpen(true)}
                  onCreateSalesInvoice={openCreateSalesInvoice}
                  onNewProduct={() => {
                    setEditingProduct(null);
                    setProductFormOpen(true);
                  }}
                  onNewCustomer={() => setPartnerModalState({ open: true, type: 'customer', editing: null })}
                  onNewSupplier={() => setPartnerModalState({ open: true, type: 'supplier', editing: null })}
                  onViewIssue={iss => setViewIssue(iss)}
                  onEditIssue={handleEditIssue}
                />
              ) : (
                <DashboardPage
                  onNavigate={navigate}
                  onOpenWarehouse={id => setWarehouseModalId(id)}
                  onViewIssue={iss => setViewIssue(iss)}
                  onEditIssue={handleEditIssue}
                />
              ))}
            {page === 'warehouses' && <WarehousesPage onOpenWarehouse={id => setWarehouseModalId(id)} />}
            {page === 'balance' && <BalancePage onPrintHtml={setPrintHtml} />}
            {page === 'products' && (
              <ProductsPage
                onAddProduct={() => {
                  setEditingProduct(null);
                  setProductFormOpen(true);
                }}
                onEditProduct={p => {
                  setEditingProduct(p);
                  setProductFormOpen(true);
                }}
                onViewProduct={id => setProductDetailId(id)}
              />
            )}
            {page === 'customers' && (
              <PartnersPage
                partnerType="customer"
                onAddPartner={type => setPartnerModalState({ open: true, type, editing: null })}
                onEditPartner={p => setPartnerModalState({ open: true, type: p.type, editing: p })}
                onOpenCompany={() => setCompanyModalOpen(true)}
                onPrintHtml={setPrintHtml}
              />
            )}
            {page === 'suppliers' && (
              <PartnersPage
                partnerType="supplier"
                onAddPartner={type => setPartnerModalState({ open: true, type, editing: null })}
                onEditPartner={p => setPartnerModalState({ open: true, type: p.type, editing: p })}
                onOpenCompany={() => setCompanyModalOpen(true)}
                onPrintHtml={setPrintHtml}
              />
            )}
            {page === 'incoming' && (
              <IncomingPage
                draft={incomingDraft}
                setDraft={setIncomingDraft}
                onOpenLinePicker={() => setLinePickerMode('incoming')}
                onOpenImport={() => setImportModalOpen(true)}
                onQuickSupplier={() => setPartnerModalState({ open: true, type: 'supplier', editing: null, target: 'incoming' })}
                onViewInvoice={inv => setViewInvoice(inv)}
              />
            )}
            {page === 'issue' && (
              <IssuePage
                draft={issueDraft}
                setDraft={setIssueDraft}
                editingIssue={editingIssue}
                supplierFilter={issueSupplierFilter}
                onChangeSupplierFilter={setIssueSupplierFilter}
                onOpenLinePicker={() => setLinePickerMode('issue')}
                onQuickCustomer={() => setPartnerModalState({ open: true, type: 'customer', editing: null, target: 'issue' })}
                onViewIssue={iss => setViewIssue(iss)}
                onEditIssue={handleEditIssue}
                onCreateSalesInvoice={openCreateSalesInvoice}
                onStartReturn={handleStartReturn}
              />
            )}
            {page === 'returns' && (
              <ReturnsPage
                preselectedIssueId={preselectedReturnIssueId}
                onViewReturn={ret => setViewReturn(ret)}
              />
            )}
            {page === 'transfers' && (
              <TransfersPage
                draft={transferDraft}
                setDraft={setTransferDraft}
                onOpenLinePicker={() => setLinePickerMode('transfer')}
                onViewTransfer={tr => setViewTransfer(tr)}
              />
            )}
            {page === 'reports' && <ReportsPage onPrintHtml={setPrintHtml} />}
            {page === 'queries' && <QueriesPage onPrintHtml={setPrintHtml} />}
            {page === 'movements' && <MovementsPage />}
          </main>
        </div>
      </div>

      {/* Modals */}
      <WarehouseReceiptModal
        warehouseId={warehouseModalId}
        onSelectWarehouse={id => setWarehouseModalId(id)}
        onClose={() => setWarehouseModalId(null)}
        onPrintHtml={setPrintHtml}
      />

      <ProductDetailModal
        productId={productDetailId}
        onClose={() => setProductDetailId(null)}
        onEdit={p => {
          setEditingProduct(p);
          setProductFormOpen(true);
        }}
      />

      <ProductFormModal
        open={productFormOpen}
        editingProduct={editingProduct}
        onClose={() => setProductFormOpen(false)}
      />

      <PartnerFormModal
        open={partnerModalState.open}
        defaultType={partnerModalState.type}
        editingPartner={partnerModalState.editing}
        onClose={() => setPartnerModalState(prev => ({ ...prev, open: false }))}
        onSaved={created => {
          if (partnerModalState.target === 'incoming' && created.type === 'supplier') {
            setIncomingDraft(prev => ({ ...prev, supplierId: created.id }));
          }
          if (partnerModalState.target === 'issue' && created.type === 'customer') {
            setIssueDraft(prev => ({ ...prev, customerId: created.id }));
          }
        }}
      />

      <CompanyModal open={companyModalOpen} onClose={() => setCompanyModalOpen(false)} />

      <DownloadAppModal open={downloadModalOpen} onClose={() => setDownloadModalOpen(false)} />

      <LinePickerModal
        open={linePickerMode !== null}
        mode={linePickerMode || 'issue'}
        warehouseId={
          linePickerMode === 'issue'
            ? issueDraft.warehouseId
            : linePickerMode === 'transfer'
              ? transferDraft.from
              : undefined
        }
        onChangeWarehouse={
          linePickerMode === 'issue' &&
          !(issueDraft.editingIssueId && (db.returns || []).some(r => r.issueId === issueDraft.editingIssueId))
            ? whId => setIssueDraft(prev => ({ ...prev, warehouseId: whId }))
            : undefined
        }
        initialSupplierId={linePickerMode === 'issue' ? issueSupplierFilter : undefined}
        onChangeSupplier={linePickerMode === 'issue' ? setIssueSupplierFilter : undefined}
        extraStockByProduct={linePickerMode === 'issue' ? issueExtraStockMap : undefined}
        onClose={() => setLinePickerMode(null)}
        onAdd={data => {
          if (linePickerMode === 'incoming') {
            setIncomingDraft(prev => ({
              ...prev,
              lines: [
                ...prev.lines,
                {
                  id: uid('ln'),
                  productId: data.productId,
                  strips: data.strips,
                  units: data.units,
                  expiry: data.expiry || todayISO(),
                  batch: data.batch || 'LOT-1'
                }
              ]
            }));
          } else if (linePickerMode === 'issue') {
            setIssueDraft(prev => ({
              ...prev,
              lines: [
                ...prev.lines,
                {
                  id: uid('ln'),
                  productId: data.productId,
                  strips: data.strips,
                  units: data.units,
                  asReceipt: data.asReceipt,
                  receiptType: data.receiptType
                }
              ]
            }));
          } else if (linePickerMode === 'transfer') {
            setTransferDraft(prev => ({
              ...prev,
              lines: [...prev.lines, { id: uid('ln'), productId: data.productId, strips: data.strips, units: data.units }]
            }));
          }
        }}
      />

      <ImportBulkModal
        open={importModalOpen}
        onClose={() => setImportModalOpen(false)}
        onImportedToDraft={rows => {
          setIncomingDraft(prev => ({
            ...prev,
            lines: [...prev.lines, ...rows.map(r => ({ id: uid('ln'), ...r }))]
          }));
        }}
      />

      <CreateSalesInvoiceModal
        open={salesInvoiceModalState.open}
        preselectedIssueId={salesInvoiceModalState.preselectedIssueId}
        onClose={() => setSalesInvoiceModalState({ open: false, preselectedIssueId: null })}
        onCreated={updated => setViewIssue(updated)}
        onGoCreateIssue={() => navigate('issue')}
      />

      <InvoiceDetailModal
        invoice={viewInvoice}
        onClose={() => setViewInvoice(null)}
        onPrintHtml={setPrintHtml}
      />

      <IssueDetailModal
        issue={viewIssue}
        onClose={() => setViewIssue(null)}
        onEdit={handleEditIssue}
        onCreateSalesInvoice={openCreateSalesInvoice}
        onStartReturn={handleStartReturn}
        onPrintHtml={setPrintHtml}
      />

      <ReturnDetailModal
        ret={viewReturn}
        onClose={() => setViewReturn(null)}
        onPrintHtml={setPrintHtml}
      />

      <TransferDetailModal
        transfer={viewTransfer}
        onClose={() => setViewTransfer(null)}
        onPrintHtml={setPrintHtml}
      />

      <Modal
        open={resetConfirmOpen}
        onClose={() => setResetConfirmOpen(false)}
        title="إعادة ضبط البيانات التجريبية"
        subtitle="سيتم استرجاع بيانات البداية وحذف الفواتير والأذون المضافة محليًا"
        footer={
          <>
            <button
              type="button"
              onClick={() => setResetConfirmOpen(false)}
              className="px-4 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="button"
              onClick={() => {
                resetData();
                setResetConfirmOpen(false);
                toast('تمت إعادة ضبط البيانات بنجاح');
              }}
              className="px-4 py-2 rounded-lg bg-[#dc2626] text-white text-xs font-bold cursor-pointer"
            >
              تأكيد إعادة الضبط
            </button>
          </>
        }
      >
        <p className="text-xs text-[#3b5653] leading-relaxed">
          هل أنت متأكد من رغبتك في مسح التعديلات الحالية والعودة للبيانات التجريبية الافتراضية؟ يمكنك أخذ نسخة احتياطية من صفحة المخازن قبل المتابعة.
        </p>
      </Modal>

      <QuickStockDrawer
        open={stockDrawerOpen}
        initialQuery={stockDrawerQuery}
        onClose={() => setStockDrawerOpen(false)}
        onGoIssue={() => navigate('issue')}
        onAddProduct={() => {
          setEditingProduct(null);
          setProductFormOpen(true);
        }}
      />

      {isSplitV2 && (
        <nav
          aria-label="التنقل السريع للموبايل"
          className="fixed bottom-0 inset-x-0 z-30 lg:hidden bg-white/95 backdrop-blur-md border-t border-[#dce6e3] grid grid-cols-5 h-14 no-print"
        >
          {(
            [
              { id: 'issue', label: 'أذن صرف', icon: <Plus className="w-4 h-4" /> },
              { id: 'issue-list', label: 'الأذون', icon: <ClipboardList className="w-4 h-4" /> },
              { id: 'balance', label: 'الرصيد', icon: <BarChart3 className="w-4 h-4" /> },
              { id: 'products', label: 'المنتجات', icon: <Package className="w-4 h-4" /> }
            ] as const
          ).map(tab => {
            const active = page === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => navigate(tab.id)}
                className={`flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold cursor-pointer ${
                  active ? 'text-[#0f766e]' : 'text-[#5c7471]'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => setMobileNavOpen(true)}
            className="flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold text-[#5c7471] cursor-pointer"
          >
            <Menu className="w-4 h-4" />
            <span>المزيد</span>
          </button>
        </nav>
      )}

      {/* Toasts */}
      <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-[100] flex flex-col gap-2 items-center pointer-events-none no-print">
        {toasts.map(t => (
          <div
            key={t.id}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold shadow-lg border ${
              t.type === 'err'
                ? 'bg-[#7f1d1d] text-white border-[#991b1b]'
                : t.type === 'warn'
                  ? 'bg-[#78350f] text-white border-[#92400e]'
                  : 'bg-[#082423] text-[#e9fbf7] border-[#0f766e]'
            }`}
          >
            {t.text}
          </div>
        ))}
      </div>

      {/* Print Portal */}
      {printHtml && (
        <div
          className="hidden print-only p-4"
          dangerouslySetInnerHTML={{ __html: printHtml }}
        />
      )}
    </>
  );
}

export default function App() {
  return (
    <LayoutModeProvider>
      <PharmaStoreProvider>
        <MainShell />
      </PharmaStoreProvider>
    </LayoutModeProvider>
  );
}
