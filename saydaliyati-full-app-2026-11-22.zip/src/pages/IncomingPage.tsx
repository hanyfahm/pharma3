import React, { useMemo, useState } from 'react';
import { Check, Eye, Plus, Search, Trash2, Upload } from 'lucide-react';
import { distributeQuantities, usePharmaStore } from '../store/usePharmaStore';
import { useLayoutMode } from '../store/useLayoutMode';
import type { DraftIncoming, Invoice, Product } from '../types/pharma';
import { calc14Percent, calcInvoiceValue, calcTotalWith14, fmtDate, fmtMoney, fmtNum, shiftISO, tafqeetEGP, todayISO, toFullDate, uid, unitsText } from '../utils/format';
import { downloadCSVTemplate, downloadExcelTemplate, exportToExcel } from '../utils/export';
import { computeNextIncomingNo, findDuplicateInvoiceNo } from '../utils/pharmaEngine';
import { EmptyState, ExcelButton, ExpiryTag, PageHeader } from '../components/ui/CommonUI';
import { CalmIncomingWizard } from '../components/CalmIncomingWizard';

export function IncomingPage({
  draft,
  setDraft,
  onOpenLinePicker,
  onOpenImport,
  onQuickSupplier,
  onViewInvoice
}: {
  draft: DraftIncoming;
  setDraft: React.Dispatch<React.SetStateAction<DraftIncoming>>;
  onOpenLinePicker: () => void;
  onOpenImport: () => void;
  onQuickSupplier: () => void;
  onViewInvoice: (inv: Invoice) => void;
}) {
  const { db, getProduct, commitIncomingInvoice, toast } = usePharmaStore();
  const { isSplitV2, isCalmSteps } = useLayoutMode();
  const suppliers = db.partners.filter(p => p.type === 'supplier');
  const [confirming, setConfirming] = useState(false);
  const [catSearch, setCatSearch] = useState('');
  const [catInputs, setCatInputs] = useState<
    Record<string, { qty: number; unitName: string; expiry: string; batch: string }>
  >({});

  const buildDefaultManualAlloc = (strips: number): Record<string, number> => {
    const nums = distributeQuantities(strips, db.warehouses.map(w => w.share));
    const map: Record<string, number> = {};
    db.warehouses.forEach((w, i) => {
      map[w.id] = nums[i] || 0;
    });
    return map;
  };

  const shares = useMemo(
    () => (draft.mode === 'equal' ? db.warehouses.map(() => 100 / db.warehouses.length) : db.warehouses.map(w => w.share)),
    [draft.mode, db.warehouses]
  );

  const distribution = useMemo(() => {
    return draft.lines.map(l => {
      const p = getProduct(l.productId);
      const fallbackNums = distributeQuantities(l.strips, shares);
      const alloc = db.warehouses.map((w, i) => ({
        warehouseId: w.id,
        strips:
          draft.mode === 'manual'
            ? Math.max(0, Math.round(Number(l.manualAlloc?.[w.id] ?? fallbackNums[i]) || 0))
            : fallbackNums[i]
      }));
      const allocSum = alloc.reduce((s, a) => s + a.strips, 0);
      return {
        line: l,
        product: p,
        alloc,
        allocSum,
        diff: l.strips - allocSum
      };
    });
  }, [draft.lines, draft.mode, shares, db.warehouses, getProduct]);

  const hasManualMismatch = draft.mode === 'manual' && distribution.some(d => d.diff !== 0);

  const totalStrips = draft.lines.reduce((s, l) => s + l.strips, 0);
  const totalValue = draft.lines.reduce((s, l) => s + l.strips * (getProduct(l.productId)?.price || 0), 0);

  const handleModeChange = (nextMode: 'shares' | 'equal' | 'manual') => {
    setDraft(prev => ({
      ...prev,
      mode: nextMode,
      lines:
        nextMode === 'manual'
          ? prev.lines.map(l => ({
              ...l,
              manualAlloc: l.manualAlloc || buildDefaultManualAlloc(l.strips)
            }))
          : prev.lines
    }));
  };

  const updateLineManualAlloc = (lineId: string, warehouseId: string, val: number) => {
    const clean = Math.max(0, Math.round(Number(val) || 0));
    setDraft(prev => ({
      ...prev,
      lines: prev.lines.map(l => {
        if (l.id !== lineId) return l;
        const base = l.manualAlloc || buildDefaultManualAlloc(l.strips);
        return {
          ...l,
          manualAlloc: {
            ...base,
            [warehouseId]: clean
          }
        };
      })
    }));
  };

  const setLineAllToMain = (lineId: string, strips: number) => {
    const mainWh = db.warehouses.find(w => w.kind === 'main') || db.warehouses[0];
    const map: Record<string, number> = {};
    db.warehouses.forEach(w => {
      map[w.id] = w.id === mainWh?.id ? strips : 0;
    });
    setDraft(prev => ({
      ...prev,
      lines: prev.lines.map(l => (l.id === lineId ? { ...l, manualAlloc: map } : l))
    }));
  };

  const resetLineManualByShares = (lineId: string, strips: number) => {
    const map = buildDefaultManualAlloc(strips);
    setDraft(prev => ({
      ...prev,
      lines: prev.lines.map(l => (l.id === lineId ? { ...l, manualAlloc: map } : l))
    }));
  };

  const clearLineManual = (lineId: string) => {
    const map: Record<string, number> = {};
    db.warehouses.forEach(w => {
      map[w.id] = 0;
    });
    setDraft(prev => ({
      ...prev,
      lines: prev.lines.map(l => (l.id === lineId ? { ...l, manualAlloc: map } : l))
    }));
  };

  const filteredCatalog = useMemo(() => {
    const q = catSearch.trim().toLowerCase();
    return db.products.filter(
      p => !q || `${p.name} ${p.code} ${p.form}`.toLowerCase().includes(q)
    );
  }, [db.products, catSearch]);

  const handleQuickAddIncoming = (p: Product) => {
    const fallbackExp = shiftISO(todayISO(), 365);
    const fallbackBatch = `L-${Math.floor(1000 + Math.random() * 8999)}`;
    const row = catInputs[p.id] || {
      qty: 1,
      unitName: p.units[1]?.name || p.units[0]?.name || 'شريط',
      expiry: fallbackExp,
      batch: fallbackBatch
    };
    const unitObj = p.units.find(u => u.name === row.unitName) || p.units[0];
    const qty = Math.max(1, Math.round(row.qty || 1));
    const strips = qty * (unitObj?.factor || 1);
    const expiry = toFullDate(row.expiry || fallbackExp);
    const batch = (row.batch || fallbackBatch).trim();
    if (!expiry || !batch) {
      toast('أدخل الصلاحية ورقم التشغيلة', 'err');
      return;
    }
    setDraft(prev => ({
      ...prev,
      lines: [
        ...prev.lines,
        {
          id: uid('ln'),
          productId: p.id,
          units: [{ name: unitObj.name, qty }],
          strips,
          expiry,
          batch,
          ...(prev.mode === 'manual' ? { manualAlloc: buildDefaultManualAlloc(strips) } : {})
        }
      ]
    }));
    toast(`تمت إضافة ${qty} ${unitObj.name} من ${p.name}`);
  };

  const loadDemoInvoice = () => {
    const exp1 = shiftISO(todayISO(), 420);
    const exp2 = shiftISO(todayISO(), 540);
    setDraft(prev => ({
      ...prev,
      lines: [
        {
          id: uid('ln'),
          productId: 'P001',
          units: [{ name: 'علبة', qty: 10 }],
          strips: 20,
          expiry: exp1,
          batch: 'DEMO-101',
          ...(prev.mode === 'manual' ? { manualAlloc: buildDefaultManualAlloc(20) } : {})
        },
        {
          id: uid('ln'),
          productId: 'P002',
          units: [{ name: 'علبة', qty: 6 }],
          strips: 12,
          expiry: exp2,
          batch: 'DEMO-102',
          ...(prev.mode === 'manual' ? { manualAlloc: buildDefaultManualAlloc(12) } : {})
        },
        {
          id: uid('ln'),
          productId: 'S001',
          units: [{ name: 'علبة', qty: 4 }],
          strips: 400,
          expiry: exp2,
          batch: 'DEMO-103',
          ...(prev.mode === 'manual' ? { manualAlloc: buildDefaultManualAlloc(400) } : {})
        }
      ]
    }));
    toast('تم تحميل فاتورة تجريبية للمعاينة');
  };

  const dupInvoiceNo = findDuplicateInvoiceNo(db, draft.no);

  const handleConfirm = async () => {
    if (!draft.lines.length) {
      toast('أضف بنودًا للفاتورة أولًا', 'err');
      return;
    }
    if (!draft.no.trim()) {
      toast('أدخل رقم فاتورة المورد أولًا', 'err');
      return;
    }
    if (dupInvoiceNo) {
      toast(
        `رقم الفاتورة «${draft.no.trim()}» مستخدم بالفعل (${dupInvoiceNo.source === 'incoming' ? `فاتورة وارد ${dupInvoiceNo.ref}` : `أذن صرف ${dupInvoiceNo.ref}`}) — لا يصح تكرار رقم الفاتورة`,
        'err'
      );
      return;
    }
    if (hasManualMismatch) {
      toast('مجموع التوزيع اليدوي على المخازن يجب أن يساوي إجمالي الوارد لكل صنف', 'err');
      return;
    }
    const preparedDraft: DraftIncoming =
      draft.mode === 'manual'
        ? {
            ...draft,
            lines: draft.lines.map(l => ({
              ...l,
              manualAlloc: l.manualAlloc || buildDefaultManualAlloc(l.strips)
            }))
          }
        : draft;
    setConfirming(true);
    try {
      const inv = await commitIncomingInvoice(preparedDraft);
      toast(`تم ترحيل فاتورة الوارد ${inv.no} وتوزيعها على ${db.warehouses.length} مخازن`);
      const nextNo = computeNextIncomingNo({
        ...db,
        invoices: [inv, ...db.invoices],
        meta: { ...db.meta, nextInvoice: db.meta.nextInvoice + 1 }
      });
      setDraft({
        no: nextNo,
        supplierId: suppliers[0]?.id || '',
        date: todayISO(),
        mode: draft.mode,
        lines: []
      });
    } catch (err) {
      toast(err instanceof Error ? err.message : 'تعذر ترحيل الفاتورة', 'err');
    } finally {
      setConfirming(false);
    }
  };

  const exportDistExcel = () => {
    const headers = ['الكود', 'الصنف', 'التشغيلة', 'الصلاحية', 'إجمالي الوارد', ...db.warehouses.map(w => w.name)];
    const rows = distribution.map(d => [
      d.product?.code || '',
      d.product?.name || '',
      d.line.batch,
      fmtDate(d.line.expiry),
      d.line.strips,
      ...d.alloc.map(a => a.strips)
    ]);
    exportToExcel(`توزيع_فاتورة_${draft.no}.xlsx`, 'التوزيع', headers, rows);
    toast('تم تصدير جدول التوزيع إلى Excel');
  };

  const exportHistoryExcel = () => {
    const headers = ['رقم الفاتورة', 'التاريخ', 'المورد', 'عدد البنود', 'إجمالي الوحدات', 'القيمة (ج.م)', 'قيمة 14% (ج.م)', 'المبلغ الإجمالي شامل 14% (ج.م)', 'تفقيط المبلغ الإجمالي'];
    const rows = db.invoices.map(inv => {
      const val = calcInvoiceValue(inv, db.products);
      const val14 = calc14Percent(val);
      const grand = calcTotalWith14(val);
      return [
        inv.no,
        fmtDate(inv.date),
        inv.supplier,
        inv.lines.length,
        inv.totalStrips,
        Number(val.toFixed(2)),
        val14,
        grand,
        tafqeetEGP(grand)
      ];
    });
    exportToExcel(`فواتير_الوارد_${todayISO()}.xlsx`, 'فواتير الوارد', headers, rows);
    toast('تم تصدير سجل فواتير الوارد إلى Excel');
  };

  if (isCalmSteps) {
    return (
      <CalmIncomingWizard
        draft={draft}
        setDraft={setDraft}
        onOpenImport={onOpenImport}
        onQuickSupplier={onQuickSupplier}
        onViewInvoice={onViewInvoice}
      />
    );
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="فاتورة وارد"
        subtitle="أضف بنود الفاتورة أو استوردها من Excel (.xlsx) أو CSV/JSON ليتم توزيعها تلقائيًا على المخازن وحساب الصلاحيات"
        actions={
          <>
            <button
              type="button"
              onClick={() => setDraft(prev => ({ ...prev, lines: [] }))}
              className="px-3.5 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
            >
              مسح المسودة
            </button>
            <button
              type="button"
              onClick={onOpenImport}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#047857] text-white text-xs font-bold hover:bg-[#065f46] cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>استيراد من Excel (.xlsx)</span>
            </button>
            <button
              type="button"
              onClick={onOpenImport}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#6d28d9] text-white text-xs font-bold hover:bg-[#5b21b6] cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>استيراد بيانات وارد</span>
            </button>
          </>
        }
      />

      {/* Upload banner (hidden in compact split V2 to keep workspace tight; quick action buttons stay in header) */}
      {!isSplitV2 ? (
        <div className="flex flex-wrap items-center justify-between gap-4 bg-[#f6fbfa] border-2 border-dashed border-[#b7d6cf] rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-white border border-[#dce6e3] text-[#0f766e] grid place-items-center shrink-0">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-extrabold text-[#102523]">استيراد فاتورة وارد دفعة واحدة</div>
              <p className="text-xs text-[#5c7471]">يدعم ملفات Excel (.xlsx / .xls) و CSV و JSON مع تجميع نفس الكود + التشغيلة + الصلاحية والتوزيع التلقائي على المخازن</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button type="button" onClick={onOpenImport} className="px-3.5 py-2 rounded-lg bg-[#047857] text-white text-xs font-bold hover:bg-[#065f46] cursor-pointer">
              استيراد ملف Excel (.xlsx)
            </button>
            <button type="button" onClick={onOpenImport} className="px-3.5 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold cursor-pointer">
              رفع ملف CSV / JSON
            </button>
            <button type="button" onClick={loadDemoInvoice} className="px-3.5 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] cursor-pointer">
              فاتورة تجريبية
            </button>
            <button type="button" onClick={downloadExcelTemplate} className="px-3 py-2 rounded-lg border border-[#a7f3d0] bg-[#ecfdf5] text-xs font-bold text-[#047857] hover:bg-[#d1fae5] cursor-pointer">
              تحميل قالب Excel (.xlsx)
            </button>
            <button type="button" onClick={downloadCSVTemplate} className="px-2.5 py-2 text-xs font-bold text-[#0f766e] hover:underline cursor-pointer">
              تحميل قالب CSV
            </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-wrap items-center justify-between gap-2 bg-[#f8fbfa] border border-[#dce6e3] rounded-xl px-3.5 py-2 text-xs">
          <span className="font-bold text-[#3b5653]">استيراد وتجربة سريعة:</span>
          <div className="flex flex-wrap items-center gap-1.5">
            <button type="button" onClick={onOpenImport} className="px-2.5 py-1 rounded-md bg-[#047857] text-white text-[11px] font-bold cursor-pointer">
              استيراد Excel (.xlsx)
            </button>
            <button type="button" onClick={loadDemoInvoice} className="px-2.5 py-1 rounded-md border border-[#dce6e3] bg-white text-[11px] font-bold text-[#233d3a] cursor-pointer">
              فاتورة تجريبية
            </button>
            <button type="button" onClick={downloadExcelTemplate} className="px-2.5 py-1 rounded-md border border-[#a7f3d0] bg-[#ecfdf5] text-[11px] font-bold text-[#047857] cursor-pointer">
              قالب Excel (.xlsx)
            </button>
            <button type="button" onClick={downloadCSVTemplate} className="px-2.5 py-1 rounded-md border border-[#b7dfd7] bg-[#eef8f6] text-[11px] font-bold text-[#0f766e] cursor-pointer">
              قالب CSV
            </button>
          </div>
        </div>
      )}

      {isSplitV2 && (
        <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
          <div className="px-3.5 py-2.5 border-b border-[#eaf1ef] bg-[#f8fbfa] flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-xs font-extrabold text-[#102523]">إضافة أصناف سريعة لفاتورة الوارد ({filteredCatalog.length})</h3>
              <p className="text-[10.5px] text-[#5c7471]">أدخل الكمية والتشغيلة والصلاحية واضغط أضف مباشرة</p>
            </div>
            <div className="relative min-w-[200px] flex-1 max-w-xs">
              <Search className="w-3.5 h-3.5 text-[#6b8481] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={catSearch}
                onChange={e => setCatSearch(e.target.value)}
                placeholder="بحث عن صنف بالاسم أو الكود..."
                className="w-full pr-8 pl-2.5 py-1.5 text-xs bg-white border border-[#dce6e3] rounded-lg focus:outline-none focus:border-[#0f766e]"
              />
            </div>
          </div>
          <div className="max-h-64 overflow-y-auto divide-y divide-[#edf3f1]">
            {filteredCatalog.map(p => {
              const defExp = shiftISO(todayISO(), 365);
              const row = catInputs[p.id] || {
                qty: 1,
                unitName: p.units[1]?.name || p.units[0]?.name || 'شريط',
                expiry: defExp,
                batch: `L-${p.code}`
              };
              return (
                <div key={p.id} className="px-3 py-2 flex flex-wrap items-center gap-2 hover:bg-[#f9fcfb]">
                  <div className="min-w-[160px] flex-1">
                    <div className="text-xs font-bold text-[#102523]">{p.name}</div>
                    <div className="text-[10.5px] text-[#5c7471]">{p.code} · {fmtMoney(p.price)} ج.م</div>
                  </div>
                  <input
                    type="number"
                    min={1}
                    value={row.qty}
                    onChange={e =>
                      setCatInputs(prev => ({
                        ...prev,
                        [p.id]: { ...row, qty: Math.max(1, Number(e.target.value) || 1) }
                      }))
                    }
                    className="w-16 px-2 py-1 rounded-md border border-[#dce6e3] text-xs text-center font-bold tabular-nums"
                  />
                  <select
                    value={row.unitName}
                    onChange={e =>
                      setCatInputs(prev => ({
                        ...prev,
                        [p.id]: { ...row, unitName: e.target.value }
                      }))
                    }
                    className="w-28 px-2 py-1 rounded-md border border-[#dce6e3] text-xs bg-white"
                  >
                    {p.units.map(u => (
                      <option key={u.name} value={u.name}>
                        {u.name} ({u.factor})
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    value={row.batch}
                    onChange={e =>
                      setCatInputs(prev => ({
                        ...prev,
                        [p.id]: { ...row, batch: e.target.value }
                      }))
                    }
                    placeholder="التشغيلة"
                    className="w-24 px-2 py-1 rounded-md border border-[#dce6e3] text-xs font-mono-num"
                  />
                  <input
                    type="date"
                    value={row.expiry}
                    onChange={e =>
                      setCatInputs(prev => ({
                        ...prev,
                        [p.id]: { ...row, expiry: e.target.value }
                      }))
                    }
                    className="w-32 px-2 py-1 rounded-md border border-[#dce6e3] text-xs"
                  />
                  <button
                    type="button"
                    onClick={() => handleQuickAddIncoming(p)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#0f766e] text-white text-[11px] font-bold hover:bg-[#0d655e] cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>أضف</span>
                  </button>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Invoice metadata */}
      <section className="bg-white border border-[#dce6e3] rounded-xl p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>رقم فاتورة المورد *</span>
            <input
              value={draft.no}
              onChange={e => setDraft(prev => ({ ...prev, no: e.target.value }))}
              className={`mt-1 w-full px-3 py-2 rounded-lg border text-xs font-mono-num ${
                dupInvoiceNo ? 'border-[#dc2626] bg-[#fef2f2] text-[#b91c1c]' : 'border-[#dce6e3]'
              }`}
            />
            {dupInvoiceNo && (
              <span className="block mt-1 text-[10.5px] font-bold text-[#dc2626]">
                رقم الفاتورة مستخدم بالفعل ({dupInvoiceNo.source === 'incoming' ? `فاتورة وارد ${dupInvoiceNo.ref}` : `أذن صرف ${dupInvoiceNo.ref}`}) — ممنوع التكرار
              </span>
            )}
          </label>
          <div className="block text-xs font-bold text-[#233d3a]">
            <label htmlFor="incoming-supplier-select" className="block">المورد *</label>
            <div className="mt-1 flex items-center gap-1.5">
              <select
                id="incoming-supplier-select"
                value={draft.supplierId || suppliers[0]?.id || ''}
                onChange={e => setDraft(prev => ({ ...prev, supplierId: e.target.value }))}
                className="flex-1 min-w-0 px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white"
              >
                {suppliers.length ? (
                  suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)
                ) : (
                  <option value="">لا يوجد موردون مسجلون</option>
                )}
              </select>
              <button
                type="button"
                onClick={onQuickSupplier}
                title="إضافة مورد جديد"
                className="w-9 h-9 rounded-lg border border-[#dce6e3] bg-white hover:bg-[#f4f8f7] grid place-items-center shrink-0 cursor-pointer"
              >
                <Plus className="w-4 h-4 text-[#0f766e]" />
              </button>
            </div>
          </div>
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>تاريخ الاستلام</span>
            <input
              type="date"
              value={draft.date}
              onChange={e => setDraft(prev => ({ ...prev, date: e.target.value }))}
              className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs"
            />
          </label>
          <label className="block text-xs font-bold text-[#233d3a]">
            <span>طريقة التوزيع</span>
            <select
              value={draft.mode}
              onChange={e => handleModeChange(e.target.value as 'shares' | 'equal' | 'manual')}
              className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white"
            >
              <option value="shares">حسب نسب المخازن</option>
              <option value="equal">بالتساوي بين المخازن</option>
              <option value="manual">توزيع يدوي على المخازن</option>
            </select>
          </label>
        </div>
      </section>

      {/* Draft lines */}
      <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
        <div className="flex items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
          <div>
            <h3 className="text-sm font-extrabold text-[#102523]">بنود الفاتورة ({draft.lines.length})</h3>
            <p className="text-[11.5px] text-[#5c7471]">الكميات بالوحدات مع تاريخ الصلاحية ورقم التشغيلة</p>
          </div>
          <button
            type="button"
            onClick={onOpenLinePicker}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#eef8f6] text-[#0f766e] border border-[#b7dfd7] text-xs font-bold hover:bg-[#dff3ef] cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>إضافة بند</span>
          </button>
        </div>
        {draft.lines.length ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                  <th className="py-2.5 px-3 text-right font-bold">الصنف</th>
                  <th className="py-2.5 px-3 text-right font-bold">الكمية</th>
                  <th className="py-2.5 px-3 text-center font-bold">الصلاحية</th>
                  <th className="py-2.5 px-3 text-center font-bold">التشغيلة</th>
                  <th className="py-2.5 px-3 text-left font-bold">القيمة</th>
                  <th className="py-2.5 px-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#edf3f1]">
                {draft.lines.map(l => {
                  const p = getProduct(l.productId);
                  if (!p) return null;
                  return (
                    <tr key={l.id}>
                      <td className="py-2.5 px-3">
                        <div className="font-bold">{p.name}</div>
                        <div className="text-[11px] text-[#5c7471]">{p.code} · {p.form}</div>
                      </td>
                      <td className="py-2.5 px-3 font-bold tabular-nums">{unitsText(l.strips, p)}</td>
                      <td className="py-2.5 px-3 text-center"><ExpiryTag date={l.expiry} /></td>
                      <td className="py-2.5 px-3 text-center font-mono-num">{l.batch}</td>
                      <td className="py-2.5 px-3 text-left font-bold tabular-nums">{fmtMoney(l.strips * p.price)} ج.م</td>
                      <td className="py-2.5 px-3 text-left">
                        <button
                          type="button"
                          onClick={() => setDraft(prev => ({ ...prev, lines: prev.lines.filter(x => x.id !== l.id) }))}
                          className="p-1.5 rounded-md border border-[#fecaca] text-[#dc2626] hover:bg-[#fef2f2] cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<Upload className="w-6 h-6" />}
            title="الفاتورة فارغة"
            description="أضف بنودًا يدويًا أو استورد ملف CSV/JSON أو جرّب الفاتورة التجريبية."
            action={
              <button type="button" onClick={onOpenLinePicker} className="px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold cursor-pointer">
                إضافة بند
              </button>
            }
          />
        )}
      </section>

      {/* Distribution preview & manual allocation */}
      {distribution.length > 0 && (
        <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
            <div>
              <h3 className="text-sm font-extrabold text-[#102523]">
                {draft.mode === 'manual' ? 'التوزيع اليدوي على المخازن' : 'معاينة توزيع نصيب المخازن'}
              </h3>
              <p className="text-[11.5px] text-[#5c7471]">
                {draft.mode === 'manual'
                  ? 'اكتب الكمية بالوحدة الأساسية لكل مخزن (الرئيسي والفروع) بحيث يساوي المجموع إجمالي الوارد'
                  : 'نصيب كل مخزن قبل الاعتماد النهائي'}
              </p>
            </div>
            <ExcelButton small onClick={exportDistExcel} />
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                  <th className="py-2.5 px-3 text-right font-bold">الصنف</th>
                  <th className="py-2.5 px-3 text-center font-bold">إجمالي الوارد</th>
                  {db.warehouses.map(w => (
                    <th key={w.id} className="py-2.5 px-3 text-center font-bold">
                      {w.name}{' '}
                      {draft.mode === 'manual'
                        ? '(يدوي)'
                        : draft.mode === 'equal'
                          ? `(${Math.round(100 / db.warehouses.length)}%)`
                          : `(${w.share}%)`}
                    </th>
                  ))}
                  {draft.mode === 'manual' && <th className="py-2.5 px-3 text-center font-bold">المطابقة</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#edf3f1]">
                {distribution.map(d => (
                  <tr key={d.line.id}>
                    <td className="py-2.5 px-3">
                      <div className="font-bold text-[#102523]">{d.product?.name}</div>
                      {draft.mode === 'manual' && (
                        <div className="flex flex-wrap items-center gap-1 mt-1">
                          <button
                            type="button"
                            onClick={() => setLineAllToMain(d.line.id, d.line.strips)}
                            className="px-1.5 py-0.5 rounded border border-[#b7dfd7] bg-[#eef8f6] text-[10px] font-bold text-[#0f766e] hover:bg-[#dff3ef] cursor-pointer"
                          >
                            الكل للرئيسي
                          </button>
                          <button
                            type="button"
                            onClick={() => resetLineManualByShares(d.line.id, d.line.strips)}
                            className="px-1.5 py-0.5 rounded border border-[#dce6e3] bg-white text-[10px] font-bold text-[#3b5653] hover:bg-[#f4f8f7] cursor-pointer"
                          >
                            حسب النسب
                          </button>
                          <button
                            type="button"
                            onClick={() => clearLineManual(d.line.id)}
                            className="px-1.5 py-0.5 rounded border border-[#fecaca] bg-white text-[10px] font-bold text-[#dc2626] hover:bg-[#fef2f2] cursor-pointer"
                          >
                            تصفير
                          </button>
                        </div>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-center font-bold tabular-nums">
                      <div>{unitsText(d.line.strips, d.product)}</div>
                      {draft.mode === 'manual' && (
                        <div className="text-[10.5px] font-semibold text-[#5c7471]">
                          ({fmtNum(d.line.strips)} {d.product?.units[0]?.name || 'وحدة'})
                        </div>
                      )}
                    </td>
                    {d.alloc.map(a => (
                      <td key={a.warehouseId} className="py-2.5 px-2 text-center tabular-nums align-top">
                        {draft.mode === 'manual' ? (
                          <div className="flex flex-col items-center gap-1">
                            <input
                              type="number"
                              min={0}
                              step={1}
                              value={a.strips}
                              onChange={e => updateLineManualAlloc(d.line.id, a.warehouseId, Number(e.target.value))}
                              className="w-20 px-2 py-1.5 rounded-lg border border-[#dce6e3] text-center text-xs font-bold tabular-nums bg-white focus:outline-none focus:border-[#0f766e]"
                            />
                            <span className="text-[10px] text-[#5c7471]">
                              {a.strips > 0 ? unitsText(a.strips, d.product) : '—'}
                            </span>
                          </div>
                        ) : a.strips > 0 ? (
                          unitsText(a.strips, d.product)
                        ) : (
                          '—'
                        )}
                      </td>
                    ))}
                    {draft.mode === 'manual' && (
                      <td className="py-2.5 px-3 text-center tabular-nums">
                        {d.diff === 0 ? (
                          <span className="inline-block px-2 py-0.5 rounded-md bg-[#ecfdf5] border border-[#a7f3d0] text-[#047857] text-[11px] font-bold">
                            مطابق ({fmtNum(d.allocSum)})
                          </span>
                        ) : d.diff > 0 ? (
                          <span className="inline-block px-2 py-0.5 rounded-md bg-[#fffbeb] border border-[#fde68a] text-[#b45309] text-[11px] font-bold">
                            متبقي {fmtNum(d.diff)}
                          </span>
                        ) : (
                          <span className="inline-block px-2 py-0.5 rounded-md bg-[#fef2f2] border border-[#fecaca] text-[#dc2626] text-[11px] font-bold">
                            زيادة {fmtNum(Math.abs(d.diff))}
                          </span>
                        )}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3.5 bg-[#f8fbfa] border-t border-[#eaf1ef] space-y-2.5">
            {hasManualMismatch && (
              <div className="px-3.5 py-2 rounded-lg border border-[#fecaca] bg-[#fef2f2] text-xs font-bold text-[#b91c1c]">
                تنبيه: يجب أن يساوي مجموع الكميات الموزعة على المخازن إجمالي الكمية الواردة لكل صنف قبل الاعتماد.
              </div>
            )}
            <div className="border border-[#dce6e3] rounded-xl overflow-hidden bg-white text-xs">
              <div className="flex items-center justify-between px-3.5 py-2 border-b border-[#edf3f1]">
                <span className="text-[#5c7471] font-bold">القيمة الأساسية ({fmtNum(draft.lines.length)} بند · {fmtNum(totalStrips)} وحدة)</span>
                <span className="font-bold tabular-nums">{fmtMoney(totalValue)} ج.م</span>
              </div>
              <div className="flex items-center justify-between px-3.5 py-2 bg-[#f8fbfa] border-b border-[#edf3f1]">
                <span className="text-[#073b39] font-bold">قيمة 14%</span>
                <span className="font-extrabold text-[#0f766e] tabular-nums">{fmtMoney(calc14Percent(totalValue))} ج.م</span>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2.5 bg-[#eef8f6]">
                <div className="flex items-center gap-2.5">
                  <span className="font-extrabold text-[#073b39]">المبلغ الإجمالي (شامل 14%):</span>
                  <span className="text-sm font-extrabold text-[#0f766e] tabular-nums">{fmtMoney(calcTotalWith14(totalValue))} ج.م</span>
                </div>
                <span className="font-extrabold text-[#14532d]">{tafqeetEGP(calcTotalWith14(totalValue))}</span>
              </div>
            </div>
            <div className="flex justify-end">
              <button
                type="button"
                disabled={confirming || hasManualMismatch || Boolean(dupInvoiceNo)}
                onClick={handleConfirm}
                className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-lg bg-[#0f766e] text-white text-xs font-extrabold hover:bg-[#0d655e] disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>اعتماد الفاتورة وترحيلها للمخازن</span>
              </button>
            </div>
          </div>
        </section>
      )}

      {/* History */}
      <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
        <div className="flex items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
          <div>
            <h3 className="text-sm font-extrabold text-[#102523]">فواتير الوارد السابقة ({db.invoices.length})</h3>
          </div>
          <ExcelButton small onClick={exportHistoryExcel} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                <th className="py-2.5 px-3 text-right font-bold">الفاتورة</th>
                <th className="py-2.5 px-3 text-right font-bold">المورد</th>
                <th className="py-2.5 px-3 text-center font-bold">البنود</th>
                <th className="py-2.5 px-3 text-center font-bold">الوحدات</th>
                <th className="py-2.5 px-3 text-left font-bold">القيمة / 14% / الإجمالي</th>
                <th className="py-2.5 px-3 text-left font-bold">عرض</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#edf3f1]">
              {db.invoices.map(inv => {
                const v = calcInvoiceValue(inv, db.products);
                const v14 = calc14Percent(v);
                const grand = calcTotalWith14(v);
                return (
                  <tr key={inv.id} className="hover:bg-[#f9fcfb]">
                    <td className="py-2.5 px-3">
                      <div className="font-mono-num font-bold text-[#0f766e]">{inv.no}</div>
                      <div className="text-[11px] text-[#5c7471]">{fmtDate(inv.date)}</div>
                    </td>
                    <td className="py-2.5 px-3 font-semibold">{inv.supplier}</td>
                    <td className="py-2.5 px-3 text-center tabular-nums">{fmtNum(inv.lines.length)}</td>
                    <td className="py-2.5 px-3 text-center tabular-nums">{fmtNum(inv.totalStrips)}</td>
                    <td className="py-2.5 px-3 text-left tabular-nums">
                      <div className="text-[11px] text-[#5c7471]">أساسي: {fmtMoney(v)} ج.م</div>
                      <div className="text-[11px] font-bold text-[#073b39]">14%: {fmtMoney(v14)} ج.م</div>
                      <div className="font-extrabold text-[#0f766e]">الإجمالي: {fmtMoney(grand)} ج.م</div>
                    </td>
                    <td className="py-2.5 px-3 text-left">
                      <button
                        type="button"
                        onClick={() => onViewInvoice(inv)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#dce6e3] text-[11px] font-bold hover:bg-[#f4f8f7] cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>عرض</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
