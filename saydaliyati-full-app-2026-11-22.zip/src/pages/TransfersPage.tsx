import React from 'react';
import { ArrowLeftRight, Check, Eye, FileText, Plus, Trash2 } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { DraftTransfer, TransferOrder } from '../types/pharma';
import { fmtDate, fmtMoney, fmtNum, todayISO, unitsText } from '../utils/format';
import { exportToExcel, exportTransferToWord } from '../utils/export';
import { EmptyState, ExcelButton, PageHeader } from '../components/ui/CommonUI';

export function TransfersPage({
  draft,
  setDraft,
  onOpenLinePicker,
  onViewTransfer
}: {
  draft: DraftTransfer;
  setDraft: React.Dispatch<React.SetStateAction<DraftTransfer>>;
  onOpenLinePicker: () => void;
  onViewTransfer: (tr: TransferOrder) => void;
}) {
  const { db, getProduct, getWarehouse, availableStock, commitTransferOrder, toast } = usePharmaStore();
  const fromWh = getWarehouse(draft.from);
  const toWh = getWarehouse(draft.to);
  const totalStrips = draft.lines.reduce((s, l) => s + l.strips, 0);
  const totalValue = draft.lines.reduce((s, l) => s + l.strips * (getProduct(l.productId)?.price || 0), 0);

  const handleSave = async () => {
    if (!draft.lines.length || draft.from === draft.to) return;
    try {
      const saved = await commitTransferOrder(draft);
      toast(`تم ترحيل أذن التحويل ${saved.no} بنجاح`);
      setDraft({
        no: `TR-${db.meta.nextTransfer + 1}`,
        from: draft.from,
        to: draft.to,
        date: todayISO(),
        lines: []
      });
    } catch (err) {
      toast(err instanceof Error ? err.message : 'تعذر حفظ التحويل', 'err');
    }
  };

  const exportHistoryExcel = () => {
    const headers = ['رقم التحويل', 'التاريخ', 'من مخزن', 'إلى مخزن', 'عدد البنود', 'إجمالي الوحدات'];
    const rows = db.transfers.map(tr => [
      tr.no,
      fmtDate(tr.date),
      getWarehouse(tr.from)?.name || '',
      getWarehouse(tr.to)?.name || '',
      tr.lines.length,
      tr.lines.reduce((s, l) => s + l.strips, 0)
    ]);
    exportToExcel(`أذون_التحويل_${todayISO()}.xlsx`, 'أذون التحويل', headers, rows);
    toast('تم تصدير سجل التحويلات إلى Excel');
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="أذون التحويل"
        subtitle="نقل الكميات بين المخازن مع الحفاظ على التشغيلة وتاريخ الصلاحية بنظام FEFO"
        actions={
          <span className="px-3 py-1.5 rounded-lg bg-[#eef8f6] border border-[#b7dfd7] font-mono-num text-xs font-extrabold text-[#0f766e]">
            {draft.no}
          </span>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        <div className="lg:col-span-8 space-y-4">
          <section className="bg-white border border-[#dce6e3] rounded-xl p-4">
            <div className="flex items-center justify-between gap-2 mb-3">
              <h3 className="text-sm font-extrabold text-[#102523]">مسار التحويل</h3>
              <button
                type="button"
                onClick={() => setDraft(prev => ({ ...prev, from: prev.to, to: prev.from }))}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-[#dce6e3] text-xs font-bold hover:bg-[#f4f8f7] cursor-pointer"
              >
                <ArrowLeftRight className="w-3.5 h-3.5" />
                <span>تبديل</span>
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <label className="block text-xs font-bold text-[#233d3a]">
                <span>من مخزن *</span>
                <select
                  value={draft.from}
                  onChange={e => setDraft(prev => ({ ...prev, from: e.target.value }))}
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white"
                >
                  {db.warehouses.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
                </select>
              </label>
              <label className="block text-xs font-bold text-[#233d3a]">
                <span>إلى مخزن *</span>
                <select
                  value={draft.to}
                  onChange={e => setDraft(prev => ({ ...prev, to: e.target.value }))}
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white"
                >
                  {db.warehouses.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
                </select>
              </label>
              <label className="block text-xs font-bold text-[#233d3a]">
                <span>التاريخ</span>
                <input
                  type="date"
                  value={draft.date}
                  onChange={e => setDraft(prev => ({ ...prev, date: e.target.value }))}
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs"
                />
              </label>
            </div>
            {draft.from === draft.to && (
              <div className="mt-3 px-3 py-2 rounded-lg bg-[#fef2f2] border border-[#fecaca] text-xs font-bold text-[#b91c1c]">
                يجب أن يكون المخزن المصدر والمستقبل مختلفين.
              </div>
            )}
          </section>

          <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
            <div className="flex items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
              <div>
                <h3 className="text-sm font-extrabold text-[#102523]">بنود التحويل</h3>
                <p className="text-[11.5px] text-[#5c7471]">{fromWh?.name} ← {toWh?.name}</p>
              </div>
              <button
                type="button"
                onClick={onOpenLinePicker}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#eef8f6] text-[#0f766e] border border-[#b7dfd7] text-xs font-bold cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة صنف</span>
              </button>
            </div>
            {draft.lines.length ? (
              <div className="overflow-x-auto">
                <table className="w-full text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                      <th className="py-2.5 px-3 text-right font-bold">الصنف</th>
                      <th className="py-2.5 px-3 text-right font-bold">الكمية</th>
                      <th className="py-2.5 px-3 text-left font-bold">القيمة</th>
                      <th className="py-2.5 px-3"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#edf3f1]">
                    {draft.lines.map(l => {
                      const p = getProduct(l.productId);
                      if (!p) return null;
                      const av = availableStock(p.id, draft.from);
                      return (
                        <tr key={l.id}>
                          <td className="py-2.5 px-3">
                            <div className="font-bold">{p.name}</div>
                            <div className="text-[11px] text-[#5c7471]">متاح بالمصدر: {unitsText(av, p)}</div>
                          </td>
                          <td className="py-2.5 px-3 font-bold tabular-nums">{unitsText(l.strips, p)}</td>
                          <td className="py-2.5 px-3 text-left font-bold tabular-nums">{fmtMoney(l.strips * p.price)} ج.م</td>
                          <td className="py-2.5 px-3 text-left">
                            <button
                              type="button"
                              onClick={() => setDraft(prev => ({ ...prev, lines: prev.lines.filter(x => x.id !== l.id) }))}
                              className="p-1.5 rounded-md border border-[#fecaca] text-[#dc2626] hover:bg-[#fef2f2] cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <EmptyState
                icon={<ArrowLeftRight className="w-6 h-6" />}
                title="أضف بنود التحويل"
                description="سيتم خصم الكمية من المصدر وإضافتها للمستقبل بنفس الصلاحية."
                action={
                  <button type="button" onClick={onOpenLinePicker} className="px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold cursor-pointer">
                    إضافة صنف
                  </button>
                }
              />
            )}
          </section>
        </div>

        <aside className="lg:col-span-4 lg:sticky lg:top-20">
          <section className="bg-white border border-[#dce6e3] rounded-xl p-4 space-y-4">
            <h3 className="text-sm font-extrabold text-[#102523]">ملخص التحويل</h3>
            <div className="border border-[#dce6e3] rounded-xl divide-y divide-[#edf3f1] text-xs">
              <div className="flex justify-between px-3 py-2.5">
                <span className="text-[#5c7471]">عدد البنود</span>
                <span className="font-bold tabular-nums">{draft.lines.length}</span>
              </div>
              <div className="flex justify-between px-3 py-2.5">
                <span className="text-[#5c7471]">إجمالي الوحدات</span>
                <span className="font-bold tabular-nums">{fmtNum(totalStrips)}</span>
              </div>
              <div className="flex justify-between px-3 py-3 bg-[#f4f9f8]">
                <span className="font-extrabold text-[#102523]">القيمة التقديرية</span>
                <span className="text-base font-extrabold text-[#0f766e] tabular-nums">{fmtMoney(totalValue)} ج.م</span>
              </div>
            </div>
            <button
              type="button"
              disabled={!draft.lines.length || draft.from === draft.to}
              onClick={handleSave}
              className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0f766e] text-white text-xs font-extrabold hover:bg-[#0d655e] disabled:opacity-45 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>حفظ وترحيل التحويل</span>
            </button>
          </section>
        </aside>
      </div>

      <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
        <div className="flex items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
          <h3 className="text-sm font-extrabold text-[#102523]">أذون التحويل السابقة ({db.transfers.length})</h3>
          <ExcelButton small onClick={exportHistoryExcel} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                <th className="py-2.5 px-3 text-right font-bold">رقم التحويل</th>
                <th className="py-2.5 px-3 text-right font-bold">المسار</th>
                <th className="py-2.5 px-3 text-center font-bold">البنود</th>
                <th className="py-2.5 px-3 text-center font-bold">الوحدات</th>
                <th className="py-2.5 px-3 text-left font-bold">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#edf3f1]">
              {db.transfers.map(tr => {
                const fw = getWarehouse(tr.from);
                const tw = getWarehouse(tr.to);
                return (
                  <tr key={tr.id} className="hover:bg-[#f9fcfb]">
                    <td className="py-2.5 px-3">
                      <div className="font-mono-num font-bold text-[#0f766e]">{tr.no}</div>
                      <div className="text-[11px] text-[#5c7471]">{fmtDate(tr.date)}</div>
                    </td>
                    <td className="py-2.5 px-3 font-semibold">{fw?.name} ← {tw?.name}</td>
                    <td className="py-2.5 px-3 text-center tabular-nums">{tr.lines.length}</td>
                    <td className="py-2.5 px-3 text-center font-bold tabular-nums">{fmtNum(tr.lines.reduce((s, l) => s + l.strips, 0))}</td>
                    <td className="py-2.5 px-3 text-left">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              await exportTransferToWord(tr, fw, tw, db.products, db.company);
                              toast(`تم تحميل أذن التحويل ${tr.no} بصيغة Word (.docx)`);
                            } catch {
                              toast('تعذر إنشاء ملف Word', 'err');
                            }
                          }}
                          className="inline-flex items-center gap-1 px-2 py-1 rounded-md border border-[#bfdbfe] bg-[#eff6ff] text-[#1d4ed8] text-[10.5px] font-bold cursor-pointer"
                        >
                          <FileText className="w-3 h-3" />
                          <span>Word</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onViewTransfer(tr)}
                          className="p-1.5 rounded-md border border-[#dce6e3] text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
