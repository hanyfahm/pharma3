import React, { useMemo, useState } from 'react';
import { BarChart3 } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import { calcIssueValue, expiryState, fmtDate, fmtMoney, fmtNum, shiftISO, todayISO, unitsText } from '../utils/format';
import { exportToExcel, type ExcelCell } from '../utils/export';
import { EmptyState, ExcelButton, MOVE_LABELS, PageHeader, PrintButton } from '../components/ui/CommonUI';

type ReportTab = 'stock' | 'expiry' | 'value' | 'moves' | 'issues' | 'supplies';

const REPORT_TABS: [ReportTab, string][] = [
  ['stock', 'رصيد المخزون'],
  ['expiry', 'الصلاحية'],
  ['value', 'القيمة بالمخزن'],
  ['moves', 'الحركات'],
  ['issues', 'فواتير العملاء'],
  ['supplies', 'المستلزمات']
];

export function ReportsPage({ onPrintHtml }: { onPrintHtml: (html: string) => void }) {
  const { db, getProduct, getWarehouse, toast } = usePharmaStore();
  const [tab, setTab] = useState<ReportTab>('stock');
  const [whFilter, setWhFilter] = useState('all');
  const [prodFilter, setProdFilter] = useState('all');
  const [catFilter, setCatFilter] = useState<'all' | 'medicine' | 'supplies'>('all');
  const [fromDate, setFromDate] = useState(() => shiftISO(todayISO(), -30));
  const [toDate, setToDate] = useState(() => todayISO());
  const [search, setSearch] = useState('');

  const data = useMemo<{
    title: string;
    headers: string[];
    rows: (string | number)[][];
    excelRows: ExcelCell[][];
    summary: { label: string; value: string }[];
  }>(() => {
    const q = search.trim().toLowerCase();
    const filterBatches = (ignoreWh: boolean) =>
      db.batches.filter(b => {
        if (b.strips <= 0) return false;
        const p = getProduct(b.productId);
        if (!p) return false;
        if (!ignoreWh && whFilter !== 'all' && b.warehouseId !== whFilter) return false;
        if (prodFilter !== 'all' && p.id !== prodFilter) return false;
        if (catFilter === 'medicine' && p.marked) return false;
        if (catFilter === 'supplies' && !p.marked) return false;
        if (q && !`${p.name} ${p.code} ${p.form} ${b.batch}`.toLowerCase().includes(q)) return false;
        return true;
      });

    const inRange = (d?: string) => {
      if (!d) return false;
      if (fromDate && d < fromDate) return false;
      if (toDate && d > toDate) return false;
      return true;
    };

    if (tab === 'stock') {
      const list = filterBatches(false).sort((a, b) => {
        const pa = getProduct(a.productId)?.name || '';
        const pb = getProduct(b.productId)?.name || '';
        return pa.localeCompare(pb, 'ar');
      });
      const strips = list.reduce((s, b) => s + b.strips, 0);
      const val = list.reduce((s, b) => s + b.strips * (getProduct(b.productId)?.price || 0), 0);
      const headers = ['الصنف', 'الكود', 'المخزن', 'التشغيلة', 'الصلاحية', 'الكمية بالوحدات', 'الوحدات الأساسية', 'القيمة (ج.م)', 'الحالة'];
      const rows = list.map(b => {
        const p = getProduct(b.productId)!;
        const w = getWarehouse(b.warehouseId);
        const st = expiryState(b.expiry);
        return [
          p.name,
          p.code,
          w?.name || '—',
          b.batch,
          fmtDate(b.expiry),
          unitsText(b.strips, p),
          b.strips,
          Number((b.strips * p.price).toFixed(2)),
          st === 'expired' ? 'منتهي' : st === 'soon' ? 'قارب الانتهاء' : 'سليم'
        ];
      });
      return {
        title: 'تقرير رصيد المخزون',
        headers,
        rows,
        excelRows: rows,
        summary: [
          { label: 'عدد الدفعات', value: fmtNum(list.length) },
          { label: 'إجمالي الوحدات', value: fmtNum(strips) },
          { label: 'القيمة', value: `${fmtMoney(val)} ج.م` }
        ]
      };
    }

    if (tab === 'expiry') {
      const list = filterBatches(false)
        .filter(b => expiryState(b.expiry) !== 'ok')
        .sort((a, b) => a.expiry.localeCompare(b.expiry));
      const strips = list.reduce((s, b) => s + b.strips, 0);
      const val = list.reduce((s, b) => s + b.strips * (getProduct(b.productId)?.price || 0), 0);
      const headers = ['الصنف', 'المخزن', 'التشغيلة', 'الصلاحية', 'الكمية بالوحدات', 'الوحدات الأساسية', 'القيمة (ج.م)', 'الحالة'];
      const rows = list.map(b => {
        const p = getProduct(b.productId)!;
        const w = getWarehouse(b.warehouseId);
        const st = expiryState(b.expiry);
        return [
          p.name,
          w?.name || '—',
          b.batch,
          fmtDate(b.expiry),
          unitsText(b.strips, p),
          b.strips,
          Number((b.strips * p.price).toFixed(2)),
          st === 'expired' ? 'منتهي' : 'قارب الانتهاء'
        ];
      });
      return {
        title: 'تقرير الصلاحية — قريب الانتهاء والمنتهي',
        headers,
        rows,
        excelRows: rows,
        summary: [
          { label: 'دفعات متأثرة', value: fmtNum(list.length) },
          { label: 'الوحدات', value: fmtNum(strips) },
          { label: 'القيمة المعرضة', value: `${fmtMoney(val)} ج.م` }
        ]
      };
    }

    if (tab === 'value') {
      const list = filterBatches(true);
      const headers = ['المخزن', 'المحافظة', 'الأصناف', 'الدفعات', 'الوحدات', 'القيمة (ج.م)'];
      const rows = db.warehouses.map(w => {
        const bs = list.filter(b => b.warehouseId === w.id);
        const strips = bs.reduce((s, b) => s + b.strips, 0);
        const val = bs.reduce((s, b) => s + b.strips * (getProduct(b.productId)?.price || 0), 0);
        return [w.name, w.gov, new Set(bs.map(b => b.productId)).size, bs.length, strips, Number(val.toFixed(2))];
      });
      const totalVal = list.reduce((s, b) => s + b.strips * (getProduct(b.productId)?.price || 0), 0);
      return {
        title: 'تقرير القيمة بالمخزن',
        headers,
        rows,
        excelRows: rows,
        summary: [
          { label: 'المخازن', value: fmtNum(db.warehouses.length) },
          { label: 'إجمالي القيمة', value: `${fmtMoney(totalVal)} ج.م` }
        ]
      };
    }

    if (tab === 'moves') {
      const list = db.movements.filter(m => {
        if (!inRange(m.date)) return false;
        const p = getProduct(m.productId);
        if (prodFilter !== 'all' && m.productId !== prodFilter) return false;
        if (whFilter !== 'all' && m.warehouseId !== whFilter) return false;
        if (catFilter === 'medicine' && p?.marked) return false;
        if (catFilter === 'supplies' && !p?.marked) return false;
        if (q && !`${p?.name || ''} ${p?.code || ''} ${m.ref}`.toLowerCase().includes(q)) return false;
        return true;
      });
      const headers = ['التاريخ', 'الحركة', 'المرجع', 'الصنف', 'المخزن', 'الكمية بالوحدات', 'الوحدات الأساسية', 'ملاحظة'];
      const rows = list.map(m => {
        const p = getProduct(m.productId);
        const w = getWarehouse(m.warehouseId);
        return [
          fmtDate(m.date),
          MOVE_LABELS[m.type]?.label || m.type,
          m.ref,
          p?.name || '—',
          w?.name || '—',
          p ? unitsText(m.strips, p) : fmtNum(m.strips),
          m.strips,
          m.note
        ];
      });
      return {
        title: 'تقرير الحركات التفصيلي',
        headers,
        rows,
        excelRows: rows,
        summary: [{ label: 'إجمالي الحركات', value: fmtNum(list.length) }]
      };
    }

    if (tab === 'issues') {
      const list = db.issues.filter(i => {
        if (!inRange(i.date)) return false;
        if (whFilter !== 'all' && i.warehouseId !== whFilter) return false;
        if (q && !`${i.no} ${i.customer} ${i.invoiceNo}`.toLowerCase().includes(q)) return false;
        return true;
      });
      const totalVal = list.reduce((s, i) => s + calcIssueValue(i, db.products), 0);
      const headers = ['رقم الأذن', 'التاريخ', 'العميل', 'رقم الفاتورة', 'المخزن', 'بنود', 'وحدات المستلزمات', 'قيمة الفاتورة (ج.م)'];
      const rows = list.map(i => [
        i.no,
        fmtDate(i.date),
        i.customer,
        i.invoiceNo,
        getWarehouse(i.warehouseId)?.name || '—',
        i.lines.length,
        i.suppliesStrips || 0,
        Number(calcIssueValue(i, db.products).toFixed(2))
      ]);
      return {
        title: 'تقرير فواتير وأذون صرف العملاء',
        headers,
        rows,
        excelRows: rows,
        summary: [
          { label: 'عدد الأذون', value: fmtNum(list.length) },
          { label: 'إجمالي الفواتير', value: `${fmtMoney(totalVal)} ج.م` }
        ]
      };
    }

    // supplies tab
    const supBatches = filterBatches(false).filter(b => getProduct(b.productId)?.marked);
    const totalSupStrips = supBatches.reduce((s, b) => s + b.strips, 0);
    const headers = ['المستلزم', 'الكود', 'المخزن', 'التشغيلة', 'الصلاحية', 'الكمية بالوحدات', 'الوحدات الأساسية'];
    const rows = supBatches.map(b => {
      const p = getProduct(b.productId)!;
      return [p.name, p.code, getWarehouse(b.warehouseId)?.name || '—', b.batch, fmtDate(b.expiry), unitsText(b.strips, p), b.strips];
    });
    return {
      title: 'تقرير رصيد المستلزمات الطبية',
      headers,
      rows,
      excelRows: rows,
      summary: [
        { label: 'الدفعات', value: fmtNum(supBatches.length) },
        { label: 'إجمالي الوحدات', value: fmtNum(totalSupStrips) }
      ]
    };
  }, [tab, whFilter, prodFilter, catFilter, fromDate, toDate, search, db, getProduct, getWarehouse]);

  const handleExcel = () => {
    exportToExcel(`${data.title.replace(/\s+/g, '_')}_${todayISO()}.xlsx`, data.title, data.headers, data.excelRows);
    toast(`تم تصدير «${data.title}» إلى Excel`);
  };

  const handlePrint = () => {
    const rowsHtml = data.rows
      .map(r => `<tr>${r.map(c => `<td style="border:1px solid #0b4f4b;padding:5px">${c}</td>`).join('')}</tr>`)
      .join('');
    onPrintHtml(`
      <div style="font-family:Cairo,Arial,sans-serif;direction:rtl;color:#111">
        <h2>${data.title} — ${db.company.name}</h2>
        <p>تاريخ الطباعة: ${fmtDate(todayISO())}</p>
        <table style="width:100%;border-collapse:collapse;font-size:10.5px">
          <thead><tr style="background:#0f766e;color:#fff">${data.headers.map(h => `<th style="border:1px solid #0b4f4b;padding:6px">${h}</th>`).join('')}</tr></thead>
          <tbody>${rowsHtml}</tbody>
        </table>
      </div>
    `);
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="التقارير"
        subtitle="تقارير تشغيلية ومالية قابلة للتصفية والتصدير المباشر إلى Excel والطباعة"
        actions={
          <>
            <ExcelButton onClick={handleExcel} />
            <PrintButton onClick={handlePrint} />
          </>
        }
      />

      <div className="flex flex-wrap items-center gap-1 p-1 bg-[#e9f0ee] rounded-xl w-fit">
        {REPORT_TABS.map(([k, lbl]) => (
          <button
            key={k}
            type="button"
            onClick={() => setTab(k)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
              tab === k ? 'bg-white text-[#102523] shadow-sm' : 'text-[#5c7471] hover:text-[#102523]'
            }`}
          >
            {lbl}
          </button>
        ))}
      </div>

      <section className="bg-white border border-[#dce6e3] rounded-xl p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          <label className="block text-[11px] font-bold text-[#5c7471]">
            <span>المخزن</span>
            <select value={whFilter} onChange={e => setWhFilter(e.target.value)} className="mt-1 w-full px-2.5 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white">
              <option value="all">كل المخازن</option>
              {db.warehouses.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
            </select>
          </label>
          <label className="block text-[11px] font-bold text-[#5c7471]">
            <span>الصنف</span>
            <select value={prodFilter} onChange={e => setProdFilter(e.target.value)} className="mt-1 w-full px-2.5 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white">
              <option value="all">كل الأصناف</option>
              {db.products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </label>
          <label className="block text-[11px] font-bold text-[#5c7471]">
            <span>التصنيف</span>
            <select value={catFilter} onChange={e => setCatFilter(e.target.value as 'all' | 'medicine' | 'supplies')} className="mt-1 w-full px-2.5 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white">
              <option value="all">الكل</option>
              <option value="medicine">أدوية</option>
              <option value="supplies">مستلزمات</option>
            </select>
          </label>
          <label className="block text-[11px] font-bold text-[#5c7471]">
            <span>من تاريخ</span>
            <input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)} className="mt-1 w-full px-2.5 py-2 rounded-lg border border-[#dce6e3] text-xs" />
          </label>
          <label className="block text-[11px] font-bold text-[#5c7471]">
            <span>إلى تاريخ</span>
            <input type="date" value={toDate} onChange={e => setToDate(e.target.value)} className="mt-1 w-full px-2.5 py-2 rounded-lg border border-[#dce6e3] text-xs" />
          </label>
          <label className="block text-[11px] font-bold text-[#5c7471]">
            <span>بحث نصي</span>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="كلمة بحث..." className="mt-1 w-full px-2.5 py-2 rounded-lg border border-[#dce6e3] text-xs" />
          </label>
        </div>
      </section>

      <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3.5 border-b border-[#eaf1ef]">
          <h3 className="text-sm font-extrabold text-[#102523]">{data.title}</h3>
          <div className="flex flex-wrap items-center gap-4 text-xs">
            {data.summary.map((s, i) => (
              <div key={i} className="tabular-nums">
                <span className="text-[#5c7471]">{s.label}: </span>
                <strong className="text-[#0f766e]">{s.value}</strong>
              </div>
            ))}
          </div>
        </div>
        {data.rows.length ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                  {data.headers.map((h, i) => (
                    <th key={i} className="py-2.5 px-3 text-right font-bold whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#edf3f1]">
                {data.rows.map((r, ri) => (
                  <tr key={ri} className="hover:bg-[#f9fcfb]">
                    {r.map((cell, ci) => (
                      <td key={ci} className="py-2.5 px-3 tabular-nums whitespace-nowrap">{cell}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState icon={<BarChart3 className="w-6 h-6" />} title="لا توجد بيانات مطابقة" description="عدّل الفلاتر أو النطاق الزمني لعرض النتائج." />
        )}
      </section>
    </div>
  );
}
