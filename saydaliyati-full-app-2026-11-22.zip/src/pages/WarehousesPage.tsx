import React, { useEffect, useState } from 'react';
import { ArrowUpLeft, Download, FileCode2, Upload } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import { expiryState, fmtMoney, fmtNum, todayISO } from '../utils/format';
import { exportBackupJSON, exportFullHTMLCopy, exportOdooJSON, exportToExcel } from '../utils/export';
import { ExcelButton, PageHeader } from '../components/ui/CommonUI';

export function WarehousesPage({ onOpenWarehouse }: { onOpenWarehouse: (warehouseId: string) => void }) {
  const { db, getProduct, saveShares, restoreBackup, toast } = usePharmaStore();
  const [shares, setShares] = useState<Record<string, number>>(() => {
    const m: Record<string, number> = {};
    db.warehouses.forEach(w => { m[w.id] = w.share; });
    return m;
  });

  useEffect(() => {
    const m: Record<string, number> = {};
    db.warehouses.forEach(w => { m[w.id] = w.share; });
    setShares(m);
  }, [db.warehouses]);

  const today = todayISO();
  const active = db.batches.filter(b => b.strips > 0 && b.expiry >= today);
  const totalShare = db.warehouses.reduce((s, w) => s + (Number(shares[w.id]) || 0), 0);

  const handleSaveShares = (e: React.FormEvent) => {
    e.preventDefault();
    if (Math.round(totalShare) !== 100) {
      toast('يجب أن يكون مجموع نسب التوزيع 100%', 'err');
      return;
    }
    saveShares(shares);
    toast('تم حفظ نسب التوزيع بين المخازن');
  };

  const handleExportExcel = () => {
    const headers = ['المخزن', 'المحافظة', 'النوع', 'نصيب التوزيع %', 'الأصناف المتوفرة', 'إجمالي الوحدات السارية', 'قيمة المخزون (ج.م)'];
    const rows = db.warehouses.map(w => {
      const bs = active.filter(b => b.warehouseId === w.id);
      const val = bs.reduce((s, b) => s + b.strips * (getProduct(b.productId)?.price || 0), 0);
      const strips = bs.reduce((s, b) => s + b.strips, 0);
      return [
        w.name,
        w.gov,
        w.kind === 'main' ? 'رئيسي' : 'فرعي',
        w.share,
        new Set(bs.map(b => b.productId)).size,
        strips,
        Number(val.toFixed(2))
      ];
    });
    exportToExcel(`المخازن_${today}.xlsx`, 'المخازن', headers, rows);
    toast('تم تصدير جدول المخازن إلى Excel (.xlsx)');
  };

  const handleRestoreFile = async (file: File) => {
    try {
      const text = await file.text();
      restoreBackup(text);
      toast('تمت استعادة النسخة الاحتياطية بنجاح');
    } catch (err) {
      toast(err instanceof Error ? err.message : 'فشل استيراد النسخة الاحتياطية', 'err');
    }
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="المخازن"
        subtitle="اضغط على أي مخزن لفتح رصيد المخزن كأنه كشف استلام تفصيلي جاهز للطباعة والتصدير"
        actions={
          <>
            <ExcelButton onClick={handleExportExcel} />
            <button
              type="button"
              onClick={() => {
                exportFullHTMLCopy(db);
                toast('تم تنزيل نسخة HTML كاملة');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#b7dfd7] bg-[#eef8f6] text-xs font-bold text-[#073b39] hover:bg-[#dff2ee] cursor-pointer"
            >
              <FileCode2 className="w-3.5 h-3.5" />
              <span>تنزيل نسخة HTML</span>
            </button>
            <button
              type="button"
              onClick={() => {
                exportOdooJSON(db);
                toast('تم تصدير ملف بيانات Odoo بنجاح');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تصدير بيانات Odoo</span>
            </button>
            <button
              type="button"
              onClick={() => {
                exportBackupJSON(db);
                toast('تم تحميل النسخة الاحتياطية الكاملة');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>نسخة احتياطية</span>
            </button>
            <label className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer">
              <Upload className="w-3.5 h-3.5" />
              <span>استعادة نسخة</span>
              <input
                type="file"
                accept=".json"
                className="hidden"
                onChange={e => {
                  const f = e.target.files?.[0];
                  if (f) handleRestoreFile(f);
                  e.target.value = '';
                }}
              />
            </label>
          </>
        }
      />

      {/* Interactive warehouse cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {db.warehouses.map(w => {
          const bs = active.filter(b => b.warehouseId === w.id);
          const val = bs.reduce((s, b) => s + b.strips * (getProduct(b.productId)?.price || 0), 0);
          const strips = bs.reduce((s, b) => s + b.strips, 0);
          const prods = new Set(bs.map(b => b.productId)).size;
          const soon = bs.filter(b => expiryState(b.expiry) === 'soon').length;
          const expired = db.batches.filter(b => b.warehouseId === w.id && b.strips > 0 && expiryState(b.expiry) === 'expired').length;

          return (
            <button
              key={w.id}
              type="button"
              onClick={() => onOpenWarehouse(w.id)}
              className="text-right bg-white border border-[#dce6e3] hover:border-[#0f766e] rounded-xl p-5 transition-all hover:shadow-md cursor-pointer group relative overflow-hidden"
            >
              <div className="absolute top-0 inset-x-0 h-1" style={{ backgroundColor: w.color }} />
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-11 h-11 rounded-xl grid place-items-center text-white font-extrabold text-xs shrink-0"
                    style={{ backgroundColor: w.color }}
                  >
                    {w.id.toUpperCase()}
                  </div>
                  <div>
                    <h3 className="text-base font-extrabold text-[#102523] group-hover:text-[#0f766e]">{w.name}</h3>
                    <div className="text-xs text-[#5c7471]">محافظة {w.gov} · نصيب التوزيع {w.share}%</div>
                  </div>
                </div>
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#eef8f6] text-[#0f766e] text-xs font-bold whitespace-nowrap">
                  <span>فتح رصيد الاستلام</span>
                  <ArrowUpLeft className="w-3.5 h-3.5" />
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2.5 mt-4">
                <div className="bg-[#f7fbfa] border border-[#e6efec] rounded-lg p-2.5">
                  <div className="text-sm font-extrabold text-[#102523] tabular-nums">{fmtMoney(val)}</div>
                  <div className="text-[11px] text-[#5c7471]">القيمة (ج.م)</div>
                </div>
                <div className="bg-[#f7fbfa] border border-[#e6efec] rounded-lg p-2.5">
                  <div className="text-sm font-extrabold text-[#102523] tabular-nums">{fmtNum(prods)}</div>
                  <div className="text-[11px] text-[#5c7471]">صنف متوفر</div>
                </div>
                <div className="bg-[#f7fbfa] border border-[#e6efec] rounded-lg p-2.5">
                  <div className="text-sm font-extrabold text-[#102523] tabular-nums">{fmtNum(strips)}</div>
                  <div className="text-[11px] text-[#5c7471]">وحدة سارية</div>
                </div>
              </div>

              <div className="mt-3.5 pt-3 border-t border-[#edf3f1] flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  {soon > 0 && <span className="font-bold text-[#b45309]">{soon} تشغيلة قريبة الانتهاء</span>}
                  {expired > 0 && <span className="font-bold text-[#dc2626]">{expired} منتهي</span>}
                  {soon === 0 && expired === 0 && <span className="font-bold text-[#047857]">كل الصلاحيات سليمة</span>}
                </div>
                <span className="text-[#5c7471] font-semibold">اضغط للاستلام والجرد</span>
              </div>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
        <section className="bg-white border border-[#dce6e3] rounded-xl p-5">
          <div className="flex items-center justify-between gap-2 mb-3">
            <div>
              <h3 className="text-sm font-extrabold text-[#102523]">نسب توزيع فاتورة الوارد</h3>
              <p className="text-xs text-[#5c7471]">يوزّع كل بند وارد تلقائيًا على المخازن بهذه النسب</p>
            </div>
            <span className={`text-xs font-extrabold tabular-nums ${Math.round(totalShare) === 100 ? 'text-[#047857]' : 'text-[#dc2626]'}`}>
              المجموع: {totalShare}%
            </span>
          </div>
          <form onSubmit={handleSaveShares} className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {db.warehouses.map(w => (
                <label key={w.id} className="block text-xs font-bold text-[#233d3a]">
                  <span className="truncate block">{w.name}</span>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={shares[w.id] ?? w.share}
                    onChange={e => setShares(prev => ({ ...prev, [w.id]: Math.max(0, Number(e.target.value) || 0) }))}
                    className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs tabular-nums focus:outline-none focus:border-[#0f766e]"
                  />
                </label>
              ))}
            </div>
            <div className="flex items-center justify-between gap-3">
              <span className="text-[11px] text-[#5c7471]">يجب أن يساوي المجموع 100%؛ وتوزّع الكسور على أكبر باقٍ.</span>
              <button type="submit" className="px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] cursor-pointer">
                حفظ النسب
              </button>
            </div>
          </form>
        </section>

        <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
          <div className="flex items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
            <div>
              <h3 className="text-sm font-extrabold text-[#102523]">مقارنة المخازن</h3>
              <p className="text-[11.5px] text-[#5c7471]">اضغط على أي صف لفتح رصيد الاستلام</p>
            </div>
            <ExcelButton small onClick={handleExportExcel} label="إكسل" />
          </div>
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                <th className="py-2 px-3 text-right font-bold">المخزن</th>
                <th className="py-2 px-3 text-right font-bold">المحافظة</th>
                <th className="py-2 px-3 text-center font-bold">النصيب</th>
                <th className="py-2 px-3 text-left font-bold">القيمة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#edf3f1]">
              {db.warehouses.map(w => {
                const val = active.filter(b => b.warehouseId === w.id).reduce((s, b) => s + b.strips * (getProduct(b.productId)?.price || 0), 0);
                return (
                  <tr
                    key={w.id}
                    onClick={() => onOpenWarehouse(w.id)}
                    className="hover:bg-[#f4fbf9] cursor-pointer"
                  >
                    <td className="py-2.5 px-3 font-bold text-[#102523]">{w.name}</td>
                    <td className="py-2.5 px-3 text-[#5c7471]">{w.gov}</td>
                    <td className="py-2.5 px-3 text-center tabular-nums">{w.share}%</td>
                    <td className="py-2.5 px-3 text-left font-bold tabular-nums">{fmtMoney(val)} ج.م</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </section>
      </div>
    </div>
  );
}
