import React, { useMemo, useState } from 'react';
import { Eye, Pencil, Plus, Search } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { Product } from '../types/pharma';
import { expiryState, fmtDate, fmtMoney, fmtNum, todayISO, unitLabel, unitsText } from '../utils/format';
import { exportToExcel } from '../utils/export';
import { EmptyState, ExcelButton, ExpiryTag, PageHeader } from '../components/ui/CommonUI';

export function ProductsPage({
  onAddProduct,
  onEditProduct,
  onViewProduct
}: {
  onAddProduct: () => void;
  onEditProduct: (p: Product) => void;
  onViewProduct: (productId: string) => void;
}) {
  const { db, totalProductStock, expiredProductStock, nearestExpiry, getPartner, toast } = usePharmaStore();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'medicine' | 'supplies' | 'soon'>('all');

  const products = useMemo(() => {
    const q = search.trim().toLowerCase();
    return db.products
      .filter(p => {
        if (q && !`${p.name} ${p.code} ${p.form} ${p.description}`.toLowerCase().includes(q)) return false;
        if (filter === 'medicine') return !p.marked;
        if (filter === 'supplies') return p.marked;
        if (filter === 'soon') {
          const n = nearestExpiry(p.id);
          return !!n && expiryState(n) !== 'ok';
        }
        return true;
      })
      .sort((a, b) => a.name.localeCompare(b.name, 'ar'));
  }, [db.products, search, filter, nearestExpiry]);

  const handleExcel = () => {
    const headers = ['الكود', 'اسم الصنف', 'الشكل', 'النوع', 'المورّد', 'هرم الوحدات', 'السعر للوحدة الأساسية', 'أقرب صلاحية', 'الرصيد المتاح', 'إجمالي الوحدات', 'القيمة (ج.م)'];
    const rows = products.map(p => {
      const active = totalProductStock(p.id);
      const near = nearestExpiry(p.id);
      const sup = p.supplierId ? getPartner(p.supplierId)?.name : '—';
      return [
        p.code,
        p.name,
        p.form || '—',
        p.marked ? 'مستلزمات' : 'دواء',
        sup || '—',
        unitLabel(p),
        p.price,
        near ? fmtDate(near) : 'لا يوجد',
        unitsText(active, p),
        active,
        Number((active * (p.price || 0)).toFixed(2))
      ];
    });
    exportToExcel(`الأصناف_والصلاحيات_${todayISO()}.xlsx`, 'الأصناف', headers, rows);
    toast('تم تصدير جدول الأصناف إلى Excel');
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="الأصناف والصلاحيات"
        subtitle="إدارة الأدوية والمستلزمات الطبية مع هرم الوحدات المتدرج وتنبيهات أقرب صلاحية"
        actions={
          <>
            <ExcelButton onClick={handleExcel} />
            <button
              type="button"
              onClick={onAddProduct}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>صنف جديد</span>
            </button>
          </>
        }
      />

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-[#6b8481] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="ابحث بالاسم أو الكود أو الشكل الصيدلي..."
            className="w-full pr-9 pl-3 py-2 text-xs bg-white border border-[#dce6e3] rounded-lg focus:outline-none focus:border-[#0f766e]"
          />
        </div>
        <div className="flex items-center gap-1 p-1 bg-[#e9f0ee] rounded-lg">
          {([['all', 'الكل'], ['medicine', 'أدوية'], ['supplies', 'مستلزمات'], ['soon', 'صلاحية قريبة']] as const).map(([k, lbl]) => (
            <button
              key={k}
              type="button"
              onClick={() => setFilter(k)}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                filter === k ? 'bg-white text-[#102523] shadow-sm' : 'text-[#5c7471] hover:text-[#102523]'
              }`}
            >
              {lbl}
            </button>
          ))}
        </div>
        <span className="text-xs font-bold text-[#5c7471] tabular-nums">{fmtNum(products.length)} صنف</span>
      </div>

      <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
        {products.length ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="bg-[#f4f8f7] text-[#5c7471] border-b border-[#dce6e3]">
                  <th className="py-2.5 px-3 text-right font-bold">الصنف</th>
                  <th className="py-2.5 px-3 text-center font-bold">النوع</th>
                  <th className="py-2.5 px-3 text-right font-bold">المورّد</th>
                  <th className="py-2.5 px-3 text-right font-bold">هرم الوحدات</th>
                  <th className="py-2.5 px-3 text-right font-bold">السعر</th>
                  <th className="py-2.5 px-3 text-center font-bold">أقرب صلاحية</th>
                  <th className="py-2.5 px-3 text-right font-bold">المتاح للبيع</th>
                  <th className="py-2.5 px-3 text-left font-bold">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#edf3f1]">
                {products.map(p => {
                  const active = totalProductStock(p.id);
                  const expired = expiredProductStock(p.id);
                  const near = nearestExpiry(p.id);
                  const sup = p.supplierId ? getPartner(p.supplierId) : null;
                  return (
                    <tr key={p.id} className="hover:bg-[#f9fcfb]">
                      <td className="py-2.5 px-3">
                        <div className="font-bold text-[#102523]">{p.name}</div>
                        <div className="text-[11px] text-[#5c7471]">{p.code} · {p.form}</div>
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`text-[11px] font-bold ${p.marked ? 'text-[#b45309]' : 'text-[#0f766e]'}`}>
                          {p.marked ? 'مستلزمات' : 'دواء'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-[#3b5653]">{sup?.name || '—'}</td>
                      <td className="py-2.5 px-3 text-[11px] text-[#3b5653] tabular-nums">{unitLabel(p)}</td>
                      <td className="py-2.5 px-3 tabular-nums">
                        <div className="font-bold text-[#102523]">{fmtMoney(p.price)} ج.م / {p.units[0].name}</div>
                        {p.units[1] && (
                          <div className="text-[10.5px] text-[#5c7471]">
                            {p.units[1].name}: {fmtMoney(p.price * p.units[1].factor)} ج.م
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-center">{near ? <ExpiryTag date={near} /> : <span className="text-[#dc2626] font-bold">نافد</span>}</td>
                      <td className="py-2.5 px-3 tabular-nums">
                        <div className="font-bold text-[#102523]">{unitsText(active, p)}</div>
                        <div className="text-[10.5px] text-[#5c7471]">
                          {fmtMoney(active * (p.price || 0))} ج.م
                          {expired > 0 && <span className="text-[#dc2626] font-bold"> · {fmtNum(expired)} منتهي</span>}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-left">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => onEditProduct(p)}
                            className="p-1.5 rounded-md border border-[#dce6e3] text-[#3b5653] hover:bg-[#f4f8f7] cursor-pointer"
                            title="تعديل"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onViewProduct(p.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#dce6e3] text-[11px] font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>تفاصيل</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<Search className="w-6 h-6" />}
            title="لا توجد أصناف مطابقة"
            description="أضف صنفًا جديدًا أو غيّر كلمات البحث."
            action={
              <button
                type="button"
                onClick={onAddProduct}
                className="px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold cursor-pointer"
              >
                إضافة صنف
              </button>
            }
          />
        )}
      </section>
    </div>
  );
}
