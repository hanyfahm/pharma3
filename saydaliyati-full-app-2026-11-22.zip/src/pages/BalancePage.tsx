import React, { useMemo, useState } from 'react';
import { ChevronDown, Search } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { Product } from '../types/pharma';
import { expiryState, fmtDate, fmtMoney, fmtNum, todayISO, unitsText } from '../utils/format';
import { exportToExcel } from '../utils/export';
import { EmptyState, ExcelButton, ExpiryTag, PageHeader, PrintButton } from '../components/ui/CommonUI';

interface BalanceGroup {
  key: string;
  product: Product;
  batch: string;
  expiry: string;
  perWh: Record<string, number>;
  total: number;
  value: number;
}

export function BalancePage({ onPrintHtml }: { onPrintHtml: (html: string) => void }) {
  const { db, getProduct, getWarehouse, toast } = usePharmaStore();
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState<'all' | 'medicine' | 'supplies'>('all');
  const [expandedKeys, setExpandedKeys] = useState<Record<string, boolean>>({});

  const groups = useMemo<BalanceGroup[]>(() => {
    const q = search.trim().toLowerCase();
    const map = new Map<string, BalanceGroup>();
    db.batches.forEach(b => {
      if (b.strips <= 0) return;
      const p = getProduct(b.productId);
      if (!p) return;
      if (q && !`${p.name} ${p.code} ${b.batch} ${p.form}`.toLowerCase().includes(q)) return;
      if (cat === 'medicine' && p.marked) return;
      if (cat === 'supplies' && !p.marked) return;
      const key = `${p.id}|${b.batch}|${b.expiry}`;
      let g = map.get(key);
      if (!g) {
        g = { key, product: p, batch: b.batch, expiry: b.expiry, perWh: {}, total: 0, value: 0 };
        map.set(key, g);
      }
      g.perWh[b.warehouseId] = (g.perWh[b.warehouseId] || 0) + b.strips;
      g.total += b.strips;
      g.value += b.strips * (p.price || 0);
    });
    return Array.from(map.values()).sort(
      (a, b) => a.product.name.localeCompare(b.product.name, 'ar') || a.batch.localeCompare(b.batch)
    );
  }, [db.batches, search, cat, getProduct]);

  const perWhTotals = db.warehouses.map(w => groups.reduce((s, g) => s + (g.perWh[w.id] || 0), 0));
  const grandTotal = groups.reduce((s, g) => s + g.total, 0);
  const grandValue = groups.reduce((s, g) => s + g.value, 0);

  const handleExcel = () => {
    const headers = ['الكود', 'الصنف', 'اللوت', 'الصلاحية', ...db.warehouses.map(w => w.name), 'الإجمالي (وحدة)', 'القيمة (ج.م)'];
    const rows = groups.map(g => [
      g.product.code,
      g.product.name,
      g.batch,
      fmtDate(g.expiry),
      ...db.warehouses.map(w => g.perWh[w.id] || 0),
      g.total,
      Number(g.value.toFixed(2))
    ]);
    exportToExcel(
      `ميزان_الرصيد_${todayISO()}.xlsx`,
      'ميزان الرصيد',
      headers,
      rows,
      ['الإجمالي', `${groups.length} لوت`, '', '', ...perWhTotals, grandTotal, Number(grandValue.toFixed(2))]
    );
    toast('تم تصدير ميزان الرصيد إلى Excel');
  };

  const handlePrint = () => {
    const rowsHtml = groups.map(g => `<tr>
      <td style="border:1px solid #0b4f4b;padding:5px">${g.product.code}</td>
      <td style="border:1px solid #0b4f4b;padding:5px">${g.product.name}</td>
      <td style="border:1px solid #0b4f4b;padding:5px">${g.batch}</td>
      <td style="border:1px solid #0b4f4b;padding:5px">${fmtDate(g.expiry)}</td>
      ${db.warehouses.map(w => `<td style="border:1px solid #0b4f4b;padding:5px;text-align:center">${g.perWh[w.id] ? unitsText(g.perWh[w.id], g.product) : '—'}</td>`).join('')}
      <td style="border:1px solid #0b4f4b;padding:5px"><b>${unitsText(g.total, g.product)}</b></td>
      <td style="border:1px solid #0b4f4b;padding:5px">${fmtMoney(g.value)} ج.م</td>
    </tr>`).join('');
    onPrintHtml(`
      <div style="font-family:Cairo,Arial,sans-serif;direction:rtl;color:#111">
        <h2>ميزان الرصيد المجمّع — ${fmtDate(todayISO())}</h2>
        <p>عدد اللوتات: ${fmtNum(groups.length)} · إجمالي الوحدات: ${fmtNum(grandTotal)} · القيمة: ${fmtMoney(grandValue)} ج.م</p>
        <table style="width:100%;border-collapse:collapse;font-size:10px">
          <thead><tr style="background:#0f766e;color:#fff">
            <th style="border:1px solid #0b4f4b;padding:5px">الكود</th>
            <th style="border:1px solid #0b4f4b;padding:5px">الصنف</th>
            <th style="border:1px solid #0b4f4b;padding:5px">اللوت</th>
            <th style="border:1px solid #0b4f4b;padding:5px">الصلاحية</th>
            ${db.warehouses.map(w => `<th style="border:1px solid #0b4f4b;padding:5px">${w.name}</th>`).join('')}
            <th style="border:1px solid #0b4f4b;padding:5px">الإجمالي</th>
            <th style="border:1px solid #0b4f4b;padding:5px">القيمة</th>
          </tr></thead>
          <tbody>${rowsHtml}</tbody>
        </table>
      </div>
    `);
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="الرصيد المجمّع"
        subtitle="سطر واحد لكل لوت يوضح الكميات الموزعة على المخزن الرئيسي والفروع مع إمكانية التوسيع"
        actions={
          <>
            <ExcelButton onClick={handleExcel} />
            <PrintButton onClick={handlePrint} label="طباعة الرصيد" />
          </>
        }
      />

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-[#6b8481] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="ابحث بالكود أو اسم الصنف أو التشغيلة..."
            className="w-full pr-9 pl-3 py-2 text-xs bg-white border border-[#dce6e3] rounded-lg focus:outline-none focus:border-[#0f766e]"
          />
        </div>
        <div className="flex items-center gap-1 p-1 bg-[#e9f0ee] rounded-lg">
          {([['all', 'الكل'], ['medicine', 'أدوية'], ['supplies', 'مستلزمات']] as const).map(([k, lbl]) => (
            <button
              key={k}
              type="button"
              onClick={() => setCat(k)}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                cat === k ? 'bg-white text-[#102523] shadow-sm' : 'text-[#5c7471] hover:text-[#102523]'
              }`}
            >
              {lbl}
            </button>
          ))}
        </div>
        <div className="text-xs font-bold text-[#5c7471] tabular-nums">
          {fmtNum(groups.length)} لوت · {fmtNum(grandTotal)} وحدة · {fmtMoney(grandValue)} ج.م
        </div>
      </div>

      <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
        {groups.length ? (
          <div className="overflow-x-auto max-h-[650px]">
            <table className="w-full text-xs border-collapse min-w-[980px]">
              <thead className="sticky top-0 z-10">
                <tr className="bg-[#f4f8f7] text-[#5c7471] border-b border-[#dce6e3]">
                  <th className="py-2.5 px-3 text-right font-bold">الكود</th>
                  <th className="py-2.5 px-3 text-right font-bold">الصنف</th>
                  <th className="py-2.5 px-3 text-center font-bold">اللوت</th>
                  <th className="py-2.5 px-3 text-center font-bold">الصلاحية</th>
                  {db.warehouses.map(w => (
                    <th key={w.id} className="py-2.5 px-3 text-center font-bold">{w.name}</th>
                  ))}
                  <th className="py-2.5 px-3 text-center font-bold">الإجمالي</th>
                  <th className="py-2.5 px-3 text-left font-bold">القيمة</th>
                  <th className="py-2.5 px-2"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#edf3f1]">
                {groups.map(g => {
                  const isOpen = !!expandedKeys[g.key];
                  const st = expiryState(g.expiry);
                  const lotBatches = isOpen
                    ? db.batches.filter(b => b.productId === g.product.id && b.batch === g.batch && b.expiry === g.expiry && b.strips > 0)
                    : [];
                  return (
                    <React.Fragment key={g.key}>
                      <tr
                        onClick={() => setExpandedKeys(prev => ({ ...prev, [g.key]: !prev[g.key] }))}
                        className={`cursor-pointer transition-colors ${isOpen ? 'bg-[#eef8f6]' : 'hover:bg-[#f9fcfb]'}`}
                      >
                        <td className="py-2.5 px-3 font-mono-num font-bold text-[#0f766e]">{g.product.code}</td>
                        <td className="py-2.5 px-3">
                          <div className="font-bold text-[#102523]">{g.product.name}</div>
                          <div className="text-[11px] text-[#5c7471]">
                            {g.product.form}{g.product.marked ? ' · مستلزمات' : ''}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-center font-mono-num font-semibold text-[#3b5653]">{g.batch}</td>
                        <td className="py-2.5 px-3 text-center"><ExpiryTag date={g.expiry} /></td>
                        {db.warehouses.map(w => {
                          const n = g.perWh[w.id] || 0;
                          return (
                            <td key={w.id} className="py-2.5 px-3 text-center tabular-nums">
                              {n > 0 ? <span className="font-bold text-[#102523]">{unitsText(n, g.product)}</span> : <span className="text-[#94a8a5]">—</span>}
                            </td>
                          );
                        })}
                        <td className="py-2.5 px-3 text-center tabular-nums">
                          <div className="font-extrabold text-[#102523]">{unitsText(g.total, g.product)}</div>
                          {st !== 'ok' && (
                            <div className={`text-[10.5px] font-bold ${st === 'expired' ? 'text-[#dc2626]' : 'text-[#b45309]'}`}>
                              {st === 'expired' ? 'منتهي' : 'قريب'}
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-left font-bold tabular-nums">{fmtMoney(g.value)} ج.م</td>
                        <td className="py-2.5 px-2 text-center">
                          <ChevronDown className={`w-4 h-4 text-[#5c7471] transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                        </td>
                      </tr>
                      {isOpen && (
                        <tr className="bg-[#f7fbfa]">
                          <td colSpan={6 + db.warehouses.length + 1} className="p-3">
                            <div className="text-[11px] font-bold text-[#073b39] mb-2">تفصيل سجلات اللوت «{g.batch}» — {g.product.name}</div>
                            <table className="w-full text-[11px] border border-[#dce6e3] rounded-lg bg-white">
                              <thead>
                                <tr className="bg-[#f0f7f5] text-[#5c7471] border-b border-[#dce6e3]">
                                  <th className="py-1.5 px-3 text-right">المخزن</th>
                                  <th className="py-1.5 px-3 text-right">الكمية</th>
                                  <th className="py-1.5 px-3 text-center">الرصيد الأساسي</th>
                                  <th className="py-1.5 px-3 text-left">القيمة</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-[#edf3f1]">
                                {lotBatches.map(lb => {
                                  const w = getWarehouse(lb.warehouseId);
                                  return (
                                    <tr key={lb.id}>
                                      <td className="py-1.5 px-3 font-bold">{w?.name} ({w?.gov})</td>
                                      <td className="py-1.5 px-3 tabular-nums font-bold">{unitsText(lb.strips, g.product)}</td>
                                      <td className="py-1.5 px-3 text-center tabular-nums">{fmtNum(lb.strips)} {g.product.units[0]?.name}</td>
                                      <td className="py-1.5 px-3 text-left tabular-nums font-bold">{fmtMoney(lb.strips * (g.product.price || 0))} ج.م</td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="bg-[#f4f8f7] border-t border-[#dce6e3] font-extrabold text-[#102523]">
                  <td colSpan={4} className="py-2.5 px-3">الإجمالي ({fmtNum(groups.length)} لوت)</td>
                  {perWhTotals.map((n, i) => (
                    <td key={i} className="py-2.5 px-3 text-center tabular-nums">{fmtNum(n)}</td>
                  ))}
                  <td className="py-2.5 px-3 text-center tabular-nums">{fmtNum(grandTotal)}</td>
                  <td className="py-2.5 px-3 text-left tabular-nums text-[#0f766e]">{fmtMoney(grandValue)} ج.م</td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        ) : (
          <EmptyState icon={<Search className="w-6 h-6" />} title="لا توجد أرصدة مطابقة" description="جرب تغيير نص البحث أو الفئة." />
        )}
      </section>
    </div>
  );
}
