import React, { useMemo, useState } from 'react';
import {
  ArrowDownToLine,
  ChevronDown,
  ChevronUp,
  Eye,
  FileSpreadsheet,
  FileText,
  Pencil,
  Plus,
  Search
} from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { Invoice, IssueOrder } from '../types/pharma';
import {
  calc14Percent,
  calcInvoiceValue,
  calcIssueValue,
  calcTotalWith14,
  fmtDate,
  fmtMoney,
  fmtNum,
  isLineReceipt,
  resolveIssueCustomer,
  type ResolvedCustomerInfo,
  tafqeetEGP,
  todayISO,
  unitsText
} from '../utils/format';
import {
  exportIncomingInvoiceToExcel,
  exportInvoiceToWord,
  exportSalesInvoiceToExcel,
  exportSalesInvoiceToWord,
  exportToExcel
} from '../utils/export';
import { EmptyState, ExcelButton, ExpiryTag, PageHeader } from '../components/ui/CommonUI';

type UnifiedInvoiceRow =
  | {
      kind: 'incoming';
      key: string;
      no: string;
      refNo?: string;
      date: string;
      createdAt: string;
      partnerName: string;
      customerInfo?: ResolvedCustomerInfo;
      linesCount: number;
      totalStrips: number;
      baseVal: number;
      val14: number;
      grandTotal: number;
      wordsTotal: string;
      raw: Invoice;
    }
  | {
      kind: 'sales';
      key: string;
      no: string;
      refNo: string;
      date: string;
      createdAt: string;
      partnerName: string;
      customerInfo: ResolvedCustomerInfo;
      linesCount: number;
      totalStrips: number;
      baseVal: number;
      val14: number;
      grandTotal: number;
      wordsTotal: string;
      raw: IssueOrder;
    };

export function InvoiceListPage({
  onCreateIncoming,
  onCreateSalesInvoice,
  onViewInvoice,
  onViewIssue,
  onEditIssue
}: {
  onCreateIncoming: () => void;
  onCreateSalesInvoice: (issueId?: string) => void;
  onViewInvoice: (inv: Invoice) => void;
  onViewIssue: (iss: IssueOrder) => void;
  onEditIssue: (iss: IssueOrder) => void;
}) {
  const { db, getProduct, getWarehouse, getPartner, toast } = usePharmaStore();

  const [search, setSearch] = useState('');
  const [kindFilter, setKindFilter] = useState<'all' | 'incoming' | 'sales'>('all');
  const [expandedKey, setExpandedKey] = useState<string | null>(null);

  const openIssueOrders = useMemo(
    () => (db.issues || []).filter(i => !i.closed && !i.invoiced),
    [db.issues]
  );

  const allInvoices = useMemo<UnifiedInvoiceRow[]>(() => {
    const incomingRows: UnifiedInvoiceRow[] = db.invoices.map(inv => {
      const baseVal = calcInvoiceValue(inv, db.products);
      const val14 = calc14Percent(baseVal);
      const grandTotal = calcTotalWith14(baseVal);
      return {
        kind: 'incoming',
        key: `in-${inv.id}`,
        no: inv.no,
        date: inv.date,
        createdAt: inv.createdAt || inv.date,
        partnerName: inv.supplier,
        linesCount: inv.lines.length,
        totalStrips: inv.totalStrips,
        baseVal,
        val14,
        grandTotal,
        wordsTotal: tafqeetEGP(grandTotal),
        raw: inv
      };
    });

    const salesRows: UnifiedInvoiceRow[] = db.issues
      .map(iss => {
        const isInvoicedOrder = Boolean(iss.invoiced && (iss.invoicedByFlow || (iss.invoiceNo && iss.invoiceNo !== '—' && iss.invoiceNo !== '-')));
        if (!isInvoicedOrder) return null;
        const billableLines = iss.lines.filter(l => !isLineReceipt(l, getProduct(l.productId)));
        const baseVal = calcIssueValue(iss, db.products);
        if (billableLines.length === 0 && baseVal <= 0) return null;
        const val14 = calc14Percent(baseVal);
        const grandTotal = calcTotalWith14(baseVal);
        const dispNo = iss.invoiceNo && iss.invoiceNo !== '—' ? iss.invoiceNo : iss.no;
        const customerInfo = resolveIssueCustomer(iss, db.partners);
        return {
          kind: 'sales' as const,
          key: `sal-${iss.id}`,
          no: dispNo,
          refNo: iss.no,
          date: iss.invoiceDate || iss.date,
          createdAt: iss.createdAt || iss.date,
          partnerName: customerInfo.name,
          customerInfo,
          linesCount: billableLines.length,
          totalStrips: billableLines.reduce((s, l) => s + l.strips, 0),
          baseVal,
          val14,
          grandTotal,
          wordsTotal: tafqeetEGP(grandTotal),
          raw: iss
        };
      })
      .filter((x): x is Extract<UnifiedInvoiceRow, { kind: 'sales' }> => x !== null);

    return [...salesRows, ...incomingRows].sort((a, b) => (b.date || '').localeCompare(a.date || '') || (b.createdAt || '').localeCompare(a.createdAt || ''));
  }, [db.invoices, db.issues, db.products, db.partners, getProduct]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return allInvoices.filter(row => {
      if (kindFilter !== 'all' && row.kind !== kindFilter) return false;
      if (!q) return true;
      const itemsText = row.raw.lines
        .map(l => {
          const p = getProduct(l.productId);
          return p ? `${p.code} ${p.name}` : '';
        })
        .join(' ');
      const hay = `${row.no} ${row.refNo || ''} ${row.partnerName} ${row.wordsTotal} ${itemsText}`.toLowerCase();
      return hay.includes(q);
    });
  }, [allInvoices, kindFilter, search, getProduct]);

  const handleExportExcel = () => {
    const headers = [
      'نوع الفاتورة',
      'رقم الفاتورة',
      'رقم المرجع / الأذن',
      'التاريخ',
      'العميل / المورد',
      'عدد البنود',
      'إجمالي الوحدات',
      'القيمة الأساسية (ج.م)',
      'قيمة 14% (ج.م)',
      'المبلغ الإجمالي (شامل 14%)',
      'تفقيط المبلغ الإجمالي بالحروف المصرية'
    ];
    const rows = filtered.map(r => [
      r.kind === 'incoming' ? 'فاتورة وارد' : 'فاتورة مبيعات',
      r.no,
      r.refNo || '—',
      fmtDate(r.date),
      r.partnerName,
      r.linesCount,
      r.totalStrips,
      Number(r.baseVal.toFixed(2)),
      r.val14,
      r.grandTotal,
      r.wordsTotal
    ]);
    exportToExcel(`قائمة_الفواتير_${todayISO()}.xlsx`, 'قائمة الفواتير', headers, rows);
    toast('تم تصدير قائمة الفواتير إلى Excel');
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="قائمة الفواتير"
        subtitle="سجل كامل لفواتير المبيعات والوارد مع حساب (المبلغ × 14%) والتفقيط التلقائي بالحروف المصرية"
        actions={
          <>
            <ExcelButton onClick={handleExportExcel} label="تصدير Excel" />
            <button
              type="button"
              onClick={onCreateIncoming}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
            >
              <ArrowDownToLine className="w-3.5 h-3.5" />
              <span>فاتورة وارد جديدة</span>
            </button>
            <button
              type="button"
              onClick={() => onCreateSalesInvoice()}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-extrabold hover:bg-[#0d655e] cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>عمل فاتورة مبيعات</span>
            </button>
          </>
        }
      />

      {openIssueOrders.length > 0 && (
        <section className="bg-[#eef8f6] border border-[#b7dfd7] rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs text-[#073b39]">
            <span className="font-extrabold">يوجد {fmtNum(openIssueOrders.length)} أذن صرف مفتوح بانتظار عمل فاتورة مبيعات.</span>
            <span className="text-[#3b5653] mr-1.5">اختر الأذن لإصدار فاتورته وإغلاقه، أو علّم عليه إذا تم عمل فاتورته بالفعل.</span>
          </div>
          <button
            type="button"
            onClick={() => onCreateSalesInvoice()}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>اختيار أذن وعمل الفاتورة</span>
          </button>
        </section>
      )}

      <section className="bg-white border border-[#dce6e3] rounded-xl p-3.5">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5 items-center">
          <div className="md:col-span-6 relative">
            <Search className="w-4 h-4 text-[#6b8481] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="بحث برقم الفاتورة، أذن الصرف، اسم العميل أو المورد، أو الصنف..."
              className="w-full pr-9 pl-3 py-2 text-xs bg-[#f8fbfa] border border-[#dce6e3] rounded-lg focus:outline-none focus:border-[#0f766e]"
            />
          </div>
          <div className="md:col-span-6 flex flex-wrap items-center gap-1.5">
            {(
              [
                { id: 'all', label: `كل الفواتير (${allInvoices.length})` },
                { id: 'sales', label: `فواتير المبيعات (${allInvoices.filter(r => r.kind === 'sales').length})` },
                { id: 'incoming', label: `فواتير الوارد (${allInvoices.filter(r => r.kind === 'incoming').length})` }
              ] as const
            ).map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setKindFilter(tab.id)}
                className={`px-3 py-2 rounded-lg text-xs font-bold border cursor-pointer transition-colors ${
                  kindFilter === tab.id
                    ? 'bg-[#0f766e] text-white border-[#0f766e]'
                    : 'bg-white text-[#233d3a] border-[#dce6e3] hover:bg-[#f4f8f7]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
        <div className="flex items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
          <div>
            <h3 className="text-sm font-extrabold text-[#102523]">بيانات الفواتير ({fmtNum(filtered.length)})</h3>
            <p className="text-[11.5px] text-[#5c7471]">تعرض كل فاتورة المبلغ الأساسي، ناتج الضرب في 14%، والمبلغ الناتج بالحروف المصرية</p>
          </div>
        </div>

        {filtered.length ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                  <th className="py-2.5 px-3 text-right font-bold">رقم الفاتورة</th>
                  <th className="py-2.5 px-3 text-center font-bold">النوع</th>
                  <th className="py-2.5 px-3 text-right font-bold">العميل / المورد</th>
                  <th className="py-2.5 px-3 text-center font-bold">البنود</th>
                  <th className="py-2.5 px-3 text-left font-bold">القيمة / 14%</th>
                  <th className="py-2.5 px-3 text-left font-bold">المبلغ الإجمالي</th>
                  <th className="py-2.5 px-3 text-right font-bold">التفقيط بالحروف المصرية</th>
                  <th className="py-2.5 px-3 text-left font-bold">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#edf3f1]">
                {filtered.map(row => {
                  const isExpanded = expandedKey === row.key;
                  return (
                    <React.Fragment key={row.key}>
                      <tr className={`hover:bg-[#f9fcfb] ${isExpanded ? 'bg-[#f4fbf9]' : ''}`}>
                        <td className="py-2.5 px-3">
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => setExpandedKey(isExpanded ? null : row.key)}
                              className="p-1 rounded border border-[#dce6e3] bg-white text-[#233d3a] hover:bg-[#eef8f6] cursor-pointer"
                              title={isExpanded ? 'إخفاء البنود' : 'عرض البنود'}
                            >
                              {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                            </button>
                            <div>
                              <div className="font-mono-num font-extrabold text-[#0f766e]">{row.no}</div>
                              <div className="text-[11px] text-[#5c7471]">
                                {fmtDate(row.date)}
                                {row.refNo ? ` · أذن ${row.refNo}` : ''}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span
                            className={`inline-block px-2 py-0.5 rounded-md border text-[10.5px] font-bold ${
                              row.kind === 'sales'
                                ? 'bg-[#eff6ff] border-[#bfdbfe] text-[#1d4ed8]'
                                : 'bg-[#f5f3ff] border-[#ddd6fe] text-[#6d28d9]'
                            }`}
                          >
                            {row.kind === 'sales' ? 'فاتورة مبيعات' : 'فاتورة وارد'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          <div className="font-bold text-[#102523]">{row.partnerName}</div>
                          {row.kind === 'sales' && (row.customerInfo.phone || row.customerInfo.address) && (
                            <div className="text-[10.5px] text-[#5c7471] leading-snug">
                              {[row.customerInfo.phone, row.customerInfo.address].filter(Boolean).join(' · ')}
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-center tabular-nums">
                          <span className="font-bold">{row.linesCount}</span>
                          <span className="text-[10.5px] text-[#5c7471] mr-1">({fmtNum(row.totalStrips)})</span>
                        </td>
                        <td className="py-2.5 px-3 text-left tabular-nums">
                          <div className="font-bold text-[#102523]">{fmtMoney(row.baseVal)} ج.م</div>
                          <div className="text-[10.5px] font-bold text-[#073b39]">14%: {fmtMoney(row.val14)} ج.م</div>
                        </td>
                        <td className="py-2.5 px-3 text-left font-extrabold text-[#0f766e] tabular-nums">
                          {fmtMoney(row.grandTotal)} ج.م
                        </td>
                        <td className="py-2.5 px-3 max-w-[270px]">
                          <div className="text-[11px] font-bold text-[#14532d] leading-snug">{row.wordsTotal}</div>
                        </td>
                        <td className="py-2.5 px-3 text-left whitespace-nowrap">
                          <div className="inline-flex items-center gap-1 whitespace-nowrap">
                            <button
                              type="button"
                              onClick={async () => {
                                try {
                                  if (row.kind === 'incoming') {
                                    await exportInvoiceToWord(row.raw, db.company, db.products);
                                  } else {
                                    const custPartner =
                                      getPartner(row.raw.customerId) ||
                                      db.partners.find(p => p.type === 'customer' && p.name === row.raw.customer);
                                    await exportSalesInvoiceToWord(
                                      row.raw,
                                      db.company,
                                      getWarehouse(row.raw.warehouseId),
                                      db.products,
                                      custPartner
                                    );
                                  }
                                  toast(`تم تحميل الفاتورة ${row.no} بصيغة Word (.docx)`);
                                } catch {
                                  toast('تعذر إنشاء ملف Word', 'err');
                                }
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#bfdbfe] bg-[#eff6ff] text-[#1d4ed8] hover:bg-[#dbeafe] text-[11px] font-bold cursor-pointer whitespace-nowrap"
                              title="تحميل الفاتورة في Word"
                            >
                              <FileText className="w-3.5 h-3.5" />
                              <span>وورد</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => (row.kind === 'incoming' ? onViewInvoice(row.raw) : onViewIssue(row.raw))}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#dce6e3] bg-white text-[#233d3a] hover:bg-[#f4f8f7] text-[11px] font-bold cursor-pointer whitespace-nowrap"
                              title="عرض التفاصيل والطباعة"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>عرض</span>
                            </button>
                            {row.kind === 'sales' && !row.raw.closed && (
                              <button
                                type="button"
                                onClick={() => onEditIssue(row.raw)}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#fde68a] bg-[#fffbeb] text-[#92400e] hover:bg-[#fef3c7] text-[11px] font-bold cursor-pointer whitespace-nowrap"
                                title="تعديل أذن الصرف"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                                <span>تعديل</span>
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => {
                                if (row.kind === 'incoming') {
                                  exportIncomingInvoiceToExcel(row.raw, db.warehouses, db.products);
                                } else {
                                  const custPartner =
                                    getPartner(row.raw.customerId) ||
                                    db.partners.find(p => p.type === 'customer' && p.name === row.raw.customer);
                                  exportSalesInvoiceToExcel(
                                    row.raw,
                                    getWarehouse(row.raw.warehouseId),
                                    db.products,
                                    custPartner
                                  );
                                }
                                toast(`تم تصدير الفاتورة ${row.no} إلى Excel`);
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#a7f3d0] bg-[#ecfdf5] text-[#047857] hover:bg-[#d1fae5] text-[11px] font-bold cursor-pointer whitespace-nowrap"
                              title="تصدير الفاتورة إلى Excel"
                            >
                              <FileSpreadsheet className="w-3.5 h-3.5" />
                              <span>إكسيل</span>
                            </button>
                          </div>
                        </td>
                      </tr>

                      {isExpanded && (
                        <tr className="bg-[#f8fbfa]">
                          <td colSpan={8} className="px-4 py-3 border-t border-[#e5efec]">
                            <div className="border border-[#dce6e3] rounded-lg overflow-hidden bg-white">
                              {row.kind === 'sales' && (
                                <div className="px-3.5 py-2.5 bg-[#f4f9f8] border-b border-[#dce6e3] text-[11.5px] flex flex-wrap items-center gap-x-5 gap-y-1">
                                  <div>
                                    <span className="font-bold text-[#5c7471]">بيانات العميل: </span>
                                    <span className="font-extrabold text-[#102523]">{row.customerInfo.name}</span>
                                    {row.customerInfo.code && <span className="font-mono-num text-[#0f766e] mr-1">({row.customerInfo.code})</span>}
                                  </div>
                                  {row.customerInfo.phone && (
                                    <div><span className="font-bold text-[#5c7471]">الهاتف: </span><span>{row.customerInfo.phone}</span></div>
                                  )}
                                  {row.customerInfo.address && (
                                    <div><span className="font-bold text-[#5c7471]">العنوان: </span><span>{row.customerInfo.address}</span></div>
                                  )}
                                  {row.customerInfo.taxNo && (
                                    <div><span className="font-bold text-[#5c7471]">الرقم الضريبي: </span><span className="font-mono-num">{row.customerInfo.taxNo}</span></div>
                                  )}
                                  {row.customerInfo.contact && (
                                    <div><span className="font-bold text-[#5c7471]">المسؤول: </span><span>{row.customerInfo.contact}</span></div>
                                  )}
                                </div>
                              )}
                              <table className="w-full text-[11.5px] border-collapse">
                                <thead>
                                  <tr className="bg-[#eef8f6] text-[#073b39] border-b border-[#dce6e3]">
                                    <th className="py-2 px-3 text-right font-bold">الكود</th>
                                    <th className="py-2 px-3 text-right font-bold">الصنف</th>
                                    <th className="py-2 px-3 text-center font-bold">التشغيلة / الصلاحية</th>
                                    <th className="py-2 px-3 text-right font-bold">الكمية</th>
                                    <th className="py-2 px-3 text-left font-bold">سعر الوحدة</th>
                                    <th className="py-2 px-3 text-left font-bold">الإجمالي</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-[#edf3f1]">
                                  {row.kind === 'incoming'
                                    ? row.raw.lines.map((l, idx) => {
                                        const p = getProduct(l.productId);
                                        if (!p) return null;
                                        return (
                                          <tr key={idx}>
                                            <td className="py-2 px-3 font-mono-num font-bold text-[#0f766e]">{p.code}</td>
                                            <td className="py-2 px-3 font-bold text-[#102523]">{p.name}</td>
                                            <td className="py-2 px-3 text-center">
                                              <span className="font-mono-num ml-2">{l.batch}</span>
                                              <ExpiryTag date={l.expiry} />
                                            </td>
                                            <td className="py-2 px-3 font-bold tabular-nums">{unitsText(l.strips, p)}</td>
                                            <td className="py-2 px-3 text-left tabular-nums">{fmtMoney(p.price)} ج.م</td>
                                            <td className="py-2 px-3 text-left font-bold tabular-nums">{fmtMoney(l.strips * p.price)} ج.م</td>
                                          </tr>
                                        );
                                      })
                                    : row.raw.lines
                                        .filter(l => !isLineReceipt(l, getProduct(l.productId)))
                                        .map((l, idx) => {
                                          const p = getProduct(l.productId);
                                          if (!p) return null;
                                          const price = l.pricePerStrip || p.price || 0;
                                          return (
                                            <tr key={idx}>
                                              <td className="py-2 px-3 font-mono-num font-bold text-[#0f766e]">{p.code}</td>
                                              <td className="py-2 px-3 font-bold text-[#102523]">{p.name}</td>
                                              <td className="py-2 px-3 text-center text-[#3b5653]">
                                                {(l.alloc || []).map((a, ai) => (
                                                  <span key={ai} className="inline-block ml-2 tabular-nums">
                                                    <b className="font-mono-num">{a.batch}</b> ({fmtDate(a.expiry)})
                                                  </span>
                                                ))}
                                              </td>
                                              <td className="py-2 px-3 font-bold tabular-nums">{unitsText(l.strips, p)}</td>
                                              <td className="py-2 px-3 text-left tabular-nums">{fmtMoney(price)} ج.م</td>
                                              <td className="py-2 px-3 text-left font-bold tabular-nums">{fmtMoney(l.strips * price)} ج.م</td>
                                            </tr>
                                          );
                                        })}
                                </tbody>
                              </table>
                              <div className="border-t border-[#dce6e3] text-xs">
                                <div className="flex items-center justify-between px-3 py-2 bg-white border-b border-[#edf3f1]">
                                  <span className="font-bold text-[#5c7471]">القيمة الأساسية</span>
                                  <span className="font-bold tabular-nums">{fmtMoney(row.baseVal)} ج.م</span>
                                </div>
                                <div className="flex items-center justify-between px-3 py-2 bg-[#f8fbfa] border-b border-[#edf3f1]">
                                  <span className="font-bold text-[#073b39]">قيمة 14%</span>
                                  <span className="font-extrabold text-[#0f766e] tabular-nums">{fmtMoney(row.val14)} ج.م</span>
                                </div>
                                <div className="px-3 py-2.5 bg-[#eef8f6] flex flex-wrap items-center justify-between gap-2">
                                  <div className="flex items-center gap-2.5">
                                    <span className="font-extrabold text-[#073b39]">المبلغ الإجمالي (شامل 14%):</span>
                                    <span className="text-sm font-extrabold text-[#0f766e] tabular-nums">{fmtMoney(row.grandTotal)} ج.م</span>
                                  </div>
                                  <span className="font-extrabold text-[#14532d]">{row.wordsTotal}</span>
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<FileSpreadsheet className="w-6 h-6" />}
            title="لا توجد فواتير مطابقة"
            description="أنشئ فاتورة وارد أو أذن صرف بفاتورة أو عدّل عبارة البحث."
            action={
              <button
                type="button"
                onClick={onCreateIncoming}
                className="px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold cursor-pointer"
              >
                فاتورة وارد جديدة
              </button>
            }
          />
        )}
      </section>
    </div>
  );
}
