import React, { useMemo, useState } from 'react';
import { Building2, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { Partner, PartnerType } from '../types/pharma';
import { fmtNum, todayISO } from '../utils/format';
import { exportToExcel } from '../utils/export';
import { EmptyState, ExcelButton, PageHeader, PrintButton } from '../components/ui/CommonUI';

export function PartnersPage({
  partnerType,
  onAddPartner,
  onEditPartner,
  onOpenCompany,
  onPrintHtml
}: {
  partnerType: PartnerType;
  onAddPartner: (type: PartnerType) => void;
  onEditPartner: (p: Partner) => void;
  onOpenCompany: () => void;
  onPrintHtml: (html: string) => void;
}) {
  const { db, deletePartner, toast } = usePharmaStore();
  const [search, setSearch] = useState('');

  const isCustomer = partnerType === 'customer';
  const titleLabel = isCustomer ? 'العملاء' : 'الموردون';
  const singularLabel = isCustomer ? 'عميل' : 'مورد';
  const subtitleLabel = isCustomer
    ? 'إدارة بيانات العملاء والصيدليات والمستشفيات الخاصة بأذون الصرف وفواتير المبيعات'
    : 'إدارة بيانات شركات الأدوية والموردين الخاصة بفواتير الوارد والأصناف';

  const partners = useMemo(() => {
    const q = search.trim().toLowerCase();
    return db.partners
      .filter(p => {
        if (p.type !== partnerType) return false;
        if (q && !`${p.name} ${p.code} ${p.phone} ${p.address} ${p.taxNo} ${p.contact}`.toLowerCase().includes(q)) return false;
        return true;
      })
      .sort((a, b) => (a.name || '').localeCompare(b.name || '', 'ar'));
  }, [db.partners, search, partnerType]);

  const totalCount = db.partners.filter(p => p.type === partnerType).length;

  const handleExcel = () => {
    const headers = ['الكود', 'الاسم', 'المسؤول', 'الهاتف', 'العنوان', 'الرقم الضريبي', 'ملاحظات'];
    const rows = partners.map(p => [
      p.code,
      p.name,
      p.contact || '—',
      p.phone || '—',
      p.address || '—',
      p.taxNo || '—',
      p.notes || '—'
    ]);
    exportToExcel(`${titleLabel}_${todayISO()}.xlsx`, titleLabel, headers, rows);
    toast(`تم تصدير قائمة ${titleLabel} إلى Excel`);
  };

  const handlePrint = () => {
    const rowsHtml = partners.map(p => `<tr>
      <td style="border:1px solid #0b4f4b;padding:5px">${p.code}</td>
      <td style="border:1px solid #0b4f4b;padding:5px">${p.name}</td>
      <td style="border:1px solid #0b4f4b;padding:5px">${p.contact || '—'}</td>
      <td style="border:1px solid #0b4f4b;padding:5px">${p.phone || '—'}</td>
      <td style="border:1px solid #0b4f4b;padding:5px">${p.address || '—'}</td>
      <td style="border:1px solid #0b4f4b;padding:5px">${p.taxNo || '—'}</td>
    </tr>`).join('');
    onPrintHtml(`
      <div style="font-family:Cairo,Arial,sans-serif;direction:rtl;color:#111">
        <h2>قائمة ${titleLabel} — ${db.company.name}</h2>
        <table style="width:100%;border-collapse:collapse;font-size:11px">
          <thead><tr style="background:#0f766e;color:#fff">
            <th style="border:1px solid #0b4f4b;padding:5px">الكود</th>
            <th style="border:1px solid #0b4f4b;padding:5px">الاسم</th>
            <th style="border:1px solid #0b4f4b;padding:5px">المسؤول</th>
            <th style="border:1px solid #0b4f4b;padding:5px">الهاتف</th>
            <th style="border:1px solid #0b4f4b;padding:5px">العنوان</th>
            <th style="border:1px solid #0b4f4b;padding:5px">الرقم الضريبي</th>
          </tr></thead>
          <tbody>${rowsHtml}</tbody>
        </table>
      </div>
    `);
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title={titleLabel}
        subtitle={subtitleLabel}
        actions={
          <>
            <ExcelButton onClick={handleExcel} />
            <PrintButton onClick={handlePrint} />
            <button
              type="button"
              onClick={onOpenCompany}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>بيانات الشركة</span>
            </button>
            <button
              type="button"
              onClick={() => onAddPartner(partnerType)}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{singularLabel} جديد</span>
            </button>
          </>
        }
      />

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-[#6b8481] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder={`ابحث في ${titleLabel} بالاسم أو الكود أو الهاتف أو الرقم الضريبي...`}
            className="w-full pr-9 pl-3 py-2 text-xs bg-white border border-[#dce6e3] rounded-lg focus:outline-none focus:border-[#0f766e]"
          />
        </div>
        <span className="px-3 py-1.5 rounded-lg bg-[#eef8f6] border border-[#b7dfd7] text-xs font-bold text-[#0f766e] tabular-nums">
          إجمالي {titleLabel}: {fmtNum(totalCount)}
        </span>
      </div>

      <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
        {partners.length ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="bg-[#f4f8f7] text-[#5c7471] border-b border-[#dce6e3]">
                  <th className="py-2.5 px-3 text-right font-bold">الكود</th>
                  <th className="py-2.5 px-3 text-right font-bold">{isCustomer ? 'العميل' : 'المورد'}</th>
                  <th className="py-2.5 px-3 text-right font-bold">الهاتف</th>
                  <th className="py-2.5 px-3 text-right font-bold">العنوان</th>
                  <th className="py-2.5 px-3 text-right font-bold">الرقم الضريبي</th>
                  <th className="py-2.5 px-3 text-left font-bold">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#edf3f1]">
                {partners.map(p => (
                  <tr key={p.id} className="hover:bg-[#f9fcfb]">
                    <td className="py-2.5 px-3 font-mono-num font-bold text-[#0f766e]">{p.code}</td>
                    <td className="py-2.5 px-3">
                      <div className="font-bold text-[#102523]">{p.name}</div>
                      {p.contact && <div className="text-[11px] text-[#5c7471]">{p.contact}</div>}
                    </td>
                    <td className="py-2.5 px-3 font-mono-num text-[#3b5653]">{p.phone || '—'}</td>
                    <td className="py-2.5 px-3 text-[#3b5653]">{p.address || '—'}</td>
                    <td className="py-2.5 px-3 font-mono-num text-[#3b5653]">{p.taxNo || '—'}</td>
                    <td className="py-2.5 px-3 text-left">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onEditPartner(p)}
                          className="p-1.5 rounded-md border border-[#dce6e3] text-[#3b5653] hover:bg-[#f4f8f7] cursor-pointer"
                          title="تعديل"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              await deletePartner(p.id);
                              toast(`تم حذف «${p.name}»`);
                            } catch (err) {
                              toast(err instanceof Error ? err.message : 'تعذر حذف الجهة', 'err');
                            }
                          }}
                          className="p-1.5 rounded-md border border-[#fecaca] text-[#dc2626] hover:bg-[#fef2f2] cursor-pointer"
                          title="حذف"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<Search className="w-6 h-6" />}
            title={isCustomer ? 'لا يوجد عملاء مطابقون' : 'لا يوجد موردون مطابقون'}
            action={
              <button
                type="button"
                onClick={() => onAddPartner(partnerType)}
                className="px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold cursor-pointer"
              >
                إضافة {singularLabel} جديد
              </button>
            }
          />
        )}
      </section>
    </div>
  );
}
