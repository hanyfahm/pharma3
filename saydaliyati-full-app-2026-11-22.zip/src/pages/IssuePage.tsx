import React, { useMemo, useState } from 'react';
import { Check, Eye, FilePlus2, FileText, Lock, Pencil, Plus, Receipt, RotateCcw, Search, Trash2, X } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import { useLayoutMode } from '../store/useLayoutMode';
import type { DraftIssue, IssueOrder, Product, ReceiptType } from '../types/pharma';
import {
  calc14Percent,
  calcIssueValue,
  calcTotalWith14,
  fmtDate,
  fmtMoney,
  fmtNum,
  getIssueReceipts,
  getLineReceiptType,
  isLineReceipt,
  sortIssueLines,
  sortIssuesByInvoiceStatus,
  tafqeetEGP,
  todayISO,
  uid,
  unitsText
} from '../utils/format';
import { exportIssueReceiptToWord, exportIssueToWord, exportToExcel } from '../utils/export';
import {
  findDuplicateInvoiceNo,
  findDuplicateReceiptNo,
  normDocNo,
  suggestReceiptNumbers
} from '../utils/pharmaEngine';
import { EmptyState, ExcelButton, PageHeader } from '../components/ui/CommonUI';
import { CalmIssueWizard } from '../components/CalmIssueWizard';

export function IssuePage({
  draft,
  setDraft,
  editingIssue,
  supplierFilter,
  onChangeSupplierFilter,
  onOpenLinePicker,
  onQuickCustomer,
  onViewIssue,
  onEditIssue,
  onCreateSalesInvoice,
  onStartReturn
}: {
  draft: DraftIssue;
  setDraft: React.Dispatch<React.SetStateAction<DraftIssue>>;
  editingIssue?: IssueOrder | null;
  supplierFilter?: string;
  onChangeSupplierFilter?: (supplierId: string) => void;
  onOpenLinePicker: () => void;
  onQuickCustomer: () => void;
  onViewIssue: (issue: IssueOrder) => void;
  onEditIssue: (issue: IssueOrder) => void;
  onCreateSalesInvoice?: (issueId?: string) => void;
  onStartReturn: (issueId: string) => void;
}) {
  const {
    db,
    getProduct,
    getWarehouse,
    getPartner,
    availableStock,
    nearestExpiry,
    nextIssueNo,
    issueReturnStats,
    commitIssueOrder,
    updateIssueOrder,
    setIssueInvoiced,
    toast
  } = usePharmaStore();

  const { isSplitV2, isCalmSteps } = useLayoutMode();
  const [catSearch, setCatSearch] = useState('');
  const [localSupplierId, setLocalSupplierId] = useState<string>('all');
  const catSupplierId = supplierFilter ?? localSupplierId;
  const setCatSupplierId = (val: string) => {
    setLocalSupplierId(val);
    onChangeSupplierFilter?.(val);
  };
  const [catInputs, setCatInputs] = useState<Record<string, { qty: number; unitName: string }>>({});
  const [quickProdId, setQuickProdId] = useState<string>('');
  const [quickQty, setQuickQty] = useState<number>(1);
  const [quickUnitName, setQuickUnitName] = useState<string>('');

  const isEditing = Boolean(editingIssue && draft.editingIssueId === editingIssue.id);
  const hasReturnsLock = Boolean(
    isEditing && editingIssue && (db.returns || []).some(r => r.issueId === editingIssue.id)
  );

  const restoredStockMap = useMemo(() => {
    const map: Record<string, number> = {};
    if (!isEditing || !editingIssue || editingIssue.warehouseId !== draft.warehouseId) return map;
    const today = todayISO();
    editingIssue.lines.forEach(ol => {
      const allocs = ol.alloc?.length ? ol.alloc : [{ batch: '', expiry: '', strips: ol.strips }];
      const validStrips = allocs.reduce((sum, a) => {
        if (!a.expiry || a.expiry >= today) return sum + (a.strips || 0);
        return sum;
      }, 0);
      map[ol.productId] = (map[ol.productId] || 0) + validStrips;
    });
    return map;
  }, [isEditing, editingIssue, draft.warehouseId]);

  const effectiveAvail = (productId: string) =>
    availableStock(productId, draft.warehouseId) + (restoredStockMap[productId] || 0);

  const customers = db.partners.filter(p => p.type === 'customer');
  const suppliers = useMemo(() => db.partners.filter(p => p.type === 'supplier'), [db.partners]);
  const selectedCustomer = getPartner(draft.customerId) || customers[0];
  const wh = getWarehouse(draft.warehouseId);
  const autoNo = nextIssueNo();
  const displayNo = isEditing && editingIssue ? editingIssue.no : autoNo;

  const warehouseAvailProducts = useMemo(() => {
    return db.products
      .map(p => ({
        product: p,
        avail: availableStock(p.id, draft.warehouseId) + (restoredStockMap[p.id] || 0),
        near: nearestExpiry(p.id, draft.warehouseId)
      }))
      .filter(row => row.avail > 0);
  }, [db.products, draft.warehouseId, availableStock, nearestExpiry, restoredStockMap]);

  const catSupplierCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    warehouseAvailProducts.forEach(row => {
      const k = row.product.supplierId || '__none__';
      counts[k] = (counts[k] || 0) + 1;
    });
    return counts;
  }, [warehouseAvailProducts]);

  const eligibleCatalog = useMemo(() => {
    const q = catSearch.trim().toLowerCase();
    return warehouseAvailProducts.filter(row => {
      if (catSupplierId !== 'all') {
        if (catSupplierId === '__none__' ? Boolean(row.product.supplierId) : row.product.supplierId !== catSupplierId) {
          return false;
        }
      }
      if (q && !`${row.product.name} ${row.product.code} ${row.product.form}`.toLowerCase().includes(q)) {
        return false;
      }
      return true;
    });
  }, [warehouseAvailProducts, catSupplierId, catSearch]);

  const supplierScopedProducts = useMemo(() => {
    return warehouseAvailProducts.filter(row => {
      if (catSupplierId === 'all') return true;
      if (catSupplierId === '__none__') return !row.product.supplierId;
      return row.product.supplierId === catSupplierId;
    });
  }, [warehouseAvailProducts, catSupplierId]);

  const activeQuickRow =
    supplierScopedProducts.find(r => r.product.id === quickProdId) || supplierScopedProducts[0] || null;
  const activeQuickProd = activeQuickRow?.product || null;
  const activeQuickUnit =
    (activeQuickProd && activeQuickProd.units.find(u => u.name === quickUnitName)) ||
    activeQuickProd?.units[0] ||
    null;

  const handleInlineQuickAdd = () => {
    if (hasReturnsLock) {
      toast('لا يمكن تعديل أصناف أذن صرف مسجل عليه مرتجع عميل', 'err');
      return;
    }
    if (!activeQuickRow || !activeQuickProd || !activeQuickUnit) {
      toast('لا توجد أصناف متاحة في المخزن والشركة المحددة', 'err');
      return;
    }
    const qty = Math.max(1, Math.round(quickQty || 1));
    const strips = qty * activeQuickUnit.factor;
    const alreadyInDraft = draft.lines
      .filter(l => l.productId === activeQuickProd.id)
      .reduce((s, l) => s + l.strips, 0);
    if (alreadyInDraft + strips > activeQuickRow.avail) {
      toast(`الكمية المطلوبة تتجاوز المتاح بالمخزن (${unitsText(activeQuickRow.avail, activeQuickProd)})`, 'err');
      return;
    }
    setDraft(prev => ({
      ...prev,
      lines: [
        ...prev.lines,
        {
          id: uid('ln'),
          productId: activeQuickProd.id,
          strips,
          units: [{ name: activeQuickUnit.name, qty }],
          asReceipt: Boolean(activeQuickProd.marked),
          receiptType: activeQuickProd.marked ? 'supplies' : undefined
        }
      ]
    }));
    setQuickQty(1);
    toast(`تمت إضافة ${qty} ${activeQuickUnit.name} من ${activeQuickProd.name}`);
  };

  const handleQuickAddFromCatalog = (p: Product, avail: number) => {
    if (hasReturnsLock) {
      toast('لا يمكن تعديل أصناف أذن صرف مسجل عليه مرتجع عميل', 'err');
      return;
    }
    const chosen = catInputs[p.id] || { qty: 1, unitName: p.units[0]?.name || 'شريط' };
    const unitObj = p.units.find(u => u.name === chosen.unitName) || p.units[0];
    const qty = Math.max(1, Math.round(chosen.qty || 1));
    const strips = qty * (unitObj?.factor || 1);
    const alreadyInDraft = draft.lines
      .filter(l => l.productId === p.id)
      .reduce((s, l) => s + l.strips, 0);
    if (alreadyInDraft + strips > avail) {
      toast(`الكمية المطلوبة تتجاوز المتاح بالمخزن (${unitsText(avail, p)})`, 'err');
      return;
    }
    setDraft(prev => ({
      ...prev,
      lines: [
        ...prev.lines,
        {
          id: uid('ln'),
          productId: p.id,
          strips,
          units: [{ name: unitObj.name, qty }],
          asReceipt: Boolean(p.marked),
          receiptType: p.marked ? 'supplies' : undefined
        }
      ]
    }));
    toast(`تمت إضافة ${qty} ${unitObj.name} من ${p.name}`);
  };

  const sortedDraftLines = useMemo(() => sortIssueLines(draft.lines, db.products), [draft.lines, db.products]);
  const sortedIssuesHistory = useMemo(() => sortIssuesByInvoiceStatus(db.issues), [db.issues]);
  const billableLines = sortedDraftLines.filter(l => !isLineReceipt(l, getProduct(l.productId)));
  const suppliesLines = sortedDraftLines.filter(l => isLineReceipt(l, getProduct(l.productId)));
  const suppliesOnlyLines = suppliesLines.filter(l => getLineReceiptType(l, getProduct(l.productId)) === 'supplies');
  const giftOnlyLines = suppliesLines.filter(l => getLineReceiptType(l, getProduct(l.productId)) === 'gift');
  const hasBothReceipts = suppliesOnlyLines.length > 0 && giftOnlyLines.length > 0;
  const suggestedRecs = suggestReceiptNumbers(
    db,
    displayNo,
    suppliesOnlyLines.length > 0,
    giftOnlyLines.length > 0,
    editingIssue?.id
  );
  const baseRecNo = draft.receiptNo?.trim() || suggestedRecs.baseNo;
  const effSuppliesRecNo =
    suppliesOnlyLines.length > 0
      ? (hasBothReceipts
          ? draft.suppliesReceiptNo?.trim() || suggestedRecs.suppliesNo
          : draft.receiptNo?.trim() || draft.suppliesReceiptNo?.trim() || suggestedRecs.suppliesNo)
      : '';
  const effGiftRecNo =
    giftOnlyLines.length > 0
      ? (hasBothReceipts
          ? draft.giftReceiptNo?.trim() || suggestedRecs.giftNo
          : draft.receiptNo?.trim() || draft.giftReceiptNo?.trim() || suggestedRecs.giftNo)
      : '';

  const dupInvoice = findDuplicateInvoiceNo(db, draft.invoiceNo, editingIssue?.id);
  const dupSuppliesRec = suppliesOnlyLines.length > 0 ? findDuplicateReceiptNo(db, effSuppliesRecNo, editingIssue?.id) : null;
  const dupGiftRec = giftOnlyLines.length > 0 ? findDuplicateReceiptNo(db, effGiftRecNo, editingIssue?.id) : null;
  const sameRecConflict =
    hasBothReceipts && Boolean(effSuppliesRecNo) && normDocNo(effSuppliesRecNo) === normDocNo(effGiftRecNo);
  const hasDocNumberConflict = Boolean(dupInvoice || dupSuppliesRec || dupGiftRec || sameRecConflict);

  const invTotal = billableLines.reduce((s, l) => s + l.strips * (getProduct(l.productId)?.price || 0), 0);
  const totalStrips = draft.lines.reduce((s, l) => s + l.strips, 0);
  const suppliesStrips = suppliesLines.reduce((s, l) => s + l.strips, 0);

  const handleSave = async () => {
    if (!draft.lines.length) {
      toast('أضف بندًا واحدًا على الأقل', 'err');
      return;
    }
    if (dupInvoice) {
      toast(
        `رقم الفاتورة «${draft.invoiceNo.trim()}» مستخدم بالفعل (${dupInvoice.source === 'incoming' ? `فاتورة وارد ${dupInvoice.ref}` : `أذن صرف ${dupInvoice.ref}`}) — لا يصح تكرار رقم الفاتورة`,
        'err'
      );
      return;
    }
    if (sameRecConflict) {
      toast('لا يصح تطابق رقم إيصال المستلزمات مع رقم إيصال الهدية بدون قيمة في نفس الأذن', 'err');
      return;
    }
    if (dupSuppliesRec) {
      toast(`رقم إيصال المستلزمات «${effSuppliesRecNo}» مستخدم بالفعل في أذن الصرف ${dupSuppliesRec.issueNo} — لا يصح التكرار`, 'err');
      return;
    }
    if (dupGiftRec) {
      toast(`رقم إيصال الهدية «${effGiftRecNo}» مستخدم بالفعل في أذن الصرف ${dupGiftRec.issueNo} — لا يصح التكرار`, 'err');
      return;
    }
    try {
      const saved = isEditing && editingIssue
        ? await updateIssueOrder(editingIssue.id, { ...draft, no: editingIssue.no })
        : await commitIssueOrder({ ...draft, no: autoNo });
      toast(
        isEditing
          ? `تم تعديل أذن الصرف ${saved.no} وتحديث الأرصدة بنجاح`
          : `تم ترحيل أذن الصرف ${saved.no} بنجاح`
      );
      setDraft({
        editingIssueId: undefined,
        no: nextIssueNo(),
        receiptNo: undefined,
        suppliesReceiptNo: undefined,
        giftReceiptNo: undefined,
        warehouseId: draft.warehouseId,
        invoiceNo: '',
        invoiced: false,
        customerId: customers[0]?.id || '',
        date: todayISO(),
        lines: []
      });
      onViewIssue(saved);
    } catch (err) {
      toast(err instanceof Error ? err.message : 'تعذر حفظ أذن الصرف', 'err');
    }
  };

  const exportHistoryExcel = () => {
    const headers = ['رقم الأذن', 'التاريخ', 'العميل', 'رقم الفاتورة', 'المخزن', 'قيمة الفاتورة (ج.م)', 'وحدات المستلزمات', 'حالة المرتجع'];
    const rows = sortedIssuesHistory.map(i => {
      const rs = issueReturnStats(i);
      const retTxt = rs.status === 'full' ? 'مرتجع كلي' : rs.status === 'partial' ? `مرتجع جزئي (${rs.totalReturned})` : 'مسلّم بالكامل';
      return [
        i.no,
        fmtDate(i.date),
        i.customer,
        i.invoiceNo,
        getWarehouse(i.warehouseId)?.name || '',
        Number(calcIssueValue(i, db.products).toFixed(2)),
        i.suppliesStrips || 0,
        retTxt
      ];
    });
    exportToExcel(`أذون_الصرف_${todayISO()}.xlsx`, 'أذون الصرف', headers, rows);
    toast('تم تصدير أذون الصرف إلى Excel');
  };

  const handleNewOrder = () => {
    setDraft({
      editingIssueId: undefined,
      no: autoNo,
      receiptNo: undefined,
      suppliesReceiptNo: undefined,
      giftReceiptNo: undefined,
      warehouseId: db.warehouses[0].id,
      invoiceNo: '',
      invoiced: false,
      customerId: customers[0]?.id || '',
      date: todayISO(),
      lines: []
    });
    toast(isEditing ? 'تم إلغاء التعديل وفتح أذن صرف جديد' : 'تم فتح أذن صرف جديد');
  };

  const exportDraftOrHistoryExcel = () => {
    if (!draft.lines.length) {
      exportHistoryExcel();
      return;
    }
    const headers = ['الكود', 'الصنف', 'التصنيف', 'الكمية بالوحدات', 'الوحدات الأساسية', 'السعر (ج.م)', 'القيمة (ج.م)', 'العميل', 'المخزن', 'تاريخ الأذن'];
    const rows = sortedDraftLines.map(l => {
      const p = getProduct(l.productId);
      const receipt = isLineReceipt(l, p);
      const lineReceiptType = getLineReceiptType(l, p);
      const kindLabel = receipt ? (lineReceiptType === 'gift' ? 'إيصال هدية' : 'إيصال مستلزمات') : 'فاتورة';
      const val = receipt ? 0 : l.strips * (p?.price || 0);
      return [
        p?.code || '',
        p?.name || '',
        kindLabel,
        unitsText(l.strips, p),
        l.strips,
        receipt ? 0 : Number((p?.price || 0).toFixed(2)),
        Number(val.toFixed(2)),
        selectedCustomer?.name || '',
        wh?.name || '',
        fmtDate(draft.date)
      ];
    });
    exportToExcel(`أذن_صرف_${displayNo}.xlsx`, `أذن ${displayNo}`, headers, rows);
    toast(`تم تصدير بنود أذن الصرف ${displayNo} إلى Excel (.xlsx)`);
  };

  if (isCalmSteps) {
    return (
      <CalmIssueWizard
        draft={draft}
        setDraft={setDraft}
        editingIssue={editingIssue}
        supplierFilter={catSupplierId}
        onChangeSupplierFilter={setCatSupplierId}
        onQuickCustomer={onQuickCustomer}
        onViewIssue={onViewIssue}
        onNewOrder={handleNewOrder}
        onExportExcel={exportDraftOrHistoryExcel}
      />
    );
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title={isEditing ? `تعديل أذن الصرف — ${displayNo}` : 'أذون الصرف'}
        subtitle={
          isEditing
            ? 'تعديل بيانات وبنود أذن الصرف مع إعادة تسوية الأرصدة تلقائيًا بنظام FEFO'
            : 'ترقيم أوتوماتيك متسلسل من تاريخ اليوم + 4 خانات، وفتح مباشر في Word بفورمة ثابتة بدون أسعار'
        }
        actions={
          <>
            <button
              type="button"
              onClick={handleNewOrder}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
            >
              {isEditing ? <X className="w-3.5 h-3.5 text-[#dc2626]" /> : <FilePlus2 className="w-3.5 h-3.5 text-[#0f766e]" />}
              <span>{isEditing ? 'إلغاء التعديل' : 'أذن صرف جديد'}</span>
            </button>
            <span className={`px-3 py-1.5 rounded-lg border font-mono-num text-xs font-extrabold ${
              isEditing
                ? 'bg-[#fffbeb] border-[#fde68a] text-[#b45309]'
                : 'bg-[#eef8f6] border-[#b7dfd7] text-[#0f766e]'
            }`}>
              {displayNo}
            </span>
          </>
        }
      />

      {isEditing && editingIssue && (
        <div className="bg-[#fffbeb] border border-[#fde68a] rounded-xl px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="text-[#92400e] font-bold">
            أنت الآن في <span className="font-extrabold">وضع تعديل أذن الصرف رقم {editingIssue.no}</span> —{' '}
            {hasReturnsLock
              ? 'مسجل عليه مرتجع عميل: يمكنك تعديل العميل ورقم الفاتورة والتاريخ وأرقام الإيصالات فقط.'
              : 'يمكنك تعديل الكميات وإضافة أو حذف الأصناف وتغيير العميل أو المخزن، وسيتم تسوية الرصيد تلقائيًا عند الحفظ.'}
          </div>
          <button
            type="button"
            onClick={handleNewOrder}
            className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-white border border-[#fde68a] text-[#92400e] font-bold hover:bg-[#fef3c7] cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
            <span>إلغاء والعودة لأذن جديد</span>
          </button>
        </div>
      )}

      <div className={`grid grid-cols-1 ${isSplitV2 ? 'lg:grid-cols-12 gap-4' : 'lg:grid-cols-12 gap-5'} items-start`}>
        {isSplitV2 && (
          <section className="lg:col-span-5 bg-white border border-[#dce6e3] rounded-xl overflow-hidden lg:sticky lg:top-16">
            <div className="px-3.5 py-2.5 border-b border-[#eaf1ef] bg-[#f8fbfa] flex items-center justify-between gap-2">
              <div>
                <h3 className="text-xs font-extrabold text-[#102523]">كتالوج {wh?.name} ({eligibleCatalog.length} صنف متاح)</h3>
                <p className="text-[10.5px] text-[#5c7471]">اختر الشركة الموردة أو المخزن وأضف مباشرة بضغطة واحدة</p>
              </div>
            </div>
            <div className="p-2.5 border-b border-[#eaf1ef] space-y-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                <label className="block text-[10.5px] font-bold text-[#233d3a]">
                  <span className="block mb-0.5 text-[#5c7471]">الشركة الموردة</span>
                  <select
                    value={catSupplierId}
                    onChange={e => setCatSupplierId(e.target.value)}
                    className="w-full px-2 py-1.5 rounded-lg border border-[#dce6e3] text-[11.5px] bg-white focus:outline-none focus:border-[#0f766e]"
                  >
                    <option value="all">كل الشركات الموردة ({fmtNum(warehouseAvailProducts.length)})</option>
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({fmtNum(catSupplierCounts[s.id] || 0)})
                      </option>
                    ))}
                    {(catSupplierCounts.__none__ || 0) > 0 && (
                      <option value="__none__">بدون شركة ({fmtNum(catSupplierCounts.__none__)})</option>
                    )}
                  </select>
                </label>
                <label className="block text-[10.5px] font-bold text-[#233d3a]">
                  <span className="block mb-0.5 text-[#5c7471]">المخزن (الرئيسي / الفرعي)</span>
                  <select
                    value={draft.warehouseId}
                    disabled={hasReturnsLock}
                    onChange={e => setDraft(prev => ({ ...prev, warehouseId: e.target.value }))}
                    className="w-full px-2 py-1.5 rounded-lg border border-[#dce6e3] text-[11.5px] bg-white disabled:bg-[#f4f8f7] focus:outline-none focus:border-[#0f766e]"
                  >
                    {db.warehouses.map(w => (
                      <option key={w.id} value={w.id}>
                        {w.name} — {w.gov}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-[#6b8481] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={catSearch}
                  onChange={e => setCatSearch(e.target.value)}
                  placeholder="ابحث بالاسم أو الكود لإضافته فورًا..."
                  className="w-full pr-8 pl-2.5 py-1.5 text-xs bg-[#f8fbfa] border border-[#dce6e3] rounded-lg focus:outline-none focus:border-[#0f766e]"
                />
              </div>
            </div>
            <div className="max-h-[430px] overflow-y-auto divide-y divide-[#edf3f1]">
              {eligibleCatalog.length ? (
                eligibleCatalog.map(({ product: p, avail, near }) => {
                  const rowInput = catInputs[p.id] || { qty: 1, unitName: p.units[0]?.name || 'شريط' };
                  const supName = getPartner(p.supplierId)?.name;
                  return (
                    <div key={p.id} className="p-2.5 hover:bg-[#f9fcfb] space-y-1.5">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-[#102523] truncate">{p.name}</div>
                          <div className="text-[10.5px] text-[#5c7471] tabular-nums">
                            {p.code} · {p.marked ? 'مستلزمات' : `${fmtMoney(p.price)} ج.م`}
                            {near ? ` · صلاحية ${fmtDate(near)}` : ''}
                            {supName ? ` · ${supName}` : ''}
                          </div>
                        </div>
                        <span className="text-[11px] font-extrabold text-[#0f766e] tabular-nums whitespace-nowrap">
                          {unitsText(avail, p)}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          min={1}
                          value={rowInput.qty}
                          onChange={e =>
                            setCatInputs(prev => ({
                              ...prev,
                              [p.id]: {
                                qty: Math.max(1, Number(e.target.value) || 1),
                                unitName: rowInput.unitName
                              }
                            }))
                          }
                          className="w-16 px-2 py-1 rounded-md border border-[#dce6e3] text-xs text-center font-bold tabular-nums"
                        />
                        <select
                          value={rowInput.unitName}
                          onChange={e =>
                            setCatInputs(prev => ({
                              ...prev,
                              [p.id]: {
                                qty: rowInput.qty,
                                unitName: e.target.value
                              }
                            }))
                          }
                          className="flex-1 min-w-0 px-2 py-1 rounded-md border border-[#dce6e3] text-xs bg-white"
                        >
                          {p.units.map(u => (
                            <option key={u.name} value={u.name}>
                              {u.name} ({u.factor})
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={() => handleQuickAddFromCatalog(p, avail)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#0f766e] text-white text-[11px] font-bold hover:bg-[#0d655e] whitespace-nowrap cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                          <span>أضف</span>
                        </button>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="p-6 text-center text-xs text-[#5c7471]">لا توجد أصناف متاحة مطابقة في هذا المخزن.</div>
              )}
            </div>
          </section>
        )}

        <div className={`${isSplitV2 ? 'lg:col-span-7 space-y-3' : 'lg:col-span-8 space-y-4'}`}>
          <section className="bg-white border border-[#dce6e3] rounded-xl p-4">
            <h3 className="text-sm font-extrabold text-[#102523] mb-3">بيانات أذن الصرف</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="block text-xs font-bold text-[#233d3a]">
                <span>{isEditing ? 'رقم أذن الصرف (قيد التعديل)' : 'رقم أذن الصرف (تلقائي متسلسل)'}</span>
                <input
                  value={displayNo}
                  readOnly
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] bg-[#f4f8f7] font-mono-num font-bold text-[#0f766e] text-xs"
                />
              </label>
              <label className="block text-xs font-bold text-[#233d3a]">
                <span>تاريخ الأذن</span>
                <input
                  type="date"
                  value={draft.date}
                  onChange={e => setDraft(prev => ({ ...prev, date: e.target.value }))}
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs"
                />
              </label>
              <label className="block text-xs font-bold text-[#233d3a]">
                <span>الشركة الموردة (تصفية الأصناف)</span>
                <select
                  value={catSupplierId}
                  onChange={e => setCatSupplierId(e.target.value)}
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white focus:outline-none focus:border-[#0f766e]"
                >
                  <option value="all">كل الشركات الموردة ({fmtNum(warehouseAvailProducts.length)} صنف متاح)</option>
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({fmtNum(catSupplierCounts[s.id] || 0)} متاح)
                    </option>
                  ))}
                  {(catSupplierCounts.__none__ || 0) > 0 && (
                    <option value="__none__">أصناف بدون شركة محددة ({fmtNum(catSupplierCounts.__none__)})</option>
                  )}
                </select>
              </label>
              <label className="block text-xs font-bold text-[#233d3a]">
                <span>المخزن الصارف (المخازن الأربعة: الرئيسي والفرعي) *</span>
                <select
                  value={draft.warehouseId}
                  disabled={hasReturnsLock}
                  onChange={e => setDraft(prev => ({ ...prev, warehouseId: e.target.value }))}
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white disabled:bg-[#f4f8f7]"
                >
                  {db.warehouses.map(w => {
                    const whCount = db.products.filter(
                      p => availableStock(p.id, w.id) + (w.id === draft.warehouseId ? restoredStockMap[p.id] || 0 : 0) > 0
                    ).length;
                    return (
                      <option key={w.id} value={w.id}>
                        {w.name} — {w.gov} ({fmtNum(whCount)} صنف متاح)
                      </option>
                    );
                  })}
                </select>
              </label>
              <label className="block text-xs font-bold text-[#233d3a]">
                <span>رقم فاتورة العميل</span>
                <input
                  value={draft.invoiceNo}
                  onChange={e => setDraft(prev => ({ ...prev, invoiceNo: e.target.value }))}
                  placeholder="مثال: 5521"
                  className={`mt-1 w-full px-3 py-2 rounded-lg border text-xs ${
                    dupInvoice ? 'border-[#dc2626] bg-[#fef2f2] text-[#b91c1c]' : 'border-[#dce6e3]'
                  }`}
                />
                {dupInvoice && (
                  <span className="block mt-1 text-[10.5px] font-bold text-[#dc2626]">
                    رقم الفاتورة مستخدم بالفعل ({dupInvoice.source === 'incoming' ? `فاتورة وارد ${dupInvoice.ref}` : `أذن صرف ${dupInvoice.ref}`}) — ممنوع التكرار
                  </span>
                )}
              </label>
              <div className="block text-xs font-bold text-[#233d3a]">
                <label htmlFor="issue-customer-select" className="block">العميل *</label>
                <div className="mt-1 flex items-center gap-1.5">
                  <select
                    id="issue-customer-select"
                    value={draft.customerId || customers[0]?.id || ''}
                    onChange={e => setDraft(prev => ({ ...prev, customerId: e.target.value }))}
                    className="flex-1 min-w-0 px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white"
                  >
                    {customers.length ? (
                      customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)
                    ) : (
                      <option value="">لا يوجد عملاء مسجلون</option>
                    )}
                  </select>
                  <button
                    type="button"
                    onClick={onQuickCustomer}
                    title="عميل جديد"
                    className="w-9 h-9 rounded-lg border border-[#dce6e3] bg-white hover:bg-[#f4f8f7] grid place-items-center shrink-0 cursor-pointer"
                  >
                    <Plus className="w-4 h-4 text-[#0f766e]" />
                  </button>
                </div>
              </div>
              {suppliesLines.length > 0 && !hasBothReceipts && (
                <label className="block text-xs font-bold text-[#92400e]">
                  <span>
                    {giftOnlyLines.length > 0 ? 'رقم إيصال الهدية المرفق' : 'رقم إيصال المستلزمات المرفق'} (غير مكرر)
                  </span>
                  <input
                    value={draft.receiptNo ?? (suggestedRecs.suppliesNo || suggestedRecs.giftNo)}
                    onChange={e => setDraft(prev => ({ ...prev, receiptNo: e.target.value }))}
                    placeholder={suggestedRecs.suppliesNo || suggestedRecs.giftNo}
                    className={`mt-1 w-full px-3 py-2 rounded-lg border font-mono-num font-bold text-xs ${
                      dupSuppliesRec || dupGiftRec
                        ? 'border-[#dc2626] bg-[#fef2f2] text-[#b91c1c]'
                        : 'border-[#fde68a] bg-[#fffbeb] text-[#b45309]'
                    }`}
                  />
                  {(dupSuppliesRec || dupGiftRec) && (
                    <span className="block mt-1 text-[10.5px] font-bold text-[#dc2626]">
                      مستخدم بالفعل في أذن الصرف {(dupSuppliesRec || dupGiftRec)?.issueNo} ({(dupSuppliesRec || dupGiftRec)?.label}) — ممنوع التكرار
                    </span>
                  )}
                </label>
              )}
              {hasBothReceipts && (
                <>
                  <label className="block text-xs font-bold text-[#92400e]">
                    <span>رقم إيصال المستلزمات (1)</span>
                    <input
                      value={draft.suppliesReceiptNo ?? suggestedRecs.suppliesNo}
                      onChange={e => setDraft(prev => ({ ...prev, suppliesReceiptNo: e.target.value }))}
                      placeholder={suggestedRecs.suppliesNo}
                      className={`mt-1 w-full px-3 py-2 rounded-lg border font-mono-num font-bold text-xs ${
                        dupSuppliesRec || sameRecConflict
                          ? 'border-[#dc2626] bg-[#fef2f2] text-[#b91c1c]'
                          : 'border-[#fde68a] bg-[#fffbeb] text-[#b45309]'
                      }`}
                    />
                    {dupSuppliesRec && (
                      <span className="block mt-1 text-[10.5px] font-bold text-[#dc2626]">
                        مستخدم بالفعل في أذن {dupSuppliesRec.issueNo} — ممنوع التكرار
                      </span>
                    )}
                    {!dupSuppliesRec && sameRecConflict && (
                      <span className="block mt-1 text-[10.5px] font-bold text-[#dc2626]">
                        لا يصح تطابق رقم إيصال المستلزمات مع إيصال الهدية
                      </span>
                    )}
                  </label>
                  <label className="block text-xs font-bold text-[#5b21b6]">
                    <span>رقم إيصال الهدية بدون قيمة (2)</span>
                    <input
                      value={draft.giftReceiptNo ?? suggestedRecs.giftNo}
                      onChange={e => setDraft(prev => ({ ...prev, giftReceiptNo: e.target.value }))}
                      placeholder={suggestedRecs.giftNo}
                      className={`mt-1 w-full px-3 py-2 rounded-lg border font-mono-num font-bold text-xs ${
                        dupGiftRec || sameRecConflict
                          ? 'border-[#dc2626] bg-[#fef2f2] text-[#b91c1c]'
                          : 'border-[#ddd6fe] bg-[#f5f3ff] text-[#6d28d9]'
                      }`}
                    />
                    {dupGiftRec && (
                      <span className="block mt-1 text-[10.5px] font-bold text-[#dc2626]">
                        مستخدم بالفعل في أذن {dupGiftRec.issueNo} — ممنوع التكرار
                      </span>
                    )}
                    {!dupGiftRec && sameRecConflict && (
                      <span className="block mt-1 text-[10.5px] font-bold text-[#dc2626]">
                        لا يصح تطابق رقم إيصال الهدية مع إيصال المستلزمات
                      </span>
                    )}
                  </label>
                </>
              )}
            </div>
            <label className="mt-3 flex items-start gap-2.5 px-3 py-2.5 rounded-xl border border-[#dce6e3] bg-[#f8fbfa] text-xs cursor-pointer select-none">
              <input
                type="checkbox"
                checked={Boolean(draft.invoiced)}
                onChange={e => setDraft(prev => ({ ...prev, invoiced: e.target.checked }))}
                className="mt-0.5 accent-[#0f766e] w-4 h-4 cursor-pointer"
              />
              <span className="text-[#233d3a]">
                <strong className="font-extrabold text-[#102523]">تم عمل فاتورة مبيعات لهذا الأذن</strong>
                <span className="text-[11px] text-[#5c7471] mr-1.5">
                  (عند التعليم عليه يُغلق الأذن باعتبار أن الفاتورة اتعملت ولا يحتاج لعمل فاتورة مبيعات لاحقًا)
                </span>
              </span>
            </label>
            {selectedCustomer && (
              <div className="mt-3 px-3 py-2 rounded-lg bg-[#f4f9f8] border border-[#dce6e3] text-[11px] text-[#233d3a] flex flex-wrap items-center gap-x-4 gap-y-1">
                <span><b className="text-[#073b39]">كود العميل:</b> <span className="font-mono-num">{selectedCustomer.code || '—'}</span></span>
                <span><b className="text-[#073b39]">الهاتف:</b> {selectedCustomer.phone || '—'}</span>
                <span><b className="text-[#073b39]">العنوان:</b> {selectedCustomer.address || '—'}</span>
                <span><b className="text-[#073b39]">الرقم الضريبي:</b> <span className="font-mono-num">{selectedCustomer.taxNo || '—'}</span></span>
                {selectedCustomer.contact && <span><b className="text-[#073b39]">المسؤول:</b> {selectedCustomer.contact}</span>}
              </div>
            )}
          </section>

          <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
              <div>
                <h3 className="text-sm font-extrabold text-[#102523]">بنود أذن الصرف ({wh?.name})</h3>
                <p className="text-[11.5px] text-[#5c7471]">الصرف بأي وحدة ويُخصم تلقائيًا بنظام FEFO (الأقرب صلاحية أولًا)</p>
              </div>
              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  disabled={hasReturnsLock}
                  onClick={onOpenLinePicker}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] disabled:opacity-45 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة صنف</span>
                </button>
                <ExcelButton small onClick={exportDraftOrHistoryExcel} label="تصدير" />
                <button
                  type="button"
                  onClick={handleNewOrder}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#dce6e3] bg-white text-[#233d3a] text-xs font-bold hover:bg-[#f4f8f7] cursor-pointer"
                >
                  <FilePlus2 className="w-3.5 h-3.5 text-[#0f766e]" />
                  <span>{isEditing ? 'إلغاء التعديل' : 'أذن صرف جديد'}</span>
                </button>
              </div>
            </div>
            {!isSplitV2 && !hasReturnsLock && (
              <div className="px-4 py-3 bg-[#f8fbfa] border-b border-[#eaf1ef] space-y-2">
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-end">
                  <label className="sm:col-span-3 block text-[11px] font-bold text-[#233d3a]">
                    <span className="block mb-1 text-[#5c7471]">الشركة الموردة</span>
                    <select
                      value={catSupplierId}
                      onChange={e => {
                        setCatSupplierId(e.target.value);
                        setQuickProdId('');
                      }}
                      className="w-full px-2.5 py-1.5 rounded-lg border border-[#dce6e3] text-xs bg-white focus:outline-none focus:border-[#0f766e]"
                    >
                      <option value="all">كل الشركات ({fmtNum(warehouseAvailProducts.length)})</option>
                      {suppliers.map(s => (
                        <option key={s.id} value={s.id}>
                          {s.name} ({fmtNum(catSupplierCounts[s.id] || 0)})
                        </option>
                      ))}
                      {(catSupplierCounts.__none__ || 0) > 0 && (
                        <option value="__none__">بدون شركة ({fmtNum(catSupplierCounts.__none__)})</option>
                      )}
                    </select>
                  </label>
                  <label className="sm:col-span-3 block text-[11px] font-bold text-[#233d3a]">
                    <span className="block mb-1 text-[#5c7471]">المخزن (الرئيسي / الفرعي)</span>
                    <select
                      value={draft.warehouseId}
                      onChange={e => setDraft(prev => ({ ...prev, warehouseId: e.target.value }))}
                      className="w-full px-2.5 py-1.5 rounded-lg border border-[#dce6e3] text-xs bg-white focus:outline-none focus:border-[#0f766e]"
                    >
                      {db.warehouses.map(w => (
                        <option key={w.id} value={w.id}>
                          {w.name} — {w.gov}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="sm:col-span-3 block text-[11px] font-bold text-[#233d3a]">
                    <span className="block mb-1 text-[#5c7471]">
                      الصنف ({fmtNum(supplierScopedProducts.length)} متاح)
                    </span>
                    <select
                      value={activeQuickProd?.id || ''}
                      onChange={e => {
                        setQuickProdId(e.target.value);
                        setQuickUnitName('');
                      }}
                      className="w-full px-2.5 py-1.5 rounded-lg border border-[#dce6e3] text-xs bg-white focus:outline-none focus:border-[#0f766e]"
                    >
                      {supplierScopedProducts.length ? (
                        supplierScopedProducts.map(({ product: p, avail }) => (
                          <option key={p.id} value={p.id}>
                            {p.code} — {p.name} · متاح {unitsText(avail, p)}
                          </option>
                        ))
                      ) : (
                        <option value="">لا توجد أصناف متاحة لهذه الشركة بالمخزن</option>
                      )}
                    </select>
                  </label>
                  <div className="sm:col-span-3 flex items-end gap-1.5">
                    <label className="w-16 block text-[11px] font-bold text-[#233d3a]">
                      <span className="block mb-1 text-[#5c7471]">الكمية</span>
                      <input
                        type="number"
                        min={1}
                        value={quickQty}
                        onChange={e => setQuickQty(Math.max(1, Number(e.target.value) || 1))}
                        className="w-full px-2 py-1.5 rounded-lg border border-[#dce6e3] text-xs text-center font-bold tabular-nums bg-white"
                      />
                    </label>
                    <label className="flex-1 min-w-0 block text-[11px] font-bold text-[#233d3a]">
                      <span className="block mb-1 text-[#5c7471]">الوحدة</span>
                      <select
                        value={activeQuickUnit?.name || ''}
                        disabled={!activeQuickProd}
                        onChange={e => setQuickUnitName(e.target.value)}
                        className="w-full px-2 py-1.5 rounded-lg border border-[#dce6e3] text-xs bg-white disabled:bg-[#f4f8f7]"
                      >
                        {(activeQuickProd?.units || []).map(u => (
                          <option key={u.name} value={u.name}>
                            {u.name} ({u.factor})
                          </option>
                        ))}
                      </select>
                    </label>
                    <button
                      type="button"
                      disabled={!activeQuickProd}
                      onClick={handleInlineQuickAdd}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] disabled:opacity-45 whitespace-nowrap cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>أضف</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
            {draft.lines.length ? (
              <div className="overflow-x-auto">
                <table className="w-full text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                      <th className="py-2.5 px-3 text-right font-bold">الصنف</th>
                      <th className="py-2.5 px-3 text-center font-bold">بإيصال (بدون قيمة)</th>
                      <th className="py-2.5 px-3 text-right font-bold">الكمية</th>
                      <th className="py-2.5 px-3 text-left font-bold">السعر</th>
                      <th className="py-2.5 px-3 text-left font-bold">القيمة</th>
                      <th className="py-2.5 px-3"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#edf3f1]">
                    {sortedDraftLines.map(l => {
                      const p = getProduct(l.productId);
                      if (!p) return null;
                      const av = effectiveAvail(p.id);
                      const totalForProduct = draft.lines
                        .filter(x => x.productId === p.id)
                        .reduce((s, x) => s + x.strips, 0);
                      const over = totalForProduct > av;
                      const near = nearestExpiry(p.id, draft.warehouseId);
                      const receipt = isLineReceipt(l, p);
                      const lineReceiptType = getLineReceiptType(l, p);

                      const matchedUnit =
                        (l.units?.length === 1 && p.units.find(u => u.name === l.units[0].name && l.units[0].qty * u.factor === l.strips)) ||
                        [...p.units].reverse().find(u => u.factor > 0 && l.strips % u.factor === 0) ||
                        p.units[0];
                      const activeUnitFactor = matchedUnit?.factor || 1;
                      const activeUnitQty = Math.max(1, Math.round(l.strips / activeUnitFactor));

                      return (
                        <tr key={l.id} className={receipt ? 'bg-[#fffbeb]/45' : ''}>
                          <td className="py-2.5 px-3">
                            <div className="font-bold">{p.name}</div>
                            <div className="text-[11px] text-[#5c7471]">{p.code} · {p.form}</div>
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <div className="inline-flex flex-col items-center gap-1">
                              <label className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-[#dce6e3] bg-white cursor-pointer select-none">
                                <input
                                  type="checkbox"
                                  disabled={hasReturnsLock}
                                  checked={receipt}
                                  onChange={e => {
                                    const checked = e.target.checked;
                                    setDraft(prev => ({
                                      ...prev,
                                      lines: prev.lines.map(x =>
                                        x.id === l.id
                                          ? {
                                              ...x,
                                              asReceipt: checked,
                                              receiptType: checked ? (x.receiptType || (p.marked ? 'supplies' : 'gift')) : undefined
                                            }
                                          : x
                                      )
                                    }));
                                  }}
                                  className="accent-[#b45309] w-3.5 h-3.5 cursor-pointer"
                                />
                                <span className={`text-[11px] font-bold ${receipt ? 'text-[#b45309]' : 'text-[#0f766e]'}`}>
                                  {receipt ? 'بإيصال' : 'فاتورة'}
                                </span>
                              </label>
                              {receipt && (
                                <select
                                  disabled={hasReturnsLock}
                                  value={lineReceiptType}
                                  onChange={e => {
                                    const val = e.target.value as ReceiptType;
                                    setDraft(prev => ({
                                      ...prev,
                                      lines: prev.lines.map(x => (x.id === l.id ? { ...x, receiptType: val } : x))
                                    }));
                                  }}
                                  className="px-2 py-1 rounded-md border border-[#fde68a] bg-[#fffbeb] text-[10.5px] font-bold text-[#92400e] cursor-pointer"
                                >
                                  <option value="supplies">إيصال مستلزمات</option>
                                  <option value="gift">إيصال هدية بدون قيمة</option>
                                </select>
                              )}
                            </div>
                          </td>
                          <td className="py-2.5 px-3 tabular-nums">
                            {!hasReturnsLock ? (
                              <div className="flex items-center gap-1 mb-0.5">
                                <input
                                  type="number"
                                  min={1}
                                  value={activeUnitQty}
                                  onChange={e => {
                                    const nextQty = Math.max(1, Math.round(Number(e.target.value) || 1));
                                    const nextStrips = nextQty * activeUnitFactor;
                                    setDraft(prev => ({
                                      ...prev,
                                      lines: prev.lines.map(x =>
                                        x.id === l.id
                                          ? { ...x, strips: nextStrips, units: [{ name: matchedUnit.name, qty: nextQty }] }
                                          : x
                                      )
                                    }));
                                  }}
                                  className="w-16 px-1.5 py-1 rounded-md border border-[#dce6e3] text-xs text-center font-bold tabular-nums bg-white"
                                />
                                <select
                                  value={matchedUnit.name}
                                  onChange={e => {
                                    const uObj = p.units.find(u => u.name === e.target.value) || p.units[0];
                                    const nextStrips = activeUnitQty * uObj.factor;
                                    setDraft(prev => ({
                                      ...prev,
                                      lines: prev.lines.map(x =>
                                        x.id === l.id
                                          ? { ...x, strips: nextStrips, units: [{ name: uObj.name, qty: activeUnitQty }] }
                                          : x
                                      )
                                    }));
                                  }}
                                  className="px-1.5 py-1 rounded-md border border-[#dce6e3] text-[11px] bg-white"
                                >
                                  {p.units.map(u => (
                                    <option key={u.name} value={u.name}>
                                      {u.name}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            ) : (
                              <div className="font-bold">{unitsText(l.strips, p)}</div>
                            )}
                            <div className="text-[10.5px] text-[#3b5653] font-semibold">{unitsText(l.strips, p)}</div>
                            {over ? (
                              <div className="text-[11px] font-bold text-[#dc2626]">يتجاوز المتاح ({unitsText(av, p)})</div>
                            ) : (
                              near && <div className="text-[10.5px] text-[#5c7471]">صلاحية {fmtDate(near)}</div>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-left tabular-nums">{receipt ? '—' : `${fmtMoney(p.price)} ج.م`}</td>
                          <td className="py-2.5 px-3 text-left font-bold tabular-nums">
                            {receipt ? <span className="text-[#b45309] font-normal">لا تدخل الفاتورة</span> : `${fmtMoney(l.strips * p.price)} ج.م`}
                          </td>
                          <td className="py-2.5 px-3 text-left">
                            <button
                              type="button"
                              disabled={hasReturnsLock}
                              onClick={() => setDraft(prev => ({ ...prev, lines: prev.lines.filter(x => x.id !== l.id) }))}
                              className="p-1.5 rounded-md border border-[#fecaca] text-[#dc2626] hover:bg-[#fef2f2] disabled:opacity-35 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <EmptyState
                icon={<FileText className="w-6 h-6" />}
                title="أضف بنود أذن الصرف"
                description="اختر الأصناف والكميات لتكوين الأذن وترحيله."
                action={
                  <button type="button" onClick={onOpenLinePicker} className="px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold cursor-pointer">
                    إضافة صنف
                  </button>
                }
              />
            )}
          </section>
          {isSplitV2 && (
            <section className="bg-white border border-[#dce6e3] rounded-xl p-3.5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="font-extrabold text-[#102523]">
                  ملخص الأذن ({billableLines.length} فاتورة · {suppliesLines.length} إيصال · {fmtNum(totalStrips)} وحدة)
                </span>
                <span className="font-mono-num font-bold text-[#0f766e]">{displayNo}</span>
              </div>
              {invTotal > 0 && (
                <div className="rounded-lg bg-[#eef8f6] border border-[#b7dfd7] px-3 py-2 text-xs flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="text-[#5c7471]">أساسي: <b>{fmtMoney(invTotal)}</b> + 14%: <b>{fmtMoney(calc14Percent(invTotal))}</b></span>
                  </div>
                  <div className="font-extrabold text-[#0f766e] tabular-nums">
                    الإجمالي: {fmtMoney(calcTotalWith14(invTotal))} ج.م
                  </div>
                </div>
              )}
              <label className="flex items-start gap-2 p-2.5 rounded-xl border border-[#dce6e3] bg-[#f8fbfa] text-xs cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={Boolean(draft.invoiced)}
                  onChange={e => setDraft(prev => ({ ...prev, invoiced: e.target.checked }))}
                  className="mt-0.5 accent-[#0f766e] w-4 h-4 cursor-pointer"
                />
                <span className="text-[#233d3a]">
                  <strong className="font-bold">تم عمل فاتورة (يُغلق الأذن ولا يحتاج لعمل فاتورة مبيعات)</strong>
                </span>
              </label>
              <button
                type="button"
                disabled={!draft.lines.length || hasDocNumberConflict}
                onClick={handleSave}
                className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0f766e] text-white text-xs font-extrabold hover:bg-[#0d655e] disabled:opacity-45 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{isEditing ? 'حفظ تعديلات أذن الصرف' : 'حفظ وترحيل أذن الصرف'}</span>
              </button>
            </section>
          )}
        </div>

        {!isSplitV2 && (
          <aside className="lg:col-span-4 lg:sticky lg:top-20">
          <section className="bg-white border border-[#dce6e3] rounded-xl p-4 space-y-4">
            <h3 className="text-sm font-extrabold text-[#102523]">ملخص الأذن</h3>
            <div className="border border-[#dce6e3] rounded-xl divide-y divide-[#edf3f1] text-xs">
              <div className="flex justify-between px-3 py-2.5">
                <span className="text-[#5c7471]">رقم أذن الصرف</span>
                <span className="font-mono-num font-bold text-[#0f766e]">{displayNo}</span>
              </div>
              {suppliesOnlyLines.length > 0 && (
                <div className="flex justify-between px-3 py-2.5 bg-[#fffbeb]/55">
                  <span className="text-[#92400e]">إيصال مستلزمات ({suppliesOnlyLines.length} بند)</span>
                  <span className="font-mono-num font-bold text-[#b45309]">{effSuppliesRecNo}</span>
                </div>
              )}
              {giftOnlyLines.length > 0 && (
                <div className="flex justify-between px-3 py-2.5 bg-[#f5f3ff]/70">
                  <span className="text-[#5b21b6]">إيصال هدية بدون قيمة ({giftOnlyLines.length} بند)</span>
                  <span className="font-mono-num font-bold text-[#6d28d9]">{effGiftRecNo}</span>
                </div>
              )}
              <div className="flex justify-between px-3 py-2.5">
                <span className="text-[#5c7471]">بنود الفاتورة</span>
                <span className="font-bold tabular-nums">{billableLines.length} بند</span>
              </div>
              <div className="flex justify-between px-3 py-2.5">
                <span className="text-[#5c7471]">بنود الإيصال / المستلزمات</span>
                <span className="font-bold text-[#b45309] tabular-nums">{suppliesLines.length} بند</span>
              </div>
              <div className="flex justify-between px-3 py-2.5">
                <span className="text-[#5c7471]">إجمالي الوحدات</span>
                <span className="font-bold tabular-nums">{fmtNum(totalStrips)} ({fmtNum(suppliesStrips)} بإيصال)</span>
              </div>
              <div className="flex justify-between px-3 py-3 bg-[#f4f9f8]">
                <span className="font-extrabold text-[#102523]">القيمة الأساسية للفاتورة</span>
                <span className="text-sm font-extrabold text-[#102523] tabular-nums">{fmtMoney(invTotal)} ج.م</span>
              </div>
              {invTotal > 0 && (
                <>
                  <div className="flex justify-between px-3 py-2.5 bg-white">
                    <span className="font-bold text-[#073b39]">قيمة 14%</span>
                    <span className="font-extrabold text-[#0f766e] tabular-nums">{fmtMoney(calc14Percent(invTotal))} ج.م</span>
                  </div>
                  <div className="px-3 py-3 bg-[#eef8f6] space-y-1.5">
                    <div className="flex justify-between items-center">
                      <span className="font-extrabold text-[#073b39]">المبلغ الإجمالي (شامل 14%)</span>
                      <span className="text-base font-extrabold text-[#0f766e] tabular-nums">{fmtMoney(calcTotalWith14(invTotal))} ج.م</span>
                    </div>
                    <div className="text-[11px] font-extrabold text-[#14532d] leading-relaxed">
                      {tafqeetEGP(calcTotalWith14(invTotal))}
                    </div>
                  </div>
                </>
              )}
            </div>

            <div className="bg-[#fffbeb] border border-[#fde68a] rounded-xl p-3 text-[11px] text-[#92400e] leading-relaxed">
              علّم على <b>«بإيصال (بدون قيمة)»</b> لأي بند لا يدخل الفاتورة، وإذا احتوى الأذن على <b>مستلزمات وهدية بدون قيمة معًا</b> يصدر لكل منهما <b>إيصال منفصل على حدة</b> في Word والطباعة.
            </div>

            <label className="flex items-start gap-2 p-3 rounded-xl border border-[#dce6e3] bg-[#f8fbfa] text-xs cursor-pointer select-none">
              <input
                type="checkbox"
                checked={Boolean(draft.invoiced)}
                onChange={e => setDraft(prev => ({ ...prev, invoiced: e.target.checked }))}
                className="mt-0.5 accent-[#0f766e] w-4 h-4 cursor-pointer"
              />
              <span className="text-[#233d3a]">
                <strong className="block font-bold text-[#102523]">تم عمل فاتورة مبيعات</strong>
                <span className="text-[10.5px] text-[#5c7471]">
                  {draft.invoiced
                    ? 'الأذن سيُغلق ولا يحتاج لعمل فاتورة مبيعات لاحقًا.'
                    : 'اتركه بدون تعليم ليظهر الأذن في قائمة عمل الفواتير لاحقًا.'}
                </span>
              </span>
            </label>

            <button
              type="button"
              disabled={!draft.lines.length || hasDocNumberConflict}
              onClick={handleSave}
              className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0f766e] text-white text-xs font-extrabold hover:bg-[#0d655e] disabled:opacity-45 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>{isEditing ? 'حفظ تعديلات أذن الصرف' : 'حفظ وترحيل أذن الصرف'}</span>
            </button>
          </section>
        </aside>
        )}
      </div>

      {/* History */}
      <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
        <div className="flex items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
          <div>
            <h3 className="text-sm font-extrabold text-[#102523]">سجل أذون الصرف السابقة ({db.issues.length})</h3>
            <p className="text-[11.5px] text-[#5c7471]">افتح أي أذن في Word للطباعة أو سجّل مرتجع عميل منه</p>
          </div>
          <ExcelButton small onClick={exportHistoryExcel} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                <th className="py-2.5 px-3 text-right font-bold">رقم الأذن</th>
                <th className="py-2.5 px-3 text-right font-bold">الفاتورة / العميل</th>
                <th className="py-2.5 px-3 text-right font-bold">المخزن</th>
                <th className="py-2.5 px-3 text-left font-bold">القيمة</th>
                <th className="py-2.5 px-3 text-center font-bold">المرتجع / الحالة</th>
                <th className="py-2.5 px-3 text-left font-bold">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#edf3f1]">
              {sortedIssuesHistory.map(i => {
                const w = getWarehouse(i.warehouseId);
                const val = calcIssueValue(i, db.products);
                const rs = issueReturnStats(i);
                const hasBillable = i.lines.some(l => !isLineReceipt(l, getProduct(l.productId)));
                const receiptGroups = getIssueReceipts(i, db.products);
                const mixed = hasBillable && receiptGroups.length > 0;
                const custPartner =
                  getPartner(i.customerId) ||
                  db.partners.find(p => p.type === 'customer' && p.name === i.customer);
                return (
                  <tr key={i.id} className="hover:bg-[#f9fcfb]">
                    <td className="py-2.5 px-3">
                      <div className="font-mono-num font-bold text-[#0f766e]">{i.no}</div>
                      {receiptGroups.map(g => (
                        <div
                          key={g.type}
                          className={`text-[10.5px] font-bold font-mono-num ${g.type === 'gift' ? 'text-[#6d28d9]' : 'text-[#b45309]'}`}
                        >
                          {g.receiptNo} · {g.label}
                        </div>
                      ))}
                      <div className="text-[11px] text-[#5c7471]">{fmtDate(i.date)}</div>
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="font-bold text-[#102523]">{i.customer}</div>
                      <div className="text-[11px] text-[#5c7471]">فاتورة {i.invoiceNo || '—'}</div>
                    </td>
                    <td className="py-2.5 px-3 text-[#3b5653]">{w?.name || '—'}</td>
                    <td className="py-2.5 px-3 text-left tabular-nums">
                      <div className="font-bold">{fmtMoney(val)} ج.م</div>
                      {rs.returnedVal > 0 && (
                        <div className="text-[10.5px] font-bold text-[#dc2626]">
                          صافي: {fmtMoney(Math.max(0, val - rs.returnedVal))} ج.م
                        </div>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <div className="inline-flex flex-col items-center gap-1">
                        <label
                          className={`inline-flex items-center gap-1 text-[10.5px] font-bold select-none ${
                            i.invoicedByFlow ? 'cursor-default text-[#0f766e]' : 'cursor-pointer text-[#233d3a]'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={Boolean(i.invoiced)}
                            disabled={Boolean(i.invoicedByFlow)}
                            onChange={async e => {
                              const chk = e.target.checked;
                              try {
                                await setIssueInvoiced(i.id, chk);
                                toast(
                                  chk
                                    ? `تم التعليم على ${i.no}: تم عمل فاتورة وإغلاقه`
                                    : `تم إعادة فتح أذن الصرف ${i.no}`
                                );
                              } catch (err) {
                                toast(err instanceof Error ? err.message : 'تعذر تحديث الحالة', 'err');
                              }
                            }}
                            className="accent-[#0f766e] w-3.5 h-3.5 cursor-pointer disabled:cursor-not-allowed"
                          />
                          <span>{i.invoiced ? 'تم عمل فاتورة (مغلق)' : 'بانتظار فاتورة'}</span>
                        </label>
                        {rs.status === 'full' ? (
                          <span className="text-[10.5px] font-bold text-[#dc2626]">مرتجع كلي</span>
                        ) : rs.status === 'partial' ? (
                          <span className="text-[10.5px] font-bold text-[#6d28d9]">مرتجع جزئي ({fmtNum(rs.totalReturned)})</span>
                        ) : null}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-left">
                      <div className="inline-flex flex-wrap items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              await exportIssueToWord(i, db.company, w, db.products, { mode: 'all', customer: custPartner });
                              toast(`تم تحميل أذن الصرف ${i.no} بالكامل بصيغة Word (.docx)`);
                            } catch {
                              toast('تعذر إنشاء ملف Word', 'err');
                            }
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#bfdbfe] bg-[#eff6ff] text-[#1d4ed8] hover:bg-[#dbeafe] text-[11px] font-bold cursor-pointer"
                          title="تحميل أذن الصرف بالكامل (فاتورة + هدية + مستلزمات) في Word للطباعة"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>Word</span>
                        </button>
                        {receiptGroups.map(g => (
                          <button
                            key={g.type}
                            type="button"
                            onClick={async () => {
                              try {
                                await exportIssueReceiptToWord(i, db.company, w, db.products, { receiptType: g.type, customer: custPartner });
                                toast(`تم تحميل ${g.label} (${g.receiptNo}) بصيغة Word (.docx)`);
                              } catch {
                                toast('تعذر إنشاء ملف الإيصال', 'err');
                              }
                            }}
                            className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border text-[11px] font-bold cursor-pointer ${
                              g.type === 'gift'
                                ? 'border-[#ddd6fe] bg-[#f5f3ff] text-[#6d28d9] hover:bg-[#ede9fe]'
                                : 'border-[#fde68a] bg-[#fffbeb] text-[#b45309] hover:bg-[#fef3c7]'
                            }`}
                            title={`تحميل ${g.label} منفصل في Word`}
                          >
                            <FileText className="w-3.5 h-3.5" />
                            <span>{receiptGroups.length > 1 ? (g.type === 'gift' ? 'إيصال هدية' : 'إيصال مستلزمات') : 'إيصال'}</span>
                          </button>
                        ))}
                        {!i.closed && !i.invoiced && hasBillable && onCreateSalesInvoice && (
                          <button
                            type="button"
                            onClick={() => onCreateSalesInvoice(i.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#b7dfd7] bg-[#eef8f6] text-[#0f766e] hover:bg-[#dff2ee] text-[11px] font-extrabold cursor-pointer"
                            title="عمل فاتورة مبيعات لهذا الأذن"
                          >
                            <Receipt className="w-3.5 h-3.5" />
                            <span>عمل فاتورة</span>
                          </button>
                        )}
                        {!i.closed ? (
                          <button
                            type="button"
                            onClick={() => onEditIssue(i)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#fde68a] bg-[#fffbeb] text-[#92400e] hover:bg-[#fef3c7] text-[11px] font-bold cursor-pointer"
                            title="تعديل أذن الصرف"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                            <span>تعديل</span>
                          </button>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-1.5 rounded-md border border-[#dce6e3] bg-[#f8fbfa] text-[#5c7471] text-[10.5px] font-bold">
                            <Lock className="w-3 h-3" />
                            <span>مغلق</span>
                          </span>
                        )}
                        <button
                          type="button"
                          onClick={() => onStartReturn(i.id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#ddd6fe] bg-[#f5f3ff] text-[#6d28d9] hover:bg-[#ede9fe] text-[11px] font-bold cursor-pointer"
                          title="عمل مرتجع عميل"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>مرتجع</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onViewIssue(i)}
                          className="p-1.5 rounded-md border border-[#dce6e3] text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
                          title="عرض التفاصيل"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
