import React from 'react';
import { AlertTriangle, Banknote, Box, FileSpreadsheet, FileText, Lock, Pencil, Plus, Receipt, RotateCcw, Upload } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { IssueOrder, PageId } from '../types/pharma';
import { calcIssueValue, expiryState, fmtDate, fmtMoney, fmtNum, getIssueReceipts, isLineReceipt, monthISO, sortIssuesByInvoiceStatus, todayISO, unitsText } from '../utils/format';
import { exportIssueReceiptToWord, exportIssueToWord, exportToExcel } from '../utils/export';
import { EmptyState, ExcelButton, ExpiryTag, KpiCard, MOVE_LABELS, PageHeader } from '../components/ui/CommonUI';

export function DashboardPage({
  onNavigate,
  onOpenWarehouse,
  onViewIssue,
  onEditIssue
}: {
  onNavigate: (page: PageId) => void;
  onOpenWarehouse: (warehouseId: string) => void;
  onViewIssue: (issue: IssueOrder) => void;
  onEditIssue: (issue: IssueOrder) => void;
}) {
  const { db, getProduct, getWarehouse, toast } = usePharmaStore();
  const today = todayISO();
  const curMonth = monthISO();

  const activeBatches = db.batches.filter(b => b.strips > 0 && b.expiry >= today);
  const stockValue = activeBatches.reduce((s, b) => {
    const p = getProduct(b.productId);
    return s + (p ? b.strips * (p.price || 0) : 0);
  }, 0);
  const totalUnits = activeBatches.reduce((s, b) => s + b.strips, 0);
  const soonBatches = db.batches.filter(b => b.strips > 0 && expiryState(b.expiry) === 'soon');
  const expiredBatches = db.batches.filter(b => b.strips > 0 && expiryState(b.expiry) === 'expired');
  const soonProducts = new Set(soonBatches.map(b => b.productId)).size;
  const monthIssues = db.issues.filter(i => (i.date || '').slice(0, 7) === curMonth);
  const monthIssueValue = monthIssues.reduce((s, i) => s + calcIssueValue(i, db.products), 0);
  const medsCount = db.products.filter(p => !p.marked).length;
  const suppliesCount = db.products.filter(p => p.marked).length;

  const nearList = db.batches
    .filter(b => b.strips > 0 && expiryState(b.expiry) !== 'ok')
    .sort((a, b) => a.expiry.localeCompare(b.expiry))
    .slice(0, 7);

  const maxWhVal = Math.max(
    ...db.warehouses.map(w =>
      activeBatches
        .filter(b => b.warehouseId === w.id)
        .reduce((s, b) => s + b.strips * (getProduct(b.productId)?.price || 0), 0)
    ),
    1
  );

  const exportWarehousesExcel = () => {
    const headers = ['المخزن', 'المحافظة', 'النصيب %', 'الأصناف المتوفرة', 'الوحدات السارية', 'القيمة (ج.م)'];
    const rows = db.warehouses.map(w => {
      const bs = activeBatches.filter(b => b.warehouseId === w.id);
      const val = bs.reduce((s, b) => s + b.strips * (getProduct(b.productId)?.price || 0), 0);
      const strips = bs.reduce((s, b) => s + b.strips, 0);
      return [w.name, w.gov, w.share, new Set(bs.map(b => b.productId)).size, strips, Number(val.toFixed(2))];
    });
    exportToExcel(`أرصدة_المخازن_${today}.xlsx`, 'أرصدة المخازن', headers, rows);
    toast('تم تصدير أرصدة المخازن إلى Excel');
  };

  const exportNearExcel = () => {
    const allNear = db.batches
      .filter(b => b.strips > 0 && expiryState(b.expiry) !== 'ok')
      .sort((a, b) => a.expiry.localeCompare(b.expiry));
    const headers = ['الكود', 'الصنف', 'المخزن', 'التشغيلة', 'تاريخ الصلاحية', 'الكمية بالوحدات', 'الوحدات الأساسية', 'الحالة'];
    const rows = allNear.map(b => {
      const p = getProduct(b.productId);
      const w = getWarehouse(b.warehouseId);
      const st = expiryState(b.expiry);
      return [
        p?.code || '',
        p?.name || '',
        w?.name || '',
        b.batch,
        fmtDate(b.expiry),
        unitsText(b.strips, p),
        b.strips,
        st === 'expired' ? 'منتهي الصلاحية' : 'قارب الانتهاء'
      ];
    });
    exportToExcel(`تنبيهات_الصلاحية_${today}.xlsx`, 'تنبيهات الصلاحية', headers, rows);
    toast('تم تصدير تنبيهات الصلاحية إلى Excel');
  };

  const exportMovesExcel = () => {
    const headers = ['التاريخ', 'النوع', 'المرجع', 'الصنف', 'المخزن', 'الوحدات', 'ملاحظة'];
    const rows = db.movements.map(m => {
      const p = getProduct(m.productId);
      const w = getWarehouse(m.warehouseId);
      return [fmtDate(m.date), MOVE_LABELS[m.type]?.label || m.type, m.ref, p?.name || '', w?.name || '', m.strips, m.note];
    });
    exportToExcel(`سجل_الحركات_${today}.xlsx`, 'الحركات', headers, rows);
    toast('تم تصدير سجل الحركات إلى Excel');
  };

  const exportIssuesExcel = () => {
    const headers = ['رقم الأذن', 'التاريخ', 'العميل', 'رقم الفاتورة', 'المخزن', 'القيمة (ج.م)', 'وحدات المستلزمات'];
    const rows = db.issues.map(i => [
      i.no,
      fmtDate(i.date),
      i.customer,
      i.invoiceNo,
      getWarehouse(i.warehouseId)?.name || '',
      Number(calcIssueValue(i, db.products).toFixed(2)),
      i.suppliesStrips || 0
    ]);
    exportToExcel(`أذون_الصرف_${today}.xlsx`, 'أذون الصرف', headers, rows);
    toast('تم تصدير أذون الصرف إلى Excel');
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="لوحة التحكم"
        subtitle="نظرة شاملة على أرصدة المخازن، الصلاحيات القريبة، وأحدث حركات الصرف والمرتجعات"
        actions={
          <>
            <button
              type="button"
              onClick={() => onNavigate('incoming')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>رفع فاتورة وارد</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('returns')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#ddd6fe] bg-[#f5f3ff] text-xs font-bold text-[#6d28d9] hover:bg-[#ede9fe] cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>مرتجع عميل</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('issue')}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold hover:bg-[#0d655e] cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>أذن صرف جديد</span>
            </button>
          </>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3.5">
        <KpiCard
          label="إجمالي الأصناف"
          value={fmtNum(db.products.length)}
          unit="صنف"
          hint={`${medsCount} دواء · ${suppliesCount} مستلزمات`}
          icon={<Box className="w-4 h-4" />}
          tone="teal"
        />
        <KpiCard
          label="قيمة المخزون الساري"
          value={fmtMoney(stockValue)}
          unit="ج.م"
          hint={`${fmtNum(totalUnits)} وحدة صالحة في ${db.warehouses.length} مخازن`}
          icon={<Banknote className="w-4 h-4" />}
          tone="blue"
        />
        <KpiCard
          label="صلاحيات قريبة من الانتهاء"
          value={fmtNum(soonBatches.length)}
          unit="دفعة"
          hint={`${soonProducts} صنف متأثر · ${expiredBatches.length} دفعة منتهية`}
          icon={<AlertTriangle className="w-4 h-4" />}
          tone="amber"
        />
        <KpiCard
          label="أذون صرف هذا الشهر"
          value={fmtNum(monthIssues.length)}
          unit="أذن"
          hint={`بقيمة ${fmtMoney(monthIssueValue)} ج.م · ${db.returns.length} مرتجع`}
          icon={<Receipt className="w-4 h-4" />}
          tone="violet"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Warehouses interactive receiving opener */}
        <section className="lg:col-span-7 bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
            <div>
              <h3 className="text-sm font-extrabold text-[#102523]">أرصدة المخازن</h3>
              <p className="text-[11.5px] text-[#5c7471]">اضغط على أي مخزن لفتح رصيده ككشف استلام</p>
            </div>
            <div className="flex items-center gap-2">
              <ExcelButton small onClick={exportWarehousesExcel} label="إكسل" />
              <button
                type="button"
                onClick={() => onNavigate('warehouses')}
                className="px-2.5 py-1.5 rounded-lg border border-[#dce6e3] text-[11px] font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
              >
                إدارة المخازن
              </button>
            </div>
          </div>
          <div className="p-3.5 space-y-2">
            {db.warehouses.map(w => {
              const bs = activeBatches.filter(b => b.warehouseId === w.id);
              const val = bs.reduce((s, b) => s + b.strips * (getProduct(b.productId)?.price || 0), 0);
              const strips = bs.reduce((s, b) => s + b.strips, 0);
              const prods = new Set(bs.map(b => b.productId)).size;
              const soon = new Set(bs.filter(b => expiryState(b.expiry) === 'soon').map(b => b.productId)).size;
              const pct = Math.max(5, Math.round((val / maxWhVal) * 100));
              return (
                <button
                  key={w.id}
                  type="button"
                  onClick={() => onOpenWarehouse(w.id)}
                  className="w-full text-right grid grid-cols-[auto_1fr_auto] gap-3 items-center p-3 rounded-xl border border-[#e6efec] bg-white hover:bg-[#f4fbf9] hover:border-[#0f766e] transition-colors cursor-pointer group"
                >
                  <div
                    className="w-10 h-10 rounded-xl grid place-items-center text-white text-xs font-extrabold shrink-0"
                    style={{ backgroundColor: w.color }}
                  >
                    {w.id.toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-extrabold text-xs text-[#102523] group-hover:text-[#0f766e]">{w.name}</span>
                      <span className="text-[11px] text-[#5c7471]">{w.gov} · نصيب {w.share}%</span>
                      <span className="text-[11px] font-bold text-[#0f766e] opacity-85 group-hover:opacity-100">فتح كاستلام ↗</span>
                    </div>
                    <div className="text-[11px] text-[#5c7471] mt-0.5 tabular-nums">
                      {fmtNum(prods)} صنف {soon > 0 ? `· ${soon} صلاحية قريبة` : ''}
                    </div>
                    <div className="h-1.5 bg-[#ecf3f1] rounded-full mt-2 overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${pct}%`, backgroundColor: w.color }} />
                    </div>
                  </div>
                  <div className="text-left tabular-nums">
                    <div className="text-xs font-extrabold text-[#102523]">{fmtMoney(val)} ج.م</div>
                    <div className="text-[10.5px] text-[#5c7471]">{fmtNum(strips)} وحدة</div>
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* Expiry alerts */}
        <section className="lg:col-span-5 bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
          <div className="flex items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
            <div>
              <h3 className="text-sm font-extrabold text-[#102523]">تنبيهات الصلاحية</h3>
              <p className="text-[11.5px] text-[#5c7471]">دفعات قاربت على الانتهاء أو منتهية</p>
            </div>
            <ExcelButton small onClick={exportNearExcel} label="إكسل" />
          </div>
          <div className="overflow-x-auto">
            {nearList.length ? (
              <table className="w-full text-xs border-collapse">
                <thead>
                  <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                    <th className="py-2 px-3 text-right font-bold">الصنف</th>
                    <th className="py-2 px-3 text-right font-bold">المخزن</th>
                    <th className="py-2 px-3 text-center font-bold">الصلاحية</th>
                    <th className="py-2 px-3 text-left font-bold">الكمية</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#edf3f1]">
                  {nearList.map(b => {
                    const p = getProduct(b.productId);
                    const w = getWarehouse(b.warehouseId);
                    if (!p || !w) return null;
                    return (
                      <tr key={b.id} className="hover:bg-[#f9fcfb]">
                        <td className="py-2 px-3">
                          <div className="font-bold text-[#102523]">{p.name}</div>
                          <div className="text-[10.5px] text-[#5c7471]">{b.batch}</div>
                        </td>
                        <td className="py-2 px-3 text-[#3b5653]">{w.name}</td>
                        <td className="py-2 px-3 text-center"><ExpiryTag date={b.expiry} /></td>
                        <td className="py-2 px-3 text-left font-bold tabular-nums">{unitsText(b.strips, p)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            ) : (
              <EmptyState icon={<AlertTriangle className="w-5 h-5" />} title="لا توجد تنبيهات" description="كل الصلاحيات سليمة حاليًا." />
            )}
          </div>
        </section>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Recent movements */}
        <section className="lg:col-span-6 bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
          <div className="flex items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
            <div>
              <h3 className="text-sm font-extrabold text-[#102523]">أحدث الحركات</h3>
              <p className="text-[11.5px] text-[#5c7471]">آخر عمليات الوارد والصرف والمرتجع والتحويل</p>
            </div>
            <div className="flex items-center gap-2">
              <ExcelButton small onClick={exportMovesExcel} label="إكسل" />
              <button
                type="button"
                onClick={() => onNavigate('movements')}
                className="px-2.5 py-1.5 rounded-lg border border-[#dce6e3] text-[11px] font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
              >
                السجل الكامل
              </button>
            </div>
          </div>
          <div className="divide-y divide-[#edf3f1]">
            {db.movements.slice(0, 7).map(m => {
              const p = getProduct(m.productId);
              const w = getWarehouse(m.warehouseId);
              const meta = MOVE_LABELS[m.type];
              return (
                <div key={m.id} className="flex items-center justify-between gap-3 px-4 py-2.5 text-xs">
                  <div className="min-w-0">
                    <div className="font-bold text-[#102523] truncate">{p?.name || 'صنف محذوف'}</div>
                    <div className="text-[11px] text-[#5c7471]">
                      <span className={`inline-block px-1.5 py-0.5 rounded border text-[10px] font-bold ml-1.5 ${meta.cls}`}>{meta.label}</span>
                      {w?.name || '—'} · {fmtDate(m.date)} · {m.ref}
                    </div>
                  </div>
                  <div className="font-bold tabular-nums text-[#102523] shrink-0">
                    {p ? unitsText(m.strips, p) : fmtNum(m.strips)}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Recent issues */}
        <section className="lg:col-span-6 bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
          <div className="flex items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
            <div>
              <h3 className="text-sm font-extrabold text-[#102523]">آخر أذون الصرف</h3>
              <p className="text-[11.5px] text-[#5c7471]">أذون الصرف المتسلسلة الجاهزة للفتح في Word</p>
            </div>
            <div className="flex items-center gap-2">
              <ExcelButton small onClick={exportIssuesExcel} label="إكسل" />
              <button
                type="button"
                onClick={() => onNavigate('issue')}
                className="px-2.5 py-1.5 rounded-lg border border-[#dce6e3] text-[11px] font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
              >
                عرض الكل
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            {db.issues.length ? (
              <table className="w-full text-xs border-collapse">
                <thead>
                  <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                    <th className="py-2 px-3 text-right font-bold">رقم الأذن</th>
                    <th className="py-2 px-3 text-right font-bold">العميل</th>
                    <th className="py-2 px-3 text-right font-bold">المخزن</th>
                    <th className="py-2 px-3 text-left font-bold">القيمة</th>
                    <th className="py-2 px-3 text-left font-bold">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#edf3f1]">
                  {sortIssuesByInvoiceStatus(db.issues).slice(0, 6).map(i => {
                    const w = getWarehouse(i.warehouseId);
                    const hasBillable = i.lines.some(l => !isLineReceipt(l, getProduct(l.productId)));
                    const receiptGroups = getIssueReceipts(i, db.products);
                    const mixed = hasBillable && receiptGroups.length > 0;
                    return (
                      <tr key={i.id} className="hover:bg-[#f9fcfb]">
                        <td className="py-2.5 px-3">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono-num font-bold text-[#0f766e]">{i.no}</span>
                            {i.closed ? (
                              <span className="inline-flex items-center gap-0.5 text-[9.5px] font-bold px-1.5 py-0.5 rounded bg-[#eef8f6] text-[#0f766e]">
                                <Lock className="w-2.5 h-2.5" />
                                مغلق
                              </span>
                            ) : (
                              <span className="text-[9.5px] font-bold px-1.5 py-0.5 rounded bg-[#fffbeb] text-[#92400e]">
                                مفتوح
                              </span>
                            )}
                          </div>
                          <div className="text-[10.5px] text-[#5c7471]">
                            {i.invoicedByFlow || (i.invoiceNo && i.invoiceNo !== '—' && i.invoiceNo !== '-')
                              ? `فاتورة ${i.invoiceNo}`
                              : i.invoiced
                                ? 'تم عمل فاتورة (لا يحتاج فاتورة مبيعات)'
                                : 'بانتظار عمل فاتورة'}
                          </div>
                          {receiptGroups.map(g => (
                            <div
                              key={g.type}
                              className={`text-[10px] font-bold font-mono-num ${g.type === 'gift' ? 'text-[#6d28d9]' : 'text-[#b45309]'}`}
                            >
                              {g.receiptNo} · {g.label}
                            </div>
                          ))}
                        </td>
                        <td className="py-2.5 px-3 font-semibold text-[#102523]">{i.customer}</td>
                        <td className="py-2.5 px-3 text-[#3b5653]">{w?.name || '—'}</td>
                        <td className="py-2.5 px-3 text-left font-bold tabular-nums">{fmtMoney(calcIssueValue(i, db.products))} ج.م</td>
                        <td className="py-2.5 px-3 text-left">
                          <div className="inline-flex flex-wrap items-center justify-end gap-1">
                            <button
                              type="button"
                              onClick={async () => {
                                const custPartner =
                                  db.partners.find(p => p.id === i.customerId) ||
                                  db.partners.find(p => p.type === 'customer' && p.name === i.customer);
                                try {
                                  await exportIssueToWord(i, db.company, w, db.products, { mode: 'all', customer: custPartner });
                                  toast(`تم تحميل أذن الصرف ${i.no} بالكامل بصيغة Word (.docx)`);
                                } catch {
                                  toast('تعذر إنشاء ملف Word', 'err');
                                }
                              }}
                              title="تحميل أذن الصرف بالكامل (فاتورة + هدية + مستلزمات) في Word للطباعة"
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-md border border-[#bfdbfe] bg-[#eff6ff] text-[#1d4ed8] hover:bg-[#dbeafe] text-[10.5px] font-bold cursor-pointer"
                            >
                              <FileText className="w-3 h-3" />
                              <span>Word</span>
                            </button>
                            {receiptGroups.map(g => (
                              <button
                                key={g.type}
                                type="button"
                                onClick={async () => {
                                  const custPartner =
                                    db.partners.find(p => p.id === i.customerId) ||
                                    db.partners.find(p => p.type === 'customer' && p.name === i.customer);
                                  try {
                                    await exportIssueReceiptToWord(i, db.company, w, db.products, { receiptType: g.type, customer: custPartner });
                                    toast(`تم تحميل ${g.label} (${g.receiptNo}) بصيغة Word (.docx)`);
                                  } catch {
                                    toast('تعذر إنشاء ملف الإيصال', 'err');
                                  }
                                }}
                                title={`تحميل ${g.label} منفصل`}
                                className={`inline-flex items-center gap-1 px-2 py-1 rounded-md border text-[10.5px] font-bold cursor-pointer ${
                                  g.type === 'gift'
                                    ? 'border-[#ddd6fe] bg-[#f5f3ff] text-[#6d28d9] hover:bg-[#ede9fe]'
                                    : 'border-[#fde68a] bg-[#fffbeb] text-[#b45309] hover:bg-[#fef3c7]'
                                }`}
                              >
                                <FileText className="w-3 h-3" />
                                <span>{receiptGroups.length > 1 ? (g.type === 'gift' ? 'هدية' : 'مستلزمات') : 'إيصال'}</span>
                              </button>
                            ))}
                            {!i.closed && (
                              <button
                                type="button"
                                onClick={() => onEditIssue(i)}
                                title="تعديل أذن الصرف"
                                className="inline-flex items-center gap-1 px-2 py-1 rounded-md border border-[#fde68a] bg-[#fffbeb] text-[#92400e] hover:bg-[#fef3c7] text-[10.5px] font-bold cursor-pointer"
                              >
                                <Pencil className="w-3 h-3" />
                                <span>تعديل</span>
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => onViewIssue(i)}
                              className="px-2 py-1 rounded-md border border-[#dce6e3] text-[10.5px] font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
                            >
                              عرض
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            ) : (
              <EmptyState icon={<FileSpreadsheet className="w-5 h-5" />} title="لا توجد أذون صرف" />
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
