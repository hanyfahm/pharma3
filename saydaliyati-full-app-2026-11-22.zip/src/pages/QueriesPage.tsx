import React, { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import { calcInvoiceValue, calcIssueValue, fmtDate, fmtMoney, fmtNum, isLineReceipt, shiftISO, todayISO, unitsText } from '../utils/format';
import { exportToExcel } from '../utils/export';
import { EmptyState, ExcelButton, MOVE_LABELS, PageHeader, PrintButton } from '../components/ui/CommonUI';

type QueryTab = 'product' | 'customer' | 'supplier' | 'supplies' | 'shortage' | 'movements';

const QUERY_TABS: [QueryTab, string][] = [
  ['product', 'المنتج راح لمين'],
  ['customer', 'كشف عميل'],
  ['supplier', 'كشف مورد'],
  ['supplies', 'المستلزمات لكل عميل'],
  ['shortage', 'نواقص المخزون'],
  ['movements', 'حركة صنف']
];

export function QueriesPage({ onPrintHtml }: { onPrintHtml: (html: string) => void }) {
  const { db, getProduct, getWarehouse, totalProductStock, toast } = usePharmaStore();
  const [tab, setTab] = useState<QueryTab>('product');
  const [text, setText] = useState('');
  const [fromDate, setFromDate] = useState(() => shiftISO(todayISO(), -60));
  const [toDate, setToDate] = useState(() => todayISO());

  const result = useMemo<{
    title: string;
    headers: string[];
    rows: (string | number)[][];
    summary: { label: string; value: string }[];
  }>(() => {
    const q = text.trim().toLowerCase();
    const inRange = (d?: string) => {
      if (!d) return false;
      if (fromDate && d < fromDate) return false;
      if (toDate && d > toDate) return false;
      return true;
    };

    if (tab === 'product') {
      const rows: (string | number)[][] = [];
      let totalStrips = 0;
      db.issues.forEach(iss => {
        if (!inRange(iss.date)) return;
        iss.lines.forEach(l => {
          const p = getProduct(l.productId);
          if (!p) return;
          if (q && !`${p.name} ${p.code} ${iss.customer} ${iss.no}`.toLowerCase().includes(q)) return;
          totalStrips += l.strips;
          rows.push([
            fmtDate(iss.date),
            iss.no,
            iss.invoiceNo,
            iss.customer,
            getWarehouse(iss.warehouseId)?.name || '—',
            p.name,
            unitsText(l.strips, p),
            l.strips
          ]);
        });
      });
      return {
        title: 'استعلام: المنتج اتصرف لمين؟',
        headers: ['التاريخ', 'أذن الصرف', 'الفاتورة', 'العميل', 'المخزن', 'الصنف', 'الكمية بالوحدات', 'الوحدات الأساسية'],
        rows,
        summary: [
          { label: 'عمليات الصرف', value: fmtNum(rows.length) },
          { label: 'إجمالي الوحدات', value: fmtNum(totalStrips) }
        ]
      };
    }

    if (tab === 'customer') {
      const list = db.issues.filter(i => {
        if (!inRange(i.date)) return false;
        if (q && !`${i.customer} ${i.no} ${i.invoiceNo}`.toLowerCase().includes(q)) return false;
        return true;
      });
      const totalVal = list.reduce((s, i) => s + calcIssueValue(i, db.products), 0);
      const rows = list.map(i => [
        fmtDate(i.date),
        i.no,
        i.invoiceNo,
        i.customer,
        getWarehouse(i.warehouseId)?.name || '—',
        i.lines.length,
        Number(calcIssueValue(i, db.products).toFixed(2))
      ]);
      return {
        title: 'كشف حساب عميل / فواتير الصرف',
        headers: ['التاريخ', 'أذن الصرف', 'رقم الفاتورة', 'العميل', 'المخزن', 'البنود', 'القيمة (ج.م)'],
        rows,
        summary: [
          { label: 'عدد الأذون', value: fmtNum(list.length) },
          { label: 'إجمالي القيمة', value: `${fmtMoney(totalVal)} ج.م` }
        ]
      };
    }

    if (tab === 'supplier') {
      const list = db.invoices.filter(inv => {
        if (!inRange(inv.date)) return false;
        if (q && !`${inv.supplier} ${inv.no}`.toLowerCase().includes(q)) return false;
        return true;
      });
      const totalVal = list.reduce((s, inv) => s + calcInvoiceValue(inv, db.products), 0);
      const rows = list.map(inv => [
        fmtDate(inv.date),
        inv.no,
        inv.supplier,
        inv.lines.length,
        inv.totalStrips,
        Number(calcInvoiceValue(inv, db.products).toFixed(2))
      ]);
      return {
        title: 'كشف فواتير الموردين',
        headers: ['التاريخ', 'رقم الفاتورة', 'المورد', 'عدد البنود', 'إجمالي الوحدات', 'القيمة (ج.م)'],
        rows,
        summary: [
          { label: 'فواتير الوارد', value: fmtNum(list.length) },
          { label: 'إجمالي المشتريات', value: `${fmtMoney(totalVal)} ج.م` }
        ]
      };
    }

    if (tab === 'supplies') {
      const map = new Map<string, { customer: string; item: string; rawStrips: number; orders: number }>();
      db.issues.forEach(iss => {
        if (!inRange(iss.date)) return;
        iss.lines.forEach(l => {
          const p = getProduct(l.productId);
          if (!p || !isLineReceipt(l, p)) return;
          if (q && !`${iss.customer} ${p.name} ${p.code}`.toLowerCase().includes(q)) return;
          const key = `${iss.customer}|${p.id}`;
          const prev = map.get(key) || { customer: iss.customer, item: p.name, rawStrips: 0, orders: 0 };
          prev.rawStrips += l.strips;
          prev.orders += 1;
          map.set(key, prev);
        });
      });
      const entries = Array.from(map.values());
      const totalRaw = entries.reduce((s, e) => s + e.rawStrips, 0);
      const rows = entries.map(e => [e.customer, e.item, e.orders, e.rawStrips]);
      return {
        title: 'استعلام: المستلزمات المنصرفة لكل عميل',
        headers: ['العميل', 'المستلزم', 'عدد الأذون', 'إجمالي الوحدات المنصرفة'],
        rows,
        summary: [
          { label: 'عدد السجلات', value: fmtNum(entries.length) },
          { label: 'إجمالي الوحدات', value: fmtNum(totalRaw) }
        ]
      };
    }

    if (tab === 'shortage') {
      const rows: (string | number)[][] = [];
      db.products.forEach(p => {
        const active = totalProductStock(p.id);
        const minTarget = (p.units[1]?.factor || 1) * 3;
        if (active > minTarget) return;
        if (q && !`${p.name} ${p.code}`.toLowerCase().includes(q)) return;
        rows.push([
          p.code,
          p.name,
          p.marked ? 'مستلزمات' : 'دواء',
          unitsText(active, p),
          active,
          minTarget,
          active === 0 ? 'نافد تمامًا' : 'منخفض'
        ]);
      });
      return {
        title: 'استعلام: نواقص المخزون',
        headers: ['الكود', 'الصنف', 'النوع', 'المتاح بالوحدات', 'الرصيد الأساسي', 'الحد الأدنى', 'الحالة'],
        rows,
        summary: [{ label: 'أصناف تحتاج طلب شراء', value: fmtNum(rows.length) }]
      };
    }

    // movements
    const list = db.movements.filter(m => {
      if (!inRange(m.date)) return false;
      const p = getProduct(m.productId);
      const w = getWarehouse(m.warehouseId);
      if (q && !`${p?.name || ''} ${p?.code || ''} ${w?.name || ''} ${m.ref}`.toLowerCase().includes(q)) return false;
      return true;
    });
    const rows = list.map(m => {
      const p = getProduct(m.productId);
      const w = getWarehouse(m.warehouseId);
      return [
        fmtDate(m.date),
        MOVE_LABELS[m.type]?.label || m.type,
        m.ref,
        p?.name || '—',
        w?.name || '—',
        p ? unitsText(m.strips, p) : fmtNum(m.strips),
        m.strips,
        m.note
      ];
    });
    return {
      title: 'استعلام: تتبع حركة صنف',
      headers: ['التاريخ', 'نوع الحركة', 'المرجع', 'الصنف', 'المخزن', 'الكمية بالوحدات', 'الوحدات الأساسية', 'ملاحظة'],
      rows,
      summary: [{ label: 'عدد الحركات', value: fmtNum(list.length) }]
    };
  }, [tab, text, fromDate, toDate, db, getProduct, getWarehouse, totalProductStock]);

  const handleExcel = () => {
    exportToExcel(`${result.title.replace(/[:\s؟]+/g, '_')}_${todayISO()}.xlsx`, 'الاستعلام', result.headers, result.rows);
    toast(`تم تصدير «${result.title}» إلى Excel`);
  };

  const handlePrint = () => {
    const rowsHtml = result.rows
      .map(r => `<tr>${r.map(c => `<td style="border:1px solid #0b4f4b;padding:5px">${c}</td>`).join('')}</tr>`)
      .join('');
    onPrintHtml(`
      <div style="font-family:Cairo,Arial,sans-serif;direction:rtl;color:#111">
        <h2>${result.title} — ${db.company.name}</h2>
        <p>تاريخ الطباعة: ${fmtDate(todayISO())}</p>
        <table style="width:100%;border-collapse:collapse;font-size:10.5px">
          <thead><tr style="background:#0f766e;color:#fff">${result.headers.map(h => `<th style="border:1px solid #0b4f4b;padding:6px">${h}</th>`).join('')}</tr></thead>
          <tbody>${rowsHtml}</tbody>
        </table>
      </div>
    `);
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="الاستعلامات"
        subtitle="بحث فوري في حركات الأصناف والعملاء والموردين والمستلزمات ونواقص المخزون مع تصدير كامل إلى Excel"
        actions={
          <>
            <ExcelButton onClick={handleExcel} />
            <PrintButton onClick={handlePrint} />
          </>
        }
      />

      <div className="flex flex-wrap items-center gap-1 p-1 bg-[#e9f0ee] rounded-xl w-fit">
        {QUERY_TABS.map(([k, lbl]) => (
          <button
            key={k}
            type="button"
            onClick={() => setTab(k)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
              tab === k ? 'bg-white text-[#102523] shadow-sm' : 'text-[#5c7471] hover:text-[#102523]'
            }`}
          >
            {lbl}
          </button>
        ))}
      </div>

      <section className="bg-white border border-[#dce6e3] rounded-xl p-4">
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div className="sm:col-span-2">
            <span className="block text-[11px] font-bold text-[#5c7471] mb-1">بحث (اسم الصنف / الكود / العميل / المورد / رقم الأذن)</span>
            <div className="relative">
              <Search className="w-4 h-4 text-[#6b8481] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={text}
                onChange={e => setText(e.target.value)}
                placeholder="اكتب للبحث الفوري..."
                className="w-full pr-9 pl-3 py-2 rounded-lg border border-[#dce6e3] text-xs focus:outline-none focus:border-[#0f766e]"
              />
            </div>
          </div>
          <label className="block text-[11px] font-bold text-[#5c7471]">
            <span>من تاريخ</span>
            <input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs" />
          </label>
          <label className="block text-[11px] font-bold text-[#5c7471]">
            <span>إلى تاريخ</span>
            <input type="date" value={toDate} onChange={e => setToDate(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs" />
          </label>
        </div>
      </section>

      <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3.5 border-b border-[#eaf1ef]">
          <h3 className="text-sm font-extrabold text-[#102523]">{result.title}</h3>
          <div className="flex flex-wrap items-center gap-4 text-xs">
            {result.summary.map((s, i) => (
              <div key={i} className="tabular-nums">
                <span className="text-[#5c7471]">{s.label}: </span>
                <strong className="text-[#0f766e]">{s.value}</strong>
              </div>
            ))}
          </div>
        </div>
        {result.rows.length ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                  {result.headers.map((h, i) => (
                    <th key={i} className="py-2.5 px-3 text-right font-bold whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#edf3f1]">
                {result.rows.map((r, ri) => (
                  <tr key={ri} className="hover:bg-[#f9fcfb]">
                    {r.map((cell, ci) => (
                      <td key={ci} className="py-2.5 px-3 tabular-nums whitespace-nowrap">{cell}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState icon={<Search className="w-6 h-6" />} title="لا توجد نتائج مطابقة" description="جرب توسيع نطاق التاريخ أو مسح كلمة البحث." />
        )}
      </section>
    </div>
  );
}
