import React, { useEffect, useMemo, useState } from 'react';
import { Eye, FileText, RotateCcw } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { CustomerReturn, CustomerReturnLine } from '../types/pharma';
import { fmtDate, fmtMoney, fmtNum, isLineReceipt, todayISO, unitsText } from '../utils/format';
import { exportReturnToWord, exportToExcel } from '../utils/export';
import { EmptyState, ExcelButton, ExpiryTag, PageHeader } from '../components/ui/CommonUI';

interface ReturnRowInput {
  qty: number;
  unitName: string;
  reason: string;
}

export function ReturnsPage({
  preselectedIssueId,
  onViewReturn
}: {
  preselectedIssueId?: string | null;
  onViewReturn: (ret: CustomerReturn) => void;
}) {
  const {
    db,
    getProduct,
    getWarehouse,
    nextReturnNo,
    returnedStripsFor,
    commitCustomerReturn,
    toast
  } = usePharmaStore();

  const [issueId, setIssueId] = useState<string>(() => preselectedIssueId || db.issues[0]?.id || '');
  const [warehouseId, setWarehouseId] = useState<string>(() => db.issues[0]?.warehouseId || db.warehouses[0].id);
  const [date, setDate] = useState(todayISO());
  const [reason, setReason] = useState('');
  const [inputs, setInputs] = useState<Record<string, ReturnRowInput>>({});

  useEffect(() => {
    if (preselectedIssueId) {
      const iss = db.issues.find(i => i.id === preselectedIssueId);
      if (iss) {
        setIssueId(iss.id);
        setWarehouseId(iss.warehouseId);
        setInputs({});
      }
    }
  }, [preselectedIssueId, db.issues]);

  const selectedIssue = useMemo(
    () => db.issues.find(i => i.id === issueId) || db.issues[0] || null,
    [db.issues, issueId]
  );

  const lotItems = useMemo(() => {
    if (!selectedIssue) return [];
    const items: {
      key: string;
      productId: string;
      batch: string;
      expiry: string;
      issuedStrips: number;
      returnedBefore: number;
      remaining: number;
      pricePerStrip: number;
    }[] = [];

    (selectedIssue.lines || []).forEach(l => {
      const p = getProduct(l.productId);
      if (!p) return;
      const allocs = l.alloc?.length ? l.alloc : [{ batch: '—', expiry: '', strips: l.strips }];
      allocs.forEach(a => {
        const before = returnedStripsFor(selectedIssue.id, l.productId, a.batch, a.expiry);
        const remaining = Math.max(0, a.strips - before);
        items.push({
          key: `${l.productId}|${a.batch}|${a.expiry}`,
          productId: l.productId,
          batch: a.batch,
          expiry: a.expiry,
          issuedStrips: a.strips,
          returnedBefore: before,
          remaining,
          pricePerStrip: isLineReceipt(l, p) ? 0 : (l.pricePerStrip != null ? l.pricePerStrip : p.price)
        });
      });
    });
    return items;
  }, [selectedIssue, getProduct, returnedStripsFor]);

  const computed = useMemo(() => {
    let retTotalStrips = 0;
    let keptTotalStrips = 0;
    let retTotalValue = 0;
    let hasError = false;
    const lines: CustomerReturnLine[] = [];

    lotItems.forEach(it => {
      const p = getProduct(it.productId);
      if (!p) return;
      const inp = inputs[it.key] || { qty: 0, unitName: p.units[0].name, reason: '' };
      const u = p.units.find(x => x.name === inp.unitName) || p.units[0];
      const strips = Math.max(0, Math.round((Number(inp.qty) || 0) * u.factor));
      if (strips > it.remaining) hasError = true;
      const validStrips = Math.min(strips, it.remaining);
      retTotalStrips += strips;
      keptTotalStrips += Math.max(0, it.remaining - validStrips);
      retTotalValue += strips * it.pricePerStrip;
      if (strips > 0) {
        lines.push({
          productId: it.productId,
          batch: it.batch,
          expiry: it.expiry,
          strips,
          pricePerStrip: it.pricePerStrip,
          reason: inp.reason.trim()
        });
      }
    });

    const returnType: 'full' | 'partial' = keptTotalStrips === 0 && retTotalStrips > 0 ? 'full' : 'partial';
    return { retTotalStrips, keptTotalStrips, retTotalValue, hasError, lines, returnType };
  }, [lotItems, inputs, getProduct]);

  const handleSelectAllFull = () => {
    const next: Record<string, ReturnRowInput> = {};
    lotItems.forEach(it => {
      if (it.remaining <= 0) return;
      const p = getProduct(it.productId);
      if (!p) return;
      next[it.key] = {
        qty: it.remaining,
        unitName: p.units[0].name,
        reason: inputs[it.key]?.reason || 'مرتجع كامل الفاتورة / الأذن'
      };
    });
    setInputs(next);
    toast('تم تحديد إرجاع كامل الكمية المتبقية');
  };

  const handleRejectLine = (key: string, remaining: number) => {
    const prodId = key.split('|')[0];
    const p = getProduct(prodId);
    if (!p) return;
    setInputs(prev => ({
      ...prev,
      [key]: {
        qty: remaining,
        unitName: p.units[0].name,
        reason: prev[key]?.reason || 'رفض الصنف'
      }
    }));
  };

  const handleCommit = async () => {
    if (!selectedIssue) return;
    if (computed.hasError) {
      toast('يوجد كمية مرتجعة أكبر من المتبقي لدى العميل', 'err');
      return;
    }
    if (!computed.lines.length) {
      toast('حدد كمية مرتجعة واحدة على الأقل', 'err');
      return;
    }
    try {
      const saved = await commitCustomerReturn({
        issueId: selectedIssue.id,
        warehouseId,
        date,
        reason,
        lines: computed.lines,
        keptStrips: computed.keptTotalStrips,
        returnType: computed.returnType
      });
      toast(`تم اعتماد ${saved.returnType === 'full' ? 'المرتجع الكلي' : 'المرتجع الجزئي'} رقم ${saved.no} وإعادة البضاعة للمخزن`);
      setInputs({});
      setReason('');
    } catch (err) {
      toast(err instanceof Error ? err.message : 'تعذر تسجيل المرتجع', 'err');
    }
  };

  const exportHistoryExcel = () => {
    const headers = ['رقم المرتجع', 'التاريخ', 'أذن الصرف', 'رقم الفاتورة', 'العميل', 'النوع', 'المخزن المستلم', 'الوحدات المرتجعة', 'الوحدات المقبولة', 'القيمة (ج.م)', 'السبب'];
    const rows = db.returns.map(r => [
      r.no,
      fmtDate(r.date),
      r.issueNo,
      r.invoiceNo,
      r.customer,
      r.returnType === 'full' ? 'مرتجع كلي' : 'مرتجع جزئي',
      getWarehouse(r.warehouseId)?.name || '',
      r.totalStrips,
      r.keptStrips,
      Number(r.totalValue.toFixed(2)),
      r.reason || '—'
    ]);
    exportToExcel(`مرتجعات_العملاء_${todayISO()}.xlsx`, 'مرتجعات العملاء', headers, rows);
    toast('تم تصدير سجل مرتجعات العملاء إلى Excel');
  };

  const retNo = nextReturnNo();

  return (
    <div className="space-y-5">
      <PageHeader
        title="مرتجع العملاء"
        subtitle="إرجاع كامل الفاتورة أو أذن الصرف، أو مرتجع جزئي (استلم العميل بضاعة ورفض بضاعة أخرى) وإعادتها للمخزن بنفس اللوت والصلاحية"
        actions={
          <>
            <button
              type="button"
              onClick={() => setInputs({})}
              className="px-3.5 py-2 rounded-lg border border-[#dce6e3] bg-white text-xs font-bold text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
            >
              تصفير الكميات
            </button>
            <span className="px-3 py-1.5 rounded-lg bg-[#f5f3ff] border border-[#ddd6fe] font-mono-num text-xs font-extrabold text-[#6d28d9]">
              {retNo}
            </span>
          </>
        }
      />

      {db.issues.length ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          <div className="lg:col-span-8 space-y-4">
            <section className="bg-white border border-[#dce6e3] rounded-xl p-4">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                <h3 className="text-sm font-extrabold text-[#102523]">اختيار أذن الصرف / الفاتورة</h3>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleSelectAllFull}
                    className="px-3 py-1.5 rounded-lg border border-[#fecaca] bg-[#fef2f2] text-[#b91c1c] hover:bg-[#fee2e2] text-xs font-bold cursor-pointer"
                  >
                    مرتجع كلي (كامل الفاتورة / الأذن)
                  </button>
                  <button
                    type="button"
                    onClick={() => setInputs({})}
                    className="px-3 py-1.5 rounded-lg border border-[#dce6e3] bg-white text-[#3b5653] hover:bg-[#f4f8f7] text-xs font-bold cursor-pointer"
                  >
                    مرتجع جزئي يدوي
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <label className="block text-xs font-bold text-[#233d3a] sm:col-span-2">
                  <span>أذن الصرف / الفاتورة *</span>
                  <select
                    value={selectedIssue?.id || ''}
                    onChange={e => {
                      const nextIss = db.issues.find(i => i.id === e.target.value);
                      setIssueId(e.target.value);
                      if (nextIss) setWarehouseId(nextIss.warehouseId);
                      setInputs({});
                    }}
                    className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white"
                  >
                    {db.issues.map(i => (
                      <option key={i.id} value={i.id}>
                        {i.no} — فاتورة {i.invoiceNo || '—'} — {i.customer} ({fmtDate(i.date)})
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block text-xs font-bold text-[#233d3a]">
                  <span>تاريخ المرتجع</span>
                  <input
                    type="date"
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs"
                  />
                </label>
                <label className="block text-xs font-bold text-[#233d3a]">
                  <span>المخزن المستلم للمرتجع *</span>
                  <select
                    value={warehouseId}
                    onChange={e => setWarehouseId(e.target.value)}
                    className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs bg-white"
                  >
                    {db.warehouses.map(w => <option key={w.id} value={w.id}>{w.name} — {w.gov}</option>)}
                  </select>
                </label>
                <label className="block text-xs font-bold text-[#233d3a] sm:col-span-2">
                  <span>سبب المرتجع / ملاحظات</span>
                  <input
                    value={reason}
                    onChange={e => setReason(e.target.value)}
                    placeholder="مثال: رفض العميل لبعض الأصناف وقبل الباقي أو مرتجع كامل"
                    className="mt-1 w-full px-3 py-2 rounded-lg border border-[#dce6e3] text-xs"
                  />
                </label>
              </div>
            </section>

            <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
              <div className="px-4 py-3.5 border-b border-[#eaf1ef]">
                <h3 className="text-sm font-extrabold text-[#102523]">البضاعة المرفوضة والمقبولة</h3>
                <p className="text-[11.5px] text-[#5c7471]">حدد الكمية المرفوضة المرتجعة فقط، واترك الأصناف التي استلمها العميل على صفر</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                      <th className="py-2.5 px-3 text-right font-bold">الصنف والتشغيلة</th>
                      <th className="py-2.5 px-3 text-center font-bold">الصلاحية</th>
                      <th className="py-2.5 px-3 text-right font-bold">المصروف</th>
                      <th className="py-2.5 px-3 text-right font-bold">المتاح للإرجاع</th>
                      <th className="py-2.5 px-3 text-right font-bold">الكمية المرتجعة</th>
                      <th className="py-2.5 px-3 text-right font-bold">سبب الرفض</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#edf3f1]">
                    {lotItems.map(it => {
                      const p = getProduct(it.productId)!;
                      const inp = inputs[it.key] || { qty: 0, unitName: p.units[0].name, reason: '' };
                      const u = p.units.find(x => x.name === inp.unitName) || p.units[0];
                      const retStrips = Math.max(0, Math.round((Number(inp.qty) || 0) * u.factor));
                      const over = retStrips > it.remaining;
                      const kept = Math.max(0, it.remaining - Math.min(retStrips, it.remaining));

                      return (
                        <tr key={it.key}>
                          <td className="py-2.5 px-3">
                            <div className="font-bold text-[#102523]">{p.name}</div>
                            <div className="text-[11px] text-[#5c7471]">
                              {p.code} · لوت <span className="font-mono-num">{it.batch}</span>
                            </div>
                          </td>
                          <td className="py-2.5 px-3 text-center">{it.expiry ? <ExpiryTag date={it.expiry} /> : '—'}</td>
                          <td className="py-2.5 px-3 tabular-nums">
                            {unitsText(it.issuedStrips, p)}
                            {it.returnedBefore > 0 && (
                              <div className="text-[10.5px] text-[#b45309]">مرتجع سابق: {unitsText(it.returnedBefore, p)}</div>
                            )}
                          </td>
                          <td className="py-2.5 px-3 font-bold tabular-nums">{unitsText(it.remaining, p)}</td>
                          <td className="py-2.5 px-3 min-w-[210px]">
                            {it.remaining > 0 ? (
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <input
                                    type="number"
                                    min="0"
                                    value={inp.qty || ''}
                                    placeholder="0"
                                    onChange={e =>
                                      setInputs(prev => ({
                                        ...prev,
                                        [it.key]: { ...inp, qty: Math.max(0, Number(e.target.value) || 0) }
                                      }))
                                    }
                                    className="w-16 px-2 py-1.5 rounded-lg border border-[#dce6e3] text-xs tabular-nums"
                                  />
                                  <select
                                    value={u.name}
                                    onChange={e =>
                                      setInputs(prev => ({
                                        ...prev,
                                        [it.key]: { ...inp, unitName: e.target.value }
                                      }))
                                    }
                                    className="flex-1 min-w-[80px] px-2 py-1.5 rounded-lg border border-[#dce6e3] text-xs bg-white"
                                  >
                                    {p.units.map(un => (
                                      <option key={un.name} value={un.name}>{un.name} ({un.factor})</option>
                                    ))}
                                  </select>
                                  <button
                                    type="button"
                                    onClick={() => handleRejectLine(it.key, it.remaining)}
                                    className="px-2 py-1.5 rounded-lg border border-[#dce6e3] bg-[#f8fbfa] text-[10.5px] font-bold hover:bg-[#eef8f6] cursor-pointer"
                                  >
                                    الكل
                                  </button>
                                </div>
                                {over ? (
                                  <div className="text-[10.5px] font-bold text-[#dc2626] mt-1">يتجاوز المتاح ({fmtNum(it.remaining)})</div>
                                ) : retStrips > 0 ? (
                                  <div className="text-[10.5px] font-bold text-[#6d28d9] mt-1">
                                    مرتجع: {unitsText(retStrips, p)} · مقبول: {unitsText(kept, p)}
                                  </div>
                                ) : (
                                  <div className="text-[10.5px] text-[#047857] mt-1">مقبول بالكامل لدى العميل</div>
                                )}
                              </div>
                            ) : (
                              <span className="text-[11px] font-bold text-[#5c7471]">تم إرجاعه بالكامل</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 min-w-[140px]">
                            {it.remaining > 0 ? (
                              <input
                                type="text"
                                value={inp.reason}
                                onChange={e =>
                                  setInputs(prev => ({
                                    ...prev,
                                    [it.key]: { ...inp, reason: e.target.value }
                                  }))
                                }
                                placeholder="سبب الرفض (اختياري)"
                                className="w-full px-2.5 py-1.5 rounded-lg border border-[#dce6e3] text-xs"
                              />
                            ) : (
                              '—'
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </section>
          </div>

          <aside className="lg:col-span-4 lg:sticky lg:top-20">
            <section className="bg-white border border-[#dce6e3] rounded-xl p-4 space-y-4">
              <div>
                <h3 className="text-sm font-extrabold text-[#102523]">ملخص المرتجع</h3>
                <p className="text-xs text-[#5c7471]">{selectedIssue?.customer}</p>
              </div>
              <div className="border border-[#dce6e3] rounded-xl divide-y divide-[#edf3f1] text-xs">
                <div className="flex justify-between px-3 py-2.5">
                  <span className="text-[#5c7471]">رقم المرتجع</span>
                  <span className="font-mono-num font-bold text-[#6d28d9]">{retNo}</span>
                </div>
                <div className="flex justify-between px-3 py-2.5">
                  <span className="text-[#5c7471]">نوع المرتجع</span>
                  <span className="font-bold">
                    {computed.retTotalStrips === 0
                      ? 'لم يحدد'
                      : computed.returnType === 'full'
                        ? 'مرتجع كلي (كامل الأذن)'
                        : 'مرتجع جزئي'}
                  </span>
                </div>
                <div className="flex justify-between px-3 py-2.5">
                  <span className="text-[#5c7471]">الوحدات المرتجعة للمخزن</span>
                  <span className="font-bold text-[#dc2626] tabular-nums">{fmtNum(computed.retTotalStrips)} وحدة</span>
                </div>
                <div className="flex justify-between px-3 py-2.5">
                  <span className="text-[#5c7471]">الوحدات المقبولة لدى العميل</span>
                  <span className="font-bold text-[#047857] tabular-nums">{fmtNum(computed.keptTotalStrips)} وحدة</span>
                </div>
                <div className="flex justify-between px-3 py-3 bg-[#f5f3ff]">
                  <span className="font-extrabold text-[#102523]">قيمة المرتجع (أدوية)</span>
                  <span className="text-base font-extrabold text-[#6d28d9] tabular-nums">{fmtMoney(computed.retTotalValue)} ج.م</span>
                </div>
              </div>

              <button
                type="button"
                disabled={computed.retTotalStrips <= 0 || computed.hasError}
                onClick={handleCommit}
                className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#6d28d9] text-white text-xs font-extrabold hover:bg-[#5b21b6] disabled:opacity-45 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>اعتماد المرتجع وإعادته للمخزن</span>
              </button>
            </section>
          </aside>
        </div>
      ) : (
        <EmptyState icon={<RotateCcw className="w-6 h-6" />} title="لا توجد أذون صرف بعد" description="أنشئ أذن صرف أولًا لتتمكن من تسجيل مرتجع عميل." />
      )}

      {/* Returns history */}
      <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
        <div className="flex items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
          <h3 className="text-sm font-extrabold text-[#102523]">سجل مرتجعات العملاء ({db.returns.length})</h3>
          <ExcelButton small onClick={exportHistoryExcel} />
        </div>
        {db.returns.length ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                  <th className="py-2.5 px-3 text-right font-bold">رقم المرتجع</th>
                  <th className="py-2.5 px-3 text-right font-bold">أذن الصرف / الفاتورة</th>
                  <th className="py-2.5 px-3 text-right font-bold">العميل</th>
                  <th className="py-2.5 px-3 text-center font-bold">النوع</th>
                  <th className="py-2.5 px-3 text-right font-bold">المخزن المستلم</th>
                  <th className="py-2.5 px-3 text-center font-bold">الوحدات</th>
                  <th className="py-2.5 px-3 text-left font-bold">القيمة</th>
                  <th className="py-2.5 px-3 text-left font-bold">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#edf3f1]">
                {db.returns.map(ret => {
                  const w = getWarehouse(ret.warehouseId);
                  return (
                    <tr key={ret.id} className="hover:bg-[#f9fcfb]">
                      <td className="py-2.5 px-3">
                        <div className="font-mono-num font-bold text-[#6d28d9]">{ret.no}</div>
                        <div className="text-[11px] text-[#5c7471]">{fmtDate(ret.date)}</div>
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-mono-num font-bold">{ret.issueNo}</div>
                        <div className="text-[11px] text-[#5c7471]">فاتورة {ret.invoiceNo}</div>
                      </td>
                      <td className="py-2.5 px-3 font-semibold">{ret.customer}</td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`text-[11px] font-bold ${ret.returnType === 'full' ? 'text-[#dc2626]' : 'text-[#6d28d9]'}`}>
                          {ret.returnType === 'full' ? 'مرتجع كلي' : 'مرتجع جزئي'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3">{w?.name || '—'}</td>
                      <td className="py-2.5 px-3 text-center font-bold tabular-nums">{fmtNum(ret.totalStrips)}</td>
                      <td className="py-2.5 px-3 text-left font-bold tabular-nums">{fmtMoney(ret.totalValue)} ج.م</td>
                      <td className="py-2.5 px-3 text-left">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={async () => {
                              try {
                                await exportReturnToWord(ret, w, db.products, db.company);
                                toast(`تم تحميل مرتجع ${ret.no} بصيغة Word (.docx)`);
                              } catch {
                                toast('تعذر إنشاء ملف Word', 'err');
                              }
                            }}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded-md border border-[#bfdbfe] bg-[#eff6ff] text-[#1d4ed8] text-[10.5px] font-bold cursor-pointer"
                          >
                            <FileText className="w-3 h-3" />
                            <span>Word</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => onViewReturn(ret)}
                            className="p-1.5 rounded-md border border-[#dce6e3] text-[#233d3a] hover:bg-[#f4f8f7] cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState icon={<RotateCcw className="w-5 h-5" />} title="لا توجد مرتجعات مسجلة" description="ستظهر هنا كل المرتجعات الكلية والجزئية المعتمدة." />
        )}
      </section>
    </div>
  );
}
