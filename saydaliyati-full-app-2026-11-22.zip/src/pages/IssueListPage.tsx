import React, { useMemo, useState } from 'react';
import {
  ChevronDown,
  ChevronUp,
  Eye,
  FileText,
  Lock,
  Pencil,
  Plus,
  Receipt,
  RotateCcw,
  Search
} from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { IssueOrder } from '../types/pharma';
import {
  calc14Percent,
  calcIssueValue,
  calcTotalWith14,
  fmtDate,
  fmtMoney,
  fmtNum,
  getIssueReceipts,
  getLineReceiptType,
  isLineReceipt,
  receiptTypeLabel,
  resolveIssueCustomer,
  sortIssueLines,
  sortIssuesByInvoiceStatus,
  tafqeetEGP,
  todayISO,
  unitsText
} from '../utils/format';
import { exportIssueReceiptToWord, exportIssueToWord, exportToExcel } from '../utils/export';
import { EmptyState, ExcelButton, KpiCard, PageHeader } from '../components/ui/CommonUI';

export function IssueListPage({
  onCreateNew,
  onCreateSalesInvoice,
  onViewIssue,
  onEditIssue,
  onStartReturn
}: {
  onCreateNew: () => void;
  onCreateSalesInvoice: (issueId?: string) => void;
  onViewIssue: (issue: IssueOrder) => void;
  onEditIssue: (issue: IssueOrder) => void;
  onStartReturn: (issueId: string) => void;
}) {
  const { db, getProduct, getWarehouse, getPartner, issueReturnStats, setIssueInvoiced, toast } = usePharmaStore();

  const [search, setSearch] = useState('');
  const [warehouseFilter, setWarehouseFilter] = useState('all');
  const [kindFilter, setKindFilter] = useState<'all' | 'invoice' | 'supplies' | 'gift' | 'mixed'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'none' | 'partial' | 'full'>('all');
  const [invoiceStateFilter, setInvoiceStateFilter] = useState<'all' | 'open' | 'closed'>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const filteredIssues = useMemo(() => {
    const q = search.trim().toLowerCase();
    return sortIssuesByInvoiceStatus(
      db.issues.filter(i => {
        if (warehouseFilter !== 'all' && i.warehouseId !== warehouseFilter) return false;

        if (invoiceStateFilter === 'open' && (i.closed || i.invoiced)) return false;
        if (invoiceStateFilter === 'closed' && !(i.closed || i.invoiced)) return false;

        const rs = issueReturnStats(i);
        if (statusFilter !== 'all' && rs.status !== statusFilter) return false;

        const hasBillable = i.lines.some(l => !isLineReceipt(l, getProduct(l.productId)));
        const receiptGroups = getIssueReceipts(i, db.products);
        const hasSupplies = receiptGroups.some(g => g.type === 'supplies');
        const hasGift = receiptGroups.some(g => g.type === 'gift');

        if (kindFilter === 'invoice' && !hasBillable) return false;
        if (kindFilter === 'supplies' && !hasSupplies) return false;
        if (kindFilter === 'gift' && !hasGift) return false;
        if (kindFilter === 'mixed' && !(hasBillable && receiptGroups.length > 0)) return false;

        if (!q) return true;
        const receiptNos = receiptGroups.map(g => g.receiptNo).join(' ');
        const itemText = i.lines
          .map(l => {
            const p = getProduct(l.productId);
            return p ? `${p.code} ${p.name}` : '';
          })
          .join(' ');
        const haystack = `${i.no} ${i.invoiceNo} ${i.customer} ${receiptNos} ${itemText}`.toLowerCase();
        return haystack.includes(q);
      })
    );
  }, [db.issues, db.products, search, warehouseFilter, kindFilter, statusFilter, invoiceStateFilter, getProduct, issueReturnStats]);

  const totalBillableValue = useMemo(
    () => filteredIssues.reduce((s, i) => s + calcIssueValue(i, db.products), 0),
    [filteredIssues, db.products]
  );

  const totalWithReceipts = useMemo(
    () => filteredIssues.filter(i => getIssueReceipts(i, db.products).length > 0).length,
    [filteredIssues, db.products]
  );

  const totalReturnedOrders = useMemo(
    () => filteredIssues.filter(i => issueReturnStats(i).status !== 'none').length,
    [filteredIssues, issueReturnStats]
  );

  const exportListExcel = () => {
    const headers = [
      'رقم أذن الصرف',
      'التاريخ',
      'العميل',
      'رقم الفاتورة',
      'المخزن',
      'الإيصالات المرفقة',
      'عدد البنود',
      'قيمة الفاتورة (ج.م)',
      'قيمة 14% (ج.م)',
      'المبلغ الإجمالي شامل 14% (ج.م)',
      'تفقيط المبلغ الإجمالي',
      'وحدات بدون قيمة',
      'حالة المرتجع'
    ];
    const rows = filteredIssues.map(i => {
      const rs = issueReturnStats(i);
      const val = calcIssueValue(i, db.products);
      const val14 = calc14Percent(val);
      const grand = calcTotalWith14(val);
      const receiptGroups = getIssueReceipts(i, db.products);
      const receiptTxt = receiptGroups.length
        ? receiptGroups.map(g => `${g.receiptNo} (${g.label})`).join(' | ')
        : '—';
      const retTxt = rs.status === 'full' ? 'مرتجع كلي' : rs.status === 'partial' ? `مرتجع جزئي (${rs.totalReturned})` : 'مسلّم بالكامل';
      return [
        i.no,
        fmtDate(i.date),
        i.customer,
        i.invoiceNo || '—',
        getWarehouse(i.warehouseId)?.name || '',
        receiptTxt,
        i.lines.length,
        Number(val.toFixed(2)),
        val14,
        grand,
        val > 0 ? tafqeetEGP(grand) : '—',
        i.suppliesStrips || 0,
        retTxt
      ];
    });
    exportToExcel(`قائمة_أذون_الصرف_${todayISO()}.xlsx`, 'أذون الصرف', headers, rows);
    toast('تم تصدير قائمة أذون الصرف إلى Excel');
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="قائمة أذون الصرف"
        subtitle="عرض ومتابعة جميع أذون الصرف الصادرة والإيصالات المرفقة (مستلزمات / هدية بدون قيمة) مع التصدير والطباعة المباشرة"
        actions={
          <>
            <ExcelButton onClick={exportListExcel} label="تصدير Excel" />
            <button
              type="button"
              onClick={() => onCreateSalesInvoice()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#b7dfd7] bg-[#eef8f6] text-xs font-extrabold text-[#0f766e] hover:bg-[#dff2ee] cursor-pointer"
            >
              <Receipt className="w-4 h-4" />
              <span>عمل فاتورة مبيعات</span>
            </button>
            <button
              type="button"
              onClick={onCreateNew}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-extrabold hover:bg-[#0d655e] cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>أذن صرف جديد</span>
            </button>
          </>
        }
      />

      <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
        <div className="flex items-center justify-between gap-2 px-4 py-3.5 border-b border-[#eaf1ef]">
          <div>
            <h3 className="text-sm font-extrabold text-[#102523]">بيانات أذون الصرف ({fmtNum(filteredIssues.length)})</h3>
            <p className="text-[11.5px] text-[#5c7471]">اضغط على السهم بجانب أي أذن لمعاينة بنوده مباشرة أو افتح التفاصيل والطباعة</p>
          </div>
        </div>

        {filteredIssues.length ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="bg-[#f7fbfa] text-[#5c7471] border-b border-[#dce6e3]">
                  <th className="py-2.5 px-3 text-right font-bold">رقم الأذن والتاريخ</th>
                  <th className="py-2.5 px-3 text-right font-bold">الإيصالات المرفقة</th>
                  <th className="py-2.5 px-3 text-right font-bold">العميل / الفاتورة</th>
                  <th className="py-2.5 px-3 text-right font-bold">المخزن</th>
                  <th className="py-2.5 px-3 text-center font-bold">البنود</th>
                  <th className="py-2.5 px-3 text-left font-bold">قيمة الفاتورة</th>
                  <th className="py-2.5 px-3 text-center font-bold">تم عمل فاتورة / الحالة</th>
                  <th className="py-2.5 px-3 text-left font-bold">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#edf3f1]">
                {filteredIssues.map(i => {
                  const w = getWarehouse(i.warehouseId);
                  const val = calcIssueValue(i, db.products);
                  const rs = issueReturnStats(i);
                  const hasBillable = i.lines.some(l => !isLineReceipt(l, getProduct(l.productId)));
                  const receiptGroups = getIssueReceipts(i, db.products);
                  const mixed = hasBillable && receiptGroups.length > 0;
                  const isExpanded = expandedId === i.id;
                  const custPartner =
                    getPartner(i.customerId) ||
                    db.partners.find(p => p.type === 'customer' && p.name === i.customer);
                  const custInfo = resolveIssueCustomer(i, db.partners);

                  return (
                    <React.Fragment key={i.id}>
                      <tr className={`hover:bg-[#f9fcfb] ${isExpanded ? 'bg-[#f4fbf9]' : ''}`}>
                        <td className="py-2.5 px-3">
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => setExpandedId(isExpanded ? null : i.id)}
                              className="p-1 rounded border border-[#dce6e3] bg-white text-[#233d3a] hover:bg-[#eef8f6] cursor-pointer"
                              title={isExpanded ? 'إخفاء البنود' : 'عرض البنود'}
                            >
                              {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                            </button>
                            <div>
                              <div className="font-mono-num font-extrabold text-[#0f766e]">{i.no}</div>
                              <div className="text-[11px] text-[#5c7471]">{fmtDate(i.date)}</div>
                            </div>
                          </div>
                        </td>
                        <td className="py-2.5 px-3">
                          {receiptGroups.length > 0 ? (
                            <div className="space-y-1">
                              {receiptGroups.map(g => (
                                <div
                                  key={g.type}
                                  className={`text-[11px] font-bold font-mono-num ${
                                    g.type === 'gift' ? 'text-[#6d28d9]' : 'text-[#b45309]'
                                  }`}
                                >
                                  {g.receiptNo} · {g.label}
                                </div>
                              ))}
                            </div>
                          ) : (
                            <span className="text-[11px] text-[#6b8481]">بدون إيصال</span>
                          )}
                        </td>
                        <td className="py-2.5 px-3">
                          <div className="font-bold text-[#102523]">{custInfo.name}</div>
                          <div className="text-[11px] text-[#5c7471]">
                            فاتورة {i.invoiceNo || '—'}
                            {custInfo.phone ? ` · ${custInfo.phone}` : ''}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-[#3b5653]">{w?.name || '—'}</td>
                        <td className="py-2.5 px-3 text-center tabular-nums">
                          <span className="font-bold text-[#102523]">{i.lines.length}</span>
                          <span className="text-[10.5px] text-[#5c7471] mr-1">بند</span>
                        </td>
                        <td className="py-2.5 px-3 text-left tabular-nums">
                          <div className="font-bold">{fmtMoney(val)} ج.م</div>
                          {val > 0 && (
                            <>
                              <div className="text-[10.5px] text-[#5c7471]">14%: {fmtMoney(calc14Percent(val))} ج.م</div>
                              <div className="text-[10.5px] font-extrabold text-[#0f766e]">
                                الإجمالي: {fmtMoney(calcTotalWith14(val))} ج.م
                              </div>
                            </>
                          )}
                          {rs.returnedVal > 0 && (
                            <div className="text-[10.5px] font-bold text-[#dc2626]">
                              صافي: {fmtMoney(Math.max(0, val - rs.returnedVal))} ج.م
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <div className="inline-flex flex-col items-center gap-1">
                            <label
                              className={`inline-flex items-center gap-1.5 text-[11px] font-bold select-none ${
                                i.invoicedByFlow ? 'cursor-default text-[#0f766e]' : 'cursor-pointer text-[#233d3a]'
                              }`}
                              title={
                                i.invoicedByFlow
                                  ? 'مغلق — تم عمل فاتورة مبيعات رسمية'
                                  : 'علّم هنا إذا تم عمل فاتورة مبيعات لهذا الأذن أو لا يحتاج فاتورة'
                              }
                            >
                              <input
                                type="checkbox"
                                checked={Boolean(i.invoiced)}
                                disabled={Boolean(i.invoicedByFlow)}
                                onChange={async e => {
                                  const chk = e.target.checked;
                                  try {
                                    await setIssueInvoiced(i.id, chk);
                                    toast(
                                      chk
                                        ? `تم التعليم على ${i.no}: تم عمل فاتورة وإغلاق الأذن`
                                        : `تم إعادة فتح أذن الصرف ${i.no}`
                                    );
                                  } catch (err) {
                                    toast(err instanceof Error ? err.message : 'تعذر تحديث الحالة', 'err');
                                  }
                                }}
                                className="accent-[#0f766e] w-3.5 h-3.5 cursor-pointer disabled:cursor-not-allowed"
                              />
                              <span>
                                {i.invoiced ? (
                                  <span className="inline-flex items-center gap-1 text-[#047857]">
                                    <Lock className="w-3 h-3" />
                                    <span>{i.invoicedByFlow ? 'تمت الفاتورة (مغلق)' : 'تم عمل فاتورة (مغلق)'}</span>
                                  </span>
                                ) : (
                                  <span className="text-[#b45309]">مفتوح (لم تُعمل فاتورة)</span>
                                )}
                              </span>
                            </label>
                            {rs.status === 'full' ? (
                              <span className="text-[10.5px] font-bold text-[#dc2626]">مرتجع كلي</span>
                            ) : rs.status === 'partial' ? (
                              <span className="text-[10.5px] font-bold text-[#6d28d9]">مرتجع جزئي ({fmtNum(rs.totalReturned)})</span>
                            ) : null}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-left">
                          <div className="inline-flex flex-wrap items-center justify-end gap-1">
                            <button
                              type="button"
                              onClick={async () => {
                                try {
                                  await exportIssueToWord(i, db.company, w, db.products, { mode: 'all', customer: custPartner });
                                  toast(`تم تحميل أذن الصرف ${i.no} بالكامل بصيغة Word (.docx)`);
                                } catch {
                                  toast('تعذر إنشاء ملف Word', 'err');
                                }
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#bfdbfe] bg-[#eff6ff] text-[#1d4ed8] hover:bg-[#dbeafe] text-[11px] font-bold cursor-pointer"
                              title="تحميل أذن الصرف بالكامل (فاتورة + هدية + مستلزمات) في Word للطباعة"
                            >
                              <FileText className="w-3.5 h-3.5" />
                              <span>Word</span>
                            </button>
                            {receiptGroups.map(g => (
                              <button
                                key={g.type}
                                type="button"
                                onClick={async () => {
                                  try {
                                    await exportIssueReceiptToWord(i, db.company, w, db.products, { receiptType: g.type, customer: custPartner });
                                    toast(`تم تحميل ${g.label} (${g.receiptNo}) بصيغة Word (.docx)`);
                                  } catch {
                                    toast('تعذر إنشاء ملف الإيصال', 'err');
                                  }
                                }}
                                className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border text-[11px] font-bold cursor-pointer ${
                                  g.type === 'gift'
                                    ? 'border-[#ddd6fe] bg-[#f5f3ff] text-[#6d28d9] hover:bg-[#ede9fe]'
                                    : 'border-[#fde68a] bg-[#fffbeb] text-[#b45309] hover:bg-[#fef3c7]'
                                }`}
                                title={`تحميل ${g.label} منفصل في Word`}
                              >
                                <FileText className="w-3.5 h-3.5" />
                                <span>{receiptGroups.length > 1 ? (g.type === 'gift' ? 'إيصال هدية' : 'إيصال مستلزمات') : 'إيصال'}</span>
                              </button>
                            ))}
                            {!i.closed && !i.invoiced && hasBillable && (
                              <button
                                type="button"
                                onClick={() => onCreateSalesInvoice(i.id)}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#b7dfd7] bg-[#eef8f6] text-[#0f766e] hover:bg-[#dff2ee] text-[11px] font-extrabold cursor-pointer"
                                title="عمل فاتورة مبيعات لهذا الأذن وإغلاقه"
                              >
                                <Receipt className="w-3.5 h-3.5" />
                                <span>عمل فاتورة</span>
                              </button>
                            )}
                            {!i.closed ? (
                              <button
                                type="button"
                                onClick={() => onEditIssue(i)}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#fde68a] bg-[#fffbeb] text-[#92400e] hover:bg-[#fef3c7] text-[11px] font-bold cursor-pointer"
                                title="تعديل أذن الصرف"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                                <span>تعديل</span>
                              </button>
                            ) : (
                              <span
                                className="inline-flex items-center gap-1 px-2 py-1.5 rounded-md border border-[#dce6e3] bg-[#f8fbfa] text-[#5c7471] text-[10.5px] font-bold"
                                title="أذن الصرف مغلق بعد عمل الفاتورة"
                              >
                                <Lock className="w-3 h-3" />
                                <span>مغلق</span>
                              </span>
                            )}
                            <button
                              type="button"
                              onClick={() => onStartReturn(i.id)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#ddd6fe] bg-[#f5f3ff] text-[#6d28d9] hover:bg-[#ede9fe] text-[11px] font-bold cursor-pointer"
                              title="عمل مرتجع عميل"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                              <span>مرتجع</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => onViewIssue(i)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#dce6e3] bg-white text-[#233d3a] hover:bg-[#f4f8f7] text-[11px] font-bold cursor-pointer"
                              title="عرض التفاصيل والطباعة"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>عرض</span>
                            </button>
                          </div>
                        </td>
                      </tr>

                      {isExpanded && (
                        <tr className="bg-[#f8fbfa]">
                          <td colSpan={8} className="px-4 py-3 border-t border-[#e5efec]">
                            <div className="border border-[#dce6e3] rounded-lg overflow-hidden bg-white">
                              <div className="px-3.5 py-2 bg-[#f4f9f8] border-b border-[#dce6e3] text-[11px] flex flex-wrap items-center gap-x-4 gap-y-1">
                                <span><b className="text-[#5c7471]">بيانات العميل:</b> <b>{custInfo.name}</b></span>
                                {custInfo.code && <span className="font-mono-num text-[#0f766e]">({custInfo.code})</span>}
                                {custInfo.phone && <span><b className="text-[#5c7471]">الهاتف:</b> {custInfo.phone}</span>}
                                {custInfo.address && <span><b className="text-[#5c7471]">العنوان:</b> {custInfo.address}</span>}
                                {custInfo.taxNo && <span><b className="text-[#5c7471]">الرقم الضريبي:</b> <span className="font-mono-num">{custInfo.taxNo}</span></span>}
                                {custInfo.contact && <span><b className="text-[#5c7471]">المسؤول:</b> {custInfo.contact}</span>}
                              </div>
                              <table className="w-full text-[11.5px] border-collapse">
                                <thead>
                                  <tr className="bg-[#eef8f6] text-[#073b39] border-b border-[#dce6e3]">
                                    <th className="py-2 px-3 text-right font-bold">الكود</th>
                                    <th className="py-2 px-3 text-right font-bold">الصنف</th>
                                    <th className="py-2 px-3 text-center font-bold">التصنيف</th>
                                    <th className="py-2 px-3 text-right font-bold">التشغيلات والصلاحيات (FEFO)</th>
                                    <th className="py-2 px-3 text-right font-bold">الكمية</th>
                                    <th className="py-2 px-3 text-left font-bold">القيمة</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-[#edf3f1]">
                                  {sortIssueLines(i.lines, db.products).map((l, idx) => {
                                    const p = getProduct(l.productId);
                                    if (!p) return null;
                                    const rec = isLineReceipt(l, p);
                                    const rType = rec ? getLineReceiptType(l, p) : undefined;
                                    const label = rec ? receiptTypeLabel(rType) : 'فاتورة';
                                    return (
                                      <tr key={idx}>
                                        <td className="py-2 px-3 font-mono-num font-bold text-[#0f766e]">{p.code}</td>
                                        <td className="py-2 px-3 font-bold text-[#102523]">{p.name}</td>
                                        <td className="py-2 px-3 text-center">
                                          <span
                                            className={`font-bold ${
                                              !rec
                                                ? 'text-[#0f766e]'
                                                : rType === 'gift'
                                                  ? 'text-[#6d28d9]'
                                                  : 'text-[#b45309]'
                                            }`}
                                          >
                                            {label}
                                          </span>
                                        </td>
                                        <td className="py-2 px-3 text-[#3b5653]">
                                          {(l.alloc || []).map((a, ai) => (
                                            <span key={ai} className="inline-block ml-3 tabular-nums">
                                              لوت <b className="font-mono-num">{a.batch}</b> ({fmtDate(a.expiry)})
                                            </span>
                                          ))}
                                        </td>
                                        <td className="py-2 px-3 font-bold tabular-nums">{unitsText(l.strips, p)}</td>
                                        <td className="py-2 px-3 text-left font-bold tabular-nums">
                                          {rec ? (
                                            <span className={rType === 'gift' ? 'text-[#6d28d9] font-normal' : 'text-[#b45309] font-normal'}>
                                              بدون قيمة
                                            </span>
                                          ) : (
                                            `${fmtMoney(l.strips * l.pricePerStrip)} ج.م`
                                          )}
                                        </td>
                                      </tr>
                                    );
                                  })}
                                </tbody>
                              </table>
                              {val > 0 && (
                                <div className="border-t border-[#dce6e3] text-[11px]">
                                  <div className="flex justify-between px-3 py-1.5 bg-white border-b border-[#edf3f1]">
                                    <span className="font-bold text-[#5c7471]">القيمة الأساسية</span>
                                    <span className="font-bold tabular-nums">{fmtMoney(val)} ج.م</span>
                                  </div>
                                  <div className="flex justify-between px-3 py-1.5 bg-[#f8fbfa] border-b border-[#edf3f1]">
                                    <span className="font-bold text-[#073b39]">قيمة 14%</span>
                                    <span className="font-extrabold text-[#0f766e] tabular-nums">{fmtMoney(calc14Percent(val))} ج.م</span>
                                  </div>
                                  <div className="px-3 py-2 bg-[#eef8f6] flex flex-wrap items-center justify-between gap-2">
                                    <span className="font-extrabold text-[#073b39] tabular-nums">
                                      المبلغ الإجمالي (شامل 14%): <b className="text-[#0f766e]">{fmtMoney(calcTotalWith14(val))} ج.م</b>
                                    </span>
                                    <span className="font-extrabold text-[#14532d]">{tafqeetEGP(calcTotalWith14(val))}</span>
                                  </div>
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<FileText className="w-6 h-6" />}
            title="لا توجد أذون صرف مطابقة"
            description="أنشئ أذن صرف جديدًا أو غيّر فلاتر البحث لعرض الأذون."
            action={
              <button
                type="button"
                onClick={onCreateNew}
                className="px-4 py-2 rounded-lg bg-[#0f766e] text-white text-xs font-bold cursor-pointer"
              >
                أذن صرف جديد
              </button>
            }
          />
        )}
      </section>

      <section className="bg-white border border-[#dce6e3] rounded-xl p-3.5">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5 items-center">
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-[#6b8481] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="بحث برقم الأذن، رقم الإيصال، الفاتورة، العميل أو الصنف..."
              className="w-full pr-9 pl-3 py-2 text-xs bg-[#f8fbfa] border border-[#dce6e3] rounded-lg focus:outline-none focus:border-[#0f766e]"
            />
          </div>
          <div className="md:col-span-2">
            <select
              value={warehouseFilter}
              onChange={e => setWarehouseFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#dce6e3] rounded-lg"
            >
              <option value="all">كل المخازن</option>
              {db.warehouses.map(w => (
                <option key={w.id} value={w.id}>{w.name}</option>
              ))}
            </select>
          </div>
          <div className="md:col-span-3">
            <select
              value={kindFilter}
              onChange={e => setKindFilter(e.target.value as typeof kindFilter)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#dce6e3] rounded-lg"
            >
              <option value="all">كل أنواع الصرف</option>
              <option value="invoice">يحتوي بضاعة فاتورة</option>
              <option value="supplies">يحتوي إيصال مستلزمات</option>
              <option value="gift">يحتوي إيصال هدية بدون قيمة</option>
              <option value="mixed">مختلط (فاتورة + إيصال)</option>
            </select>
          </div>
          <div className="md:col-span-2">
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value as typeof statusFilter)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#dce6e3] rounded-lg"
            >
              <option value="all">كل الحالات</option>
              <option value="none">مسلّم بالكامل</option>
              <option value="partial">مرتجع جزئي</option>
              <option value="full">مرتجع كلي</option>
            </select>
          </div>
          <div className="md:col-span-2">
            <select
              value={invoiceStateFilter}
              onChange={e => setInvoiceStateFilter(e.target.value as typeof invoiceStateFilter)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#dce6e3] rounded-lg"
            >
              <option value="all">كل حالات الفاتورة</option>
              <option value="open">مفتوح (لم تُعمل فاتورة)</option>
              <option value="closed">مغلق (تم عمل فاتورة)</option>
            </select>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3.5">
        <KpiCard
          label="إجمالي أذون الصرف"
          value={fmtNum(filteredIssues.length)}
          unit="أذن"
          hint={`من أصل ${fmtNum(db.issues.length)} أذن مسجل`}
          icon={<FileText className="w-4 h-4" />}
          tone="teal"
        />
        <KpiCard
          label="إجمالي قيمة الفواتير"
          value={fmtMoney(totalBillableValue)}
          unit="ج.م"
          hint="لبنود الفواتير المسعّرة"
          icon={<Receipt className="w-4 h-4" />}
          tone="blue"
        />
        <KpiCard
          label="أذون بإيصالات مرفقة"
          value={fmtNum(totalWithReceipts)}
          unit="أذن"
          hint="تشمل مستلزمات أو هدية بدون قيمة"
          icon={<FileText className="w-4 h-4" />}
          tone="amber"
        />
        <KpiCard
          label="أذون بها مرتجعات"
          value={fmtNum(totalReturnedOrders)}
          unit="أذن"
          hint="مرتجع جزئي أو كلي"
          icon={<RotateCcw className="w-4 h-4" />}
          tone="violet"
        />
      </div>
    </div>
  );
}
