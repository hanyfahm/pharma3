import React, { useMemo, useState } from 'react';
import { Activity, Search } from 'lucide-react';
import { usePharmaStore } from '../store/usePharmaStore';
import type { MovementType } from '../types/pharma';
import { fmtDate, fmtNum, todayISO, unitsText } from '../utils/format';
import { exportToExcel } from '../utils/export';
import { EmptyState, ExcelButton, MOVE_LABELS, PageHeader } from '../components/ui/CommonUI';

export function MovementsPage() {
  const { db, getProduct, getWarehouse, toast } = usePharmaStore();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | MovementType>('all');

  const moves = useMemo(() => {
    const q = search.trim().toLowerCase();
    return db.movements.filter(m => {
      if (typeFilter !== 'all' && m.type !== typeFilter) return false;
      const p = getProduct(m.productId);
      const w = getWarehouse(m.warehouseId);
      if (q && !`${p?.name || ''} ${p?.code || ''} ${w?.name || ''} ${m.ref} ${m.note}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [db.movements, search, typeFilter, getProduct, getWarehouse]);

  const handleExcel = () => {
    const headers = ['التاريخ', 'نوع الحركة', 'المرجع', 'الكود', 'الصنف', 'المخزن', 'الكمية بالوحدات', 'الوحدات الأساسية', 'ملاحظة'];
    const rows = moves.map(m => {
      const p = getProduct(m.productId);
      const w = getWarehouse(m.warehouseId);
      return [
        fmtDate(m.date),
        MOVE_LABELS[m.type]?.label || m.type,
        m.ref,
        p?.code || '',
        p?.name || '—',
        w?.name || '—',
        p ? unitsText(m.strips, p) : fmtNum(m.strips),
        m.strips,
        m.note
      ];
    });
    exportToExcel(`سجل_الحركات_${todayISO()}.xlsx`, 'سجل الحركات', headers, rows);
    toast('تم تصدير سجل الحركات إلى Excel');
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="سجل الحركات"
        subtitle="سجل تدقيقي كامل لكل عمليات الوارد والصرف ومرتجع العملاء والتحويلات"
        actions={<ExcelButton onClick={handleExcel} />}
      />

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-[#6b8481] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="ابحث بالصنف أو رقم الأذن أو المخزن..."
            className="w-full pr-9 pl-3 py-2 text-xs bg-white border border-[#dce6e3] rounded-lg focus:outline-none focus:border-[#0f766e]"
          />
        </div>
        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#e9f0ee] rounded-lg">
          {(
            [
              ['all', 'الكل'],
              ['in', 'وارد'],
              ['issue', 'صرف'],
              ['return-in', 'مرتجع عميل'],
              ['transfer-in', 'تحويل وارد'],
              ['transfer-out', 'تحويل صادر']
            ] as const
          ).map(([k, lbl]) => (
            <button
              key={k}
              type="button"
              onClick={() => setTypeFilter(k)}
              className={`px-2.5 py-1.5 rounded-md text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                typeFilter === k ? 'bg-white text-[#102523] shadow-sm' : 'text-[#5c7471] hover:text-[#102523]'
              }`}
            >
              {lbl}
            </button>
          ))}
        </div>
        <span className="text-xs font-bold text-[#5c7471] tabular-nums">{fmtNum(moves.length)} حركة</span>
      </div>

      <section className="bg-white border border-[#dce6e3] rounded-xl overflow-hidden">
        {moves.length ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="bg-[#f4f8f7] text-[#5c7471] border-b border-[#dce6e3]">
                  <th className="py-2.5 px-3 text-right font-bold">التاريخ</th>
                  <th className="py-2.5 px-3 text-center font-bold">النوع</th>
                  <th className="py-2.5 px-3 text-right font-bold">المرجع</th>
                  <th className="py-2.5 px-3 text-right font-bold">الصنف</th>
                  <th className="py-2.5 px-3 text-right font-bold">المخزن</th>
                  <th className="py-2.5 px-3 text-right font-bold">الكمية</th>
                  <th className="py-2.5 px-3 text-right font-bold">ملاحظة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#edf3f1]">
                {moves.map(m => {
                  const p = getProduct(m.productId);
                  const w = getWarehouse(m.warehouseId);
                  const meta = MOVE_LABELS[m.type];
                  return (
                    <tr key={m.id} className="hover:bg-[#f9fcfb]">
                      <td className="py-2.5 px-3 tabular-nums text-[#3b5653]">{fmtDate(m.date)}</td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded-md border text-[10.5px] font-bold ${meta.cls}`}>
                          {meta.label}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-mono-num font-bold text-[#0f766e]">{m.ref}</td>
                      <td className="py-2.5 px-3 font-bold text-[#102523]">{p?.name || 'صنف محذوف'}</td>
                      <td className="py-2.5 px-3 text-[#3b5653]">{w?.name || '—'}</td>
                      <td className="py-2.5 px-3 font-bold tabular-nums">{p ? unitsText(m.strips, p) : fmtNum(m.strips)}</td>
                      <td className="py-2.5 px-3 text-[#5c7471]">{m.note}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState icon={<Activity className="w-6 h-6" />} title="لا توجد حركات مطابقة" />
        )}
      </section>
    </div>
  );
}
