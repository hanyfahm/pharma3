export type PageId =
  | 'issue-list'
  | 'invoice-list'
  | 'dashboard'
  | 'warehouses'
  | 'balance'
  | 'products'
  | 'customers'
  | 'suppliers'
  | 'incoming'
  | 'issue'
  | 'returns'
  | 'transfers'
  | 'reports'
  | 'queries'
  | 'movements';

export interface Warehouse {
  id: string;
  name: string;
  gov: string;
  share: number;
  color: string;
  kind: 'main' | 'sub';
}

export type PartnerType = 'supplier' | 'customer';

export interface Partner {
  id: string;
  code: string;
  type: PartnerType;
  name: string;
  phone: string;
  address: string;
  taxNo: string;
  contact: string;
  notes: string;
}

export interface ProductUnit {
  name: string;
  factor: number;
}

export interface Product {
  id: string;
  code: string;
  supplierId: string | null;
  name: string;
  description: string;
  form: string;
  category: string;
  marked: boolean;
  price: number;
  units: ProductUnit[];
}

export interface Batch {
  id: string;
  productId: string;
  warehouseId: string;
  batch: string;
  expiry: string; // YYYY-MM-DD
  strips: number;
}

export interface UnitQty {
  name: string;
  qty: number;
}

export interface WarehouseAlloc {
  warehouseId: string;
  strips: number;
}

export interface InvoiceLine {
  productId: string;
  strips: number;
  units: UnitQty[];
  expiry: string;
  batch: string;
  alloc: WarehouseAlloc[];
}

export interface Invoice {
  id: string;
  no: string;
  supplierId?: string;
  supplier: string;
  date: string;
  createdAt: string;
  createdBy?: string;
  totalStrips: number;
  lines: InvoiceLine[];
}

export interface LotAllocation {
  batchId?: string;
  batch: string;
  expiry: string;
  strips: number;
}

export type ReceiptType = 'supplies' | 'gift';

export interface IssueLine {
  productId: string;
  strips: number;
  pricePerStrip: number;
  asReceipt?: boolean;
  receiptType?: ReceiptType;
  alloc: LotAllocation[];
}

export interface IssueOrder {
  id: string;
  no: string; // YYYYMMDD-0001
  receiptNo?: string;
  suppliesReceiptNo?: string;
  giftReceiptNo?: string;
  receiptType?: ReceiptType;
  date: string;
  warehouseId: string;
  customerId?: string;
  customer: string;
  customerCode?: string;
  customerPhone?: string;
  customerAddress?: string;
  customerTaxNo?: string;
  customerContact?: string;
  invoiceNo: string;
  invoiceDate?: string;
  closed?: boolean;
  invoiced?: boolean;
  invoicedByFlow?: boolean;
  invoicedAt?: string;
  invoicedBy?: string;
  createdAt: string;
  createdBy?: string;
  invoiceTotal: number;
  suppliesStrips: number;
  lines: IssueLine[];
}

export interface CustomerReturnLine {
  productId: string;
  batch: string;
  expiry: string;
  strips: number;
  pricePerStrip: number;
  reason?: string;
}

export interface CustomerReturn {
  id: string;
  no: string;
  issueId: string;
  issueNo: string;
  invoiceNo: string;
  customerId?: string;
  customer: string;
  warehouseId: string;
  date: string;
  returnType: 'full' | 'partial';
  reason: string;
  totalStrips: number;
  keptStrips: number;
  totalValue: number;
  createdAt: string;
  createdBy?: string;
  lines: CustomerReturnLine[];
}

export interface TransferLine {
  productId: string;
  strips: number;
  alloc: LotAllocation[];
}

export interface TransferOrder {
  id: string;
  no: string;
  date: string;
  from: string;
  to: string;
  createdAt: string;
  createdBy?: string;
  lines: TransferLine[];
}

export type MovementType = 'in' | 'issue' | 'return-in' | 'transfer-in' | 'transfer-out';

export interface Movement {
  id: string;
  type: MovementType;
  productId: string;
  warehouseId: string;
  strips: number;
  ref: string;
  note: string;
  date: string;
  createdAt: string;
}

export interface CompanyInfo {
  name: string;
  address: string;
  gov: string;
  phone: string;
  taxNo: string;
  sales: string;
}

export interface DBMeta {
  nextIssue: number;
  issueSeqDate: string;
  issueSeq: number;
  returnSeq: number;
  nextTransfer: number;
  nextInvoice: number;
  seq: number;
}

export interface AppDB {
  version: number;
  warehouses: Warehouse[];
  partners: Partner[];
  products: Product[];
  batches: Batch[];
  invoices: Invoice[];
  issues: IssueOrder[];
  returns: CustomerReturn[];
  transfers: TransferOrder[];
  movements: Movement[];
  company: CompanyInfo;
  meta: DBMeta;
}

export interface DraftIncomingLine {
  id: string;
  productId: string;
  strips: number;
  units: UnitQty[];
  expiry: string;
  batch: string;
  manualAlloc?: Record<string, number>;
}

export interface DraftIncoming {
  no: string;
  supplierId: string;
  date: string;
  mode: 'shares' | 'equal' | 'manual';
  lines: DraftIncomingLine[];
}

export interface DraftIssueLine {
  id: string;
  productId: string;
  strips: number;
  units: UnitQty[];
  asReceipt?: boolean;
  receiptType?: ReceiptType;
}

export interface DraftIssue {
  editingIssueId?: string;
  no: string;
  receiptNo?: string;
  suppliesReceiptNo?: string;
  giftReceiptNo?: string;
  receiptType?: ReceiptType;
  warehouseId: string;
  invoiceNo: string;
  invoiced?: boolean;
  customerId: string;
  date: string;
  lines: DraftIssueLine[];
}

export interface DraftTransferLine {
  id: string;
  productId: string;
  strips: number;
  units: UnitQty[];
}

export interface DraftTransfer {
  no: string;
  from: string;
  to: string;
  date: string;
  lines: DraftTransferLine[];
}

export interface TeamMember {
  clientId: string;
  name: string;
  joinedAt: string;
}
