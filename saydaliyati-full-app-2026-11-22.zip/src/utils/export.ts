import {
  AlignmentType,
  BorderStyle,
  convertMillimetersToTwip,
  Document,
  HeightRule,
  Packer,
  Paragraph,
  ShadingType,
  Table,
  TableCell,
  TableLayoutType,
  TableRow,
  TextRun,
  VerticalAlign,
  WidthType
} from 'docx';
import * as XLSX from 'xlsx';
import type {
  AppDB,
  Batch,
  CompanyInfo,
  CustomerReturn,
  Invoice,
  IssueOrder,
  Partner,
  Product,
  ReceiptType,
  TransferOrder,
  Warehouse
} from '../types/pharma';
import {
  calc14Percent,
  calcInvoiceValue,
  calcIssueValue,
  calcTotalWith14,
  escHtml,
  expiryState,
  fmtDate,
  fmtMoney,
  fmtNum,
  getIssueReceipts,
  getLineReceiptType,
  isLineReceipt,
  receiptTypeLabel,
  resolveIssueCustomer,
  type ResolvedCustomerInfo,
  sortIssueLines,
  sortIssuesByInvoiceStatus,
  tafqeetEGP,
  todayISO,
  toFullDate,
  unitsText
} from './format';

export type ExcelCell = string | number | { value: string | number; type?: 'Number' | 'String' };

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 150);
}

/**
 * تصدير جداول إلى إكسل بصيغة أصلية (.xlsx)
 * يدعم العربية الكاملة، اتجاه RTL، عرض الأعمدة التلقائي، والأرقام الحقيقية
 */
export function exportToExcel(
  filename: string,
  sheetName: string,
  headers: string[],
  rows: ExcelCell[][],
  footerRow?: ExcelCell[]
) {
  const safeSheet = sheetName.replace(/[\\/?*[\]:]/g, ' ').trim().slice(0, 31) || 'Sheet1';

  const normalizeCell = (cell: ExcelCell): string | number => {
    if (cell !== null && typeof cell === 'object') {
      if (cell.type === 'Number' || typeof cell.value === 'number') {
        const n = Number(cell.value);
        return isNaN(n) ? 0 : n;
      }
      return String(cell.value ?? '');
    }
    if (typeof cell === 'number' && !isNaN(cell)) {
      return cell;
    }
    return String(cell ?? '');
  };

  const aoa: (string | number)[][] = [
    headers.map(h => String(h ?? '')),
    ...rows.map(r => r.map(normalizeCell))
  ];

  if (footerRow && footerRow.length) {
    aoa.push(footerRow.map(normalizeCell));
  }

  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!views'] = [{ rightToLeft: true }];

  const colCount = headers.length;
  ws['!cols'] = Array.from({ length: colCount }, (_, colIdx) => {
    let maxLen = String(headers[colIdx] ?? '').length;
    for (let r = 1; r < aoa.length; r++) {
      const val = aoa[r]?.[colIdx];
      const len = val == null ? 0 : String(val).length;
      if (len > maxLen) maxLen = len;
    }
    // الحد الأدنى ~3 سم (16 خانة ≈ 114px)
    return { wch: Math.min(54, Math.max(16, maxLen + 4)) };
  });
  // ارتفاع كل صف ~1 سم (28.35 نقطة)
  ws['!rows'] = aoa.map(() => ({ hpt: 28.5 }));

  const wb = XLSX.utils.book_new();
  wb.Workbook = { Views: [{ RTL: true }] };
  XLSX.utils.book_append_sheet(wb, ws, safeSheet);

  const out = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const baseName = filename.replace(/\.xlsx?$/i, '');
  const finalName = `${baseName}.xlsx`;
  downloadBlob(
    new Blob([out], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    }),
    finalName
  );
}

// =====================================================================
// Native Word (.docx) Generator — Clean A4 RTL Structured Table Design
// =====================================================================

const DOC_FONT = {
  ascii: 'Arial',
  hAnsi: 'Arial',
  cs: 'Arial',
  eastAsia: 'Arial'
};

// A4 width (210mm) minus 2 * 12mm margins = 186mm ≈ 10545 DXA
const PAGE_CONTENT_TWIPS = convertMillimetersToTwip(186);

const COLORS = {
  tealDark: '073B39',
  tealPrimary: '0F766E',
  tealFrame: '0B4F4B',
  tealTint: 'EEF8F6',
  tealSoft: 'F4F9F8',
  zebra: 'F8FBFA',
  white: 'FFFFFF',
  ink: '0F172A',
  muted: '475569',
  gridBorder: 'CBD5E1',
  innerFrame: '99C2BA',
  violet: '5B21B6',
  danger: 'B91C1C',
  amber: 'B45309'
};

type AlignKind = (typeof AlignmentType)[keyof typeof AlignmentType];

function rtlRun(
  text: string,
  opts: { bold?: boolean; size?: number; color?: string } = {}
): TextRun {
  return new TextRun({
    text: text || '',
    bold: opts.bold,
    size: opts.size ?? 20, // 10pt
    color: opts.color ?? COLORS.ink,
    font: DOC_FONT,
    rightToLeft: true
  });
}

function rtlParagraph(
  children: TextRun[],
  opts: {
    alignment?: AlignKind;
    before?: number;
    after?: number;
    line?: number;
  } = {}
): Paragraph {
  return new Paragraph({
    children,
    bidirectional: true,
    alignment: opts.alignment ?? AlignmentType.RIGHT,
    spacing: {
      before: opts.before ?? 0,
      after: opts.after ?? 30,
      line: opts.line ?? 260
    }
  });
}

function kvLine(label: string, value: string, opts: { size?: number; boldValue?: boolean } = {}): Paragraph {
  return rtlParagraph(
    [
      rtlRun(`${label}: `, { bold: true, size: opts.size ?? 19, color: COLORS.tealDark }),
      rtlRun(value || '—', { bold: opts.boldValue, size: opts.size ?? 19, color: COLORS.ink })
    ],
    { after: 40, line: 250 }
  );
}

const CELL_PADDING = { top: 85, bottom: 85, left: 100, right: 100 };
const HEADER_CELL_PADDING = { top: 105, bottom: 105, left: 95, right: 95 };

const FRAME_BORDER = { style: BorderStyle.SINGLE, size: 12, color: COLORS.tealFrame };
const INNER_FRAME_BORDER = { style: BorderStyle.SINGLE, size: 4, color: COLORS.innerFrame };
const GRID_BORDER = { style: BorderStyle.SINGLE, size: 4, color: COLORS.gridBorder };
const HEADER_BOTTOM_BORDER = { style: BorderStyle.SINGLE, size: 12, color: COLORS.tealDark };

interface DocHeaderConfig {
  company: CompanyInfo;
  docTitle: string;
  docNumber: string;
  docSubtitle?: string;
  accentColor?: string;
  metaLines: Array<{ label: string; value: string; boldValue?: boolean }>;
  includeCompanyTax?: boolean;
  customerBox?: ResolvedCustomerInfo;
}

function buildHeaderBannerTable(cfg: DocHeaderConfig): Table {
  const rightW = 3650;
  const centerW = 3245;
  const leftW = PAGE_CONTENT_TWIPS - rightW - centerW;

  const companyParas: Paragraph[] = [
    rtlParagraph([rtlRun(cfg.company.name, { bold: true, size: 24, color: COLORS.tealDark })], {
      after: 55
    }),
    kvLine(
      'العنوان',
      `${cfg.company.address || '—'}${cfg.company.gov ? ` — ${cfg.company.gov}` : ''}`,
      { size: 18 }
    ),
    kvLine('الهاتف', cfg.company.phone || '—', { size: 18 })
  ];
  if (cfg.includeCompanyTax) {
    companyParas.push(kvLine('الرقم الضريبي', cfg.company.taxNo || '—', { size: 18 }));
  }

  const centerParas: Paragraph[] = [
    rtlParagraph(
      [rtlRun(cfg.docTitle, { bold: true, size: 26, color: cfg.accentColor ?? COLORS.tealDark })],
      { alignment: AlignmentType.CENTER, after: 65 }
    ),
    rtlParagraph([rtlRun(cfg.docNumber, { bold: true, size: 24, color: COLORS.tealPrimary })], {
      alignment: AlignmentType.CENTER,
      after: 55
    })
  ];
  if (cfg.docSubtitle) {
    centerParas.push(
      rtlParagraph([rtlRun(cfg.docSubtitle, { bold: true, size: 18, color: COLORS.muted })], {
        alignment: AlignmentType.CENTER,
        after: 0
      })
    );
  }

  const metaParas = cfg.metaLines.map(m =>
    kvLine(m.label, m.value, { size: 18, boldValue: m.boldValue })
  );

  const tableRows: TableRow[] = [
    new TableRow({
      cantSplit: true,
      children: [
        new TableCell({
          width: { size: rightW, type: WidthType.DXA },
          margins: { top: 110, bottom: 110, left: 120, right: 120 },
          verticalAlign: VerticalAlign.CENTER,
          shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.white },
          children: companyParas
        }),
        new TableCell({
          width: { size: centerW, type: WidthType.DXA },
          margins: { top: 110, bottom: 110, left: 100, right: 100 },
          verticalAlign: VerticalAlign.CENTER,
          shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.tealTint },
          children: centerParas
        }),
        new TableCell({
          width: { size: leftW, type: WidthType.DXA },
          margins: { top: 110, bottom: 110, left: 120, right: 120 },
          verticalAlign: VerticalAlign.CENTER,
          shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.white },
          children: metaParas
        })
      ]
    })
  ];

  if (cfg.customerBox) {
    const c = cfg.customerBox;
    const line1Runs: TextRun[] = [
      rtlRun('بيانات العميل: ', { bold: true, size: 19, color: COLORS.tealDark }),
      rtlRun(c.name || '—', { bold: true, size: 19, color: COLORS.ink })
    ];
    if (c.code) {
      line1Runs.push(rtlRun('   |   كود العميل: ', { bold: true, size: 18, color: COLORS.tealDark }));
      line1Runs.push(rtlRun(c.code, { bold: true, size: 18, color: COLORS.ink }));
    }
    if (c.contact) {
      line1Runs.push(rtlRun('   |   المسؤول: ', { bold: true, size: 18, color: COLORS.tealDark }));
      line1Runs.push(rtlRun(c.contact, { size: 18, color: COLORS.ink }));
    }

    const line2Runs: TextRun[] = [
      rtlRun('الهاتف: ', { bold: true, size: 18, color: COLORS.tealDark }),
      rtlRun(c.phone || '—', { size: 18, color: COLORS.ink }),
      rtlRun('   |   العنوان: ', { bold: true, size: 18, color: COLORS.tealDark }),
      rtlRun(c.address || '—', { size: 18, color: COLORS.ink }),
      rtlRun('   |   الرقم الضريبي: ', { bold: true, size: 18, color: COLORS.tealDark }),
      rtlRun(c.taxNo || '—', { size: 18, color: COLORS.ink })
    ];

    tableRows.push(
      new TableRow({
        cantSplit: true,
        children: [
          new TableCell({
            columnSpan: 3,
            width: { size: PAGE_CONTENT_TWIPS, type: WidthType.DXA },
            margins: { top: 90, bottom: 90, left: 120, right: 120 },
            shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.tealSoft },
            children: [
              rtlParagraph(line1Runs, { after: 35, line: 240 }),
              rtlParagraph(line2Runs, { after: 0, line: 240 })
            ]
          })
        ]
      })
    );
  }

  return new Table({
    visuallyRightToLeft: true,
    layout: TableLayoutType.FIXED,
    width: { size: PAGE_CONTENT_TWIPS, type: WidthType.DXA },
    columnWidths: [rightW, centerW, leftW],
    borders: {
      top: FRAME_BORDER,
      bottom: FRAME_BORDER,
      left: FRAME_BORDER,
      right: FRAME_BORDER,
      insideHorizontal: INNER_FRAME_BORDER,
      insideVertical: INNER_FRAME_BORDER
    },
    rows: tableRows
  });
}

interface DataColumnDef {
  title: string;
  width: number;
  align?: AlignKind;
}

interface DataCellContent {
  primary: string;
  secondary?: string;
  bold?: boolean;
  color?: string;
  align?: AlignKind;
}

function buildItemsDataTable(
  columns: DataColumnDef[],
  dataRows: DataCellContent[][],
  summaryRow?: { label: string; value: string }
): Table {
  const rowHeight1Cm = convertMillimetersToTwip(10);
  const headerRow = new TableRow({
    tableHeader: true,
    cantSplit: true,
    height: { value: rowHeight1Cm, rule: HeightRule.ATLEAST },
    children: columns.map(col =>
      new TableCell({
        width: { size: col.width, type: WidthType.DXA },
        margins: HEADER_CELL_PADDING,
        verticalAlign: VerticalAlign.CENTER,
        shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.tealPrimary },
        borders: {
          top: FRAME_BORDER,
          bottom: HEADER_BOTTOM_BORDER,
          left: INNER_FRAME_BORDER,
          right: INNER_FRAME_BORDER
        },
        children: [
          rtlParagraph([rtlRun(col.title, { bold: true, size: 19, color: COLORS.white })], {
            alignment: col.align ?? AlignmentType.CENTER,
            after: 0,
            line: 240
          })
        ]
      })
    )
  });

  // Strictly render ONLY populated rows — zero empty/filler rows
  const bodyRows = dataRows.map((cells, rIdx) => {
    const rowFill = rIdx % 2 === 1 ? COLORS.zebra : COLORS.white;
    return new TableRow({
      cantSplit: true,
      height: { value: rowHeight1Cm, rule: HeightRule.ATLEAST },
      children: cells.map((cell, cIdx) => {
        const col = columns[cIdx];
        const cellParas: Paragraph[] = [
          rtlParagraph(
            [
              rtlRun(cell.primary || '—', {
                bold: cell.bold,
                size: 19,
                color: cell.color ?? COLORS.ink
              })
            ],
            {
              alignment: cell.align ?? col.align ?? AlignmentType.RIGHT,
              after: cell.secondary ? 25 : 0,
              line: 240
            }
          )
        ];
        if (cell.secondary) {
          cellParas.push(
            rtlParagraph([rtlRun(cell.secondary, { size: 16, color: COLORS.muted })], {
              alignment: cell.align ?? col.align ?? AlignmentType.RIGHT,
              after: 0,
              line: 210
            })
          );
        }
        return new TableCell({
          width: { size: col.width, type: WidthType.DXA },
          margins: CELL_PADDING,
          verticalAlign: VerticalAlign.CENTER,
          shading: { type: ShadingType.CLEAR, color: 'auto', fill: rowFill },
          children: cellParas
        });
      })
    });
  });

  const rows: TableRow[] = [headerRow, ...bodyRows];

  if (summaryRow && columns.length >= 2) {
    const lastColWidth = columns[columns.length - 1].width;
    const spanWidth = PAGE_CONTENT_TWIPS - lastColWidth;
    rows.push(
      new TableRow({
        cantSplit: true,
        height: { value: rowHeight1Cm, rule: HeightRule.ATLEAST },
        children: [
          new TableCell({
            columnSpan: columns.length - 1,
            width: { size: spanWidth, type: WidthType.DXA },
            margins: CELL_PADDING,
            verticalAlign: VerticalAlign.CENTER,
            shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.tealTint },
            borders: {
              top: HEADER_BOTTOM_BORDER,
              bottom: FRAME_BORDER,
              left: INNER_FRAME_BORDER,
              right: FRAME_BORDER
            },
            children: [
              rtlParagraph([rtlRun(summaryRow.label, { bold: true, size: 19, color: COLORS.tealDark })], {
                alignment: AlignmentType.RIGHT,
                after: 0
              })
            ]
          }),
          new TableCell({
            width: { size: lastColWidth, type: WidthType.DXA },
            margins: CELL_PADDING,
            verticalAlign: VerticalAlign.CENTER,
            shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.tealTint },
            borders: {
              top: HEADER_BOTTOM_BORDER,
              bottom: FRAME_BORDER,
              left: FRAME_BORDER,
              right: INNER_FRAME_BORDER
            },
            children: [
              rtlParagraph([rtlRun(summaryRow.value, { bold: true, size: 19, color: COLORS.tealDark })], {
                alignment: AlignmentType.CENTER,
                after: 0
              })
            ]
          })
        ]
      })
    );
  }

  return new Table({
    visuallyRightToLeft: true,
    layout: TableLayoutType.FIXED,
    width: { size: PAGE_CONTENT_TWIPS, type: WidthType.DXA },
    columnWidths: columns.map(c => c.width),
    borders: {
      top: FRAME_BORDER,
      bottom: FRAME_BORDER,
      left: FRAME_BORDER,
      right: FRAME_BORDER,
      insideHorizontal: GRID_BORDER,
      insideVertical: GRID_BORDER
    },
    rows
  });
}

function buildSignatureFooterTable(
  cols: [
    { title: string; subtitle: string; boldSubtitle?: boolean },
    { title: string; subtitle: string; boldSubtitle?: boolean },
    { title: string; subtitle: string; boldSubtitle?: boolean }
  ]
): Table {
  const w1 = 3515;
  const w2 = 3515;
  const w3 = PAGE_CONTENT_TWIPS - w1 - w2;
  const widths = [w1, w2, w3];

  return new Table({
    visuallyRightToLeft: true,
    layout: TableLayoutType.FIXED,
    width: { size: PAGE_CONTENT_TWIPS, type: WidthType.DXA },
    columnWidths: widths,
    borders: {
      top: FRAME_BORDER,
      bottom: FRAME_BORDER,
      left: FRAME_BORDER,
      right: FRAME_BORDER,
      insideHorizontal: INNER_FRAME_BORDER,
      insideVertical: INNER_FRAME_BORDER
    },
    rows: [
      new TableRow({
        cantSplit: true,
        height: { value: 1120, rule: HeightRule.ATLEAST },
        children: cols.map((c, idx) =>
          new TableCell({
            width: { size: widths[idx], type: WidthType.DXA },
            margins: { top: 120, bottom: 120, left: 100, right: 100 },
            verticalAlign: VerticalAlign.CENTER,
            shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.tealSoft },
            children: [
              rtlParagraph([rtlRun(c.title, { bold: true, size: 20, color: COLORS.tealDark })], {
                alignment: AlignmentType.CENTER,
                after: 220
              }),
              rtlParagraph(
                [
                  rtlRun(c.subtitle, {
                    bold: c.boldSubtitle,
                    size: 19,
                    color: c.boldSubtitle ? COLORS.ink : COLORS.muted
                  })
                ],
                { alignment: AlignmentType.CENTER, after: 0 }
              )
            ]
          })
        )
      })
    ]
  });
}

function spacerParagraph(size = 160): Paragraph {
  return new Paragraph({
    children: [],
    spacing: { before: 0, after: size, line: 120 }
  });
}

async function saveDocxDocument(
  title: string,
  children: (Table | Paragraph)[],
  filename: string
): Promise<void> {
  const doc = new Document({
    title,
    creator: 'صيدليتي',
    sections: [
      {
        properties: {
          page: {
            size: {
              width: convertMillimetersToTwip(210),
              height: convertMillimetersToTwip(297)
            },
            margin: {
              top: convertMillimetersToTwip(11),
              bottom: convertMillimetersToTwip(11),
              left: convertMillimetersToTwip(12),
              right: convertMillimetersToTwip(12)
            }
          }
        },
        children
      }
    ]
  });

  const blob = await Packer.toBlob(doc);
  const docxBlob = new Blob([blob], {
    type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  });
  downloadBlob(docxBlob, filename.endsWith('.docx') ? filename : `${filename}.docx`);
}

/**
 * تصدير أذن الصرف إلى Word (.docx) بفورمة جدولية نظيفة بدون صفوف فارغة وبدون أسعار:
 * - أعلى يمين: بيانات الشركة
 * - أعلى وسط: عنوان الأذن + الرقم المتسلسل + التاريخ
 * - أعلى يسار: العميل، المخزن الصارف، رقم الفاتورة، المندوب
 * - الوسط: جدول المواد بالكميات والتشغيلة وتاريخ الصلاحية بدون سعر (الصفوف الممتلئة فقط)
 * - النهاية: المُسلِّم | تاريخ اليوم | التوقيع
 */
export async function exportIssueToWord(
  issue: IssueOrder,
  company: CompanyInfo,
  warehouse: Warehouse | undefined,
  products: Product[],
  opts?: { mode?: 'all' | 'billable'; customer?: Partner }
): Promise<void> {
  const onlyBillable = opts?.mode === 'billable';
  const rows: DataCellContent[][] = [];
  let rowIndex = 1;
  let totalStrips = 0;

  sortIssueLines(issue.lines || [], products).forEach(line => {
    const p = products.find(x => x.id === line.productId);
    if (!p) return;
    if (onlyBillable && isLineReceipt(line, p)) return;
    const allocs =
      line.alloc && line.alloc.length
        ? line.alloc
        : [{ batch: '—', expiry: '', strips: line.strips }];

    const isRec = isLineReceipt(line, p);
    const kindLabel = isRec ? receiptTypeLabel(getLineReceiptType(line, p)) : 'فاتورة';
    const descLine = [p.form, p.description, kindLabel].filter(Boolean).join(' — ');

    allocs.forEach(a => {
      totalStrips += a.strips;
      rows.push([
        { primary: String(rowIndex++), align: AlignmentType.CENTER },
        { primary: p.code, bold: true, align: AlignmentType.CENTER },
        {
          primary: p.name,
          secondary: descLine || undefined,
          bold: true,
          align: AlignmentType.RIGHT
        },
        { primary: a.batch || '—', align: AlignmentType.CENTER },
        { primary: a.expiry ? fmtDate(a.expiry) : '—', bold: true, align: AlignmentType.CENTER },
        {
          primary: unitsText(a.strips, p),
          secondary: `(${fmtNum(a.strips)} ${p.units[0]?.name || 'وحدة'})`,
          bold: true,
          align: AlignmentType.CENTER
        }
      ]);
    });
  });

  const receiptGroups = getIssueReceipts(issue, products);

  const metaLines: Array<{ label: string; value: string; boldValue?: boolean }> = [
    { label: 'العميل', value: issue.customer || '—', boldValue: true },
    { label: 'المخزن الصارف', value: warehouse ? warehouse.name : '—' },
    { label: 'رقم الفاتورة', value: issue.invoiceNo || '—' },
    { label: 'المندوب', value: company.sales || '—' }
  ];
  if (receiptGroups.length === 1) {
    metaLines.push({
      label: 'رقم الإيصال المرفق',
      value: `${receiptGroups[0].receiptNo} (${receiptGroups[0].label})`
    });
  } else if (receiptGroups.length > 1) {
    metaLines.push({
      label: 'الإيصالات المرفقة',
      value: receiptGroups.map(g => `${g.receiptNo} (${g.label})`).join(' · ')
    });
  }

  const customerInfo = resolveIssueCustomer(issue, opts?.customer);

  const headerTable = buildHeaderBannerTable({
    company,
    docTitle: onlyBillable ? 'أذن صرف مخزني (بضاعة الفاتورة)' : 'أذن صرف مخزني',
    docNumber: `أذن رقم: ${issue.no}`,
    docSubtitle: `التاريخ: ${fmtDate(issue.date)}`,
    includeCompanyTax: true,
    metaLines,
    customerBox: customerInfo
  });

  const itemsTable = buildItemsDataTable(
    [
      { title: 'م', width: 560, align: AlignmentType.CENTER },
      { title: 'الكود', width: 1040, align: AlignmentType.CENTER },
      { title: 'هيكل المواد (الصنف والوصف)', width: 3445, align: AlignmentType.RIGHT },
      { title: 'التشغيلة (Lot)', width: 1500, align: AlignmentType.CENTER },
      { title: 'تاريخ الصلاحية', width: 1550, align: AlignmentType.CENTER },
      { title: 'الكمية المصروفة', width: 2450, align: AlignmentType.CENTER }
    ],
    rows,
    {
      label: `إجمالي عدد السطور الفعلية: ${fmtNum(rows.length)} سطر`,
      value: `${fmtNum(totalStrips)} وحدة أساسية`
    }
  );

  const footerTable = buildSignatureFooterTable([
    { title: 'المُسلِّم', subtitle: company.sales || 'أمين المخزن', boldSubtitle: true },
    { title: 'تاريخ اليوم', subtitle: fmtDate(todayISO()), boldSubtitle: true },
    { title: 'التوقيع', subtitle: '........................................' }
  ]);

  await saveDocxDocument(
    `أذن صرف ${issue.no}`,
    [headerTable, spacerParagraph(150), itemsTable, spacerParagraph(200), footerTable],
    `اذن_صرف_${issue.no}.docx`
  );
}

/**
 * تصدير إيصال تسليم منفصل (.docx) للبنود المعلّمة كإيصال.
 * إذا وُجد نوعا الإيصال معًا (مستلزمات + هدية بدون قيمة) يصدر كل إيصال في ملف مستقل.
 */
export async function exportIssueReceiptToWord(
  issue: IssueOrder,
  company: CompanyInfo,
  warehouse: Warehouse | undefined,
  products: Product[],
  opts?: { receiptType?: ReceiptType; customer?: Partner }
): Promise<void> {
  const customerInfo = resolveIssueCustomer(issue, opts?.customer);
  const allGroups = getIssueReceipts(issue, products);
  const targetGroups = opts?.receiptType
    ? allGroups.filter(g => g.type === opts.receiptType)
    : allGroups;

  if (!targetGroups.length) {
    throw new Error('لا توجد بنود إيصال مطابقة في هذا الأذن');
  }

  for (const group of targetGroups) {
    const rows: DataCellContent[][] = [];
    let rowIndex = 1;
    let totalStrips = 0;

    group.lines.forEach(line => {
      const p = products.find(x => x.id === line.productId);
      if (!p) return;
      const allocs =
        line.alloc && line.alloc.length
          ? line.alloc
          : [{ batch: '—', expiry: '', strips: line.strips }];

      allocs.forEach(a => {
        totalStrips += a.strips;
        const descParts = [p.form, p.description, group.label].filter(Boolean).join(' — ');
        rows.push([
          { primary: String(rowIndex++), align: AlignmentType.CENTER },
          { primary: p.code, bold: true, align: AlignmentType.CENTER },
          {
            primary: p.name,
            secondary: descParts || undefined,
            bold: true,
            align: AlignmentType.RIGHT
          },
          { primary: a.batch || '—', align: AlignmentType.CENTER },
          { primary: a.expiry ? fmtDate(a.expiry) : '—', bold: true, align: AlignmentType.CENTER },
          {
            primary: unitsText(a.strips, p),
            secondary: `(${fmtNum(a.strips)} ${p.units[0]?.name || 'وحدة'})`,
            bold: true,
            align: AlignmentType.CENTER
          }
        ]);
      });
    });

    if (!rows.length) continue;

    const headerTable = buildHeaderBannerTable({
      company,
      docTitle: group.label,
      docNumber: `إيصال: ${group.receiptNo}`,
      docSubtitle: `أذن الصرف: ${issue.no} · ${fmtDate(issue.date)}`,
      accentColor: group.type === 'gift' ? COLORS.violet : COLORS.amber,
      includeCompanyTax: true,
      customerBox: customerInfo,
      metaLines: [
        { label: 'العميل', value: customerInfo.name, boldValue: true },
        { label: 'نوع الإيصال', value: group.label, boldValue: true },
        { label: 'رقم أذن الصرف', value: issue.no, boldValue: true },
        { label: 'رقم الإيصال', value: group.receiptNo, boldValue: true },
        { label: 'المخزن الصارف', value: warehouse ? warehouse.name : '—' },
        { label: 'المندوب', value: company.sales || '—' }
      ]
    });

    const itemsTable = buildItemsDataTable(
      [
        { title: 'م', width: 560, align: AlignmentType.CENTER },
        { title: 'الكود', width: 1040, align: AlignmentType.CENTER },
        { title: 'البيان (الصنف)', width: 3445, align: AlignmentType.RIGHT },
        { title: 'التشغيلة (Lot)', width: 1500, align: AlignmentType.CENTER },
        { title: 'تاريخ الصلاحية', width: 1550, align: AlignmentType.CENTER },
        { title: 'الكمية المسلّمة', width: 2450, align: AlignmentType.CENTER }
      ],
      rows,
      {
        label: `${group.label} (${fmtNum(rows.length)} سطر بدون قيمة فاتورة)`,
        value: `${fmtNum(totalStrips)} وحدة أساسية`
      }
    );

    const footerTable = buildSignatureFooterTable([
      { title: 'المُسلِّم', subtitle: company.sales || 'أمين المخزن', boldSubtitle: true },
      { title: 'تاريخ اليوم', subtitle: fmtDate(todayISO()), boldSubtitle: true },
      { title: 'توقيع المستلم', subtitle: '........................................' }
    ]);

    const kindSlug = group.type === 'gift' ? 'هدية' : 'مستلزمات';
    await saveDocxDocument(
      `${group.label} ${group.receiptNo}`,
      [headerTable, spacerParagraph(150), itemsTable, spacerParagraph(200), footerTable],
      `ايصال_${kindSlug}_${group.receiptNo}_اذن_${issue.no}.docx`
    );
  }
}

export async function exportWarehouseReceiptToWord(
  warehouse: Warehouse,
  batches: Batch[],
  products: Product[],
  company: CompanyInfo
): Promise<void> {
  let totalStrips = 0;
  let validStrips = 0;
  let rowIndex = 1;
  const rows: DataCellContent[][] = [];

  batches.forEach(b => {
    const p = products.find(x => x.id === b.productId);
    if (!p) return;
    totalStrips += b.strips;
    const st = expiryState(b.expiry);
    if (st !== 'expired') validStrips += b.strips;
    const statusLabel = st === 'expired' ? 'منتهي الصلاحية' : st === 'soon' ? 'قارب الانتهاء' : 'ساري';
    const statusColor =
      st === 'expired' ? COLORS.danger : st === 'soon' ? COLORS.amber : COLORS.tealPrimary;

    rows.push([
      { primary: String(rowIndex++), align: AlignmentType.CENTER },
      { primary: p.code, bold: true, align: AlignmentType.CENTER },
      {
        primary: p.name,
        secondary: p.form || undefined,
        bold: true,
        align: AlignmentType.RIGHT
      },
      { primary: b.batch, align: AlignmentType.CENTER },
      { primary: fmtDate(b.expiry), align: AlignmentType.CENTER },
      { primary: unitsText(b.strips, p), bold: true, align: AlignmentType.RIGHT },
      {
        primary: `${fmtNum(b.strips)} ${p.units[0]?.name || 'وحدة'}`,
        align: AlignmentType.CENTER
      },
      { primary: statusLabel, bold: true, color: statusColor, align: AlignmentType.CENTER }
    ]);
  });

  const headerTable = buildHeaderBannerTable({
    company,
    docTitle: 'كشف رصيد واستلام مخزن',
    docNumber: warehouse.name,
    docSubtitle: `محافظة ${warehouse.gov}`,
    metaLines: [
      { label: 'تاريخ الكشف', value: fmtDate(todayISO()), boldValue: true },
      { label: 'عدد التشغيلات', value: fmtNum(rows.length) },
      { label: 'الوحدات السارية', value: fmtNum(validStrips) },
      { label: 'إجمالي الوحدات', value: fmtNum(totalStrips), boldValue: true }
    ]
  });

  const itemsTable = buildItemsDataTable(
    [
      { title: 'م', width: 480, align: AlignmentType.CENTER },
      { title: 'الكود', width: 920, align: AlignmentType.CENTER },
      { title: 'الصنف والوصف', width: 2845, align: AlignmentType.RIGHT },
      { title: 'التشغيلة', width: 1250, align: AlignmentType.CENTER },
      { title: 'الصلاحية', width: 1250, align: AlignmentType.CENTER },
      { title: 'الكمية (بالوحدات)', width: 1650, align: AlignmentType.RIGHT },
      { title: 'الرصيد الأساسي', width: 1150, align: AlignmentType.CENTER },
      { title: 'الحالة', width: 1000, align: AlignmentType.CENTER }
    ],
    rows,
    {
      label: `إجمالي التشغيلات الفعلية: ${fmtNum(rows.length)} تشغيلة — الساري: ${fmtNum(validStrips)} وحدة`,
      value: `${fmtNum(totalStrips)} وحدة`
    }
  );

  const footerTable = buildSignatureFooterTable([
    { title: 'أمين المخزن المستلم', subtitle: '....................................' },
    { title: 'تاريخ اليوم', subtitle: fmtDate(todayISO()), boldSubtitle: true },
    { title: 'اعتماد الإدارة', subtitle: '....................................' }
  ]);

  await saveDocxDocument(
    `استلام رصيد ${warehouse.name}`,
    [headerTable, spacerParagraph(150), itemsTable, spacerParagraph(200), footerTable],
    `رصيد_استلام_${warehouse.name}_${todayISO()}.docx`
  );
}

export async function exportReturnToWord(
  ret: CustomerReturn,
  warehouse: Warehouse | undefined,
  products: Product[],
  company: CompanyInfo
): Promise<void> {
  let rowIndex = 1;
  let totalStrips = 0;
  const rows: DataCellContent[][] = [];

  (ret.lines || []).forEach(l => {
    const p = products.find(x => x.id === l.productId);
    if (!p) return;
    totalStrips += l.strips;
    rows.push([
      { primary: String(rowIndex++), align: AlignmentType.CENTER },
      { primary: p.code, bold: true, align: AlignmentType.CENTER },
      { primary: p.name, bold: true, align: AlignmentType.RIGHT },
      { primary: l.batch || '—', align: AlignmentType.CENTER },
      { primary: l.expiry ? fmtDate(l.expiry) : '—', align: AlignmentType.CENTER },
      {
        primary: unitsText(l.strips, p),
        secondary: `(${fmtNum(l.strips)} ${p.units[0]?.name || 'وحدة'})`,
        bold: true,
        align: AlignmentType.CENTER
      },
      { primary: l.reason || ret.reason || '—', align: AlignmentType.RIGHT }
    ]);
  });

  const headerTable = buildHeaderBannerTable({
    company,
    docTitle: 'أذن مرتجع عميل',
    docNumber: ret.no,
    docSubtitle: ret.returnType === 'full' ? 'مرتجع كلي (كامل الفاتورة)' : 'مرتجع جزئي',
    accentColor: COLORS.violet,
    metaLines: [
      { label: 'العميل', value: ret.customer, boldValue: true },
      { label: 'أصل أذن الصرف', value: ret.issueNo },
      { label: 'رقم الفاتورة', value: ret.invoiceNo || '—' },
      { label: 'المخزن المستلم', value: warehouse ? warehouse.name : '—' },
      { label: 'التاريخ', value: fmtDate(ret.date) }
    ]
  });

  const itemsTable = buildItemsDataTable(
    [
      { title: 'م', width: 480, align: AlignmentType.CENTER },
      { title: 'الكود', width: 900, align: AlignmentType.CENTER },
      { title: 'الصنف المرتجع', width: 2565, align: AlignmentType.RIGHT },
      { title: 'التشغيلة', width: 1250, align: AlignmentType.CENTER },
      { title: 'الصلاحية', width: 1250, align: AlignmentType.CENTER },
      { title: 'الكمية المرتجعة', width: 1850, align: AlignmentType.CENTER },
      { title: 'سبب الرفض / المرتجع', width: 2250, align: AlignmentType.RIGHT }
    ],
    rows,
    {
      label: `إجمالي سطور المرتجع: ${fmtNum(rows.length)} سطر`,
      value: `${fmtNum(totalStrips)} وحدة`
    }
  );

  const footerTable = buildSignatureFooterTable([
    { title: 'أمين المخزن المستلم', subtitle: '....................................' },
    { title: 'تاريخ اليوم', subtitle: fmtDate(todayISO()), boldSubtitle: true },
    { title: 'توقيع العميل / المندوب', subtitle: '....................................' }
  ]);

  await saveDocxDocument(
    `أذن مرتجع عميل ${ret.no}`,
    [headerTable, spacerParagraph(150), itemsTable, spacerParagraph(200), footerTable],
    `مرتجع_عميل_${ret.no}.docx`
  );
}

export async function exportTransferToWord(
  tr: TransferOrder,
  fromWh: Warehouse | undefined,
  toWh: Warehouse | undefined,
  products: Product[],
  company: CompanyInfo
): Promise<void> {
  let idx = 1;
  let totalStrips = 0;
  const rows: DataCellContent[][] = [];

  tr.lines.forEach(l => {
    const p = products.find(x => x.id === l.productId);
    if (!p) return;
    const allocs = l.alloc && l.alloc.length ? l.alloc : [{ batch: '—', expiry: '', strips: l.strips }];
    allocs.forEach(a => {
      totalStrips += a.strips;
      rows.push([
        { primary: String(idx++), align: AlignmentType.CENTER },
        { primary: p.code, bold: true, align: AlignmentType.CENTER },
        { primary: p.name, bold: true, align: AlignmentType.RIGHT },
        { primary: a.batch || '—', align: AlignmentType.CENTER },
        { primary: a.expiry ? fmtDate(a.expiry) : '—', align: AlignmentType.CENTER },
        {
          primary: unitsText(a.strips, p),
          secondary: `(${fmtNum(a.strips)} ${p.units[0]?.name || 'وحدة'})`,
          bold: true,
          align: AlignmentType.CENTER
        }
      ]);
    });
  });

  const headerTable = buildHeaderBannerTable({
    company,
    docTitle: 'أذن تحويل مخزني',
    docNumber: tr.no,
    docSubtitle: `التاريخ: ${fmtDate(tr.date)}`,
    metaLines: [
      { label: 'من مخزن', value: fromWh ? fromWh.name : '—', boldValue: true },
      { label: 'إلى مخزن', value: toWh ? toWh.name : '—', boldValue: true }
    ]
  });

  const itemsTable = buildItemsDataTable(
    [
      { title: 'م', width: 560, align: AlignmentType.CENTER },
      { title: 'الكود', width: 1040, align: AlignmentType.CENTER },
      { title: 'الصنف', width: 3445, align: AlignmentType.RIGHT },
      { title: 'التشغيلة', width: 1500, align: AlignmentType.CENTER },
      { title: 'الصلاحية', width: 1550, align: AlignmentType.CENTER },
      { title: 'الكمية المحولة', width: 2450, align: AlignmentType.CENTER }
    ],
    rows,
    {
      label: `إجمالي السطور المحولة: ${fmtNum(rows.length)} سطر`,
      value: `${fmtNum(totalStrips)} وحدة أساسية`
    }
  );

  const footerTable = buildSignatureFooterTable([
    { title: 'المُسلِّم (المصدر)', subtitle: '....................................' },
    { title: 'تاريخ اليوم', subtitle: fmtDate(todayISO()), boldSubtitle: true },
    { title: 'المُستلِم (الفرع)', subtitle: '....................................' }
  ]);

  await saveDocxDocument(
    `أذن تحويل ${tr.no}`,
    [headerTable, spacerParagraph(150), itemsTable, spacerParagraph(200), footerTable],
    `اذن_تحويل_${tr.no}.docx`
  );
}

function buildInvoiceTotalsBox(baseVal: number): Table {
  const val14 = calc14Percent(baseVal);
  const grandTotal = calcTotalWith14(baseVal);
  const words = tafqeetEGP(grandTotal);
  const labelW = 2900;
  const amountW = 2100;
  const wordsW = PAGE_CONTENT_TWIPS - labelW - amountW;

  return new Table({
    visuallyRightToLeft: true,
    layout: TableLayoutType.FIXED,
    width: { size: PAGE_CONTENT_TWIPS, type: WidthType.DXA },
    columnWidths: [labelW, amountW, wordsW],
    borders: {
      top: FRAME_BORDER,
      bottom: FRAME_BORDER,
      left: FRAME_BORDER,
      right: FRAME_BORDER,
      insideHorizontal: INNER_FRAME_BORDER,
      insideVertical: INNER_FRAME_BORDER
    },
    rows: [
      new TableRow({
        cantSplit: true,
        children: [
          new TableCell({
            width: { size: labelW, type: WidthType.DXA },
            margins: CELL_PADDING,
            shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.tealSoft },
            children: [
              rtlParagraph([rtlRun('القيمة الأساسية (قبل 14%)', { bold: true, size: 19, color: COLORS.tealDark })], {
                alignment: AlignmentType.RIGHT,
                after: 0
              })
            ]
          }),
          new TableCell({
            columnSpan: 2,
            width: { size: amountW + wordsW, type: WidthType.DXA },
            margins: CELL_PADDING,
            shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.white },
            children: [
              rtlParagraph([rtlRun(`${fmtMoney(baseVal)} ج.م`, { bold: true, size: 20, color: COLORS.ink })], {
                alignment: AlignmentType.RIGHT,
                after: 0
              })
            ]
          })
        ]
      }),
      new TableRow({
        cantSplit: true,
        children: [
          new TableCell({
            width: { size: labelW, type: WidthType.DXA },
            margins: CELL_PADDING,
            shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.tealSoft },
            children: [
              rtlParagraph([rtlRun('قيمة 14%', { bold: true, size: 19, color: COLORS.tealDark })], {
                alignment: AlignmentType.RIGHT,
                after: 0
              })
            ]
          }),
          new TableCell({
            columnSpan: 2,
            width: { size: amountW + wordsW, type: WidthType.DXA },
            margins: CELL_PADDING,
            shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.white },
            children: [
              rtlParagraph([rtlRun(`${fmtMoney(val14)} ج.م`, { bold: true, size: 20, color: COLORS.tealPrimary })], {
                alignment: AlignmentType.RIGHT,
                after: 0
              })
            ]
          })
        ]
      }),
      new TableRow({
        cantSplit: true,
        children: [
          new TableCell({
            width: { size: labelW, type: WidthType.DXA },
            margins: CELL_PADDING,
            shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.tealTint },
            children: [
              rtlParagraph([rtlRun('المبلغ الإجمالي (شامل 14%)', { bold: true, size: 20, color: COLORS.tealDark })], {
                alignment: AlignmentType.RIGHT,
                after: 0
              })
            ]
          }),
          new TableCell({
            width: { size: amountW, type: WidthType.DXA },
            margins: CELL_PADDING,
            shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.tealTint },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              rtlParagraph([rtlRun(`${fmtMoney(grandTotal)} ج.م`, { bold: true, size: 22, color: COLORS.tealDark })], {
                alignment: AlignmentType.CENTER,
                after: 0
              })
            ]
          }),
          new TableCell({
            width: { size: wordsW, type: WidthType.DXA },
            margins: CELL_PADDING,
            shading: { type: ShadingType.CLEAR, color: 'auto', fill: COLORS.tealTint },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              rtlParagraph([rtlRun(words, { bold: true, size: 19, color: COLORS.tealDark })], {
                alignment: AlignmentType.RIGHT,
                after: 0
              })
            ]
          })
        ]
      })
    ]
  });
}

export async function exportInvoiceToWord(
  invoice: Invoice,
  company: CompanyInfo,
  products: Product[]
): Promise<void> {
  const rows: DataCellContent[][] = [];
  let rowIndex = 1;
  const baseVal = calcInvoiceValue(invoice, products);

  (invoice.lines || []).forEach(l => {
    const p = products.find(x => x.id === l.productId);
    if (!p) return;
    const lineVal = (l.strips || 0) * (p.price || 0);
    rows.push([
      { primary: String(rowIndex++), align: AlignmentType.CENTER },
      { primary: p.code, bold: true, align: AlignmentType.CENTER },
      { primary: p.name, secondary: p.form || undefined, bold: true, align: AlignmentType.RIGHT },
      { primary: l.batch || '—', align: AlignmentType.CENTER },
      { primary: l.expiry ? fmtDate(l.expiry) : '—', align: AlignmentType.CENTER },
      { primary: unitsText(l.strips, p), bold: true, align: AlignmentType.CENTER },
      { primary: `${fmtMoney(p.price)} ج.م`, align: AlignmentType.CENTER },
      { primary: `${fmtMoney(lineVal)} ج.م`, bold: true, align: AlignmentType.CENTER }
    ]);
  });

  const headerTable = buildHeaderBannerTable({
    company,
    docTitle: 'فاتورة وارد',
    docNumber: invoice.no,
    docSubtitle: `التاريخ: ${fmtDate(invoice.date)}`,
    includeCompanyTax: true,
    metaLines: [
      { label: 'المورد', value: invoice.supplier || '—', boldValue: true },
      { label: 'عدد البنود', value: fmtNum(rows.length) },
      { label: 'قيمة 14%', value: `${fmtMoney(calc14Percent(baseVal))} ج.م` },
      { label: 'المبلغ الإجمالي', value: `${fmtMoney(calcTotalWith14(baseVal))} ج.م`, boldValue: true }
    ]
  });

  const itemsTable = buildItemsDataTable(
    [
      { title: 'م', width: 450, align: AlignmentType.CENTER },
      { title: 'الكود', width: 850, align: AlignmentType.CENTER },
      { title: 'الصنف', width: 2545, align: AlignmentType.RIGHT },
      { title: 'التشغيلة', width: 1200, align: AlignmentType.CENTER },
      { title: 'الصلاحية', width: 1250, align: AlignmentType.CENTER },
      { title: 'الكمية', width: 1650, align: AlignmentType.CENTER },
      { title: 'السعر', width: 1200, align: AlignmentType.CENTER },
      { title: 'القيمة', width: 1400, align: AlignmentType.CENTER }
    ],
    rows,
    {
      label: `إجمالي الفاتورة (${fmtNum(rows.length)} بند)`,
      value: `${fmtMoney(baseVal)} ج.م`
    }
  );

  const totalsBox = buildInvoiceTotalsBox(baseVal);

  const footerTable = buildSignatureFooterTable([
    { title: 'المستلم بالمخزن', subtitle: '....................................' },
    { title: 'تاريخ اليوم', subtitle: fmtDate(todayISO()), boldSubtitle: true },
    { title: 'اعتماد الحسابات', subtitle: '....................................' }
  ]);

  await saveDocxDocument(
    `فاتورة وارد ${invoice.no}`,
    [headerTable, spacerParagraph(140), itemsTable, spacerParagraph(140), totalsBox, spacerParagraph(180), footerTable],
    `فاتورة_وارد_${invoice.no}.docx`
  );
}

export async function exportSalesInvoiceToWord(
  issue: IssueOrder,
  company: CompanyInfo,
  warehouse: Warehouse | undefined,
  products: Product[],
  customer?: Partner
): Promise<void> {
  const rows: DataCellContent[][] = [];
  let rowIndex = 1;
  let baseVal = 0;

  (issue.lines || []).forEach(l => {
    const p = products.find(x => x.id === l.productId);
    if (!p || isLineReceipt(l, p)) return;
    const unitPrice = l.pricePerStrip || p.price || 0;
    const allocs =
      l.alloc && l.alloc.length
        ? l.alloc
        : [{ batch: '—', expiry: '', strips: l.strips }];

    allocs.forEach(a => {
      const lineVal = a.strips * unitPrice;
      baseVal += lineVal;
      rows.push([
        { primary: String(rowIndex++), align: AlignmentType.CENTER },
        { primary: p.code, bold: true, align: AlignmentType.CENTER },
        {
          primary: p.name,
          secondary: p.form
            ? `${p.form}${p.description ? ` — ${p.description}` : ''}`
            : p.description || undefined,
          bold: true,
          align: AlignmentType.RIGHT
        },
        { primary: a.batch || '—', align: AlignmentType.CENTER },
        { primary: a.expiry ? fmtDate(a.expiry) : '—', bold: true, align: AlignmentType.CENTER },
        {
          primary: unitsText(a.strips, p),
          secondary: `(${fmtNum(a.strips)} ${p.units[0]?.name || 'وحدة'})`,
          bold: true,
          align: AlignmentType.CENTER
        },
        { primary: `${fmtMoney(unitPrice)} ج.م`, align: AlignmentType.CENTER },
        { primary: `${fmtMoney(lineVal)} ج.م`, bold: true, align: AlignmentType.CENTER }
      ]);
    });
  });

  const invDisplayNo = issue.invoiceNo && issue.invoiceNo !== '—' ? issue.invoiceNo : issue.no;
  const customerInfo = resolveIssueCustomer(issue, customer);
  const receiptGroups = getIssueReceipts(issue, products);

  const metaLines: Array<{ label: string; value: string; boldValue?: boolean }> = [
    { label: 'العميل', value: customerInfo.name, boldValue: true },
    { label: 'المخزن الصارف', value: warehouse ? warehouse.name : '—' },
    { label: 'رقم أذن الصرف', value: issue.no, boldValue: true },
    { label: 'المندوب', value: company.sales || '—' }
  ];
  if (receiptGroups.length === 1) {
    metaLines.push({
      label: 'رقم الإيصال المرفق',
      value: `${receiptGroups[0].receiptNo} (${receiptGroups[0].label})`
    });
  } else if (receiptGroups.length > 1) {
    metaLines.push({
      label: 'الإيصالات المرفقة',
      value: receiptGroups.map(g => `${g.receiptNo} (${g.label})`).join(' · ')
    });
  }

  const headerTable = buildHeaderBannerTable({
    company,
    docTitle: 'فاتورة مبيعات',
    docNumber: `فاتورة رقم: ${invDisplayNo}`,
    docSubtitle: `التاريخ: ${fmtDate(issue.date)}`,
    includeCompanyTax: true,
    customerBox: customerInfo,
    metaLines
  });

  const itemsTable = buildItemsDataTable(
    [
      { title: 'م', width: 450, align: AlignmentType.CENTER },
      { title: 'الكود', width: 850, align: AlignmentType.CENTER },
      { title: 'هيكل المواد (الصنف والوصف)', width: 2345, align: AlignmentType.RIGHT },
      { title: 'التشغيلة (Lot)', width: 1150, align: AlignmentType.CENTER },
      { title: 'تاريخ الصلاحية', width: 1200, align: AlignmentType.CENTER },
      { title: 'الكمية', width: 1750, align: AlignmentType.CENTER },
      { title: 'سعر الوحدة', width: 1300, align: AlignmentType.CENTER },
      { title: 'الإجمالي', width: 1500, align: AlignmentType.CENTER }
    ],
    rows,
    {
      label: `إجمالي عدد السطور الفعلية: ${fmtNum(rows.length)} سطر`,
      value: `${fmtMoney(baseVal)} ج.م`
    }
  );

  const totalsBox = buildInvoiceTotalsBox(baseVal);

  const footerTable = buildSignatureFooterTable([
    { title: 'المُسلِّم', subtitle: company.sales || 'أمين المخزن', boldSubtitle: true },
    { title: 'تاريخ اليوم', subtitle: fmtDate(todayISO()), boldSubtitle: true },
    { title: 'توقيع العميل', subtitle: '........................................' }
  ]);

  await saveDocxDocument(
    `فاتورة مبيعات ${invDisplayNo}`,
    [headerTable, spacerParagraph(140), itemsTable, spacerParagraph(140), totalsBox, spacerParagraph(180), footerTable],
    `فاتورة_مبيعات_${invDisplayNo}.docx`
  );
}

export function exportIncomingInvoiceToExcel(
  invoice: Invoice,
  warehouses: Warehouse[],
  products: Product[]
): void {
  const val = calcInvoiceValue(invoice, products);
  const val14 = calc14Percent(val);
  const grandTotal = calcTotalWith14(val);
  const grandTotalWords = tafqeetEGP(grandTotal);

  const headers = [
    'الكود',
    'الصنف',
    'التشغيلة',
    'الصلاحية',
    'إجمالي الكمية',
    ...warehouses.map(w => w.name),
    'القيمة الأساسية (ج.م)',
    'قيمة 14% (ج.م)',
    'المبلغ الإجمالي شامل 14% (ج.م)'
  ];

  const rows: ExcelCell[][] = invoice.lines.map(l => {
    const p = products.find(x => x.id === l.productId);
    const map: Record<string, number> = {};
    l.alloc.forEach(a => { map[a.warehouseId] = a.strips; });
    const lineVal = (l.strips || 0) * (p?.price || 0);
    return [
      p?.code || '',
      p?.name || '',
      l.batch,
      fmtDate(l.expiry),
      l.strips,
      ...warehouses.map(w => map[w.id] || 0),
      Number(lineVal.toFixed(2)),
      calc14Percent(lineVal),
      calcTotalWith14(lineVal)
    ];
  });

  const footerRow: ExcelCell[] = [
    grandTotalWords,
    `المورد: ${invoice.supplier}`,
    `فاتورة: ${invoice.no}`,
    fmtDate(invoice.date),
    invoice.totalStrips,
    ...warehouses.map(() => ''),
    Number(val.toFixed(2)),
    val14,
    grandTotal
  ];

  exportToExcel(`فاتورة_وارد_${invoice.no}.xlsx`, `فاتورة ${invoice.no}`, headers, rows, footerRow);
}

export function exportSalesInvoiceToExcel(
  issue: IssueOrder,
  warehouse: Warehouse | undefined,
  products: Product[],
  customer?: Partner
): void {
  const customerInfo = resolveIssueCustomer(issue, customer);
  const invDisplayNo = issue.invoiceNo && issue.invoiceNo !== '—' ? issue.invoiceNo : issue.no;
  const baseVal = calcIssueValue(issue, products);
  const val14 = calc14Percent(baseVal);
  const grandTotal = calcTotalWith14(baseVal);
  const grandTotalWords = tafqeetEGP(grandTotal);

  const headers = [
    'الكود',
    'الصنف',
    'التشغيلة',
    'الصلاحية',
    'الكمية بالوحدات',
    'الوحدات الأساسية',
    'سعر الوحدة (ج.م)',
    'القيمة الأساسية (ج.م)',
    'قيمة 14% (ج.م)',
    'المبلغ الإجمالي شامل 14% (ج.م)'
  ];

  const rows: ExcelCell[][] = [];
  let totalStrips = 0;

  (issue.lines || []).forEach(l => {
    const p = products.find(x => x.id === l.productId);
    if (!p || isLineReceipt(l, p)) return;
    const unitPrice = l.pricePerStrip || p.price || 0;
    const allocs = l.alloc && l.alloc.length ? l.alloc : [{ batch: '—', expiry: '', strips: l.strips }];
    allocs.forEach(a => {
      totalStrips += a.strips;
      const lineVal = a.strips * unitPrice;
      rows.push([
        p.code,
        p.name,
        a.batch || '—',
        a.expiry ? fmtDate(a.expiry) : '—',
        unitsText(a.strips, p),
        a.strips,
        Number(unitPrice.toFixed(2)),
        Number(lineVal.toFixed(2)),
        calc14Percent(lineVal),
        calcTotalWith14(lineVal)
      ]);
    });
  });

  const footerRow: ExcelCell[] = [
    grandTotalWords,
    `العميل: ${customerInfo.name}${customerInfo.phone ? ` (${customerInfo.phone})` : ''}`,
    `فاتورة: ${invDisplayNo} · أذن: ${issue.no}`,
    warehouse?.name || '—',
    customerInfo.address || '—',
    totalStrips,
    '',
    Number(baseVal.toFixed(2)),
    val14,
    grandTotal
  ];

  exportToExcel(`فاتورة_مبيعات_${invDisplayNo}.xlsx`, `فاتورة ${invDisplayNo}`, headers, rows, footerRow);
}

export function downloadCSVTemplate() {
  const csv = [
    'code,name,unit,qty,expiry,batch',
    'P001,بانادول إكسترا,علبة,10,2027-08-31,N-9012',
    'P002,أوجمنتين 1 جم,شريط,5,2027-05-31,N-9014',
    'S001,قفازات طبية معقمة,علبة,4,2028-02-28,S-4410'
  ].join('\n');
  downloadBlob(new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' }), 'قالب_فاتورة_الوارد.csv');
}

export function downloadExcelTemplate() {
  const headers = ['code', 'name', 'unit', 'qty', 'expiry', 'batch'];
  const rows: ExcelCell[][] = [
    ['P001', 'بانادول إكسترا', 'علبة', 10, '2027-08-31', 'N-9012'],
    ['P002', 'أوجمنتين 1 جم', 'شريط', 5, '2027-05-31', 'N-9014'],
    ['S001', 'قفازات طبية معقمة', 'علبة', 4, '2028-02-28', 'S-4410']
  ];
  exportToExcel('قالب_فاتورة_الوارد.xlsx', 'قالب_الوارد', headers, rows);
}

function normalizeExcelCell(val: unknown): string {
  if (val instanceof Date && !isNaN(val.getTime())) {
    const y = val.getFullYear();
    const m = String(val.getMonth() + 1).padStart(2, '0');
    const d = String(val.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  if (typeof val === 'number' && !isNaN(val)) {
    return String(val);
  }
  return String(val ?? '').trim();
}

export function parseExcelImportRows(buffer: ArrayBuffer): string[][] {
  const wb = XLSX.read(buffer, { type: 'array', cellDates: true });
  const firstSheet = wb.SheetNames[0];
  if (!firstSheet) return [];
  const ws = wb.Sheets[firstSheet];
  const aoa = XLSX.utils.sheet_to_json<unknown[]>(ws, {
    header: 1,
    defval: '',
    raw: true
  });
  return aoa
    .map(row => (Array.isArray(row) ? row.map(normalizeExcelCell) : []))
    .filter(row => row.some(cell => cell.length > 0));
}

export function parseCSVRow(line: string, delimiter: string): string[] {
  const out: string[] = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === delimiter && !inQuotes) {
      out.push(cur.trim());
      cur = '';
    } else {
      cur += ch;
    }
  }
  out.push(cur.trim());
  return out;
}

export function exportOdooJSON(db: AppDB) {
  const odoo = {
    meta: { source: 'صيدليتي', exportedAt: new Date().toISOString() },
    'stock.warehouse': db.warehouses.map(w => ({ id: w.id, name: w.name, code: w.id.toUpperCase(), city: w.gov, distribution_share: w.share })),
    'res.partner': db.partners.map(p => ({ id: p.id, ref: p.code, name: p.name, is_supplier: p.type === 'supplier', is_customer: p.type === 'customer', phone: p.phone, street: p.address, vat: p.taxNo })),
    'product.template': db.products.map(p => ({
      default_code: p.code,
      name: p.name,
      description: p.description,
      uom_name: p.units[0].name,
      list_price: p.price,
      is_supplies: p.marked
    })),
    'stock.quant': db.batches.filter(b => b.strips > 0).map(b => ({
      product_id: b.productId,
      location_id: b.warehouseId,
      lot_name: b.batch,
      expiration_date: toFullDate(b.expiry),
      quantity: b.strips
    }))
  };
  downloadBlob(new Blob([JSON.stringify(odoo, null, 2)], { type: 'application/json;charset=utf-8' }), `pharma_odoo_export_${todayISO()}.json`);
}

export function exportBackupJSON(db: AppDB) {
  downloadBlob(new Blob([JSON.stringify(db, null, 2)], { type: 'application/json;charset=utf-8' }), `saydaliyati_backup_${todayISO()}.json`);
}

export function exportHtmlDocument(title: string, bodyHtml: string, filename: string): void {
  const safeTitle = escHtml(title);
  const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${safeTitle}</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      padding: 24px;
      font-family: 'Cairo', 'Tahoma', 'Arial', sans-serif;
      background: #f4f8f7;
      color: #102523;
      direction: rtl;
      line-height: 1.65;
    }
    .page-wrap {
      max-width: 1200px;
      margin: 0 auto;
      background: #ffffff;
      border: 1px solid #dce6e3;
      border-radius: 14px;
      padding: 24px;
      box-shadow: 0 6px 24px rgba(7, 59, 57, 0.06);
    }
    .toolbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 12px;
      margin-bottom: 18px;
      padding-bottom: 12px;
      border-bottom: 1px solid #dce6e3;
    }
    .btn-print {
      background: #0f766e;
      color: #fff;
      border: none;
      border-radius: 8px;
      padding: 8px 16px;
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
    }
    .header-box {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      gap: 16px;
      background: #eef8f6;
      border: 1.5px solid #0b4f4b;
      border-radius: 12px;
      padding: 16px 20px;
      margin-bottom: 20px;
    }
    .header-box h1 { margin: 0 0 6px; font-size: 20px; color: #073b39; }
    .meta { font-size: 12.5px; color: #3b5653; }
    .kpi-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 10px;
      margin-bottom: 22px;
    }
    .kpi {
      background: #f8fbfa;
      border: 1px solid #dce6e3;
      border-radius: 10px;
      padding: 12px;
    }
    .kpi-val { font-size: 18px; font-weight: 800; color: #0f766e; }
    .kpi-lbl { font-size: 11.5px; color: #5c7471; font-weight: 700; }
    h2 {
      font-size: 15px;
      color: #073b39;
      margin: 24px 0 10px;
      padding-right: 10px;
      border-right: 4px solid #0f766e;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
      margin-bottom: 14px;
    }
    th, td {
      border: 1px solid #94a3b8;
      padding: 6px 9px;
      min-width: 3cm;
      height: 1cm;
      text-align: right;
      vertical-align: middle;
    }
    th {
      background: #0f766e;
      color: #ffffff;
      font-weight: 700;
      white-space: nowrap;
    }
    tr:nth-child(even) td { background: #f8fbfa; }
    .num { text-align: center; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .badge-ok { color: #047857; font-weight: 700; }
    .badge-soon { color: #b45309; font-weight: 700; }
    .badge-exp { color: #dc2626; font-weight: 700; }
    .empty { font-size: 12px; color: #5c7471; padding: 10px; background: #f8fbfa; border-radius: 8px; }
    @media print {
      body { background: #fff; padding: 0; }
      .page-wrap { border: none; box-shadow: none; padding: 0; }
      .no-print { display: none !important; }
      table { page-break-inside: auto; }
      tr { page-break-inside: avoid; }
    }
  </style>
</head>
<body>
  <div class="page-wrap">
    <div class="toolbar no-print">
      <div style="font-size:13px;font-weight:700;color:#073b39">${safeTitle}</div>
      <button type="button" class="btn-print" onclick="window.print()">طباعة / حفظ PDF</button>
    </div>
    ${bodyHtml}
  </div>
</body>
</html>`;

  const finalName = filename.toLowerCase().endsWith('.html') ? filename : `${filename}.html`;
  downloadBlob(new Blob([html], { type: 'text/html;charset=utf-8' }), finalName);
}

export function exportFullHTMLCopy(db: AppDB): void {
  const today = todayISO();
  const activeBatches = db.batches.filter(b => b.strips > 0 && b.expiry >= today);
  const totalActiveUnits = activeBatches.reduce((s, b) => s + b.strips, 0);
  const totalStockValue = activeBatches.reduce((s, b) => {
    const p = db.products.find(x => x.id === b.productId);
    return s + b.strips * (p?.price || 0);
  }, 0);

  const whRows = db.warehouses
    .map(w => {
      const bs = activeBatches.filter(b => b.warehouseId === w.id);
      const units = bs.reduce((s, b) => s + b.strips, 0);
      const val = bs.reduce((s, b) => {
        const p = db.products.find(x => x.id === b.productId);
        return s + b.strips * (p?.price || 0);
      }, 0);
      return `<tr>
        <td><b>${escHtml(w.name)}</b></td>
        <td>${escHtml(w.gov)}</td>
        <td class="num">${w.kind === 'main' ? 'رئيسي' : 'فرعي'}</td>
        <td class="num">${w.share}%</td>
        <td class="num">${fmtNum(new Set(bs.map(b => b.productId)).size)}</td>
        <td class="num">${fmtNum(units)}</td>
        <td class="num"><b>${fmtMoney(val)} ج.م</b></td>
      </tr>`;
    })
    .join('');

  const batchRows = db.batches
    .filter(b => b.strips > 0)
    .map((b, i) => {
      const p = db.products.find(x => x.id === b.productId);
      const w = db.warehouses.find(x => x.id === b.warehouseId);
      const st = expiryState(b.expiry);
      const stLabel = st === 'expired' ? 'منتهي' : st === 'soon' ? 'قارب الانتهاء' : 'ساري';
      const stCls = st === 'expired' ? 'badge-exp' : st === 'soon' ? 'badge-soon' : 'badge-ok';
      return `<tr>
        <td class="num">${i + 1}</td>
        <td class="num">${escHtml(p?.code || '—')}</td>
        <td><b>${escHtml(p?.name || '—')}</b></td>
        <td>${escHtml(w?.name || '—')}</td>
        <td class="num">${escHtml(b.batch)}</td>
        <td class="num">${fmtDate(b.expiry)}</td>
        <td>${escHtml(unitsText(b.strips, p))}</td>
        <td class="num">${fmtNum(b.strips)}</td>
        <td class="num ${stCls}">${stLabel}</td>
      </tr>`;
    })
    .join('');

  const salesInvoiceRows = db.issues
    .filter(iss => (iss.lines || []).some(l => !isLineReceipt(l, db.products.find(p => p.id === l.productId))))
    .map(iss => {
      const cust = resolveIssueCustomer(iss, db.partners);
      const wh = db.warehouses.find(w => w.id === iss.warehouseId);
      const base = calcIssueValue(iss, db.products);
      const val14 = calc14Percent(base);
      const grand = calcTotalWith14(base);
      const invNo = iss.invoiceNo && iss.invoiceNo !== '—' ? iss.invoiceNo : iss.no;
      return `<tr>
        <td class="num"><b>${escHtml(invNo)}</b></td>
        <td class="num">${escHtml(iss.no)}</td>
        <td class="num">${fmtDate(iss.date)}</td>
        <td><b>${escHtml(cust.name)}</b>${cust.phone ? `<br><small>${escHtml(cust.phone)}</small>` : ''}</td>
        <td>${escHtml(wh?.name || '—')}</td>
        <td class="num">${fmtMoney(base)} ج.م</td>
        <td class="num">${fmtMoney(val14)} ج.م</td>
        <td class="num"><b>${fmtMoney(grand)} ج.م</b></td>
        <td>${escHtml(tafqeetEGP(grand))}</td>
      </tr>`;
    })
    .join('');

  const incomingInvoiceRows = db.invoices
    .map(inv => {
      const base = calcInvoiceValue(inv, db.products);
      const val14 = calc14Percent(base);
      const grand = calcTotalWith14(base);
      return `<tr>
        <td class="num"><b>${escHtml(inv.no)}</b></td>
        <td class="num">${fmtDate(inv.date)}</td>
        <td><b>${escHtml(inv.supplier)}</b></td>
        <td class="num">${fmtNum(inv.lines.length)}</td>
        <td class="num">${fmtNum(inv.totalStrips)}</td>
        <td class="num">${fmtMoney(base)} ج.م</td>
        <td class="num">${fmtMoney(val14)} ج.م</td>
        <td class="num"><b>${fmtMoney(grand)} ج.م</b></td>
        <td>${escHtml(tafqeetEGP(grand))}</td>
      </tr>`;
    })
    .join('');

  const issueRows = sortIssuesByInvoiceStatus(db.issues)
    .map(iss => {
      const cust = resolveIssueCustomer(iss, db.partners);
      const wh = db.warehouses.find(w => w.id === iss.warehouseId);
      const recs = getIssueReceipts(iss, db.products);
      const recSummary = recs.length
        ? recs.map(r => `${r.label} (${r.receiptNo})`).join(' + ')
        : '—';
      const val = calcIssueValue(iss, db.products);
      return `<tr>
        <td class="num"><b>${escHtml(iss.no)}</b></td>
        <td class="num">${fmtDate(iss.date)}</td>
        <td>
          <b>${escHtml(cust.name)}</b>
          ${cust.code ? ` (${escHtml(cust.code)})` : ''}
          ${cust.phone ? `<br><small>${escHtml(cust.phone)}</small>` : ''}
          ${cust.address ? `<br><small>${escHtml(cust.address)}</small>` : ''}
        </td>
        <td class="num">${escHtml(iss.invoiceNo || '—')}</td>
        <td>${escHtml(wh?.name || '—')}</td>
        <td>${escHtml(recSummary)}</td>
        <td class="num">${fmtNum(iss.lines.length)}</td>
        <td class="num"><b>${val > 0 ? `${fmtMoney(calcTotalWith14(val))} ج.م` : 'بدون قيمة'}</b></td>
      </tr>`;
    })
    .join('');

  const partnerRows = db.partners
    .map(
      p => `<tr>
        <td class="num">${escHtml(p.code)}</td>
        <td><b>${escHtml(p.name)}</b></td>
        <td class="num">${p.type === 'supplier' ? 'مورد' : 'عميل'}</td>
        <td>${escHtml(p.contact || '—')}</td>
        <td class="num">${escHtml(p.phone || '—')}</td>
        <td>${escHtml(p.address || '—')}</td>
        <td class="num">${escHtml(p.taxNo || '—')}</td>
      </tr>`
    )
    .join('');

  const returnRows = db.returns
    .map(r => {
      const wh = db.warehouses.find(w => w.id === r.warehouseId);
      return `<tr>
        <td class="num"><b>${escHtml(r.no)}</b></td>
        <td class="num">${fmtDate(r.date)}</td>
        <td class="num">${escHtml(r.issueNo)}</td>
        <td><b>${escHtml(r.customer)}</b></td>
        <td class="num">${r.returnType === 'full' ? 'مرتجع كلي' : 'مرتجع جزئي'}</td>
        <td>${escHtml(wh?.name || '—')}</td>
        <td class="num">${fmtNum(r.totalStrips)}</td>
        <td class="num"><b>${fmtMoney(r.totalValue)} ج.م</b></td>
        <td>${escHtml(r.reason || '—')}</td>
      </tr>`;
    })
    .join('');

  const bodyHtml = `
    <div class="header-box">
      <div>
        <h1>${escHtml(db.company.name)} — نسخة بيانات كاملة (HTML)</h1>
        <div class="meta">
          <b>العنوان:</b> ${escHtml(db.company.address || '—')} ${db.company.gov ? `— ${escHtml(db.company.gov)}` : ''}
          &nbsp;|&nbsp; <b>الهاتف:</b> ${escHtml(db.company.phone || '—')}
          &nbsp;|&nbsp; <b>الرقم الضريبي:</b> ${escHtml(db.company.taxNo || '—')}
        </div>
      </div>
      <div class="meta" style="text-align:left">
        <div><b>تاريخ التصدير:</b> ${fmtDate(today)}</div>
        <div><b>الوقت:</b> ${escHtml(new Date().toLocaleTimeString('ar-EG'))}</div>
      </div>
    </div>

    <div class="kpi-grid">
      <div class="kpi"><div class="kpi-val">${fmtNum(db.warehouses.length)}</div><div class="kpi-lbl">المخازن</div></div>
      <div class="kpi"><div class="kpi-val">${fmtNum(db.products.length)}</div><div class="kpi-lbl">الأصناف</div></div>
      <div class="kpi"><div class="kpi-val">${fmtNum(totalActiveUnits)}</div><div class="kpi-lbl">الوحدات السارية</div></div>
      <div class="kpi"><div class="kpi-val">${fmtMoney(totalStockValue)} ج.م</div><div class="kpi-lbl">قيمة المخزون</div></div>
      <div class="kpi"><div class="kpi-val">${fmtNum(db.issues.length)}</div><div class="kpi-lbl">أذون الصرف</div></div>
      <div class="kpi"><div class="kpi-val">${fmtNum(db.invoices.length)}</div><div class="kpi-lbl">فواتير الوارد</div></div>
      <div class="kpi"><div class="kpi-val">${fmtNum(db.returns.length)}</div><div class="kpi-lbl">المرتجعات</div></div>
      <div class="kpi"><div class="kpi-val">${fmtNum(db.partners.length)}</div><div class="kpi-lbl">العملاء والموردون</div></div>
    </div>

    <h2>المخازن</h2>
    <table>
      <thead><tr><th>المخزن</th><th>المحافظة</th><th>النوع</th><th>النصيب</th><th>الأصناف</th><th>الوحدات السارية</th><th>القيمة</th></tr></thead>
      <tbody>${whRows}</tbody>
    </table>

    <h2>أذون الصرف والإيصالات المرفقة</h2>
    ${issueRows ? `<table><thead><tr><th>رقم الأذن</th><th>التاريخ</th><th>بيانات العميل</th><th>رقم الفاتورة</th><th>المخزن</th><th>الإيصالات المرفقة</th><th>البنود</th><th>الإجمالي (شامل 14%)</th></tr></thead><tbody>${issueRows}</tbody></table>` : '<div class="empty">لا توجد أذون صرف مسجلة.</div>'}

    <h2>فواتير المبيعات (شامل 14% والتفقيط)</h2>
    ${salesInvoiceRows ? `<table><thead><tr><th>رقم الفاتورة</th><th>رقم الأذن</th><th>التاريخ</th><th>العميل</th><th>المخزن</th><th>القيمة الأساسية</th><th>قيمة 14%</th><th>الإجمالي شامل 14%</th><th>المبلغ بالحروف</th></tr></thead><tbody>${salesInvoiceRows}</tbody></table>` : '<div class="empty">لا توجد فواتير مبيعات.</div>'}

    <h2>فواتير الوارد</h2>
    ${incomingInvoiceRows ? `<table><thead><tr><th>رقم الفاتورة</th><th>التاريخ</th><th>المورد</th><th>البنود</th><th>إجمالي الوحدات</th><th>القيمة الأساسية</th><th>قيمة 14%</th><th>الإجمالي شامل 14%</th><th>المبلغ بالحروف</th></tr></thead><tbody>${incomingInvoiceRows}</tbody></table>` : '<div class="empty">لا توجد فواتير وارد.</div>'}

    <h2>أرصدة التشغيلات الحالية بالمخازن</h2>
    ${batchRows ? `<table><thead><tr><th>م</th><th>الكود</th><th>الصنف</th><th>المخزن</th><th>التشغيلة</th><th>الصلاحية</th><th>الكمية بالوحدات</th><th>الوحدات الأساسية</th><th>الحالة</th></tr></thead><tbody>${batchRows}</tbody></table>` : '<div class="empty">لا توجد أرصدة مسجلة.</div>'}

    <h2>مرتجعات العملاء</h2>
    ${returnRows ? `<table><thead><tr><th>رقم المرتجع</th><th>التاريخ</th><th>أذن الصرف</th><th>العميل</th><th>النوع</th><th>المخزن</th><th>الكمية</th><th>القيمة</th><th>السبب</th></tr></thead><tbody>${returnRows}</tbody></table>` : '<div class="empty">لا توجد مرتجعات مسجلة.</div>'}

    <h2>الموردون والعملاء</h2>
    ${partnerRows ? `<table><thead><tr><th>الكود</th><th>الاسم</th><th>النوع</th><th>المسؤول</th><th>الهاتف</th><th>العنوان</th><th>الرقم الضريبي</th></tr></thead><tbody>${partnerRows}</tbody></table>` : '<div class="empty">لا توجد جهات مسجلة.</div>'}
  `;

  exportHtmlDocument(`${db.company.name} — نسخة HTML`, bodyHtml, `نسخة_صيدليتي_${today}.html`);
}

export async function downloadStandaloneAppHTML(db: AppDB): Promise<void> {
  const today = todayISO();
  const filename = `صيدليتي_التطبيق_الكامل_${today}.html`;

  if (!window.__PHARMA_STANDALONE__ && window.location.protocol !== 'file:') {
    const res = await fetch('/api/download-app-html', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ db })
    });
    const ct = res.headers.get('content-type') || '';
    if (res.ok && ct.includes('text/html')) {
      const blob = await res.blob();
      downloadBlob(blob, filename);
      return;
    }
  }

  // Fallback for offline standalone HTML self-export with latest DB embedded
  const clone = document.documentElement.cloneNode(true) as HTMLElement;
  const rootEl = clone.querySelector('#root');
  if (rootEl) rootEl.innerHTML = '';

  const headEl = clone.querySelector('head');
  if (headEl) {
    Array.from(headEl.querySelectorAll('script')).forEach(sc => {
      if (sc.textContent?.includes('__PHARMA_EMBEDDED_DB__')) {
        sc.remove();
      }
    });
    const bootstrap = document.createElement('script');
    const key = `${today}-${Date.now().toString(36)}`;
    const safeDb = JSON.stringify(db).replace(/</g, '\\u003c');
    bootstrap.textContent = `window.__PHARMA_STANDALONE__=true;window.__PHARMA_EMBEDDED_KEY__=${JSON.stringify(key)};window.__PHARMA_EMBEDDED_DB__=${safeDb};`;
    headEl.appendChild(bootstrap);
  }

  const html = `<!doctype html>\n${clone.outerHTML}`;
  downloadBlob(new Blob([html], { type: 'text/html;charset=utf-8' }), filename);
}

export async function downloadFullAppZIP(): Promise<void> {
  const today = todayISO();
  const res = await fetch('/api/download-app-zip');
  if (!res.ok) {
    throw new Error('تعذر تحميل حزمة المشروع المضغوطة (ZIP) — تأكد من تشغيل التطبيق عبر الخادم');
  }
  const blob = await res.blob();
  downloadBlob(blob, `saydaliyati-full-app-${today}.zip`);
}

export function fmtValueStr(n: number) {
  return fmtMoney(n);
}
