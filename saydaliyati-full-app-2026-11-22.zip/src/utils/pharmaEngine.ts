import type {
  AppDB,
  Batch,
  CompanyInfo,
  CustomerReturn,
  CustomerReturnLine,
  DraftIncoming,
  DraftIssue,
  DraftTransfer,
  Invoice,
  IssueOrder,
  LotAllocation,
  Movement,
  Partner,
  Product,
  TransferOrder
} from '../types/pharma.ts';
import {
  fmtNum,
  getIssueReceipts,
  getLineReceiptType,
  isLineReceipt,
  normalizeUnits,
  pad4,
  shiftISO,
  sortIssueLines,
  sortIssuesByInvoiceStatus,
  todayISO,
  toFullDate,
  uid
} from './format.ts';

export const SEED_WAREHOUSES = [
  { id: 'w1', name: 'المخزن الرئيسي', gov: 'القاهرة', share: 30, color: '#0f766e', kind: 'main' as const },
  { id: 'w2', name: 'مخزن فرعي 1', gov: 'الجيزة', share: 25, color: '#2563eb', kind: 'sub' as const },
  { id: 'w3', name: 'مخزن فرعي 2', gov: 'الإسكندرية', share: 25, color: '#7c3aed', kind: 'sub' as const },
  { id: 'w4', name: 'مخزن فرعي 3', gov: 'المنصورة', share: 20, color: '#d97706', kind: 'sub' as const }
];

export const SEED_PARTNERS: Partner[] = [
  { id: 'sup1', code: 'SUP-001', type: 'supplier', name: 'شركة النيل للأدوية', phone: '0221234567', address: '15 شارع الجلاء، القاهرة', taxNo: '301-456-789', contact: 'أ. أحمد الشريف', notes: 'مورّد رئيسي للأدوية' },
  { id: 'sup2', code: 'SUP-002', type: 'supplier', name: 'شركة الشفاء للتوزيع', phone: '01001234567', address: '4 مساكن الشروق، الجيزة', taxNo: '301-222-333', contact: 'م. منى فؤاد', notes: '' },
  { id: 'sup3', code: 'SUP-003', type: 'supplier', name: 'المصرية للمستلزمات الطبية', phone: '0354445555', address: '9 بورسعيد، الإسكندرية', taxNo: '301-888-999', contact: 'أ. طارق علام', notes: 'مستلزمات وقفازات' },
  { id: 'sup4', code: 'SUP-004', type: 'supplier', name: 'شركة الدلتا للمستحضرات', phone: '0403334444', address: '12 شارع البحر، الغربية', taxNo: '301-111-777', contact: 'د. سارة حسين', notes: '' },

  { id: 'cus1', code: 'CUS-001', type: 'customer', name: 'صيدلية الشفاء', phone: '0190001111', address: '21 رمسيس، القاهرة', taxNo: '310-222-111', contact: 'أ. سيد', notes: 'فاتورة أسبوعية' },
  { id: 'cus2', code: 'CUS-002', type: 'customer', name: 'صيدلية النور', phone: '0108889999', address: '7 شارع 6 أكتوبر، الجيزة', taxNo: '310-555-444', contact: 'د. هبة', notes: '' },
  { id: 'cus3', code: 'CUS-003', type: 'customer', name: 'مركز الإسكندرية الطبي', phone: '0354445555', address: '15 شارع فؤاد، الإسكندرية', taxNo: '310-777-888', contact: 'د. محمود', notes: '' },
  { id: 'cus4', code: 'CUS-004', type: 'customer', name: 'مستشفى المنصورة الجامعية', phone: '0503332233', address: 'ميدان الجمهورية، المنصورة', taxNo: '310-000-333', contact: 'أ. رضوى', notes: 'توريد أسبوعي' },
  { id: 'cus5', code: 'CUS-005', type: 'customer', name: 'صيدليات العز — فرع المهندسين', phone: '0233332222', address: '101 جامعة الدول العربية، الجيزة', taxNo: '310-123-009', contact: 'أ. كريم', notes: '' }
];

export const SEED_PRODUCTS: Product[] = [
  { id: 'P001', code: 'P001', supplierId: 'sup1', name: 'بانادول إكسترا', description: 'باراسيتامول + كافيين — مسكن وخافض حرارة', form: 'أقراص 24', category: 'دواء', marked: false, price: 24,
    units: [{ name: 'شريط', factor: 1 }, { name: 'علبة', factor: 2 }, { name: 'كرتونة', factor: 12 }] },
  { id: 'P002', code: 'P002', supplierId: 'sup1', name: 'أوجمنتين 1 جم', description: 'أموكسيسيلين + كلافيولانيت 875/125', form: 'أقراص 14', category: 'دواء', marked: false, price: 97.5,
    units: [{ name: 'شريط', factor: 1 }, { name: 'علبة', factor: 2 }, { name: 'كرتونة', factor: 24 }] },
  { id: 'P003', code: 'P003', supplierId: 'sup1', name: 'كونجستال', description: 'باراسيتامول + سودوافدرين + ديفينهيدرأمين — دور البرد', form: 'أقراص 20', category: 'دواء', marked: false, price: 33,
    units: [{ name: 'شريط', factor: 1 }, { name: 'علبة', factor: 2 }, { name: 'كرتونة', factor: 18 }] },
  { id: 'P004', code: 'P004', supplierId: 'sup1', name: 'فولتارين 50 مجم', description: 'ديكلوفيناك بوتاسيوم 50 مجم', form: 'أقراص 20', category: 'دواء', marked: false, price: 39,
    units: [{ name: 'شريط', factor: 1 }, { name: 'علبة', factor: 2 }, { name: 'كرتونة', factor: 20 }] },
  { id: 'P005', code: 'P005', supplierId: 'sup1', name: 'نيكسيوم 40 مجم', description: 'إيزوميبرازول — قرحة المعدة والارتجاع', form: 'كبسولات 14', category: 'دواء', marked: false, price: 115,
    units: [{ name: 'شريط', factor: 1 }, { name: 'علبة', factor: 2 }, { name: 'كرتونة', factor: 14 }] },
  { id: 'P006', code: 'P006', supplierId: 'sup1', name: 'كلاريتين 10 مجم', description: 'لوراتادين — مضاد للهيستامين', form: 'أقراص 10', category: 'دواء', marked: false, price: 60,
    units: [{ name: 'شريط', factor: 1 }, { name: 'علبة', factor: 1 }, { name: 'كرتونة', factor: 20 }] },
  { id: 'P007', code: 'P007', supplierId: 'sup1', name: 'فيتامين د3 50000', description: 'كوليكالسيفيرول 50,000 وحدة', form: 'أقراص 8', category: 'دواء', marked: false, price: 95,
    units: [{ name: 'شريط', factor: 1 }, { name: 'علبة', factor: 1 }, { name: 'كرتونة', factor: 30 }] },
  { id: 'P008', code: 'P008', supplierId: 'sup2', name: 'تليفاست 100 مل', description: 'فيكسوفينادين 120 — شراب للحساسية', form: 'شراب 120 مل', category: 'دواء', marked: false, price: 72,
    units: [{ name: 'زجاجة', factor: 1 }, { name: 'علبة', factor: 1 }, { name: 'كرتونة', factor: 12 }] },
  { id: 'P009', code: 'P009', supplierId: 'sup2', name: 'لانتوس سولوستار', description: 'أنسولين جلارجين 100 وحدة/مل', form: 'أقلام 5', category: 'دواء', marked: false, price: 104,
    units: [{ name: 'قلم', factor: 1 }, { name: 'علبة', factor: 5 }, { name: 'كرتونة', factor: 25 }] },
  { id: 'P010', code: 'P010', supplierId: 'sup2', name: 'جاست ريج 50 مجم', description: 'تريميبوتين — القولون العصبي والحركية', form: 'أقراص 30', category: 'دواء', marked: false, price: 28,
    units: [{ name: 'شريط', factor: 1 }, { name: 'علبة', factor: 3 }, { name: 'كرتونة', factor: 30 }] },

  { id: 'S001', code: 'S001', supplierId: 'sup3', name: 'قفازات طبية معقمة', description: 'قفازات لاتكس معقمة مقاس M', form: 'علبة 100', category: 'مستلزمات', marked: true, price: 2.6,
    units: [{ name: 'جوانتي', factor: 1 }, { name: 'علبة', factor: 100 }, { name: 'كرتونة', factor: 1000 }] },
  { id: 'S002', code: 'S002', supplierId: 'sup3', name: 'سرنجات 5 مل', description: 'سرنجات ديسبوزيبل 5 مل', form: 'علبة 100', category: 'مستلزمات', marked: true, price: 1.9,
    units: [{ name: 'سرنجة', factor: 1 }, { name: 'علبة', factor: 100 }, { name: 'كرتونة', factor: 1000 }] },
  { id: 'S003', code: 'S003', supplierId: 'sup3', name: 'كمامات طبية 3 طبقات', description: 'كمامات جراحية 3 طبقات', form: 'علبة 50', category: 'مستلزمات', marked: true, price: 2.6,
    units: [{ name: 'كمامة', factor: 1 }, { name: 'علبة', factor: 50 }, { name: 'كرتونة', factor: 500 }] },
  { id: 'S004', code: 'S004', supplierId: 'sup3', name: 'شاش طبي 10×10', description: 'شاش معقم 10×10 — 16 طبقة', form: 'علبة 20', category: 'مستلزمات', marked: true, price: 3.25,
    units: [{ name: 'قطعة', factor: 1 }, { name: 'علبة', factor: 20 }, { name: 'كرتونة', factor: 200 }] },
  { id: 'S005', code: 'S005', supplierId: 'sup3', name: 'كحول إيثيلي 70%', description: 'كحول إيثيلي للتعقيم 70%', form: 'علبة 12', category: 'مستلزمات', marked: true, price: 7.5,
    units: [{ name: 'زجاجة', factor: 1 }, { name: 'علبة', factor: 12 }, { name: 'كرتونة', factor: 144 }] }
];

export function distributeQuantities(total: number, shares: number[]): number[] {
  const sum = shares.reduce((a, b) => a + b, 0) || 1;
  const exact = shares.map(s => (total * s) / sum);
  const base = exact.map(Math.floor);
  const rem = total - base.reduce((a, b) => a + b, 0);
  const order = exact
    .map((v, i) => ({ i, frac: v - Math.floor(v) }))
    .sort((a, b) => b.frac - a.frac);
  for (let k = 0; k < rem; k++) {
    base[order[k % order.length].i]++;
  }
  return base;
}

export function makeSeed(): AppDB {
  const nowISO = todayISO();
  const issDate = shiftISO(nowISO, -1);
  const issPrefix = issDate.replace(/-/g, '') + '-';
  const db: AppDB = {
    version: 3,
    warehouses: JSON.parse(JSON.stringify(SEED_WAREHOUSES)),
    partners: JSON.parse(JSON.stringify(SEED_PARTNERS)),
    products: SEED_PRODUCTS.map(p => ({ ...p, units: p.units.map(u => ({ ...u })) })),
    batches: [],
    invoices: [],
    issues: [],
    returns: [],
    transfers: [],
    movements: [],
    company: {
      name: 'صيدلية النور',
      address: '١٢ شارع الجمهورية، القاهرة',
      gov: 'القاهرة',
      phone: '0223001122',
      taxNo: '310-000-111',
      sales: 'أ. إسلام — مندوب المبيعات'
    },
    meta: {
      nextIssue: 3,
      issueSeqDate: nowISO.replace(/-/g, '') + '-',
      issueSeq: 2,
      returnSeq: 1,
      nextTransfer: 5002,
      nextInvoice: 119,
      seq: 1
    }
  };

  let bid = 1;
  const dFromNow = (days: number) => shiftISO(nowISO, days);

  db.products.forEach((p, pi) => {
    const level1 = p.units[1] ? p.units[1].factor : 1;
    const lots = [
      { lot: 'L' + (24000 + pi * 100), exp: dFromNow(300 + ((pi * 7) % 420)), boxes: 8 + ((pi * 3) % 12) },
      { lot: 'L' + (94000 + pi * 100), exp: dFromNow(35 + ((pi * 5) % 95)), boxes: 3 + ((pi * 5) % 6) }
    ];
    lots.forEach(l => {
      const total = l.boxes * level1;
      const nums = distributeQuantities(total, db.warehouses.map(w => w.share));
      db.warehouses.forEach((w, wi) => {
        if (nums[wi] > 0) {
          db.batches.push({ id: 'b' + bid++, productId: p.id, warehouseId: w.id, batch: l.lot, expiry: l.exp, strips: nums[wi] });
        }
      });
    });
  });

  db.batches.push({ id: 'b' + bid++, productId: 'P001', warehouseId: 'w1', batch: 'B-EXP-2401', expiry: dFromNow(-55), strips: 10 });
  db.batches.push({ id: 'b' + bid++, productId: 'P003', warehouseId: 'w2', batch: 'B-EXP-2402', expiry: dFromNow(-20), strips: 6 });
  db.batches.push({ id: 'b' + bid++, productId: 'P008', warehouseId: 'w4', batch: 'B-EXP-2403', expiry: dFromNow(-95), strips: 3 });

  const prod = (id: string) => db.products.find(p => p.id === id)!;

  const addMove = (m: Omit<Movement, 'id' | 'createdAt'> & { createdAt?: string }) => {
    db.movements.unshift({
      ...m,
      id: 'mv-' + db.meta.seq++,
      createdAt: m.createdAt || new Date().toISOString()
    });
  };

  const putBatch = (productId: string, warehouseId: string, batch: string, expiry: string, strips: number) => {
    if (strips <= 0) return;
    const found = db.batches.find(b => b.productId === productId && b.warehouseId === warehouseId && b.batch === batch && b.expiry === expiry);
    if (found) found.strips += strips;
    else db.batches.push({ id: 'b' + bid++, productId, warehouseId, batch, expiry, strips });
  };

  const takeBatch = (productId: string, warehouseId: string, need: number): LotAllocation[] => {
    const list = db.batches
      .filter(b => b.productId === productId && b.warehouseId === warehouseId && b.strips > 0 && b.expiry >= nowISO)
      .sort((a, b) => a.expiry.localeCompare(b.expiry));
    let rem = need;
    const alloc: LotAllocation[] = [];
    for (const b of list) {
      if (rem <= 0) break;
      const t = Math.min(b.strips, rem);
      b.strips -= t;
      rem -= t;
      alloc.push({ batchId: b.id, batch: b.batch, expiry: b.expiry, strips: t });
    }
    return alloc;
  };

  const invDate = shiftISO(nowISO, -6);
  const invoice: Invoice = {
    id: 'inv-1001',
    no: 'INV-2026-118',
    supplierId: 'sup1',
    supplier: 'شركة النيل للأدوية',
    date: invDate,
    createdAt: invDate + 'T10:30:00',
    totalStrips: 0,
    lines: []
  };
  const invLines = [
    { productId: 'P002', units: [{ name: 'علبة', qty: 3 }, { name: 'شريط', qty: 1 }], expiry: dFromNow(540), batch: 'N-8841' },
    { productId: 'P005', units: [{ name: 'علبة', qty: 2 }], expiry: dFromNow(455), batch: 'N-8852' },
    { productId: 'P009', units: [{ name: 'علبة', qty: 1 }, { name: 'قلم', qty: 2 }], expiry: dFromNow(365), batch: 'N-8867' },
    { productId: 'P007', units: [{ name: 'علبة', qty: 4 }], expiry: dFromNow(630), batch: 'N-8873' }
  ];
  let invTotalStrips = 0;
  invLines.forEach((line, li) => {
    const p = prod(line.productId);
    const factor = (uName: string) => (p.units.find(u => u.name === uName) || { factor: 1 }).factor;
    const total = line.units.reduce((s, u) => s + u.qty * factor(u.name), 0);
    const allocNums = distributeQuantities(total, db.warehouses.map(w => w.share));
    const alloc = db.warehouses.map((w, wi) => {
      putBatch(p.id, w.id, line.batch, line.expiry, allocNums[wi]);
      if (allocNums[wi] > 0) {
        addMove({
          type: 'in', productId: p.id, warehouseId: w.id, strips: allocNums[wi],
          ref: invoice.no, note: 'وارد فاتورة', date: invDate,
          createdAt: invDate + 'T10:3' + li + ':00'
        });
      }
      return { warehouseId: w.id, strips: allocNums[wi] };
    });
    invTotalStrips += total;
    invoice.lines.push({ productId: p.id, strips: total, units: line.units, expiry: line.expiry, batch: line.batch, alloc });
  });
  invoice.totalStrips = invTotalStrips;
  db.invoices.unshift(invoice);

  const trDate = shiftISO(nowISO, -3);
  const transfer: TransferOrder = {
    id: 'tr-5001', no: 'TR-5001', date: trDate, from: 'w1', to: 'w3',
    createdAt: trDate + 'T09:00:00', lines: []
  };
  [
    { productId: 'P002', units: [{ name: 'علبة', qty: 2 }] },
    { productId: 'P005', units: [{ name: 'علبة', qty: 1 }, { name: 'شريط', qty: 1 }] }
  ].forEach((l, li) => {
    const p = prod(l.productId);
    const need = l.units.reduce((s, u) => s + u.qty * ((p.units.find(x => x.name === u.name) || { factor: 1 }).factor), 0);
    const alloc = takeBatch(p.id, 'w1', need);
    alloc.forEach(a => {
      putBatch(p.id, 'w3', a.batch, a.expiry, a.strips);
      addMove({
        type: 'transfer-in', productId: p.id, warehouseId: 'w3', strips: a.strips,
        ref: transfer.no, note: 'تحويل وارد', date: trDate, createdAt: trDate + 'T09:0' + li + ':30'
      });
    });
    addMove({
      type: 'transfer-out', productId: p.id, warehouseId: 'w1', strips: need,
      ref: transfer.no, note: 'تحويل صادر', date: trDate, createdAt: trDate + 'T09:0' + li + ':00'
    });
    transfer.lines.push({ productId: p.id, strips: need, alloc });
  });
  db.transfers.push(transfer);

  const seedCustomer = db.partners.find(p => p.id === 'cus1');
  const issue: IssueOrder = {
    id: 'iss-1001', no: issPrefix + '0001', receiptNo: 'REC-' + issPrefix + '0001', receiptType: 'supplies',
    date: issDate, warehouseId: 'w1',
    customerId: 'cus1',
    customer: seedCustomer?.name || 'صيدلية الشفاء',
    customerCode: seedCustomer?.code || '',
    customerPhone: seedCustomer?.phone || '',
    customerAddress: seedCustomer?.address || '',
    customerTaxNo: seedCustomer?.taxNo || '',
    customerContact: seedCustomer?.contact || '',
    invoiceNo: '5521',
    invoiceDate: issDate,
    closed: true,
    invoiced: true,
    invoicedByFlow: true,
    invoicedAt: issDate + 'T13:00:00',
    createdAt: issDate + 'T12:15:00', invoiceTotal: 0, suppliesStrips: 0, lines: []
  };
  [
    { productId: 'P001', units: [{ name: 'علبة', qty: 3 }, { name: 'شريط', qty: 1 }] },
    { productId: 'P004', units: [{ name: 'علبة', qty: 1 }, { name: 'شريط', qty: 1 }] },
    { productId: 'S001', units: [{ name: 'علبة', qty: 2 }] },
    { productId: 'S002', units: [{ name: 'علبة', qty: 1 }] }
  ].forEach((l, li) => {
    const p = prod(l.productId);
    const need = l.units.reduce((s, u) => s + u.qty * ((p.units.find(x => x.name === u.name) || { factor: 1 }).factor), 0);
    const alloc = takeBatch(p.id, 'w1', need);
    addMove({
      type: 'issue', productId: p.id, warehouseId: 'w1', strips: need,
      ref: issue.no, note: p.marked ? 'صرف إيصال مستلزمات' : 'صرف على فاتورة',
      date: issDate, createdAt: issDate + 'T12:1' + li + ':00'
    });
    const price = p.marked ? 0 : p.price;
    issue.lines.push({
      productId: p.id,
      strips: need,
      pricePerStrip: price,
      asReceipt: Boolean(p.marked),
      receiptType: p.marked ? 'supplies' : undefined,
      alloc
    });
  });
  issue.invoiceTotal = issue.lines.reduce((s, l) => s + l.strips * l.pricePerStrip, 0);
  issue.suppliesStrips = issue.lines.filter(l => isLineReceipt(l, prod(l.productId))).reduce((s, l) => s + l.strips, 0);
  db.issues.unshift(issue);

  const openCustomer = db.partners.find(p => p.id === 'cus2');
  const openPrefix = nowISO.replace(/-/g, '') + '-';
  const openIssue: IssueOrder = {
    id: 'iss-1002',
    no: openPrefix + '0001',
    date: nowISO,
    warehouseId: 'w1',
    customerId: 'cus2',
    customer: openCustomer?.name || 'صيدلية النور',
    customerCode: openCustomer?.code || '',
    customerPhone: openCustomer?.phone || '',
    customerAddress: openCustomer?.address || '',
    customerTaxNo: openCustomer?.taxNo || '',
    customerContact: openCustomer?.contact || '',
    invoiceNo: '—',
    closed: false,
    invoiced: false,
    createdAt: nowISO + 'T09:30:00',
    invoiceTotal: 0,
    suppliesStrips: 0,
    lines: []
  };
  [
    { productId: 'P002', units: [{ name: 'علبة', qty: 2 }] },
    { productId: 'P003', units: [{ name: 'علبة', qty: 2 }, { name: 'شريط', qty: 1 }] }
  ].forEach((l, li) => {
    const p = prod(l.productId);
    const need = l.units.reduce((s, u) => s + u.qty * ((p.units.find(x => x.name === u.name) || { factor: 1 }).factor), 0);
    const alloc = takeBatch(p.id, 'w1', need);
    addMove({
      type: 'issue', productId: p.id, warehouseId: 'w1', strips: need,
      ref: openIssue.no, note: 'صرف بانتظار الفاتورة',
      date: nowISO, createdAt: nowISO + 'T09:3' + li + ':00'
    });
    openIssue.lines.push({
      productId: p.id,
      strips: need,
      pricePerStrip: p.price,
      asReceipt: false,
      alloc
    });
  });
  openIssue.invoiceTotal = openIssue.lines.reduce((s, l) => s + l.strips * l.pricePerStrip, 0);
  db.issues.unshift(openIssue);
  db.issues.forEach(iss => {
    iss.lines = sortIssueLines(iss.lines || [], db.products);
  });
  db.issues = sortIssuesByInvoiceStatus(db.issues);

  return db;
}

export function normalizeDB(parsed: AppDB): AppDB {
  const db = parsed;
  if (!db.company) {
    db.company = {
      name: 'صيدلية النور', address: '١٢ شارع الجمهورية، القاهرة', gov: 'القاهرة',
      phone: '0223001122', taxNo: '310-000-111', sales: 'أ. إسلام — مندوب المبيعات'
    };
  }
  if (!Array.isArray(db.returns)) db.returns = [];
  if (!db.meta) {
    db.meta = { nextIssue: 2, issueSeqDate: '', issueSeq: 1, returnSeq: 1, nextTransfer: 5002, nextInvoice: 119, seq: 1 };
  }
  if (!db.meta.returnSeq) db.meta.returnSeq = db.returns.length + 1;
  db.batches.forEach(b => { b.expiry = toFullDate(b.expiry); });
  db.products.forEach((p, i) => {
    p.units = normalizeUnits(p.units);
    if (!p.supplierId) p.supplierId = p.marked ? 'sup3' : (i % 2 ? 'sup2' : 'sup1');
  });
  (db.issues || []).forEach(iss => {
    iss.lines = sortIssueLines(iss.lines || [], db.products || []);
    if (iss.invoiced === undefined) {
      const hasExplicitInv = Boolean(iss.invoiceNo && iss.invoiceNo !== '—' && iss.invoiceNo !== '-');
      iss.invoiced = hasExplicitInv;
      iss.closed = hasExplicitInv;
      if (hasExplicitInv && iss.invoicedByFlow === undefined) {
        iss.invoicedByFlow = true;
      }
    } else if (iss.closed === undefined) {
      iss.closed = Boolean(iss.invoiced);
    }
  });
  db.issues = sortIssuesByInvoiceStatus(db.issues || []);
  return db;
}

export function normDocNo(s?: string | null): string {
  return String(s || '').trim().toLowerCase();
}

export function computeNextIssueNo(currentDb: AppDB): string {
  const prefix = todayISO().replace(/-/g, '') + '-';
  const todayNums = (currentDb.issues || [])
    .filter(i => String(i.no || '').startsWith(prefix))
    .map(i => parseInt(String(i.no).slice(prefix.length), 10))
    .filter(n => !isNaN(n));
  const maxToday = todayNums.length ? Math.max(...todayNums) : 0;
  const savedSeq = currentDb.meta.issueSeqDate === prefix ? (currentDb.meta.issueSeq || 1) : 1;
  let seq = Math.max(maxToday + 1, savedSeq);
  const used = new Set((currentDb.issues || []).map(i => normDocNo(i.no)).filter(Boolean));
  while (used.has(normDocNo(prefix + pad4(seq)))) {
    seq += 1;
  }
  return prefix + pad4(seq);
}

export function computeNextIncomingNo(currentDb: AppDB): string {
  const year = new Date().getFullYear();
  let seq = currentDb.meta?.nextInvoice || 1;
  const used = new Set<string>();
  (currentDb.invoices || []).forEach(inv => {
    const k = normDocNo(inv.no);
    if (k) used.add(k);
  });
  (currentDb.issues || []).forEach(iss => {
    const k = normDocNo(iss.invoiceNo);
    if (k && k !== '—' && k !== '-') used.add(k);
  });
  while (used.has(normDocNo(`INV-${year}-${seq}`))) {
    seq += 1;
  }
  return `INV-${year}-${seq}`;
}

export function computeNextSalesInvoiceNo(currentDb: AppDB): string {
  const year = new Date().getFullYear();
  let seq = 1;
  const used = new Set<string>();
  (currentDb.invoices || []).forEach(inv => {
    const k = normDocNo(inv.no);
    if (k) used.add(k);
  });
  (currentDb.issues || []).forEach(iss => {
    const k = normDocNo(iss.invoiceNo);
    if (k && k !== '—' && k !== '-') used.add(k);
  });
  while (used.has(normDocNo(`SAL-${year}-${pad4(seq)}`))) {
    seq += 1;
  }
  return `SAL-${year}-${pad4(seq)}`;
}

export function findDuplicateInvoiceNo(
  currentDb: AppDB,
  rawNo?: string | null,
  excludeIssueId?: string
): { source: 'incoming' | 'issue'; ref: string } | null {
  const q = normDocNo(rawNo);
  if (!q || q === '—' || q === '-') return null;

  const dupIncoming = (currentDb.invoices || []).find(inv => normDocNo(inv.no) === q);
  if (dupIncoming) {
    return { source: 'incoming', ref: dupIncoming.no };
  }

  const dupIssue = (currentDb.issues || []).find(iss => {
    if (excludeIssueId && iss.id === excludeIssueId) return false;
    const invKey = normDocNo(iss.invoiceNo);
    if (invKey && invKey !== '—' && invKey !== '-' && invKey === q) return true;
    // If a billable sales issue has no explicit invoiceNo, InvoiceListPage displays iss.no as its invoice number
    if ((!invKey || invKey === '—' || invKey === '-') && iss.invoiceTotal > 0 && normDocNo(iss.no) === q) {
      return true;
    }
    return false;
  });
  if (dupIssue) {
    return { source: 'issue', ref: dupIssue.no };
  }

  return null;
}

export function collectUsedReceiptNumbers(
  currentDb: AppDB,
  excludeIssueId?: string
): Map<string, { issueNo: string; label: string }> {
  const map = new Map<string, { issueNo: string; label: string }>();
  (currentDb.issues || []).forEach(iss => {
    if (excludeIssueId && iss.id === excludeIssueId) return;
    const groups = getIssueReceipts(iss, currentDb.products || []);
    groups.forEach(g => {
      const key = normDocNo(g.receiptNo);
      if (key && !map.has(key)) {
        map.set(key, { issueNo: iss.no, label: g.label });
      }
    });
  });
  return map;
}

export function findDuplicateReceiptNo(
  currentDb: AppDB,
  rawNo?: string | null,
  excludeIssueId?: string
): { issueNo: string; label: string } | null {
  const q = normDocNo(rawNo);
  if (!q) return null;
  const used = collectUsedReceiptNumbers(currentDb, excludeIssueId);
  return used.get(q) || null;
}

export function suggestReceiptNumbers(
  currentDb: AppDB,
  issueNo: string,
  hasSupplies: boolean,
  hasGift: boolean,
  excludeIssueId?: string
): { baseNo: string; suppliesNo: string; giftNo: string } {
  const used = collectUsedReceiptNumbers(currentDb, excludeIssueId);
  const baseNo = `REC-${issueNo}`;

  const pickUnique = (preferred: string, extraReserved?: string): string => {
    const reservedKey = extraReserved ? normDocNo(extraReserved) : '';
    if (!used.has(normDocNo(preferred)) && normDocNo(preferred) !== reservedKey) {
      return preferred;
    }
    let idx = 2;
    while (idx < 1000) {
      const cand = `${preferred}-${idx}`;
      const k = normDocNo(cand);
      if (!used.has(k) && k !== reservedKey) return cand;
      idx += 1;
    }
    return `${preferred}-${Date.now()}`;
  };

  if (hasSupplies && hasGift) {
    const suppliesNo = pickUnique(`${baseNo}-1`);
    const giftNo = pickUnique(`${baseNo}-2`, suppliesNo);
    return { baseNo, suppliesNo, giftNo };
  }
  if (hasSupplies) {
    const suppliesNo = pickUnique(baseNo);
    return { baseNo: suppliesNo, suppliesNo, giftNo: '' };
  }
  if (hasGift) {
    const giftNo = pickUnique(baseNo);
    return { baseNo: giftNo, suppliesNo: '', giftNo };
  }
  return { baseNo, suppliesNo: '', giftNo: '' };
}

export function computeNextReturnNo(currentDb: AppDB): string {
  const prefix = 'RET-' + todayISO().replace(/-/g, '') + '-';
  const todayNums = (currentDb.returns || [])
    .filter(r => String(r.no || '').startsWith(prefix))
    .map(r => parseInt(String(r.no).slice(prefix.length), 10))
    .filter(n => !isNaN(n));
  const maxToday = todayNums.length ? Math.max(...todayNums) : 0;
  const seq = Math.max(maxToday + 1, currentDb.meta.returnSeq || 1);
  return prefix + pad4(seq);
}

export type PharmaAction =
  | { type: 'saveShares'; shares: Record<string, number> }
  | { type: 'addProduct'; data: Omit<Product, 'id'> }
  | { type: 'updateProduct'; id: string; data: Partial<Omit<Product, 'id'>> }
  | { type: 'addPartner'; data: Omit<Partner, 'id'> }
  | { type: 'updatePartner'; id: string; data: Partial<Omit<Partner, 'id'>> }
  | { type: 'deletePartner'; id: string }
  | { type: 'updateCompany'; data: CompanyInfo }
  | { type: 'commitIncoming'; draft: DraftIncoming }
  | {
      type: 'bulkImportIncoming';
      rows: { productId: string; units: { name: string; qty: number }[]; strips: number; expiry: string; batch: string }[];
      meta: { no: string; supplierId: string; date: string; mode: 'shares' | 'equal' };
    }
  | { type: 'commitIssue'; draft: DraftIssue }
  | { type: 'updateIssue'; id: string; draft: DraftIssue }
  | { type: 'createSalesInvoice'; issueId: string; invoiceNo: string; invoiceDate: string }
  | { type: 'setIssueInvoiced'; issueId: string; invoiced: boolean }
  | {
      type: 'commitReturn';
      params: {
        issueId: string;
        warehouseId: string;
        date: string;
        reason: string;
        lines: CustomerReturnLine[];
        keptStrips: number;
        returnType: 'full' | 'partial';
      };
    }
  | { type: 'commitTransfer'; draft: DraftTransfer }
  | { type: 'restoreBackup'; jsonText: string }
  | { type: 'resetData' };

function cloneDB(db: AppDB): AppDB {
  return JSON.parse(JSON.stringify(db)) as AppDB;
}

function commitIncomingOnDB(db: AppDB, draft: DraftIncoming, actor?: string): { db: AppDB; invoice: Invoice } {
  const nextDb = cloneDB(db);
  const supplier = nextDb.partners.find(p => p.id === draft.supplierId);
  const shares =
    draft.mode === 'equal'
      ? nextDb.warehouses.map(() => 100 / nextDb.warehouses.length)
      : nextDb.warehouses.map(w => w.share);

  let seq = nextDb.meta.seq;

  const putBatch = (productId: string, warehouseId: string, batch: string, expiry: string, strips: number) => {
    if (strips <= 0) return;
    const normExp = toFullDate(expiry);
    const found = nextDb.batches.find(
      b => b.productId === productId && b.warehouseId === warehouseId && b.batch === batch && b.expiry === normExp
    );
    if (found) found.strips += strips;
    else nextDb.batches.push({ id: uid('b'), productId, warehouseId, batch, expiry: normExp, strips });
  };

  const resolvedNo = draft.no.trim() || computeNextIncomingNo(nextDb);
  const dupInv = findDuplicateInvoiceNo(nextDb, resolvedNo);
  if (dupInv) {
    throw new Error(
      `رقم الفاتورة «${resolvedNo}» مستخدم بالفعل (${dupInv.source === 'incoming' ? `فاتورة وارد ${dupInv.ref}` : `أذن صرف ${dupInv.ref}`}) — لا يصح تكرار رقم الفاتورة.`
    );
  }

  const invoice: Invoice = {
    id: uid('inv'),
    no: resolvedNo,
    supplierId: draft.supplierId,
    supplier: supplier ? supplier.name : 'مورد عام',
    date: draft.date,
    createdAt: new Date().toISOString(),
    createdBy: actor,
    totalStrips: 0,
    lines: []
  };

  draft.lines.forEach(l => {
    let nums: number[];
    if (draft.mode === 'manual') {
      nums = nextDb.warehouses.map(w => Math.max(0, Math.round(Number(l.manualAlloc?.[w.id]) || 0)));
      const allocSum = nums.reduce((a, b) => a + b, 0);
      if (allocSum !== l.strips) {
        const prod = nextDb.products.find(x => x.id === l.productId);
        throw new Error(
          `مجموع التوزيع اليدوي لصنف «${prod?.name || l.productId}» (${fmtNum(allocSum)}) لا يساوي الكمية الواردة (${fmtNum(l.strips)}).`
        );
      }
    } else {
      nums = distributeQuantities(l.strips, shares);
    }

    const alloc = nextDb.warehouses.map((w, i) => {
      putBatch(l.productId, w.id, l.batch, l.expiry, nums[i]);
      if (nums[i] > 0) {
        nextDb.movements.unshift({
          id: 'mv-' + seq++,
          type: 'in',
          productId: l.productId,
          warehouseId: w.id,
          strips: nums[i],
          ref: invoice.no,
          note: actor ? `وارد فاتورة (${actor})` : 'وارد فاتورة',
          date: draft.date,
          createdAt: new Date().toISOString()
        });
      }
      return { warehouseId: w.id, strips: nums[i] };
    });
    invoice.totalStrips += l.strips;
    invoice.lines.push({
      productId: l.productId,
      strips: l.strips,
      units: l.units,
      expiry: toFullDate(l.expiry),
      batch: l.batch,
      alloc
    });
  });

  nextDb.invoices.unshift(invoice);
  nextDb.meta.nextInvoice += 1;
  nextDb.meta.seq = seq;

  return { db: nextDb, invoice };
}

export function executePharmaAction(
  currentDb: AppDB,
  action: PharmaAction,
  actor?: string
): { db: AppDB; result?: unknown; summary: string } {
  switch (action.type) {
    case 'saveShares': {
      const nextDb = cloneDB(currentDb);
      nextDb.warehouses = nextDb.warehouses.map(w => ({ ...w, share: action.shares[w.id] ?? w.share }));
      return { db: nextDb, summary: 'تحديث نسب توزيع المخازن' };
    }

    case 'addProduct': {
      const nextDb = cloneDB(currentDb);
      const id = uid('P');
      const newProd: Product = {
        ...action.data,
        id,
        code: (action.data.code || id).toUpperCase(),
        units: normalizeUnits(action.data.units)
      };
      nextDb.products.push(newProd);
      return { db: nextDb, result: newProd, summary: `إضافة صنف: ${newProd.name}` };
    }

    case 'updateProduct': {
      const nextDb = cloneDB(currentDb);
      nextDb.products = nextDb.products.map(p =>
        p.id === action.id
          ? {
              ...p,
              ...action.data,
              code: (action.data.code || p.code).toUpperCase(),
              units: action.data.units ? normalizeUnits(action.data.units) : p.units
            }
          : p
      );
      return { db: nextDb, summary: 'تحديث بيانات صنف' };
    }

    case 'addPartner': {
      const nextDb = cloneDB(currentDb);
      const id = uid('prt');
      const newPartner: Partner = { ...action.data, id, code: (action.data.code || id).toUpperCase() };
      nextDb.partners.push(newPartner);
      return {
        db: nextDb,
        result: newPartner,
        summary: `إضافة ${newPartner.type === 'customer' ? 'عميل' : 'مورد'}: ${newPartner.name}`
      };
    }

    case 'updatePartner': {
      const nextDb = cloneDB(currentDb);
      nextDb.partners = nextDb.partners.map(p =>
        p.id === action.id ? { ...p, ...action.data, code: (action.data.code || p.code).toUpperCase() } : p
      );
      return { db: nextDb, summary: 'تحديث بيانات جهة' };
    }

    case 'deletePartner': {
      const nextDb = cloneDB(currentDb);
      nextDb.partners = nextDb.partners.filter(p => p.id !== action.id);
      return { db: nextDb, summary: 'حذف جهة' };
    }

    case 'updateCompany': {
      const nextDb = cloneDB(currentDb);
      nextDb.company = action.data;
      return { db: nextDb, summary: 'تحديث بيانات الصيدلية للترويسة' };
    }

    case 'commitIncoming': {
      const { db: nextDb, invoice } = commitIncomingOnDB(currentDb, action.draft, actor);
      return { db: nextDb, result: invoice, summary: `ترحيل فاتورة وارد ${invoice.no}` };
    }

    case 'bulkImportIncoming': {
      const mergedMap = new Map<
        string,
        { productId: string; units: { name: string; qty: number }[]; strips: number; expiry: string; batch: string }
      >();
      action.rows.forEach(r => {
        const normExp = toFullDate(r.expiry);
        const key = `${r.productId}|${r.batch}|${normExp}`;
        const existing = mergedMap.get(key);
        if (existing) {
          existing.strips += r.strips;
          existing.units = [...existing.units, ...r.units];
        } else {
          mergedMap.set(key, { ...r, expiry: normExp, units: [...r.units] });
        }
      });

      const draft: DraftIncoming = {
        no: action.meta.no,
        supplierId: action.meta.supplierId,
        date: action.meta.date,
        mode: action.meta.mode,
        lines: Array.from(mergedMap.values()).map(m => ({ id: uid('ln'), ...m }))
      };
      const { db: nextDb, invoice } = commitIncomingOnDB(currentDb, draft, actor);
      return { db: nextDb, result: invoice, summary: `استيراد وترحيل فاتورة وارد ${invoice.no}` };
    }

    case 'commitIssue': {
      const nextDb = cloneDB(currentDb);
      const draft = action.draft;
      const today = todayISO();
      const customer = nextDb.partners.find(p => p.id === draft.customerId);
      let seq = nextDb.meta.seq;
      const issueNo = computeNextIssueNo(nextDb);

      const cleanInvoiceNo = draft.invoiceNo.trim();
      if (cleanInvoiceNo && cleanInvoiceNo !== '—' && cleanInvoiceNo !== '-') {
        const dupInv = findDuplicateInvoiceNo(nextDb, cleanInvoiceNo);
        if (dupInv) {
          throw new Error(
            `رقم الفاتورة «${cleanInvoiceNo}» مستخدم بالفعل (${dupInv.source === 'incoming' ? `فاتورة وارد ${dupInv.ref}` : `أذن صرف ${dupInv.ref}`}) — لا يصح تكرار رقم الفاتورة.`
          );
        }
      }

      const preSuppliesCount = draft.lines.filter(l => {
        const p = nextDb.products.find(x => x.id === l.productId);
        const asRec = l.asReceipt !== undefined ? l.asReceipt : Boolean(p?.marked);
        return asRec && getLineReceiptType(l, p) === 'supplies';
      }).length;
      const preGiftCount = draft.lines.filter(l => {
        const p = nextDb.products.find(x => x.id === l.productId);
        const asRec = l.asReceipt !== undefined ? l.asReceipt : Boolean(p?.marked);
        return asRec && getLineReceiptType(l, p) === 'gift';
      }).length;

      const hasPreBoth = preSuppliesCount > 0 && preGiftCount > 0;
      const suggestedPre = suggestReceiptNumbers(nextDb, issueNo, preSuppliesCount > 0, preGiftCount > 0);
      const preBaseRec = draft.receiptNo?.trim() || suggestedPre.baseNo;
      const preSuppliesRecNo =
        preSuppliesCount > 0
          ? (hasPreBoth
              ? draft.suppliesReceiptNo?.trim() || suggestedPre.suppliesNo
              : draft.receiptNo?.trim() || draft.suppliesReceiptNo?.trim() || suggestedPre.suppliesNo)
          : undefined;
      const preGiftRecNo =
        preGiftCount > 0
          ? (hasPreBoth
              ? draft.giftReceiptNo?.trim() || suggestedPre.giftNo
              : draft.receiptNo?.trim() || draft.giftReceiptNo?.trim() || suggestedPre.giftNo)
          : undefined;

      if (preSuppliesRecNo && preGiftRecNo && normDocNo(preSuppliesRecNo) === normDocNo(preGiftRecNo)) {
        throw new Error('لا يصح تطابق رقم إيصال المستلزمات مع رقم إيصال الهدية بدون قيمة في نفس الأذن.');
      }
      if (preSuppliesRecNo) {
        const dupSup = findDuplicateReceiptNo(nextDb, preSuppliesRecNo);
        if (dupSup) {
          throw new Error(
            `رقم إيصال المستلزمات «${preSuppliesRecNo}» مستخدم بالفعل في أذن الصرف ${dupSup.issueNo} (${dupSup.label}) — لا يصح تكرار رقم الإيصال.`
          );
        }
      }
      if (preGiftRecNo) {
        const dupGift = findDuplicateReceiptNo(nextDb, preGiftRecNo);
        if (dupGift) {
          throw new Error(
            `رقم إيصال الهدية «${preGiftRecNo}» مستخدم بالفعل في أذن الصرف ${dupGift.issueNo} (${dupGift.label}) — لا يصح تكرار رقم الإيصال.`
          );
        }
      }

      const lines = draft.lines.map(l => {
        const p = nextDb.products.find(x => x.id === l.productId);
        if (!p) throw new Error('صنف غير موجود');
        const eligible = nextDb.batches
          .filter(b => b.productId === l.productId && b.warehouseId === draft.warehouseId && b.strips > 0 && b.expiry >= today)
          .sort((a, b) => a.expiry.localeCompare(b.expiry));
        const avail = eligible.reduce((s, b) => s + b.strips, 0);
        if (avail < l.strips) {
          throw new Error(`الرصيد غير كافٍ من ${p.name}. المتاح ${fmtNum(avail)} وحدة.`);
        }
        let rem = l.strips;
        const alloc: LotAllocation[] = [];
        for (const b of eligible) {
          if (rem <= 0) break;
          const take = Math.min(b.strips, rem);
          b.strips -= take;
          rem -= take;
          alloc.push({ batchId: b.id, batch: b.batch, expiry: b.expiry, strips: take });
        }
        const asReceipt = l.asReceipt !== undefined ? l.asReceipt : Boolean(p.marked);
        const rType = asReceipt ? getLineReceiptType(l, p) : undefined;
        nextDb.movements.unshift({
          id: 'mv-' + seq++,
          type: 'issue',
          productId: l.productId,
          warehouseId: draft.warehouseId,
          strips: l.strips,
          ref: issueNo,
          note: `${asReceipt ? (rType === 'gift' ? 'صرف إيصال هدية بدون قيمة' : 'صرف إيصال مستلزمات') : 'صرف على فاتورة'}${actor ? ` (${actor})` : ''}`,
          date: draft.date,
          createdAt: new Date().toISOString()
        });
        const pricePerStrip = asReceipt ? 0 : p.price;
        return { productId: l.productId, strips: l.strips, pricePerStrip, asReceipt, receiptType: rType, alloc };
      });

      const sortedLines = sortIssueLines(lines, nextDb.products);
      const invoiceTotal = sortedLines.reduce((s, l) => s + l.strips * l.pricePerStrip, 0);
      const receiptLineItems = sortedLines.filter(l => isLineReceipt(l, nextDb.products.find(p => p.id === l.productId)));
      const suppliesStrips = receiptLineItems.reduce((s, l) => s + l.strips, 0);
      const hasReceipts = receiptLineItems.length > 0;
      const defaultOrderReceiptType = hasReceipts ? receiptLineItems[0].receiptType || 'supplies' : undefined;

      const isMarkedInvoiced = Boolean(draft.invoiced);
      const isFormalInv = Boolean(isMarkedInvoiced && cleanInvoiceNo && cleanInvoiceNo !== '—');
      const issue: IssueOrder = {
        id: uid('iss'),
        no: issueNo,
        receiptNo: hasReceipts ? preBaseRec : undefined,
        suppliesReceiptNo: preSuppliesRecNo,
        giftReceiptNo: preGiftRecNo,
        receiptType: hasReceipts ? draft.receiptType || defaultOrderReceiptType : undefined,
        date: draft.date,
        warehouseId: draft.warehouseId,
        customerId: draft.customerId,
        customer: customer ? customer.name : 'عميل عام',
        customerCode: customer?.code || '',
        customerPhone: customer?.phone || '',
        customerAddress: customer?.address || '',
        customerTaxNo: customer?.taxNo || '',
        customerContact: customer?.contact || '',
        invoiceNo: cleanInvoiceNo || '—',
        invoiceDate: isFormalInv ? draft.date : undefined,
        closed: isMarkedInvoiced,
        invoiced: isMarkedInvoiced,
        invoicedByFlow: isFormalInv,
        invoicedAt: isMarkedInvoiced ? new Date().toISOString() : undefined,
        invoicedBy: isMarkedInvoiced ? actor : undefined,
        createdAt: new Date().toISOString(),
        createdBy: actor,
        invoiceTotal,
        suppliesStrips,
        lines: sortedLines
      };

      const prefix = today.replace(/-/g, '') + '-';
      const usedSeq = issueNo.startsWith(prefix) ? parseInt(issueNo.slice(prefix.length), 10) : NaN;

      nextDb.issues.unshift(issue);
      nextDb.issues = sortIssuesByInvoiceStatus(nextDb.issues);
      nextDb.meta.nextIssue += 1;
      nextDb.meta.issueSeqDate = prefix;
      nextDb.meta.issueSeq = !isNaN(usedSeq) ? usedSeq + 1 : nextDb.meta.issueSeq + 1;
      nextDb.meta.seq = seq;

      return { db: nextDb, result: issue, summary: `ترحيل أذن صرف ${issue.no}` };
    }

    case 'updateIssue': {
      const nextDb = cloneDB(currentDb);
      const existingIdx = nextDb.issues.findIndex(i => i.id === action.id);
      if (existingIdx < 0) throw new Error('أذن الصرف غير موجود');

      const existing = nextDb.issues[existingIdx];
      if (existing.closed) {
        throw new Error('أذن الصرف مغلق بعد عمل الفاتورة ولا يمكن تعديله.');
      }
      const draft = action.draft;
      if (!draft.lines.length) throw new Error('أضف بندًا واحدًا على الأقل في أذن الصرف');

      const today = todayISO();
      const customer = nextDb.partners.find(p => p.id === draft.customerId);
      const hasReturns = (nextDb.returns || []).some(r => r.issueId === existing.id);

      const cleanInvoiceNo = draft.invoiceNo.trim();
      if (cleanInvoiceNo && cleanInvoiceNo !== '—' && cleanInvoiceNo !== '-') {
        const dupInv = findDuplicateInvoiceNo(nextDb, cleanInvoiceNo, existing.id);
        if (dupInv) {
          throw new Error(
            `رقم الفاتورة «${cleanInvoiceNo}» مستخدم بالفعل (${dupInv.source === 'incoming' ? `فاتورة وارد ${dupInv.ref}` : `أذن صرف ${dupInv.ref}`}) — لا يصح تكرار رقم الفاتورة.`
          );
        }
      }

      const preSuppliesCount = draft.lines.filter(l => {
        const p = nextDb.products.find(x => x.id === l.productId);
        const asRec = l.asReceipt !== undefined ? l.asReceipt : Boolean(p?.marked);
        return asRec && getLineReceiptType(l, p) === 'supplies';
      }).length;
      const preGiftCount = draft.lines.filter(l => {
        const p = nextDb.products.find(x => x.id === l.productId);
        const asRec = l.asReceipt !== undefined ? l.asReceipt : Boolean(p?.marked);
        return asRec && getLineReceiptType(l, p) === 'gift';
      }).length;

      const hasPreBoth = preSuppliesCount > 0 && preGiftCount > 0;
      const suggestedPre = suggestReceiptNumbers(nextDb, existing.no, preSuppliesCount > 0, preGiftCount > 0, existing.id);
      const preBaseRec = draft.receiptNo?.trim() || suggestedPre.baseNo;
      const preSuppliesRecNo =
        preSuppliesCount > 0
          ? (hasPreBoth
              ? draft.suppliesReceiptNo?.trim() || suggestedPre.suppliesNo
              : draft.receiptNo?.trim() || draft.suppliesReceiptNo?.trim() || suggestedPre.suppliesNo)
          : undefined;
      const preGiftRecNo =
        preGiftCount > 0
          ? (hasPreBoth
              ? draft.giftReceiptNo?.trim() || suggestedPre.giftNo
              : draft.receiptNo?.trim() || draft.giftReceiptNo?.trim() || suggestedPre.giftNo)
          : undefined;

      if (preSuppliesRecNo && preGiftRecNo && normDocNo(preSuppliesRecNo) === normDocNo(preGiftRecNo)) {
        throw new Error('لا يصح تطابق رقم إيصال المستلزمات مع رقم إيصال الهدية بدون قيمة في نفس الأذن.');
      }
      if (preSuppliesRecNo) {
        const dupSup = findDuplicateReceiptNo(nextDb, preSuppliesRecNo, existing.id);
        if (dupSup) {
          throw new Error(
            `رقم إيصال المستلزمات «${preSuppliesRecNo}» مستخدم بالفعل في أذن الصرف ${dupSup.issueNo} (${dupSup.label}) — لا يصح تكرار رقم الإيصال.`
          );
        }
      }
      if (preGiftRecNo) {
        const dupGift = findDuplicateReceiptNo(nextDb, preGiftRecNo, existing.id);
        if (dupGift) {
          throw new Error(
            `رقم إيصال الهدية «${preGiftRecNo}» مستخدم بالفعل في أذن الصرف ${dupGift.issueNo} (${dupGift.label}) — لا يصح تكرار رقم الإيصال.`
          );
        }
      }

      let lines = existing.lines;
      let seq = nextDb.meta.seq;

      if (hasReturns) {
        const draftSorted = sortIssueLines(draft.lines, nextDb.products);
        const existingSorted = sortIssueLines(existing.lines, nextDb.products);
        const linesChanged =
          draft.warehouseId !== existing.warehouseId ||
          draftSorted.length !== existingSorted.length ||
          draftSorted.some((dl, idx) => {
            const ol = existingSorted[idx];
            if (!ol) return true;
            const p = nextDb.products.find(x => x.id === dl.productId);
            const dAsRec = dl.asReceipt !== undefined ? dl.asReceipt : Boolean(p?.marked);
            const oAsRec = isLineReceipt(ol, p);
            const dRecType = dAsRec ? getLineReceiptType(dl, p) : undefined;
            const oRecType = oAsRec ? getLineReceiptType(ol, p) : undefined;
            return dl.productId !== ol.productId || dl.strips !== ol.strips || dAsRec !== oAsRec || dRecType !== oRecType;
          });
        if (linesChanged) {
          throw new Error('لا يمكن تعديل أصناف أو مخزن أذن صرف مسجل عليه مرتجع عميل؛ يمكنك تعديل بيانات العميل أو رقم الفاتورة أو التاريخ فقط.');
        }
      } else {
        // 1) Restore previously deducted batch quantities back to the original warehouse
        existing.lines.forEach(oldLine => {
          const allocs = oldLine.alloc?.length
            ? oldLine.alloc
            : [{ batchId: undefined, batch: 'ADJ', expiry: shiftISO(today, 365), strips: oldLine.strips }];
          allocs.forEach(a => {
            if (!a.strips || a.strips <= 0) return;
            const normExp = toFullDate(a.expiry || shiftISO(today, 365));
            const found =
              (a.batchId ? nextDb.batches.find(b => b.id === a.batchId) : undefined) ||
              nextDb.batches.find(
                b =>
                  b.productId === oldLine.productId &&
                  b.warehouseId === existing.warehouseId &&
                  b.batch === a.batch &&
                  b.expiry === normExp
              );
            if (found) {
              found.strips += a.strips;
            } else {
              nextDb.batches.push({
                id: a.batchId || uid('b'),
                productId: oldLine.productId,
                warehouseId: existing.warehouseId,
                batch: a.batch || 'RET',
                expiry: normExp,
                strips: a.strips
              });
            }
          });
        });

        // 2) Replace previous issue movements for this order number
        nextDb.movements = nextDb.movements.filter(m => !(m.type === 'issue' && m.ref === existing.no));

        // 3) Deduct updated lines using FEFO from target warehouse
        lines = draft.lines.map(l => {
          const p = nextDb.products.find(x => x.id === l.productId);
          if (!p) throw new Error('صنف غير موجود');
          const eligible = nextDb.batches
            .filter(b => b.productId === l.productId && b.warehouseId === draft.warehouseId && b.strips > 0 && b.expiry >= today)
            .sort((a, b) => a.expiry.localeCompare(b.expiry));
          const avail = eligible.reduce((s, b) => s + b.strips, 0);
          if (avail < l.strips) {
            throw new Error(`الرصيد غير كافٍ من ${p.name}. المتاح ${fmtNum(avail)} وحدة.`);
          }
          let rem = l.strips;
          const alloc: LotAllocation[] = [];
          for (const b of eligible) {
            if (rem <= 0) break;
            const take = Math.min(b.strips, rem);
            b.strips -= take;
            rem -= take;
            alloc.push({ batchId: b.id, batch: b.batch, expiry: b.expiry, strips: take });
          }
          const asReceipt = l.asReceipt !== undefined ? l.asReceipt : Boolean(p.marked);
          const rType = asReceipt ? getLineReceiptType(l, p) : undefined;
          nextDb.movements.unshift({
            id: 'mv-' + seq++,
            type: 'issue',
            productId: l.productId,
            warehouseId: draft.warehouseId,
            strips: l.strips,
            ref: existing.no,
            note: `${asReceipt ? (rType === 'gift' ? 'صرف إيصال هدية بدون قيمة' : 'صرف إيصال مستلزمات') : 'صرف على فاتورة'} (تعديل${actor ? ` - ${actor}` : ''})`,
            date: draft.date,
            createdAt: new Date().toISOString()
          });
          const pricePerStrip = asReceipt ? 0 : p.price;
          return { productId: l.productId, strips: l.strips, pricePerStrip, asReceipt, receiptType: rType, alloc };
        });
      }

      const sortedLines = sortIssueLines(lines, nextDb.products);
      const invoiceTotal = sortedLines.reduce((s, l) => s + l.strips * l.pricePerStrip, 0);
      const receiptLineItems = sortedLines.filter(l => isLineReceipt(l, nextDb.products.find(p => p.id === l.productId)));
      const suppliesStrips = receiptLineItems.reduce((s, l) => s + l.strips, 0);
      const hasReceipts = receiptLineItems.length > 0;
      const defaultOrderReceiptType = hasReceipts ? receiptLineItems[0].receiptType || 'supplies' : undefined;

      const isMarkedInvoiced = Boolean(draft.invoiced);
      const isFormalInv = Boolean(isMarkedInvoiced && cleanInvoiceNo && cleanInvoiceNo !== '—');
      const updatedIssue: IssueOrder = {
        ...existing,
        receiptNo: hasReceipts ? preBaseRec : undefined,
        suppliesReceiptNo: preSuppliesRecNo,
        giftReceiptNo: preGiftRecNo,
        receiptType: hasReceipts ? draft.receiptType || defaultOrderReceiptType : undefined,
        date: draft.date,
        warehouseId: draft.warehouseId,
        customerId: draft.customerId,
        customer: customer ? customer.name : existing.customer || 'عميل عام',
        customerCode: customer?.code || '',
        customerPhone: customer?.phone || '',
        customerAddress: customer?.address || '',
        customerTaxNo: customer?.taxNo || '',
        customerContact: customer?.contact || '',
        invoiceNo: cleanInvoiceNo || '—',
        invoiceDate: isFormalInv ? draft.date : existing.invoiceDate,
        closed: isMarkedInvoiced,
        invoiced: isMarkedInvoiced,
        invoicedByFlow: isFormalInv,
        invoicedAt: isMarkedInvoiced ? existing.invoicedAt || new Date().toISOString() : undefined,
        invoicedBy: isMarkedInvoiced ? existing.invoicedBy || actor : undefined,
        invoiceTotal,
        suppliesStrips,
        lines: sortedLines
      };

      nextDb.issues[existingIdx] = updatedIssue;
      nextDb.issues = sortIssuesByInvoiceStatus(nextDb.issues);
      nextDb.meta.seq = seq;

      return { db: nextDb, result: updatedIssue, summary: `تعديل أذن صرف ${updatedIssue.no}` };
    }

    case 'createSalesInvoice': {
      const nextDb = cloneDB(currentDb);
      const idx = nextDb.issues.findIndex(i => i.id === action.issueId);
      if (idx < 0) throw new Error('أذن الصرف غير موجود');
      const iss = nextDb.issues[idx];
      if (iss.closed || iss.invoiced) {
        throw new Error(`أذن الصرف ${iss.no} مغلق أو تم عمل فاتورة له بالفعل.`);
      }
      const billableLines = (iss.lines || []).filter(l => {
        const p = nextDb.products.find(x => x.id === l.productId);
        return !isLineReceipt(l, p);
      });
      if (!billableLines.length) {
        throw new Error('هذا الأذن لا يحتوي على بنود فاتورة مسعّرة (إيصالات فقط) — يمكنك التعليم عليه بـ «تم عمل فاتورة» لإغلاقه.');
      }

      const cleanNo = action.invoiceNo.trim() || computeNextSalesInvoiceNo(nextDb);
      const dupInv = findDuplicateInvoiceNo(nextDb, cleanNo, iss.id);
      if (dupInv) {
        throw new Error(
          `رقم الفاتورة «${cleanNo}» مستخدم بالفعل (${dupInv.source === 'incoming' ? `فاتورة وارد ${dupInv.ref}` : `أذن صرف ${dupInv.ref}`}) — لا يصح تكرار رقم الفاتورة.`
        );
      }

      const updated: IssueOrder = {
        ...iss,
        invoiceNo: cleanNo,
        invoiceDate: action.invoiceDate || todayISO(),
        closed: true,
        invoiced: true,
        invoicedByFlow: true,
        invoicedAt: new Date().toISOString(),
        invoicedBy: actor
      };
      nextDb.issues[idx] = updated;
      nextDb.issues = sortIssuesByInvoiceStatus(nextDb.issues);
      return {
        db: nextDb,
        result: updated,
        summary: `إصدار فاتورة مبيعات ${cleanNo} وإغلاق أذن الصرف ${iss.no}`
      };
    }

    case 'setIssueInvoiced': {
      const nextDb = cloneDB(currentDb);
      const idx = nextDb.issues.findIndex(i => i.id === action.issueId);
      if (idx < 0) throw new Error('أذن الصرف غير موجود');
      const iss = nextDb.issues[idx];
      if (iss.invoicedByFlow && !action.invoiced) {
        throw new Error('تم إصدار فاتورة مبيعات رسمية لهذا الأذن ولا يمكن إلغاء إغلاقه.');
      }
      const updated: IssueOrder = {
        ...iss,
        invoiced: action.invoiced,
        closed: action.invoiced,
        invoicedAt: action.invoiced ? iss.invoicedAt || new Date().toISOString() : undefined,
        invoicedBy: action.invoiced ? iss.invoicedBy || actor : undefined
      };
      nextDb.issues[idx] = updated;
      nextDb.issues = sortIssuesByInvoiceStatus(nextDb.issues);
      return {
        db: nextDb,
        result: updated,
        summary: action.invoiced
          ? `تم التعليم على أذن الصرف ${iss.no} (تم عمل فاتورة وإغلاقه)`
          : `إعادة فتح أذن الصرف ${iss.no}`
      };
    }

    case 'commitReturn': {
      const nextDb = cloneDB(currentDb);
      const params = action.params;
      const iss = nextDb.issues.find(i => i.id === params.issueId);
      if (!iss) throw new Error('أذن الصرف غير موجود');
      if (!params.lines.length) throw new Error('اختر كمية مرتجعة واحدة على الأقل');

      let seq = nextDb.meta.seq;
      const retNo = computeNextReturnNo(nextDb);

      params.lines.forEach(l => {
        const normExp = toFullDate(l.expiry);
        const found = nextDb.batches.find(
          b => b.productId === l.productId && b.warehouseId === params.warehouseId && b.batch === l.batch && b.expiry === normExp
        );
        if (found) found.strips += l.strips;
        else {
          nextDb.batches.push({
            id: uid('b'),
            productId: l.productId,
            warehouseId: params.warehouseId,
            batch: l.batch || 'RET',
            expiry: normExp || shiftISO(todayISO(), 180),
            strips: l.strips
          });
        }
        nextDb.movements.unshift({
          id: 'mv-' + seq++,
          type: 'return-in',
          productId: l.productId,
          warehouseId: params.warehouseId,
          strips: l.strips,
          ref: retNo,
          note: `${params.returnType === 'full' ? `مرتجع كلي من ${iss.no}` : `مرتجع جزئي من ${iss.no}`}${actor ? ` (${actor})` : ''}`,
          date: params.date,
          createdAt: new Date().toISOString()
        });
      });

      const totalStrips = params.lines.reduce((s, l) => s + l.strips, 0);
      const totalValue = params.lines.reduce((s, l) => s + l.strips * (l.pricePerStrip || 0), 0);

      const retRec: CustomerReturn = {
        id: uid('ret'),
        no: retNo,
        issueId: iss.id,
        issueNo: iss.no,
        invoiceNo: iss.invoiceNo,
        customerId: iss.customerId,
        customer: iss.customer,
        warehouseId: params.warehouseId,
        date: params.date,
        returnType: params.returnType,
        reason: params.reason.trim(),
        totalStrips,
        keptStrips: params.keptStrips,
        totalValue,
        createdAt: new Date().toISOString(),
        createdBy: actor,
        lines: params.lines
      };

      nextDb.returns.unshift(retRec);
      nextDb.meta.returnSeq = (nextDb.meta.returnSeq || 1) + 1;
      nextDb.meta.seq = seq;

      return { db: nextDb, result: retRec, summary: `تسجيل مرتجع عميل ${retRec.no}` };
    }

    case 'commitTransfer': {
      const nextDb = cloneDB(currentDb);
      const draft = action.draft;
      if (draft.from === draft.to) throw new Error('المخزن المصدر والمستقبل يجب أن يكونا مختلفين');
      const today = todayISO();
      let seq = nextDb.meta.seq;
      const trNo = draft.no || `TR-${nextDb.meta.nextTransfer}`;

      const putBatch = (productId: string, warehouseId: string, batch: string, expiry: string, strips: number) => {
        const normExp = toFullDate(expiry);
        const found = nextDb.batches.find(
          b => b.productId === productId && b.warehouseId === warehouseId && b.batch === batch && b.expiry === normExp
        );
        if (found) found.strips += strips;
        else nextDb.batches.push({ id: uid('b'), productId, warehouseId, batch, expiry: normExp, strips });
      };

      const lines = draft.lines.map(l => {
        const p = nextDb.products.find(x => x.id === l.productId);
        if (!p) throw new Error('صنف غير موجود');
        const eligible = nextDb.batches
          .filter(b => b.productId === l.productId && b.warehouseId === draft.from && b.strips > 0 && b.expiry >= today)
          .sort((a, b) => a.expiry.localeCompare(b.expiry));
        const avail = eligible.reduce((s, b) => s + b.strips, 0);
        if (avail < l.strips) throw new Error(`الرصيد غير كافٍ من ${p.name} في المخزن المصدر`);
        let rem = l.strips;
        const alloc: LotAllocation[] = [];
        for (const b of eligible) {
          if (rem <= 0) break;
          const t = Math.min(b.strips, rem);
          b.strips -= t;
          rem -= t;
          alloc.push({ batchId: b.id, batch: b.batch, expiry: b.expiry, strips: t });
          putBatch(l.productId, draft.to, b.batch, b.expiry, t);
          nextDb.movements.unshift({
            id: 'mv-' + seq++,
            type: 'transfer-in',
            productId: l.productId,
            warehouseId: draft.to,
            strips: t,
            ref: trNo,
            note: actor ? `تحويل وارد (${actor})` : 'تحويل وارد',
            date: draft.date,
            createdAt: new Date().toISOString()
          });
        }
        nextDb.movements.unshift({
          id: 'mv-' + seq++,
          type: 'transfer-out',
          productId: l.productId,
          warehouseId: draft.from,
          strips: l.strips,
          ref: trNo,
          note: actor ? `تحويل صادر (${actor})` : 'تحويل صادر',
          date: draft.date,
          createdAt: new Date().toISOString()
        });
        return { productId: l.productId, strips: l.strips, alloc };
      });

      const tr: TransferOrder = {
        id: uid('tr'),
        no: trNo,
        date: draft.date,
        from: draft.from,
        to: draft.to,
        createdAt: new Date().toISOString(),
        createdBy: actor,
        lines
      };

      nextDb.transfers.unshift(tr);
      nextDb.meta.nextTransfer += 1;
      nextDb.meta.seq = seq;

      return { db: nextDb, result: tr, summary: `ترحيل أذن تحويل ${tr.no}` };
    }

    case 'restoreBackup': {
      const parsed = JSON.parse(action.jsonText) as AppDB;
      if (!parsed || parsed.version !== 3 || !Array.isArray(parsed.warehouses) || !Array.isArray(parsed.products)) {
        throw new Error('ملف النسخة الاحتياطية غير صالح أو لا يطابق بنية النظام');
      }
      return { db: normalizeDB(parsed), summary: 'استعادة نسخة احتياطية كاملة' };
    }

    case 'resetData': {
      return { db: normalizeDB(makeSeed()), summary: 'إعادة ضبط البيانات التجريبية' };
    }
  }
}
