import type { Product, ProductUnit, IssueLine, IssueOrder, Invoice, Partner, ReceiptType } from '../types/pharma.ts';

export const MONTHS = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
];

export const pad = (n: number | string) => String(n).padStart(2, '0');
export const pad4 = (n: number | string) => String(n).padStart(4, '0');

export function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function monthISO(): string {
  return todayISO().slice(0, 7);
}

export function shiftISO(iso: string, days: number): string {
  const d = new Date(iso + 'T12:00:00');
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function fmtDate(iso?: string | null): string {
  if (!iso) return '—';
  const parts = iso.split('-').map(Number);
  if (parts.length < 3 || parts.some(isNaN)) return iso;
  const [y, m, d] = parts;
  return `${d} ${MONTHS[(m || 1) - 1] || ''} ${y}`;
}

export function fmtMoney(n: number): string {
  const v = Math.round((Number(n) || 0) * 100) / 100;
  return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function fmtNum(n: number): string {
  return (Number(n) || 0).toLocaleString('en-US');
}

export function normalizeUnits(units?: Partial<ProductUnit>[]): ProductUnit[] {
  const list = (units && units.length ? units : [{ name: 'وحدة', factor: 1 }])
    .map(u => ({
      name: String(u.name || 'وحدة').trim() || 'وحدة',
      factor: Math.max(1, Math.round(Number(u.factor) || 1))
    }));
  list.sort((a, b) => a.factor - b.factor);
  list[0].factor = 1;
  return list;
}

export function unitLabel(p: Product): string {
  return p.units.map(u => `${u.name}=${fmtNum(u.factor)}${p.units[0].name}`).join(' · ');
}

export function unitsText(strips: number, p?: Product | null): string {
  const n = Math.max(0, Math.round(strips || 0));
  if (!p || !p.units || !p.units.length) return fmtNum(n);
  let remaining = n;
  const parts: string[] = [];
  const sorted = [...p.units].sort((a, b) => b.factor - a.factor);
  for (const u of sorted) {
    if (u.factor <= 1) {
      if (remaining > 0 || parts.length === 0) {
        parts.push(`${fmtNum(remaining)} ${u.name}`);
      }
      remaining = 0;
      break;
    }
    const q = Math.floor(remaining / u.factor);
    if (q > 0) {
      parts.push(`${fmtNum(q)} ${u.name}`);
      remaining -= q * u.factor;
    }
  }
  return parts.join(' + ');
}

export function toFullDate(s?: string | null): string {
  if (!s) return '';
  const v = String(s).trim();
  if (/^\d{4}-\d{2}$/.test(v)) {
    const [y, m] = v.split('-').map(Number);
    return `${v}-${pad(new Date(y, m, 0).getDate())}`;
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;
  const m = v.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/);
  if (m) return `${m[3]}-${pad(m[2])}-${pad(m[1])}`;
  const m2 = v.match(/^(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})$/);
  if (m2) return `${m2[1]}-${pad(m2[2])}-${pad(m2[3])}`;
  return v;
}

export function daysToExpiry(dateStr?: string | null): number {
  if (!dateStr) return 9999;
  const iso = toFullDate(dateStr);
  const [y, m, d] = iso.split('-').map(Number);
  if (!y || !m || !d) return 9999;
  const end = new Date(y, m - 1, d, 23, 59, 59);
  return Math.ceil((end.getTime() - Date.now()) / 86400000);
}

export type ExpiryState = 'ok' | 'soon' | 'expired';

export function expiryState(dateStr?: string | null): ExpiryState {
  if (!dateStr) return 'ok';
  const iso = toFullDate(dateStr);
  if (iso < todayISO()) return 'expired';
  if (daysToExpiry(iso) <= 120) return 'soon';
  return 'ok';
}

export function escHtml(s: unknown): string {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function escXml(s: unknown): string {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

let uidSeq = 0;
export function uid(prefix = 'id'): string {
  uidSeq++;
  return `${prefix}-${Date.now().toString(36)}-${uidSeq}`;
}

export function isLineReceipt(
  line: Pick<Partial<IssueLine>, 'asReceipt' | 'pricePerStrip'>,
  product?: Product | null
): boolean {
  if (line.asReceipt !== undefined) return line.asReceipt;
  if (line.pricePerStrip !== undefined && line.pricePerStrip === 0 && (product?.price || 0) > 0) {
    return true;
  }
  return Boolean(product?.marked);
}

export function getLineReceiptType(
  line: Pick<Partial<IssueLine>, 'receiptType'>,
  product?: Product | null
): ReceiptType {
  if (line.receiptType === 'supplies' || line.receiptType === 'gift') return line.receiptType;
  return product?.marked ? 'supplies' : 'gift';
}

export function receiptTypeLabel(type?: ReceiptType): string {
  return type === 'gift' ? 'إيصال هدية بدون قيمة' : 'إيصال مستلزمات';
}

export interface IssueReceiptGroup {
  type: ReceiptType;
  label: string;
  receiptNo: string;
  lines: IssueLine[];
  totalStrips: number;
}

export function getIssueReceipts(
  issue: Pick<IssueOrder, 'no' | 'receiptNo' | 'suppliesReceiptNo' | 'giftReceiptNo' | 'lines'>,
  products: Product[]
): IssueReceiptGroup[] {
  const recLines = (issue.lines || []).filter(l => isLineReceipt(l, products.find(p => p.id === l.productId)));
  if (!recLines.length) return [];

  const suppliesLines = recLines.filter(l => getLineReceiptType(l, products.find(p => p.id === l.productId)) === 'supplies');
  const giftLines = recLines.filter(l => getLineReceiptType(l, products.find(p => p.id === l.productId)) === 'gift');
  const baseNo = issue.receiptNo?.trim() || `REC-${issue.no}`;
  const hasBoth = suppliesLines.length > 0 && giftLines.length > 0;

  const groups: IssueReceiptGroup[] = [];
  if (suppliesLines.length > 0) {
    groups.push({
      type: 'supplies',
      label: receiptTypeLabel('supplies'),
      receiptNo: issue.suppliesReceiptNo?.trim() || (hasBoth ? `${baseNo}-1` : baseNo),
      lines: suppliesLines,
      totalStrips: suppliesLines.reduce((s, l) => s + l.strips, 0)
    });
  }
  if (giftLines.length > 0) {
    groups.push({
      type: 'gift',
      label: receiptTypeLabel('gift'),
      receiptNo: issue.giftReceiptNo?.trim() || (hasBoth ? `${baseNo}-2` : baseNo),
      lines: giftLines,
      totalStrips: giftLines.reduce((s, l) => s + l.strips, 0)
    });
  }
  return groups;
}

export function getIssueReceiptNo(issue: Pick<IssueOrder, 'no' | 'receiptNo'>): string {
  return issue.receiptNo?.trim() || `REC-${issue.no}`;
}

export function getIssueReceiptSummaryLabel(issue: IssueOrder, products: Product[]): string {
  const groups = getIssueReceipts(issue, products);
  if (!groups.length) return receiptTypeLabel(issue.receiptType);
  if (groups.length > 1) return '2 إيصال (مستلزمات + هدية بدون قيمة)';
  return groups[0].label;
}

export function getIssueLineSortRank(
  line: Pick<Partial<IssueLine>, 'asReceipt' | 'pricePerStrip' | 'receiptType'>,
  product?: Product | null
): number {
  if (!isLineReceipt(line, product)) return 0; // أصناف الفاتورة أولًا
  return getLineReceiptType(line, product) === 'gift' ? 2 : 1; // مستلزمات ثم إيصال هدية بدون قيمة
}

export function sortIssueLines<
  T extends Pick<Partial<IssueLine>, 'productId' | 'asReceipt' | 'pricePerStrip' | 'receiptType'>
>(lines: T[], products: Product[]): T[] {
  return [...lines].sort((a, b) => {
    const pA = products.find(x => x.id === a.productId);
    const pB = products.find(x => x.id === b.productId);
    return getIssueLineSortRank(a, pA) - getIssueLineSortRank(b, pB);
  });
}

export function isIssueInvoicedOrClosed(issue: Pick<IssueOrder, 'invoiced' | 'closed'>): boolean {
  return Boolean(issue.invoiced || issue.closed);
}

export function sortIssuesByInvoiceStatus(issues: IssueOrder[]): IssueOrder[] {
  return [...issues].sort(
    (a, b) => Number(isIssueInvoicedOrClosed(a)) - Number(isIssueInvoicedOrClosed(b))
  );
}

export interface ResolvedCustomerInfo {
  name: string;
  code: string;
  phone: string;
  address: string;
  taxNo: string;
  contact: string;
}

export function resolveIssueCustomer(
  issue: Pick<
    Partial<IssueOrder>,
    'customerId' | 'customer' | 'customerCode' | 'customerPhone' | 'customerAddress' | 'customerTaxNo' | 'customerContact'
  >,
  partners?: Partner[] | Partner
): ResolvedCustomerInfo {
  const partner = Array.isArray(partners)
    ? partners.find(p => p.id === issue.customerId) ||
      partners.find(p => p.type === 'customer' && issue.customer && p.name === issue.customer)
    : partners;

  return {
    name: issue.customer || partner?.name || 'عميل عام',
    code: issue.customerCode || partner?.code || '',
    phone: issue.customerPhone || partner?.phone || '',
    address: issue.customerAddress || partner?.address || '',
    taxNo: issue.customerTaxNo || partner?.taxNo || '',
    contact: issue.customerContact || partner?.contact || ''
  };
}

export function calcIssueValue(rec: IssueOrder, products: Product[]): number {
  return (rec.lines || []).reduce((s, l) => {
    const p = products.find(x => x.id === l.productId);
    if (!p) return s;
    const price = isLineReceipt(l, p) ? 0 : (l.pricePerStrip != null ? l.pricePerStrip : (p.price || 0));
    return s + l.strips * price;
  }, 0);
}

export function calcInvoiceValue(inv: Invoice, products: Product[]): number {
  return (inv.lines || []).reduce((s, l) => {
    const p = products.find(x => x.id === l.productId);
    if (!p) return s;
    return s + (l.strips || 0) * (p.price || 0);
  }, 0);
}

export function calc14Percent(amount: number): number {
  return Math.round((Number(amount) || 0) * 0.14 * 100) / 100;
}

export function calcTotalWith14(amount: number): number {
  const base = Math.round((Number(amount) || 0) * 100) / 100;
  return Math.round((base + calc14Percent(base)) * 100) / 100;
}

function arabicNumberBelow1000(n: number): string {
  const ones = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة'];
  const teens = [
    'عشرة', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر',
    'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر'
  ];
  const tens = ['', 'عشرة', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
  const hundreds = ['', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة'];

  const parts: string[] = [];
  const h = Math.floor(n / 100);
  const rem = n % 100;
  if (h > 0) parts.push(hundreds[h]);
  if (rem > 0) {
    if (rem < 10) {
      parts.push(ones[rem]);
    } else if (rem < 20) {
      parts.push(teens[rem - 10]);
    } else {
      const o = rem % 10;
      const t = Math.floor(rem / 10);
      if (o > 0) parts.push(`${ones[o]} و${tens[t]}`);
      else parts.push(tens[t]);
    }
  }
  return parts.join(' و');
}

function arabicIntegerToWords(num: number): string {
  const n = Math.floor(Math.max(0, num));
  if (n === 0) return 'صفر';

  const parts: string[] = [];
  const millions = Math.floor(n / 1_000_000);
  const thousands = Math.floor((n % 1_000_000) / 1000);
  const rest = n % 1000;

  if (millions > 0) {
    if (millions === 1) parts.push('مليون');
    else if (millions === 2) parts.push('مليونان');
    else if (millions >= 3 && millions <= 10) parts.push(`${arabicNumberBelow1000(millions)} ملايين`);
    else parts.push(`${arabicNumberBelow1000(millions)} مليونًا`);
  }

  if (thousands > 0) {
    if (thousands === 1) parts.push('ألف');
    else if (thousands === 2) parts.push(rest === 0 ? 'ألفا' : 'ألفان');
    else if (thousands >= 3 && thousands <= 10) parts.push(`${arabicNumberBelow1000(thousands)} آلاف`);
    else parts.push(`${arabicNumberBelow1000(thousands)} ${rest === 0 ? 'ألف' : 'ألفًا'}`);
  }

  if (rest > 0) {
    parts.push(arabicNumberBelow1000(rest));
  }

  return parts.join(' و');
}

function formatPoundUnit(n: number): string {
  if (n === 0) return 'صفر جنيهًا';
  if (n === 1) return 'جنيه واحد';
  if (n === 2) return 'جنيهان';
  const last2 = n % 100;
  const words = arabicIntegerToWords(n);
  if (last2 >= 3 && last2 <= 10) return `${words} جنيهات`;
  if (last2 >= 11) return `${words} جنيهًا`;
  return `${words} جنيه`;
}

function formatPiasterUnit(n: number): string {
  if (n === 1) return 'قرش واحد';
  if (n === 2) return 'قرشان';
  const words = arabicIntegerToWords(n);
  if (n >= 3 && n <= 10) return `${words} قروش`;
  return `${words} قرشًا`;
}

export function tafqeetEGP(amount: number): string {
  const totalPiasters = Math.round(Math.max(0, Number(amount) || 0) * 100);
  const pounds = Math.floor(totalPiasters / 100);
  const piasters = totalPiasters % 100;

  if (pounds === 0 && piasters === 0) {
    return 'فقط صفر جنيهًا فقط لا غير';
  }
  if (pounds > 0 && piasters === 0) {
    return `فقط ${formatPoundUnit(pounds)} فقط لا غير`;
  }
  if (pounds === 0 && piasters > 0) {
    return `فقط ${formatPiasterUnit(piasters)} فقط لا غير`;
  }
  return `فقط ${formatPoundUnit(pounds)} و${formatPiasterUnit(piasters)} فقط لا غير`;
}
